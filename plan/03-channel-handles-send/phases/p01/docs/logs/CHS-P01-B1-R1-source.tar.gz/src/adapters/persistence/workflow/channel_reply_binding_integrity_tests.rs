use super::*;
use crate::entities::correlation::CorrelationId;

#[tokio::test]
async fn channel_reply_binding_competing_ingress_claimants_create_one_owned_run() {
    let s = Intents::new().await;
    let binding = s.binding(MessageTrigger::Any, None).await;
    select(&s, binding).await;
    let intent = s.intent(TO).await;
    let service = s.admissions(admission(s.p()));
    let (first, second) = tokio::join!(
        service.claim(MessageIntentWorkerId(Uuid::new_v4()), 1),
        service.claim(MessageIntentWorkerId(Uuid::new_v4()), 1)
    );
    let claimed: Vec<_> = first.unwrap().into_iter().chain(second.unwrap()).collect();
    assert_eq!(claimed.len(), 1);
    service
        .process(claimed.into_iter().next().unwrap())
        .await
        .unwrap();
    assert_eq!(shape(&s, intent).await, (1, 1));
    assert_eq!(s.runs(binding).await.len(), 1);
}

#[tokio::test]
async fn channel_reply_binding_thread_scoped_binding_cannot_own_channel_responses() {
    let s = Intents::new().await;
    let target = s.target(s.owner(), WorkflowBindingId::new(Uuid::new_v4()));
    let mut request = s.configuration(target, None, None, Some(MessageTrigger::Any));
    request.association = RelatedAssociation::Thread {
        channel_id: RelatedChannelId::new(s.channel),
        thread_id: RelatedThreadId::new(s.thread),
    };
    let state = s.bindings().configure(request).await.unwrap();
    s.bindings()
        .activate(SetBindingActivity {
            target,
            expected: state.revision,
        })
        .await
        .unwrap();
    assert!(
        s.p()
            .configure_channel_reply(selection(&s, target.binding, None).await)
            .await
            .is_err()
    );
}

#[tokio::test]
async fn channel_reply_binding_manual_root_has_no_automatic_response_authority() {
    let s = Intents::new().await;
    let binding = s.binding(MessageTrigger::Any, None).await;
    select(&s, binding).await;
    let intent = s.intent(TO).await;
    let request = AdmitWorkflowRequest {
        company_id: s.fixture.target.company,
        actor: s.owner(),
        association: RelatedAssociation::Thread {
            channel_id: RelatedChannelId::new(s.channel),
            thread_id: RelatedThreadId::new(s.thread),
        },
        trigger: TriggerRef::new(
            s.fixture.target.company,
            TriggerId::new(Uuid::new_v4()),
            TriggerSource::Manual,
        )
        .unwrap(),
        correlation_id: CorrelationId::new(),
        binding_id: binding,
        idempotency_key: IdempotencyKey::parse("manual-with-selected-channel").unwrap(),
        input: json!({}),
        rerun_of: None,
        delivery_policy: DeliveryPolicy::InAppOnly,
        expected_binding_revision: None,
        admission_claim: None,
    };
    let AdmissionResult::Created(run) = admission(s.p()).admit(request).await.unwrap() else {
        panic!("manual root");
    };
    assert_eq!(shape(&s, intent).await, (1, 0));
    let links: i64 = sqlx::query_scalar("SELECT count(*) FROM channel_reply_runs WHERE run_id=$1")
        .bind(run.as_uuid())
        .fetch_one(s.pool())
        .await
        .unwrap();
    assert_eq!(links, 0);
}

#[tokio::test]
async fn channel_reply_binding_context_insert_and_source_acceptance_roll_back_together() {
    let s = Intents::new().await;
    let binding = s.binding(MessageTrigger::Any, None).await;
    select(&s, binding).await;
    let message = s.message().await;
    let intent = Uuid::new_v4();
    let mut tx = s.pool().begin().await.unwrap();
    sqlx::query(
        "INSERT INTO workflow_message_intents(company_id,id,message_id,channel_id,thread_id,role,\
        mentioned,admissible,origin,hop_count,trace_channels,delivery_policy,correlation_id) \
        VALUES($1,$2,$3,$4,$5,'to',false,true,'external',0,'{}','deliver',$2)",
    )
    .bind(s.fixture.target.company.as_uuid())
    .bind(intent)
    .bind(message.as_uuid())
    .bind(s.channel)
    .bind(s.thread)
    .execute(&mut *tx)
    .await
    .unwrap();
    let count: i64 =
        sqlx::query_scalar("SELECT count(*) FROM channel_reply_contexts WHERE intent_id=$1")
            .bind(intent)
            .fetch_one(&mut *tx)
            .await
            .unwrap();
    assert_eq!(count, 1);
    tx.rollback().await.unwrap();
    assert_eq!(shape(&s, intent).await, (0, 0));
}

#[tokio::test]
async fn channel_reply_binding_observer_run_cannot_replace_response_owner() {
    let s = Intents::new().await;
    let owner = s.binding(MessageTrigger::Any, None).await;
    let observer = s.binding(MessageTrigger::Any, None).await;
    select(&s, owner).await;
    let intent = s.intent(TO).await;
    s.drain(&s.admissions(admission(s.p()))).await;
    let observer_run = s.runs(observer).await[0];
    let mut tx = s.pool().begin().await.unwrap();
    let refused = sqlx::query(
        "INSERT INTO channel_reply_runs(company_id,intent_id,run_id,binding_id,binding_revision) \
        VALUES($1,$2,$3,$4,1)",
    )
    .bind(s.fixture.target.company.as_uuid())
    .bind(intent)
    .bind(observer_run)
    .bind(owner.as_uuid())
    .execute(&mut *tx)
    .await
    .unwrap_err();
    assert_eq!(
        refused.as_database_error().unwrap().code().as_deref(),
        Some("23514")
    );
    tx.rollback().await.unwrap();
    assert_eq!(shape(&s, intent).await, (1, 1));
}
