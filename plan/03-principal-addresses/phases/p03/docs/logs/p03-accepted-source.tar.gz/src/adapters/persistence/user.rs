use async_trait::async_trait;
use chrono::{DateTime, Utc};
use serde::Serialize;
use uuid::Uuid;

use crate::{
    adapters::persistence::{PostgresPersistence, account_identity::rekey_account_identity_on},
    app_error::{AppError, AppResult},
    entities::{
        address::PersonAddress,
        notification::NotificationPreferences,
        user::User,
        value_objects::{AvatarUrl, ChannelSlug, CompanySlug, EmailAddress},
    },
    use_cases::user::{
        AccountChange, AccountChangeKind, AccountChangePersistence, AuthAttemptKey,
        ExternalIdentity, LoginMethod, PendingAccountChange, PendingChange, PendingRegistration,
        ProfileUpdate, RegistrationPersistence, UserPersistence,
    },
};

use super::auth_attempts;

// User struct as stored in the db.
#[derive(sqlx::FromRow, Debug, Serialize)]
pub struct UserDb {
    pub id: Uuid,
    pub auth_revision: i64,
    pub username: String,
    pub email: String,
    pub email_verified_at: Option<DateTime<Utc>>,
    pub password_hash: Option<String>,
    pub avatar_url: Option<String>,
    pub created_at: DateTime<Utc>,
}

#[derive(sqlx::FromRow)]
struct NotificationPreferencesDb {
    delivery_failure_email_enabled: bool,
    decision_email_enabled: bool,
}

#[async_trait]
impl RegistrationPersistence for PostgresPersistence {
    async fn save_pending_registration(&self, pending: PendingRegistration<'_>) -> AppResult<()> {
        auth_attempts::cleanup_pending_registrations(&self.pool).await?;
        sqlx::query(
            r#"INSERT INTO pending_user_registrations
                   (email, username, password_hash, confirmation_code_hash, expires_at)
               VALUES ($1, $2, $3, $4, $5)
               ON CONFLICT (email) DO UPDATE SET
                   username = EXCLUDED.username,
                   password_hash = EXCLUDED.password_hash,
                   confirmation_code_hash = EXCLUDED.confirmation_code_hash,
                   expires_at = EXCLUDED.expires_at,
                   created_at = CURRENT_TIMESTAMP"#,
        )
        .bind(pending.email.as_str())
        .bind(pending.username)
        .bind(pending.password_hash)
        .bind(pending.confirmation_code_hash)
        .bind(pending.expires_at)
        .execute(&self.pool)
        .await
        .map_err(AppError::from)?;
        Ok(())
    }

    async fn confirm_pending_registration(
        &self,
        email: &crate::entities::value_objects::EmailAddress,
        confirmation_code_hash: &str,
        attempt_key: &AuthAttemptKey,
    ) -> AppResult<Option<User>> {
        auth_attempts::cleanup_code_attempts(&self.pool).await?;
        let mut transaction = self.pool.begin().await.map_err(AppError::from)?;
        if !auth_attempts::reserve_code_attempt(&mut transaction, attempt_key).await? {
            transaction.commit().await.map_err(AppError::from)?;
            return Ok(None);
        }
        let pending = sqlx::query_as::<_, (String, String, String)>(
            r#"SELECT username::text, password_hash, confirmation_code_hash
               FROM pending_user_registrations
               WHERE email = $1::citext AND expires_at > CURRENT_TIMESTAMP
               FOR UPDATE"#,
        )
        .bind(email.as_str())
        .fetch_optional(&mut *transaction)
        .await
        .map_err(AppError::from)?;
        let Some((username, password_hash, stored_hash)) = pending else {
            transaction.commit().await.map_err(AppError::from)?;
            return Ok(None);
        };
        if stored_hash != confirmation_code_hash {
            transaction.commit().await.map_err(AppError::from)?;
            return Ok(None);
        }

        sqlx::query("DELETE FROM pending_user_registrations WHERE email = $1::citext")
            .bind(email.as_str())
            .execute(&mut *transaction)
            .await
            .map_err(AppError::from)?;
        let user = sqlx::query_as::<_, UserDb>(
            r#"INSERT INTO users (id, username, email, password_hash, email_verified_at)
               VALUES ($1, $2, $3, $4, CURRENT_TIMESTAMP)
               RETURNING id, username, email, password_hash, avatar_url, email_verified_at, auth_revision, created_at"#,
        )
        .bind(Uuid::new_v4())
        .bind(username)
        .bind(email.as_str())
        .bind(password_hash)
        .fetch_one(&mut *transaction)
        .await
        .map_err(AppError::from)?;

        sqlx::query("INSERT INTO user_login_methods (user_id, provider) VALUES ($1, 'password')")
            .bind(user.id)
            .execute(&mut *transaction)
            .await
            .map_err(AppError::from)?;
        auth_attempts::clear_code_attempt(&mut transaction, attempt_key).await?;
        transaction.commit().await.map_err(AppError::from)?;
        Ok(Some(user.into()))
    }
}

impl From<UserDb> for User {
    fn from(user_db: UserDb) -> Self {
        User {
            auth_revision: user_db.auth_revision,
            id: user_db.id,
            username: user_db.username,
            email: user_db.email,
            email_verified_at: user_db.email_verified_at,
            password_hash: user_db.password_hash,
            avatar_url: user_db.avatar_url.map(AvatarUrl::from),
            created_at: user_db.created_at,
        }
    }
}

#[async_trait]
impl UserPersistence for PostgresPersistence {
    async fn canonical_auth_identifier(&self, value: &str) -> AppResult<String> {
        sqlx::query_scalar("SELECT lower($1::citext)::text")
            .bind(value)
            .fetch_one(&self.pool)
            .await
            .map_err(AppError::from)
    }

    async fn reserve_login_attempt(&self, key: &AuthAttemptKey) -> AppResult<bool> {
        auth_attempts::reserve_login_attempt(&self.pool, key).await
    }

    async fn clear_login_attempt(&self, key: &AuthAttemptKey) -> AppResult<()> {
        auth_attempts::clear_login_attempt(&self.pool, key).await
    }

    async fn create_user(
        &self,
        username: &str,
        email: &str,
        password_hash: &str,
    ) -> AppResult<User> {
        let uuid = Uuid::new_v4();

        let mut transaction = self.pool.begin().await.map_err(AppError::from)?;
        let db = sqlx::query_as::<_, UserDb>(
            r#"INSERT INTO users (id, username, email, password_hash)
               VALUES ($1, $2, $3, $4)
               RETURNING id, username, email, password_hash, avatar_url, email_verified_at, auth_revision, created_at"#,
        )
        .bind(uuid)
        .bind(username)
        .bind(email)
        .bind(password_hash)
        .fetch_one(&mut *transaction)
        .await
        .map_err(AppError::from)?;

        sqlx::query("INSERT INTO user_login_methods (user_id, provider) VALUES ($1, 'password')")
            .bind(uuid)
            .execute(&mut *transaction)
            .await
            .map_err(AppError::from)?;
        transaction.commit().await.map_err(AppError::from)?;

        Ok(db.into())
    }

    async fn person_addresses(&self, user_id: Uuid) -> AppResult<Vec<PersonAddress>> {
        let rows: Vec<(Uuid, String, String, String)> = sqlx::query_as(
            "SELECT company.id, company.name, company.slug::text, address.slug::text \
               FROM principals AS principal \
               JOIN addresses AS address ON address.company_id = principal.company_id \
                AND address.principal_id = principal.id \
               JOIN companies AS company ON company.id = principal.company_id \
              WHERE principal.user_id = $1 AND principal.kind = 'person' \
              ORDER BY company.name, company.id",
        )
        .bind(user_id)
        .fetch_all(&self.pool)
        .await
        .map_err(AppError::from)?;
        Ok(rows.into_iter().map(person_address).collect())
    }

    async fn rename_person_address(
        &self,
        user_id: Uuid,
        company_id: Uuid,
        slug: &ChannelSlug,
    ) -> AppResult<Option<PersonAddress>> {
        let mut transaction = self.pool.begin().await?;
        sqlx::query("SET LOCAL lock_timeout = '5s'")
            .execute(&mut *transaction)
            .await?;
        // The address trigger advances its principal's routing revision. Lock that principal
        // before the address, matching removal and avoiding an address/principal lock cycle.
        let principal: Option<Uuid> = sqlx::query_scalar(
            "SELECT id FROM principals WHERE company_id = $1 AND user_id = $2 \
             AND kind = 'person' FOR UPDATE",
        )
        .bind(company_id)
        .bind(user_id)
        .fetch_optional(&mut *transaction)
        .await?;
        let Some(principal) = principal else {
            transaction.commit().await?;
            return Ok(None);
        };
        let row: Option<(Uuid, String, String, String)> = sqlx::query_as(
            "UPDATE addresses AS address SET slug = $3 \
               FROM principals AS principal, companies AS company \
              WHERE principal.company_id = $2 AND principal.user_id = $1 \
                AND principal.kind = 'person' \
                AND address.company_id = principal.company_id \
                AND address.principal_id = principal.id \
                AND company.id = principal.company_id \
          RETURNING company.id, company.name, company.slug::text, address.slug::text",
        )
        .bind(user_id)
        .bind(company_id)
        .bind(slug.as_str())
        .fetch_optional(&mut *transaction)
        .await
        .map_err(|error| match &error {
            sqlx::Error::Database(database) if database.code().as_deref() == Some("23505") => {
                AppError::Conflict(format!(
                    "Address '{slug}' is already in use in this company."
                ))
            }
            _ => AppError::from(error),
        })?;
        if row.is_some() {
            super::integration::email_binding::sync_principal_email_binding_on(
                &mut transaction,
                company_id,
                crate::entities::transport::PrincipalId::new(principal),
            )
            .await?;
        }
        transaction.commit().await?;
        Ok(row.map(person_address))
    }

    async fn notification_preferences(&self, id: Uuid) -> AppResult<NotificationPreferences> {
        let row = sqlx::query_as::<_, NotificationPreferencesDb>(
            r#"SELECT
                   COALESCE(preference.delivery_failure_email_enabled, TRUE)
                       AS delivery_failure_email_enabled,
                   COALESCE(preference.decision_email_enabled, TRUE)
                       AS decision_email_enabled
               FROM users AS account
               LEFT JOIN user_notification_preferences AS preference
                 ON preference.user_id = account.id
               WHERE account.id = $1"#,
        )
        .bind(id)
        .fetch_one(&self.pool)
        .await
        .map_err(AppError::from)?;
        Ok(NotificationPreferences {
            delivery_failure_email_enabled: row.delivery_failure_email_enabled,
            decision_email_enabled: row.decision_email_enabled,
        })
    }

    async fn set_notification_preferences(
        &self,
        id: Uuid,
        preferences: NotificationPreferences,
    ) -> AppResult<()> {
        let mut transaction = self.pool.begin().await.map_err(AppError::from)?;
        let account: Option<Uuid> =
            sqlx::query_scalar("SELECT id FROM users AS account WHERE account.id = $1 FOR UPDATE")
                .bind(id)
                .fetch_optional(&mut *transaction)
                .await
                .map_err(AppError::from)?;
        if account.is_none() {
            return Err(AppError::NotFound("User not found".into()));
        }
        let result = sqlx::query(
            r#"INSERT INTO user_notification_preferences (
                   user_id, delivery_failure_email_enabled, decision_email_enabled, updated_at
               ) VALUES ($1, $2, $3, CURRENT_TIMESTAMP)
               ON CONFLICT (user_id) DO UPDATE
               SET delivery_failure_email_enabled = EXCLUDED.delivery_failure_email_enabled,
                   decision_email_enabled = EXCLUDED.decision_email_enabled,
                   updated_at = CURRENT_TIMESTAMP"#,
        )
        .bind(id)
        .bind(preferences.delivery_failure_email_enabled)
        .bind(preferences.decision_email_enabled)
        .execute(&mut *transaction)
        .await
        .map_err(AppError::from)?;
        if result.rows_affected() == 0 {
            return Err(AppError::NotFound("User not found".into()));
        }
        transaction.commit().await.map_err(AppError::from)?;
        Ok(())
    }

    async fn get_by_email(&self, email: &str) -> AppResult<Option<User>> {
        let result = sqlx::query_as!(
            UserDb,
            r#"SELECT id, username, email, password_hash, avatar_url, email_verified_at, auth_revision, created_at as "created_at!" FROM users WHERE email = $1::citext"#,
            email
        )
        .fetch_optional(&self.pool)
        .await
        .map_err(AppError::from)?;

        Ok(result.map(Into::into))
    }

    async fn get_by_username(&self, username: &str) -> AppResult<Option<User>> {
        let result = sqlx::query_as!(
            UserDb,
            r#"SELECT id, username, email, password_hash, avatar_url, email_verified_at, auth_revision, created_at as "created_at!" FROM users WHERE username = $1::citext"#,
            username
        )
        .fetch_optional(&self.pool)
        .await
        .map_err(AppError::from)?;

        Ok(result.map(Into::into))
    }

    async fn get_by_id(&self, id: Uuid) -> AppResult<Option<User>> {
        let result = sqlx::query_as!(
            UserDb,
            r#"SELECT id, username, email, password_hash, avatar_url, email_verified_at, auth_revision, created_at as "created_at!" FROM users WHERE id = $1"#,
            id
        )
        .fetch_optional(&self.pool)
        .await
        .map_err(AppError::from)?;

        Ok(result.map(Into::into))
    }

    async fn update_avatar_url(
        &self,
        id: Uuid,
        avatar_url: Option<&AvatarUrl>,
    ) -> AppResult<Option<User>> {
        let result = sqlx::query_as!(
            UserDb,
            r#"UPDATE users SET avatar_url = $2 WHERE id = $1
               RETURNING id, username, email, password_hash, avatar_url, email_verified_at, auth_revision, created_at as "created_at!""#,
            id,
            avatar_url.map(AvatarUrl::as_str)
        )
        .fetch_optional(&self.pool)
        .await
        .map_err(AppError::from)?;

        Ok(result.map(Into::into))
    }

    /// Writes the profile, address included, without proving the address first (the unverified
    /// bypass). A changed address re-keys the account's identity in every company in the same
    /// transaction, exactly as a confirmed change does.
    async fn update_profile(
        &self,
        id: Uuid,
        profile: ProfileUpdate<'_>,
    ) -> AppResult<Option<User>> {
        let mut transaction = self.pool.begin().await.map_err(AppError::from)?;
        let Some(previous_email) = locked_account_email(&mut transaction, id).await? else {
            return Ok(None);
        };
        let result = sqlx::query_as!(
            UserDb,
            r#"UPDATE users
               SET username = $2, email = $3, avatar_url = $4,
                   email_verified_at = CASE WHEN email IS DISTINCT FROM $3::citext
                                            THEN NULL ELSE email_verified_at END
               WHERE id = $1
               RETURNING id, username, email, password_hash, avatar_url, email_verified_at, auth_revision, created_at as "created_at!""#,
            id,
            profile.username,
            profile.email.as_str(),
            profile.avatar_url.map(AvatarUrl::as_str)
        )
        .fetch_optional(&mut *transaction)
        .await
        .map_err(|err| taken_identity_error(err, &profile))?;
        if let Some(updated) = &result {
            rekey_account_identity_on(&mut transaction, id, &previous_email, &updated.email)
                .await?;
        }
        transaction.commit().await.map_err(AppError::from)?;

        Ok(result.map(Into::into))
    }

    async fn update_profile_display(
        &self,
        id: Uuid,
        username: &str,
        avatar_url: Option<&AvatarUrl>,
    ) -> AppResult<Option<User>> {
        let result = sqlx::query_as!(
            UserDb,
            r#"UPDATE users SET username = $2, avatar_url = $3 WHERE id = $1
               RETURNING id, username, email, password_hash, avatar_url, email_verified_at, auth_revision, created_at as "created_at!""#,
            id,
            username,
            avatar_url.map(AvatarUrl::as_str)
        )
        .fetch_optional(&self.pool)
        .await
        .map_err(AppError::from)?;
        Ok(result.map(Into::into))
    }

    async fn update_password_hash(&self, id: Uuid, password_hash: &str) -> AppResult<Option<User>> {
        let result = sqlx::query_as!(
            UserDb,
            r#"UPDATE users SET password_hash = $2 WHERE id = $1
               RETURNING id, username, email, password_hash, avatar_url, email_verified_at, auth_revision, created_at as "created_at!""#,
            id,
            password_hash
        )
        .fetch_optional(&self.pool)
        .await
        .map_err(AppError::from)?;

        Ok(result.map(Into::into))
    }

    async fn activate_password(&self, id: Uuid, password_hash: &str) -> AppResult<Option<User>> {
        let mut transaction = self.pool.begin().await.map_err(AppError::from)?;
        let result = sqlx::query_as::<_, UserDb>(
            r#"UPDATE users SET password_hash = $2 WHERE id = $1
               RETURNING id, username, email, password_hash, avatar_url, email_verified_at, auth_revision, created_at"#,
        )
        .bind(id)
        .bind(password_hash)
        .fetch_optional(&mut *transaction)
        .await
        .map_err(AppError::from)?;
        if result.is_some() {
            sqlx::query(
                "INSERT INTO user_login_methods (user_id, provider) VALUES ($1, 'password') ON CONFLICT (user_id, provider) DO NOTHING",
            )
            .bind(id)
            .execute(&mut *transaction)
            .await
            .map_err(AppError::from)?;
        }
        transaction.commit().await.map_err(AppError::from)?;
        Ok(result.map(Into::into))
    }

    async fn has_login_method(&self, id: Uuid, method: LoginMethod) -> AppResult<bool> {
        sqlx::query_scalar::<_, bool>(
            "SELECT EXISTS(SELECT 1 FROM user_login_methods WHERE user_id = $1 AND provider = $2)",
        )
        .bind(id)
        .bind(method.as_str())
        .fetch_one(&self.pool)
        .await
        .map_err(AppError::from)
    }

    async fn create_external_user(&self, identity: ExternalIdentity<'_>) -> AppResult<User> {
        if identity.provider == LoginMethod::Password || !identity.email_verified {
            return Err(AppError::BadRequest(
                "An external account requires a verified provider email claim.".into(),
            ));
        }
        let id = Uuid::new_v4();
        let base = external_username(identity.display_name, identity.email.as_str());
        let username = format!("{}-{}", base, &id.simple().to_string()[..8]);
        let mut transaction = self.pool.begin().await.map_err(AppError::from)?;
        let user = sqlx::query_as::<_, UserDb>(
            r#"INSERT INTO users (id, username, email, password_hash, email_verified_at)
               VALUES ($1, $2, $3, NULL, CURRENT_TIMESTAMP)
               RETURNING id, username, email, password_hash, avatar_url, email_verified_at, auth_revision, created_at"#,
        )
        .bind(id)
        .bind(username)
        .bind(identity.email.as_str())
        .fetch_one(&mut *transaction)
        .await
        .map_err(external_account_conflict)?;
        sqlx::query(
            "INSERT INTO user_login_methods (user_id, provider, provider_subject) VALUES ($1, $2, $3)",
        )
        .bind(id)
        .bind(identity.provider.as_str())
        .bind(identity.subject)
        .execute(&mut *transaction)
        .await
        .map_err(external_identity_conflict)?;
        transaction.commit().await.map_err(AppError::from)?;
        Ok(user.into())
    }

    async fn get_by_external_subject(
        &self,
        provider: LoginMethod,
        subject: &str,
    ) -> AppResult<Option<User>> {
        sqlx::query_as::<_, UserDb>(
            r#"SELECT users.id, users.username, users.email, users.password_hash,
                      users.avatar_url, users.email_verified_at, users.auth_revision, users.created_at
               FROM users
               JOIN user_login_methods methods ON methods.user_id = users.id
               WHERE methods.provider = $1 AND methods.provider_subject = $2"#,
        )
        .bind(provider.as_str())
        .bind(subject)
        .fetch_optional(&self.pool)
        .await
        .map(|user| user.map(Into::into))
        .map_err(AppError::from)
    }

    async fn login_external_identity(
        &self,
        identity: ExternalIdentity<'_>,
    ) -> AppResult<Option<User>> {
        if identity.provider == LoginMethod::Password || !identity.email_verified {
            return Err(AppError::BadRequest(
                "An external login requires a verified provider email claim.".into(),
            ));
        }
        let mut transaction = self.pool.begin().await.map_err(AppError::from)?;
        // The row lock from UPDATE serializes with an address change. The provider's proof
        // installs a marker only while it names the address currently stored on this row.
        let user = sqlx::query_as::<_, UserDb>(
            r#"UPDATE users AS account
               SET email_verified_at = CASE
                   WHEN account.email = $3::citext THEN COALESCE(account.email_verified_at, CURRENT_TIMESTAMP)
                   ELSE account.email_verified_at END
               FROM user_login_methods AS method
               WHERE method.user_id = account.id AND method.provider = $1 AND method.provider_subject = $2
               RETURNING account.id, account.username, account.email, account.password_hash,
                         account.avatar_url, account.email_verified_at, account.auth_revision, account.created_at"#,
        )
        .bind(identity.provider.as_str())
        .bind(identity.subject)
        .bind(identity.email.as_str())
        .fetch_optional(&mut *transaction)
        .await
        .map_err(AppError::from)?;
        if let Some(user) = &user {
            let companies =
                super::workflow::prelock_account_companies_on(&mut transaction, user.id).await?;
            Box::pin(super::workflow::refresh_account_dependents_on(
                &mut transaction,
                &companies,
            ))
            .await?;
        }
        transaction.commit().await.map_err(AppError::from)?;
        Ok(user.map(Into::into))
    }

    async fn link_external_identity(
        &self,
        user_id: Uuid,
        identity: ExternalIdentity<'_>,
    ) -> AppResult<()> {
        if identity.provider == LoginMethod::Password || !identity.email_verified {
            return Err(AppError::BadRequest(
                "An external link requires a verified provider email claim.".into(),
            ));
        }
        let mut transaction = self.pool.begin().await.map_err(AppError::from)?;
        // Take the exclusive account owner before the login-method FK's key-share lock,
        // so competing links cannot each hold a weaker account lock and then upgrade it.
        sqlx::query("SELECT id FROM users WHERE id=$1 FOR UPDATE")
            .bind(user_id)
            .execute(&mut *transaction)
            .await
            .map_err(AppError::from)?;
        sqlx::query(
            "INSERT INTO user_login_methods (user_id, provider, provider_subject) VALUES ($1, $2, $3)",
        )
        .bind(user_id)
        .bind(identity.provider.as_str())
        .bind(identity.subject)
        .execute(&mut *transaction)
        .await
        .map_err(external_identity_conflict)?;
        let updated = sqlx::query(
            "UPDATE users SET email_verified_at = COALESCE(email_verified_at, CURRENT_TIMESTAMP) WHERE id = $1 AND email = $2::citext",
        )
        .bind(user_id)
        .bind(identity.email.as_str())
        .execute(&mut *transaction)
        .await
        .map_err(AppError::from)?;
        if updated.rows_affected() != 1 {
            return Err(AppError::Conflict(
                "The verified provider email no longer matches this account.".into(),
            ));
        }
        let companies =
            super::workflow::prelock_account_companies_on(&mut transaction, user_id).await?;
        Box::pin(super::workflow::refresh_account_dependents_on(
            &mut transaction,
            &companies,
        ))
        .await?;
        transaction.commit().await.map_err(AppError::from)?;
        Ok(())
    }
}

fn external_username(display_name: Option<&str>, email: &str) -> String {
    let source = display_name
        .filter(|name| !name.trim().is_empty())
        .unwrap_or_else(|| email.split('@').next().unwrap_or("user"));
    let normalized: String = source
        .chars()
        .filter_map(|character| {
            if character.is_ascii_alphanumeric() {
                Some(character.to_ascii_lowercase())
            } else if character == ' ' || character == '-' || character == '_' {
                Some('-')
            } else {
                None
            }
        })
        .take(40)
        .collect();
    let name = normalized.trim_matches('-');
    if name.is_empty() {
        "user".to_string()
    } else {
        name.to_string()
    }
}

fn external_identity_conflict(err: sqlx::Error) -> AppError {
    if is_unique_violation(&err) {
        AppError::Conflict("That login method is already connected.".into())
    } else {
        AppError::from(err)
    }
}

fn external_account_conflict(err: sqlx::Error) -> AppError {
    if is_unique_violation(&err) {
        AppError::BadRequest("An account with that email already exists.".into())
    } else {
        AppError::from(err)
    }
}

/// A username or address somebody else already holds is routine user input, not a database fault,
/// so it surfaces as a bad request naming the field that clashed rather than a raw driver message.
///
/// Which of the two clashed comes from the constraint the row violated, because the statement
/// writes both at once and the message has to point at the field the reader must change.
fn taken_identity_error(err: sqlx::Error, profile: &ProfileUpdate<'_>) -> AppError {
    if !is_unique_violation(&err) {
        return AppError::from(err);
    }
    let sqlx::Error::Database(ref db_err) = err else {
        return AppError::from(err);
    };

    match db_err.constraint() {
        Some("users_username_key") => AppError::BadRequest(format!(
            "The username '{}' is already taken.",
            profile.username
        )),
        Some("users_email_key") => AppError::BadRequest(format!(
            "An account already uses the address '{}'.",
            profile.email
        )),
        _ => AppError::BadRequest("That username or email is already taken.".into()),
    }
}

/// Whether the driver is reporting a duplicate key rather than a fault. Both places that turn one
/// into a readable refusal ask this, so the code lives in one place.
fn is_unique_violation(err: &sqlx::Error) -> bool {
    matches!(err, sqlx::Error::Database(db_err) if db_err.code().as_deref() == Some("23505"))
}

/// One row of `pending_account_changes`, before its `kind` and payload are folded into the
/// [`PendingChange`] the domain speaks in.
#[derive(sqlx::FromRow, Debug)]
struct PendingAccountChangeDb {
    kind: String,
    new_email: Option<String>,
    expires_at: DateTime<Utc>,
}

impl PendingAccountChangeDb {
    /// The row as the domain reads it. `None` for a row whose `kind` is not one this build knows
    /// -- the schema's CHECK should make that unreachable, and a row from the future is better
    /// skipped than guessed at.
    fn into_pending(self) -> Option<PendingChange> {
        match AccountChangeKind::parse(&self.kind)? {
            AccountChangeKind::Email => Some(PendingChange::Email {
                new_email: EmailAddress::from(self.new_email?),
                expires_at: self.expires_at,
            }),
            AccountChangeKind::Password => Some(PendingChange::Password {
                expires_at: self.expires_at,
            }),
        }
    }
}

#[async_trait]
impl AccountChangePersistence for PostgresPersistence {
    async fn save_pending_account_change(
        &self,
        pending: PendingAccountChange<'_>,
    ) -> AppResult<()> {
        auth_attempts::cleanup_pending_account_changes(&self.pool).await?;
        // Split here rather than in the SQL: the columns a kind may fill are the one thing the
        // table's CHECK constraint enforces, and the enum is what makes filling the wrong one
        // impossible to write in the first place.
        let (new_email, new_password_hash) = match &pending.change {
            AccountChange::Email(email) => (Some(email.as_str()), None),
            AccountChange::Password(hash) => (None, Some(*hash)),
        };

        sqlx::query!(
            r#"INSERT INTO pending_account_changes
                   (user_id, kind, new_email, new_password_hash, confirmation_code_hash, expires_at)
               VALUES ($1, $2, $3, $4, $5, $6)
               ON CONFLICT (user_id, kind) DO UPDATE SET
                   new_email = EXCLUDED.new_email,
                   new_password_hash = EXCLUDED.new_password_hash,
                   confirmation_code_hash = EXCLUDED.confirmation_code_hash,
                   expires_at = EXCLUDED.expires_at,
                   created_at = CURRENT_TIMESTAMP"#,
            pending.user_id,
            pending.change.kind().as_str(),
            new_email,
            new_password_hash,
            pending.confirmation_code_hash,
            pending.expires_at,
        )
        .execute(&self.pool)
        .await
        .map_err(AppError::from)?;

        Ok(())
    }

    async fn confirm_pending_account_change(
        &self,
        user_id: Uuid,
        kind: AccountChangeKind,
        confirmation_code_hash: &str,
        attempt_key: &AuthAttemptKey,
    ) -> AppResult<Option<User>> {
        auth_attempts::cleanup_code_attempts(&self.pool).await?;
        let mut transaction = self.pool.begin().await.map_err(AppError::from)?;

        if !auth_attempts::reserve_code_attempt(&mut transaction, attempt_key).await? {
            transaction.commit().await.map_err(AppError::from)?;
            return Ok(None);
        }
        let stored_hash = sqlx::query_scalar::<_, String>(
            r#"SELECT confirmation_code_hash FROM pending_account_changes
               WHERE user_id = $1 AND kind = $2 AND expires_at > CURRENT_TIMESTAMP
               FOR UPDATE"#,
        )
        .bind(user_id)
        .bind(kind.as_str())
        .fetch_optional(&mut *transaction)
        .await
        .map_err(AppError::from)?;
        if stored_hash.as_deref() != Some(confirmation_code_hash) {
            transaction.commit().await.map_err(AppError::from)?;
            return Ok(None);
        }

        // The locked row is deleted in the same transaction as the account mutation. A second
        // claimant waits, then sees no row to spend.
        let claimed = sqlx::query!(
            r#"DELETE FROM pending_account_changes
               WHERE user_id = $1
                 AND kind = $2
                 AND confirmation_code_hash = $3
                 AND expires_at > CURRENT_TIMESTAMP
               RETURNING new_email, new_password_hash"#,
            user_id,
            kind.as_str(),
            confirmation_code_hash,
        )
        .fetch_optional(&mut *transaction)
        .await
        .map_err(AppError::from)?;

        let Some(claimed) = claimed else {
            transaction.commit().await.map_err(AppError::from)?;
            return Ok(None);
        };

        let updated = match kind {
            AccountChangeKind::Email => {
                let Some(previous_email) = locked_account_email(&mut transaction, user_id).await?
                else {
                    transaction.commit().await.map_err(AppError::from)?;
                    return Ok(None);
                };
                let updated = sqlx::query_as!(
                    UserDb,
                    r#"UPDATE users SET email = $2, email_verified_at = CURRENT_TIMESTAMP WHERE id = $1
                       RETURNING id, username, email, password_hash, avatar_url, email_verified_at, auth_revision, created_at as "created_at!""#,
                    user_id,
                    claimed.new_email,
                )
                .fetch_optional(&mut *transaction)
                .await
                .map_err(|err| taken_address_error(err, claimed.new_email.as_deref()))?;
                if let Some(updated) = &updated {
                    rekey_account_identity_on(
                        &mut transaction,
                        user_id,
                        &previous_email,
                        &updated.email,
                    )
                    .await?;
                }
                updated
            }
            AccountChangeKind::Password => {
                let updated = sqlx::query_as!(
                    UserDb,
                    r#"UPDATE users SET password_hash = $2 WHERE id = $1
                       RETURNING id, username, email, password_hash, avatar_url, email_verified_at, auth_revision, created_at as "created_at!""#,
                    user_id,
                    claimed.new_password_hash,
                )
                .fetch_optional(&mut *transaction)
                .await
                .map_err(AppError::from)?;
                if updated.is_some() {
                    sqlx::query(
                        "INSERT INTO user_login_methods (user_id, provider) VALUES ($1, 'password') ON CONFLICT (user_id, provider) DO NOTHING",
                    )
                    .bind(user_id)
                    .execute(&mut *transaction)
                    .await
                    .map_err(AppError::from)?;
                }
                updated
            }
        };

        auth_attempts::clear_code_attempt(&mut transaction, attempt_key).await?;
        transaction.commit().await.map_err(AppError::from)?;
        Ok(updated.map(Into::into))
    }

    async fn list_pending_account_changes(&self, user_id: Uuid) -> AppResult<Vec<PendingChange>> {
        let rows = sqlx::query_as!(
            PendingAccountChangeDb,
            r#"SELECT kind, new_email as "new_email: String", expires_at
               FROM pending_account_changes
               WHERE user_id = $1 AND expires_at > CURRENT_TIMESTAMP
               ORDER BY kind"#,
            user_id,
        )
        .fetch_all(&self.pool)
        .await
        .map_err(AppError::from)?;

        Ok(rows
            .into_iter()
            .filter_map(PendingAccountChangeDb::into_pending)
            .collect())
    }

    async fn discard_pending_account_change(
        &self,
        user_id: Uuid,
        kind: AccountChangeKind,
    ) -> AppResult<()> {
        sqlx::query!(
            "DELETE FROM pending_account_changes WHERE user_id = $1 AND kind = $2",
            user_id,
            kind.as_str(),
        )
        .execute(&self.pool)
        .await
        .map_err(AppError::from)?;

        Ok(())
    }
}

/// The account's current address, read under the row lock its address change will hold. Company
/// creation and invite acceptance lock the same row before registering the address, so the re-key
/// that follows sees every principal they made with the old one.
async fn locked_account_email(
    connection: &mut sqlx::PgConnection,
    user_id: Uuid,
) -> AppResult<Option<String>> {
    sqlx::query_scalar!(
        r#"SELECT email::text AS "email!" FROM users WHERE id = $1 FOR UPDATE"#,
        user_id
    )
    .fetch_optional(&mut *connection)
    .await
    .map_err(AppError::from)
}

/// The address having been taken in the fifteen minutes since the code went out is the one thing
/// that can still refuse a confirmation, and the reader is the only one who can resolve it.
fn taken_address_error(err: sqlx::Error, address: Option<&str>) -> AppError {
    if is_unique_violation(&err) {
        return AppError::BadRequest(format!(
            "An account already uses the address '{}'.",
            address.unwrap_or_default()
        ));
    }
    AppError::from(err)
}

fn person_address(
    (company_id, company_name, company_slug, slug): (Uuid, String, String, String),
) -> PersonAddress {
    PersonAddress {
        company_id,
        company_name,
        company_slug: CompanySlug::from(company_slug),
        slug: ChannelSlug::from(slug),
    }
}

#[cfg(test)]
mod tests {
    //! What a pending account change does is decided by SQL — the CHECK constraint that keeps a
    //! row's payload matching its kind, the `DELETE ... RETURNING` that makes spending a code
    //! atomic, and the `expires_at` comparison — so none of it can be shown anywhere but against a
    //! real database.

    use super::*;
    use crate::adapters::persistence::test_support::own_database;
    use crate::use_cases::user::{
        AccountChangePersistence, UserCredentialsHasher, auth_attempt_key,
    };

    fn code_key(id: Uuid, kind: AccountChangeKind) -> AuthAttemptKey {
        auth_attempt_key(
            "test-attempt-secret",
            "account-change-code:v1",
            &[id.as_bytes(), kind.as_str().as_bytes()],
        )
    }

    async fn account(persistence: &PostgresPersistence) -> User {
        let username = format!("pending_{}", Uuid::new_v4().simple());
        persistence
            .create_user(&username, &format!("{username}@example.com"), "hash")
            .await
            .expect("an account")
    }

    fn in_fifteen_minutes() -> DateTime<Utc> {
        Utc::now() + chrono::Duration::minutes(15)
    }

    #[tokio::test]
    async fn security_email_identity_proof_round_trips_and_stays_with_current_address() {
        let Some(database) = own_database().await else {
            return;
        };
        let persistence = PostgresPersistence::new(database.pool.clone());
        let user = account(&persistence).await;
        assert!(
            user.email_verified_at.is_none(),
            "generic creation is unverified"
        );
        assert!(
            persistence
                .get_by_id(user.id)
                .await
                .unwrap()
                .unwrap()
                .email_verified_at
                .is_none()
        );

        let provider_email =
            EmailAddress::from(format!("oauth-{}@example.com", Uuid::new_v4().simple()));
        let subject = format!("subject-{}", Uuid::new_v4().simple());
        let identity = ExternalIdentity {
            provider: LoginMethod::Google,
            subject: &subject,
            email: &provider_email,
            email_verified: true,
            display_name: None,
        };
        let external = persistence.create_external_user(identity).await.unwrap();
        assert!(external.email_verified_at.is_some());
        assert!(
            persistence
                .get_by_email(provider_email.as_str())
                .await
                .unwrap()
                .unwrap()
                .email_verified_at
                .is_some()
        );

        let renamed = persistence
            .update_profile(
                external.id,
                ProfileUpdate {
                    username: "renamed",
                    email: &provider_email,
                    avatar_url: None,
                },
            )
            .await
            .unwrap()
            .unwrap();
        assert_eq!(renamed.email_verified_at, external.email_verified_at);

        let new_email = EmailAddress::from(format!("new-{}@example.com", Uuid::new_v4().simple()));
        let changed = persistence
            .update_profile(
                external.id,
                ProfileUpdate {
                    username: "renamed",
                    email: &new_email,
                    avatar_url: None,
                },
            )
            .await
            .unwrap()
            .unwrap();
        assert!(
            changed.email_verified_at.is_none(),
            "old-address proof cannot verify a new address"
        );
        let old_claim = persistence
            .login_external_identity(identity)
            .await
            .unwrap()
            .unwrap();
        assert!(
            old_claim.email_verified_at.is_none(),
            "old provider email cannot refresh the marker"
        );
        assert!(matches!(
            persistence
                .login_external_identity(ExternalIdentity {
                    email_verified: false,
                    email: &new_email,
                    ..identity
                })
                .await,
            Err(AppError::BadRequest(_))
        ));
        let new_claim = persistence
            .login_external_identity(ExternalIdentity {
                email: &new_email,
                ..identity
            })
            .await
            .unwrap()
            .unwrap();
        assert!(new_claim.email_verified_at.is_some());
        assert_eq!(
            persistence
                .get_by_id(external.id)
                .await
                .unwrap()
                .unwrap()
                .email_verified_at,
            new_claim.email_verified_at
        );
    }

    #[tokio::test]
    async fn security_email_identity_registration_code_installs_proof_once() {
        let Some(database) = own_database().await else {
            return;
        };
        let persistence = PostgresPersistence::new(database.pool.clone());
        let email =
            EmailAddress::from(format!("confirmed-{}@example.com", Uuid::new_v4().simple()));
        let key = auth_attempt_key(
            "test-attempt-secret",
            "registration-code:v1",
            &[email.as_str().as_bytes()],
        );
        persistence
            .save_pending_registration(PendingRegistration {
                username: "confirmed",
                email: &email,
                password_hash: "hash",
                confirmation_code_hash: "exact-code-hash",
                expires_at: in_fifteen_minutes(),
            })
            .await
            .unwrap();
        assert!(
            persistence
                .confirm_pending_registration(&email, "wrong-code-hash", &key)
                .await
                .unwrap()
                .is_none()
        );
        let confirmed = persistence
            .confirm_pending_registration(&email, "exact-code-hash", &key)
            .await
            .unwrap()
            .unwrap();
        assert!(confirmed.email_verified_at.is_some());
        assert_eq!(
            persistence
                .get_by_id(confirmed.id)
                .await
                .unwrap()
                .unwrap()
                .email_verified_at,
            confirmed.email_verified_at
        );
        assert!(
            persistence
                .confirm_pending_registration(&email, "exact-code-hash", &key)
                .await
                .unwrap()
                .is_none()
        );
    }

    #[tokio::test]
    async fn security_email_identity_link_proof_is_atomic_and_idempotent() {
        let Some(database) = own_database().await else {
            return;
        };
        let persistence = std::sync::Arc::new(PostgresPersistence::new(database.pool.clone()));
        let user = account(&persistence).await;
        let email = EmailAddress::from(user.email.as_str());
        let subject = format!("linked-{}", Uuid::new_v4().simple());
        let identity = ExternalIdentity {
            provider: LoginMethod::Google,
            subject: &subject,
            email: &email,
            email_verified: true,
            display_name: None,
        };
        assert!(matches!(
            persistence
                .link_external_identity(
                    user.id,
                    ExternalIdentity {
                        email_verified: false,
                        ..identity
                    }
                )
                .await,
            Err(AppError::BadRequest(_))
        ));
        assert!(
            !persistence
                .has_login_method(user.id, LoginMethod::Google)
                .await
                .unwrap()
        );

        persistence
            .link_external_identity(user.id, identity)
            .await
            .unwrap();
        let marked = persistence.get_by_id(user.id).await.unwrap().unwrap();
        assert!(marked.email_verified_at.is_some());
        let use_cases = crate::use_cases::user::UserUseCases::new(
            std::sync::Arc::new(crate::infra::argon2_password_hasher()),
            persistence.clone(),
            ("test-attempt-secret").into(),
        );
        let repeated = use_cases.link_external(user.id, identity).await.unwrap();
        assert_eq!(repeated.email_verified_at, marked.email_verified_at);

        let new_email =
            EmailAddress::from(format!("changed-{}@example.com", Uuid::new_v4().simple()));
        persistence
            .update_profile(
                user.id,
                ProfileUpdate {
                    username: &user.username,
                    email: &new_email,
                    avatar_url: None,
                },
            )
            .await
            .unwrap();
        let apple_subject = format!("apple-{}", Uuid::new_v4().simple());
        let stale = ExternalIdentity {
            provider: LoginMethod::Apple,
            subject: &apple_subject,
            ..identity
        };
        assert!(matches!(
            persistence.link_external_identity(user.id, stale).await,
            Err(AppError::Conflict(_))
        ));
        assert!(
            !persistence
                .has_login_method(user.id, LoginMethod::Apple)
                .await
                .unwrap()
        );
        assert!(
            persistence
                .get_by_id(user.id)
                .await
                .unwrap()
                .unwrap()
                .email_verified_at
                .is_none()
        );
    }

    #[tokio::test]
    async fn security_email_identity_competing_claimants_verify_only_the_winner() {
        let Some(database) = own_database().await else {
            return;
        };
        let persistence = std::sync::Arc::new(PostgresPersistence::new(database.pool.clone()));
        let first = account(&persistence).await;
        let second = account(&persistence).await;
        let destination =
            EmailAddress::from(format!("contended-{}@example.com", Uuid::new_v4().simple()));
        for user in [&first, &second] {
            persistence
                .save_pending_account_change(PendingAccountChange {
                    user_id: user.id,
                    change: AccountChange::Email(&destination),
                    confirmation_code_hash: "shared-code-hash",
                    expires_at: in_fifteen_minutes(),
                })
                .await
                .unwrap();
        }
        let first_key = code_key(first.id, AccountChangeKind::Email);
        let second_key = code_key(second.id, AccountChangeKind::Email);
        let (one, two) = tokio::join!(
            persistence.confirm_pending_account_change(
                first.id,
                AccountChangeKind::Email,
                "shared-code-hash",
                &first_key
            ),
            persistence.confirm_pending_account_change(
                second.id,
                AccountChangeKind::Email,
                "shared-code-hash",
                &second_key
            ),
        );
        let winners = [one, two]
            .into_iter()
            .filter(|result| matches!(result, Ok(Some(_))))
            .count();
        assert_eq!(winners, 1);
        let first_after = persistence.get_by_id(first.id).await.unwrap().unwrap();
        let second_after = persistence.get_by_id(second.id).await.unwrap().unwrap();
        assert_eq!(
            [
                first_after.email_verified_at,
                second_after.email_verified_at
            ]
            .into_iter()
            .filter(Option::is_some)
            .count(),
            1
        );
        assert_eq!(
            [first_after.email, second_after.email]
                .into_iter()
                .filter(|email| email == destination.as_str())
                .count(),
            1
        );
    }

    #[tokio::test]
    async fn security_email_identity_bypassed_address_claim_is_atomic_under_contention() {
        let Some(database) = own_database().await else {
            return;
        };
        let persistence = std::sync::Arc::new(PostgresPersistence::new(database.pool.clone()));
        let first = account(&persistence).await;
        let second = account(&persistence).await;
        sqlx::query("UPDATE users SET email_verified_at = CURRENT_TIMESTAMP WHERE id = ANY($1)")
            .bind(vec![first.id, second.id])
            .execute(&database.pool)
            .await
            .unwrap();
        let destination =
            EmailAddress::from(format!("bypass-{}@example.com", Uuid::new_v4().simple()));
        let (one, two) = tokio::join!(
            persistence.update_profile(
                first.id,
                ProfileUpdate {
                    username: &first.username,
                    email: &destination,
                    avatar_url: None,
                }
            ),
            persistence.update_profile(
                second.id,
                ProfileUpdate {
                    username: &second.username,
                    email: &destination,
                    avatar_url: None,
                }
            ),
        );
        assert_eq!(
            [&one, &two]
                .into_iter()
                .filter(|result| result.is_ok())
                .count(),
            1
        );
        let first_after = persistence.get_by_id(first.id).await.unwrap().unwrap();
        let second_after = persistence.get_by_id(second.id).await.unwrap().unwrap();
        let claimants = [&first_after, &second_after];
        assert_eq!(
            claimants
                .iter()
                .filter(|user| user.email == destination.as_str())
                .count(),
            1
        );
        for user in claimants {
            assert_eq!(
                user.email_verified_at.is_some(),
                user.email != destination.as_str(),
                "only the account retaining its proved address may retain proof"
            );
        }
    }

    #[tokio::test]
    async fn security_email_identity_display_save_cannot_restore_address_confirmed_after_read() {
        let Some(database) = own_database().await else {
            return;
        };
        let persistence = PostgresPersistence::new(database.pool.clone());
        let user = account(&persistence).await;
        let observed = persistence.get_by_id(user.id).await.unwrap().unwrap();
        assert_eq!(observed.email, user.email);

        let destination = EmailAddress::from(format!(
            "concurrent-{}@example.com",
            Uuid::new_v4().simple()
        ));
        persistence
            .save_pending_account_change(PendingAccountChange {
                user_id: user.id,
                change: AccountChange::Email(&destination),
                confirmation_code_hash: "right-code",
                expires_at: in_fifteen_minutes(),
            })
            .await
            .unwrap();
        let key = code_key(user.id, AccountChangeKind::Email);
        let confirmed = persistence
            .confirm_pending_account_change(user.id, AccountChangeKind::Email, "right-code", &key)
            .await
            .unwrap()
            .unwrap();
        assert_eq!(confirmed.email, destination.as_str());
        assert!(confirmed.email_verified_at.is_some());

        // This is the display write that follows the stale profile read. It never supplies the
        // observed address to SQL, so a confirmed address and its proof survive the interleaving.
        let saved = persistence
            .update_profile_display(user.id, "renamed", None)
            .await
            .unwrap()
            .unwrap();
        assert_eq!(saved.username, "renamed");
        assert_eq!(saved.email, destination.as_str());
        assert_eq!(saved.email_verified_at, confirmed.email_verified_at);
    }

    #[tokio::test]
    async fn a_confirmed_code_moves_the_address_and_cannot_be_spent_twice() {
        let Some(database) = own_database().await else {
            return;
        };
        let pool = database.pool.clone();
        let persistence = std::sync::Arc::new(PostgresPersistence::new(pool));
        let user = account(&persistence).await;
        let moved_to = EmailAddress::from(format!("moved_{}@example.com", Uuid::new_v4().simple()));

        persistence
            .save_pending_account_change(PendingAccountChange {
                user_id: user.id,
                change: AccountChange::Email(&moved_to),
                confirmation_code_hash: "hash-of-123456",
                expires_at: in_fifteen_minutes(),
            })
            .await
            .expect("a stored request");

        // Until it is confirmed the account still has the address it signed up with.
        let stored = persistence
            .get_by_id(user.id)
            .await
            .expect("a lookup")
            .expect("the account");
        assert_eq!(stored.email, user.email);

        let pending = persistence
            .list_pending_account_changes(user.id)
            .await
            .expect("the pending list");
        assert!(
            matches!(pending.as_slice(), [PendingChange::Email { new_email, .. }] if new_email == &moved_to),
            "the request reads back as the address it will move to: {pending:?}"
        );

        let confirmed = persistence
            .confirm_pending_account_change(
                user.id,
                AccountChangeKind::Email,
                "hash-of-123456",
                &code_key(user.id, AccountChangeKind::Email),
            )
            .await
            .expect("a confirmation")
            .expect("the updated account");
        assert_eq!(confirmed.email, moved_to.as_str());

        // The delete is what claims the request, so the same code cannot be replayed.
        assert!(
            persistence
                .confirm_pending_account_change(
                    user.id,
                    AccountChangeKind::Email,
                    "hash-of-123456",
                    &code_key(user.id, AccountChangeKind::Email)
                )
                .await
                .expect("a second attempt")
                .is_none()
        );
    }

    #[tokio::test]
    async fn a_wrong_or_expired_code_changes_nothing() {
        let Some(database) = own_database().await else {
            return;
        };
        let pool = database.pool.clone();
        let persistence = PostgresPersistence::new(pool);
        let user = account(&persistence).await;

        persistence
            .save_pending_account_change(PendingAccountChange {
                user_id: user.id,
                change: AccountChange::Password("new-hash"),
                confirmation_code_hash: "hash-of-123456",
                expires_at: in_fifteen_minutes(),
            })
            .await
            .expect("a stored request");

        assert!(
            persistence
                .confirm_pending_account_change(
                    user.id,
                    AccountChangeKind::Password,
                    "hash-of-000000",
                    &code_key(user.id, AccountChangeKind::Password),
                )
                .await
                .expect("a wrong code")
                .is_none()
        );

        // A code that missed its window is refused, and does not show up as something to confirm.
        persistence
            .save_pending_account_change(PendingAccountChange {
                user_id: user.id,
                change: AccountChange::Password("new-hash"),
                confirmation_code_hash: "hash-of-123456",
                expires_at: Utc::now() - chrono::Duration::minutes(1),
            })
            .await
            .expect("an expired request");

        assert!(
            persistence
                .confirm_pending_account_change(
                    user.id,
                    AccountChangeKind::Password,
                    "hash-of-123456",
                    &code_key(user.id, AccountChangeKind::Password),
                )
                .await
                .expect("an expired code")
                .is_none()
        );
        assert!(
            persistence
                .list_pending_account_changes(user.id)
                .await
                .expect("the pending list")
                .is_empty()
        );
        assert_eq!(
            persistence
                .get_by_id(user.id)
                .await
                .expect("a lookup")
                .expect("the account")
                .password_hash,
            Some("hash".to_owned()),
            "neither refusal may write the new password"
        );
    }

    #[tokio::test]
    async fn each_kind_gets_one_request_and_a_second_ask_replaces_it() {
        let Some(database) = own_database().await else {
            return;
        };
        let pool = database.pool.clone();
        let persistence = PostgresPersistence::new(pool);
        let user = account(&persistence).await;
        let first = EmailAddress::from(format!("first_{}@example.com", Uuid::new_v4().simple()));
        let second = EmailAddress::from(format!("second_{}@example.com", Uuid::new_v4().simple()));

        for (address, code) in [(&first, "hash-of-111111"), (&second, "hash-of-222222")] {
            persistence
                .save_pending_account_change(PendingAccountChange {
                    user_id: user.id,
                    change: AccountChange::Email(address),
                    confirmation_code_hash: code,
                    expires_at: in_fifteen_minutes(),
                })
                .await
                .expect("a stored request");
        }
        persistence
            .save_pending_account_change(PendingAccountChange {
                user_id: user.id,
                change: AccountChange::Password("new-hash"),
                confirmation_code_hash: "hash-of-333333",
                expires_at: in_fifteen_minutes(),
            })
            .await
            .expect("a stored request");

        // One per kind: asking twice for an address change leaves the second ask, not both.
        let pending = persistence
            .list_pending_account_changes(user.id)
            .await
            .expect("the pending list");
        assert_eq!(pending.len(), 2);
        assert!(matches!(
            pending.iter().find(|p| p.kind() == AccountChangeKind::Email),
            Some(PendingChange::Email { new_email, .. }) if new_email == &second
        ));

        // ...and the code the first ask mailed out is dead.
        assert!(
            persistence
                .confirm_pending_account_change(
                    user.id,
                    AccountChangeKind::Email,
                    "hash-of-111111",
                    &code_key(user.id, AccountChangeKind::Email)
                )
                .await
                .expect("the superseded code")
                .is_none()
        );

        // Discarding one kind leaves the other alone.
        persistence
            .discard_pending_account_change(user.id, AccountChangeKind::Email)
            .await
            .expect("a discard");
        let pending = persistence
            .list_pending_account_changes(user.id)
            .await
            .expect("the pending list");
        assert_eq!(pending.len(), 1);
        assert_eq!(pending[0].kind(), AccountChangeKind::Password);
    }

    #[tokio::test]
    async fn an_address_taken_since_the_code_was_mailed_refuses_the_confirmation() {
        let Some(database) = own_database().await else {
            return;
        };
        let pool = database.pool.clone();
        let persistence = PostgresPersistence::new(pool);
        let mover = account(&persistence).await;
        let squatter = account(&persistence).await;

        persistence
            .save_pending_account_change(PendingAccountChange {
                user_id: mover.id,
                change: AccountChange::Email(&EmailAddress::from(squatter.email.as_str())),
                confirmation_code_hash: "hash-of-123456",
                expires_at: in_fifteen_minutes(),
            })
            .await
            .expect("a stored request");

        let refused = persistence
            .confirm_pending_account_change(
                mover.id,
                AccountChangeKind::Email,
                "hash-of-123456",
                &code_key(mover.id, AccountChangeKind::Email),
            )
            .await;
        assert!(
            matches!(refused, Err(AppError::BadRequest(ref message)) if message.contains(&squatter.email)),
            "a taken address must be named, not reported as a driver fault: {refused:?}"
        );

        // The transaction rolled back, so the request is still there to retry with another address.
        assert_eq!(
            persistence
                .get_by_id(mover.id)
                .await
                .expect("a lookup")
                .expect("the account")
                .email,
            mover.email
        );
    }

    #[tokio::test]
    async fn notification_preferences_default_and_round_trip_every_email_family() {
        let Some(database) = own_database().await else {
            return;
        };
        let pool = database.pool.clone();
        let persistence = PostgresPersistence::new(pool);
        let user = account(&persistence).await;
        assert_eq!(
            persistence
                .notification_preferences(user.id)
                .await
                .expect("default preferences"),
            NotificationPreferences::default()
        );

        // Each flag on its own, so a transposed column cannot pass (P08-Q8).
        for expected in [
            NotificationPreferences {
                delivery_failure_email_enabled: false,
                decision_email_enabled: true,
            },
            NotificationPreferences {
                delivery_failure_email_enabled: true,
                decision_email_enabled: false,
            },
        ] {
            persistence
                .set_notification_preferences(user.id, expected)
                .await
                .expect("stored preferences");
            assert_eq!(
                persistence
                    .notification_preferences(user.id)
                    .await
                    .expect("updated preferences"),
                expected
            );
        }
    }

    #[tokio::test]
    async fn accounts_only_receive_the_login_method_they_registered() {
        let Some(database) = own_database().await else {
            return;
        };
        let pool = database.pool.clone();
        let persistence = std::sync::Arc::new(PostgresPersistence::new(pool));
        let suffix = Uuid::new_v4().simple().to_string();
        let password_user = persistence
            .create_user(
                &format!("password-{suffix}"),
                &format!("password-{suffix}@example.com"),
                "hash",
            )
            .await
            .expect("password registration");
        assert!(
            persistence
                .has_login_method(password_user.id, LoginMethod::Password)
                .await
                .expect("method lookup")
        );
        assert!(
            !persistence
                .has_login_method(password_user.id, LoginMethod::Google)
                .await
                .expect("method lookup")
        );

        let google_email = EmailAddress::from(format!("google-{suffix}@example.com"));
        let google_subject = format!("google-subject-{suffix}");
        let google_user = persistence
            .create_external_user(ExternalIdentity {
                provider: LoginMethod::Google,
                subject: &google_subject,
                email: &google_email,
                email_verified: true,
                display_name: Some("Google Person"),
            })
            .await
            .expect("Google registration");
        assert!(
            persistence
                .has_login_method(google_user.id, LoginMethod::Google)
                .await
                .expect("method lookup")
        );
        assert!(
            !persistence
                .has_login_method(google_user.id, LoginMethod::Password)
                .await
                .expect("method lookup")
        );
        assert_eq!(
            persistence
                .get_by_external_subject(LoginMethod::Google, &google_subject)
                .await
                .expect("Google lookup")
                .expect("registered identity")
                .id,
            google_user.id
        );
        assert!(
            persistence
                .get_by_external_subject(LoginMethod::Google, "some-other-google-subject")
                .await
                .expect("Google lookup")
                .is_none()
        );

        let use_cases = crate::use_cases::user::UserUseCases::new(
            std::sync::Arc::new(crate::infra::argon2_password_hasher()),
            persistence.clone(),
            ("test-attempt-secret").into(),
        );
        assert!(matches!(
            use_cases
                .login(
                    &google_user.email,
                    &secrecy::SecretString::from("irrelevant-password"),
                    None,
                    None,
                )
                .await,
            Err(AppError::InvalidCredentials)
        ));
        assert!(matches!(
            use_cases
                .login_external(ExternalIdentity {
                    provider: LoginMethod::Google,
                    subject: "some-other-google-subject",
                    email: &google_email,
                    email_verified: true,
                    display_name: None,
                })
                .await,
            Err(AppError::InvalidCredentials)
        ));
        assert_eq!(
            use_cases
                .login_external(ExternalIdentity {
                    provider: LoginMethod::Google,
                    subject: &google_subject,
                    email: &google_email,
                    email_verified: true,
                    display_name: None,
                })
                .await
                .expect("registered Google login")
                .id,
            google_user.id
        );

        let password = "new-password-login";
        let password_hash = crate::infra::argon2_password_hasher()
            .hash_password(password)
            .expect("password hash");
        persistence
            .activate_password(google_user.id, &password_hash)
            .await
            .expect("activate password")
            .expect("Google user still exists");
        assert!(
            persistence
                .has_login_method(google_user.id, LoginMethod::Password)
                .await
                .expect("password method lookup")
        );
        assert_eq!(
            use_cases
                .login(
                    &google_user.email,
                    &secrecy::SecretString::from(password),
                    None,
                    None,
                )
                .await
                .expect("added password login")
                .id,
            google_user.id
        );

        let linked_subject = format!("linked-google-{suffix}");
        let password_email = EmailAddress::from(password_user.email.as_str());
        use_cases
            .link_external(
                password_user.id,
                ExternalIdentity {
                    provider: LoginMethod::Google,
                    subject: &linked_subject,
                    email: &password_email,
                    email_verified: true,
                    display_name: None,
                },
            )
            .await
            .expect("link Google to password account");
        assert_eq!(
            use_cases
                .login_external(ExternalIdentity {
                    provider: LoginMethod::Google,
                    subject: &linked_subject,
                    email: &password_email,
                    email_verified: true,
                    display_name: None,
                })
                .await
                .expect("linked Google login")
                .id,
            password_user.id
        );

        let apple_email = EmailAddress::from(format!("apple-{suffix}@example.com"));
        let apple_subject = format!("apple-subject-{suffix}");
        let apple_user = persistence
            .create_external_user(ExternalIdentity {
                provider: LoginMethod::Apple,
                subject: &apple_subject,
                email: &apple_email,
                email_verified: true,
                display_name: Some("Apple Person"),
            })
            .await
            .expect("Apple registration");
        assert!(
            persistence
                .has_login_method(apple_user.id, LoginMethod::Apple)
                .await
                .expect("Apple method lookup")
        );
        assert_eq!(
            use_cases
                .login_external(ExternalIdentity {
                    provider: LoginMethod::Apple,
                    subject: &apple_subject,
                    email: &apple_email,
                    email_verified: true,
                    display_name: None,
                })
                .await
                .expect("Apple login")
                .id,
            apple_user.id
        );
    }
}
