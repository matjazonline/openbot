//! Database tests for the canonical message store and its correlation maps.
//!
//! The fixture and the message-shaped helpers live in [`super::test_support`].

use super::test_support::*;
use super::*;
use crate::entities::value_objects::MessageId;
use crate::entities::{
    correlation::CorrelationId,
    email_message::EmailMessageMetadata,
    internal_note::{AddInternalNote, InternalNoteProvenance, TombstoneInternalNote},
    message::{
        AttachmentMetadata, AttachmentSource, MessageAudience, MessageDirection,
        MessageParticipantKind, MessageRole, ThreadEntryKind,
    },
    participant::IdentityProvenance,
    transport::{ExternalMessageKey, ExternalThreadKey},
};

#[tokio::test]
async fn internal_notes_are_idempotent_immutable_and_auditable() {
    let Some(fixture) = Fixture::new("internal_note_lifecycle").await else {
        return;
    };
    let actor = crate::entities::transport::PrincipalId::new(
        sqlx::query_scalar::<_, Uuid>(
            "SELECT id FROM principals WHERE company_id = $1 AND user_id = $2",
        )
        .bind(fixture.company_id)
        .bind(fixture.owner_id)
        .fetch_one(&fixture.pool)
        .await
        .unwrap(),
    );
    let before_tasks: i64 = sqlx::query_scalar(
        "SELECT COUNT(*) FROM background_tasks WHERE company_id = $1 AND thread_id = $2",
    )
    .bind(fixture.company_id)
    .bind(fixture.thread.id)
    .fetch_one(&fixture.pool)
    .await
    .unwrap();
    let before_deliveries: i64 =
        sqlx::query_scalar("SELECT COUNT(*) FROM message_deliveries WHERE company_id = $1")
            .bind(fixture.company_id)
            .fetch_one(&fixture.pool)
            .await
            .unwrap();
    let command = AddInternalNote {
        company_id: fixture.company_id,
        target: crate::entities::address::AddressTarget::Desk(fixture.channel_id),
        thread_id: fixture.thread.id,
        text: "Customer supplied a replacement purchase order.".into(),
        command_id: Uuid::new_v4(),
        supersedes_note_id: None,
        provenance: InternalNoteProvenance::Api,
    };
    let disabled_actor = crate::entities::transport::PrincipalId::random();
    sqlx::query(
        "INSERT INTO principals (id, company_id, kind, display_label) VALUES ($1, $2, 'external', 'Former teammate')",
    )
    .bind(disabled_actor.as_uuid())
    .bind(fixture.company_id)
    .execute(&fixture.pool)
    .await
    .unwrap();
    assert!(matches!(
        fixture
            .persistence
            .create_internal_note(
                &AddInternalNote {
                    command_id: Uuid::new_v4(),
                    ..command.clone()
                },
                disabled_actor,
            )
            .await,
        Err(AppError::NotFound(_))
    ));
    sqlx::query(
        "INSERT INTO principals (id, company_id, kind, display_label) VALUES ($1, $2, 'system', 'CRM sync') ON CONFLICT DO NOTHING",
    )
    .bind(Uuid::new_v4())
    .bind(fixture.company_id)
    .execute(&fixture.pool)
    .await
    .unwrap();
    let system_actor = crate::entities::transport::PrincipalId::new(
        sqlx::query_scalar::<_, Uuid>(
            "SELECT id FROM principals WHERE company_id = $1 AND kind = 'system'",
        )
        .bind(fixture.company_id)
        .fetch_one(&fixture.pool)
        .await
        .unwrap(),
    );
    let integration_note = fixture
        .persistence
        .create_internal_note(
            &AddInternalNote {
                text: "CRM sync confirmed the account tier.".into(),
                command_id: Uuid::new_v4(),
                provenance: InternalNoteProvenance::Integration,
                ..command.clone()
            },
            system_actor,
        )
        .await
        .unwrap();
    assert_eq!(integration_note.role, MessageRole::System);
    let (first, retry) = tokio::join!(
        fixture.persistence.create_internal_note(&command, actor),
        fixture.persistence.create_internal_note(&command, actor),
    );
    let first = first.unwrap();
    let retry = retry.unwrap();
    assert_eq!(first.canonical_id, retry.canonical_id);
    let note = first.internal_note.unwrap();
    assert!(note.is_active());
    assert_eq!(first.audience, MessageAudience::InternalOnly);
    assert_eq!(first.entry_kind, ThreadEntryKind::Note);
    assert!(first.attachments.is_empty());

    let mismatch = AddInternalNote {
        text: "Different content under the same command id.".into(),
        ..command.clone()
    };
    assert!(matches!(
        fixture
            .persistence
            .create_internal_note(&mismatch, actor)
            .await,
        Err(AppError::Conflict(_))
    ));

    let correction = fixture
        .persistence
        .create_internal_note(
            &AddInternalNote {
                text: "Customer supplied purchase order PO-42.".into(),
                command_id: Uuid::new_v4(),
                supersedes_note_id: Some(note.id),
                ..command.clone()
            },
            actor,
        )
        .await
        .unwrap();
    let correction_note = correction.internal_note.unwrap();
    assert_eq!(correction_note.supersedes_note_id, Some(note.id));
    let refreshed = fixture
        .persistence
        .get_thread_message_view(fixture.thread.id, first.canonical_id)
        .await
        .unwrap()
        .unwrap();
    assert_eq!(
        refreshed.internal_note.unwrap().superseded_by_note_id,
        Some(correction_note.id)
    );

    let tombstone = TombstoneInternalNote {
        company_id: fixture.company_id,
        target: crate::entities::address::AddressTarget::Desk(fixture.channel_id),
        thread_id: fixture.thread.id,
        note_id: correction_note.id,
        command_id: Uuid::new_v4(),
    };
    let removed = fixture
        .persistence
        .tombstone_internal_note(&tombstone, actor)
        .await
        .unwrap();
    assert!(!removed.is_active());
    assert_eq!(
        fixture
            .persistence
            .tombstone_internal_note(&tombstone, actor)
            .await
            .unwrap(),
        removed
    );
    let body: String = sqlx::query_scalar(
        "SELECT clean_text_body FROM messages WHERE company_id = $1 AND id = $2",
    )
    .bind(fixture.company_id)
    .bind(correction.canonical_id.as_uuid())
    .fetch_one(&fixture.pool)
    .await
    .unwrap();
    assert_eq!(body, "Customer supplied purchase order PO-42.");

    let after_tasks: i64 = sqlx::query_scalar(
        "SELECT COUNT(*) FROM background_tasks WHERE company_id = $1 AND thread_id = $2",
    )
    .bind(fixture.company_id)
    .bind(fixture.thread.id)
    .fetch_one(&fixture.pool)
    .await
    .unwrap();
    assert_eq!(after_tasks, before_tasks, "notes never create agent work");
    let after_deliveries: i64 =
        sqlx::query_scalar("SELECT COUNT(*) FROM message_deliveries WHERE company_id = $1")
            .bind(fixture.company_id)
            .fetch_one(&fixture.pool)
            .await
            .unwrap();
    assert_eq!(
        after_deliveries, before_deliveries,
        "notes and lifecycle changes never enter a transport queue"
    );
    let prompt_history = fixture
        .persistence
        .list_agent_history(fixture.thread.id)
        .await
        .unwrap();
    assert!(
        prompt_history.iter().all(|message| {
            !message.body.contains("Customer supplied")
                && !message.body.contains("CRM sync confirmed")
        }),
        "internal notes enter prompts only through an explicit selected-note projection"
    );
    fixture.cleanup().await;
}

#[tokio::test]
async fn private_messages_cannot_enter_the_external_delivery_queue() {
    let Some(fixture) = Fixture::new("private_delivery_guard").await else {
        return;
    };
    let private = fixture
        .persistence
        .create_message(&MessageWrite::internal(
            fixture.thread.id,
            MessageAuthorWrite::Platform,
            "Internal finding",
            "Do not disclose this source material.",
            MessageDirection::Outbound,
            MessageRole::Agent,
            CorrelationId::new(),
        ))
        .await
        .unwrap();
    assert_eq!(private.audience, MessageAudience::InternalOnly);
    assert_eq!(private.entry_kind, ThreadEntryKind::Note);

    let mut delivery = crate::adapters::persistence::test_support::delivery_fixture(
        &fixture.persistence,
        crate::adapters::persistence::test_support::DeliveryFixtureRequest::new(
            fixture.company_id,
            fixture.channel_id,
            fixture.thread.id,
            &format!("private-guard-{}", fixture.suffix),
        ),
    )
    .await
    .delivery;
    delivery.message_id = private.canonical_id;

    let mut tx = fixture.pool.begin().await.unwrap();
    let refused =
        crate::adapters::persistence::delivery::enqueue::insert_delivery_on(&mut tx, &delivery)
            .await;
    assert!(
        refused.is_err(),
        "the composite audience FK must fail closed"
    );
    tx.rollback().await.unwrap();

    let widened =
        sqlx::query("UPDATE messages SET audience = 'external_conversation' WHERE id = $1")
            .bind(private.canonical_id.as_uuid())
            .execute(&fixture.pool)
            .await;
    assert!(
        widened.is_err(),
        "stored private content cannot be widened in place"
    );
    let unknown_audience = sqlx::query("UPDATE messages SET audience = 'public-ish' WHERE id = $1")
        .bind(private.canonical_id.as_uuid())
        .execute(&fixture.pool)
        .await;
    assert!(unknown_audience.is_err());
    let unknown_kind = sqlx::query("UPDATE thread_messages SET entry_kind = 'memo' WHERE id = $1")
        .bind(private.id)
        .execute(&fixture.pool)
        .await;
    assert!(unknown_kind.is_err());
    fixture.cleanup().await;
}

#[tokio::test]
async fn schema_constraint_messages_require_declared_audience() {
    let fixture = Fixture::new("declared_audience")
        .await
        .expect("native fixture");
    let stored = fixture
        .persistence
        .create_message(&inbound_email(
            fixture.thread.id,
            email_metadata(&format!("<audience-{}@partner.test>", fixture.suffix)),
            "Explicit audience",
        ))
        .await
        .unwrap();
    struct AudienceCase {
        expression: &'static str,
        code: &'static str,
    }
    for case in [
        AudienceCase {
            expression: "'legacy_unclassified'",
            code: "23514",
        },
        AudienceCase {
            expression: "DEFAULT",
            code: "23502",
        },
    ] {
        let error = sqlx::query(&format!(
            "UPDATE messages SET audience = {} WHERE id = $1",
            case.expression
        ))
        .bind(stored.canonical_id.as_uuid())
        .execute(&fixture.pool)
        .await
        .unwrap_err();
        assert_eq!(
            error
                .as_database_error()
                .and_then(|error| error.code())
                .as_deref(),
            Some(case.code)
        );
    }
    let read = fixture
        .persistence
        .get_thread_message(fixture.thread.id, stored.canonical_id)
        .await
        .unwrap()
        .unwrap();
    assert_eq!(read.audience, MessageAudience::ExternalConversation);
    fixture.cleanup().await;
}

#[tokio::test]
async fn derived_attachments_cannot_publish_a_private_source() {
    let Some(fixture) = Fixture::new("private_attachment_guard").await else {
        return;
    };
    let private = fixture
        .persistence
        .create_message(&MessageWrite::internal(
            fixture.thread.id,
            MessageAuthorWrite::Platform,
            "Private evidence",
            "Evidence",
            MessageDirection::Inbound,
            MessageRole::System,
            CorrelationId::new(),
        ))
        .await
        .unwrap();
    let publish = MessageWrite::internal(
        fixture.thread.id,
        MessageAuthorWrite::Platform,
        "Customer answer",
        "New wording based on private evidence.",
        MessageDirection::Outbound,
        MessageRole::Agent,
        CorrelationId::new(),
    )
    .external_conversation()
    .with_attachments(vec![AttachmentMetadata {
        filename: "derived.pdf".into(),
        content_type: "application/pdf".into(),
        sha256_hash: "derived-hash".into(),
        size_bytes: 42,
        storage_key: None,
        source: Some(AttachmentSource {
            message_id: private.canonical_id,
            sha256_hash: "source-hash".into(),
        }),
    }]);

    let refused = fixture.persistence.create_message(&publish).await;
    assert!(refused.is_err());
    fixture.cleanup().await;
}
use crate::application::ports::thread::MessageAuthorWrite;
use crate::application::ports::thread::MessageCorrelation;
use crate::application::ports::thread::MessageWrite;
use crate::transport::ExternalCorrelationStore;
use crate::use_cases::company::CompanyPersistence;

/// The heart of the canonical store: one payload, many conversations -- and never a conversation
/// belonging to somebody else.
#[tokio::test]
async fn one_message_joins_several_threads_but_never_a_foreign_one() {
    let Some(fixture) = Fixture::new("message_fanout").await else {
        return;
    };

    let second_channel = fixture.extra_channel("second").await;
    let second_thread = fixture.extra_thread(second_channel, "Subject").await;

    let stored = fixture
        .persistence
        .create_message(&inbound_email(
            fixture.thread.id,
            email_metadata(&format!("<fanout-{}@partner.test>", fixture.suffix)),
            "One body",
        ))
        .await
        .unwrap();

    let joined = fixture
        .persistence
        .associate_message(
            second_thread.id,
            stored.canonical_id,
            crate::entities::message::ThreadEntryKind::Note,
        )
        .await
        .unwrap();

    assert_eq!(joined.canonical_id, stored.canonical_id);
    assert_ne!(
        joined.id, stored.id,
        "each association has its own identity"
    );
    assert_eq!(joined.clean_text_body, stored.clean_text_body);
    assert_eq!(joined.thread_id, second_thread.id);

    let canonical_rows: i64 =
        sqlx::query_scalar("SELECT COUNT(*) FROM messages WHERE company_id = $1")
            .bind(fixture.company_id)
            .fetch_one(&fixture.pool)
            .await
            .unwrap();
    assert_eq!(canonical_rows, 1, "one payload, stored once");

    // A thread in another company is refused by the composite foreign key, not by a check in Rust
    // that a future caller could forget.
    let foreign_company = fixture.foreign_company().await;
    let foreign_channel = fixture
        .persistence
        .channel(foreign_company, "foreign", &fixture.suffix)
        .await
        .unwrap();
    let foreign_thread = fixture
        .persistence
        .create_thread(
            foreign_company,
            crate::entities::address::AddressTarget::Desk(foreign_channel.id),
            "Elsewhere",
            &[],
        )
        .await
        .unwrap();
    let refused = fixture
        .persistence
        .associate_message(
            foreign_thread.id,
            stored.canonical_id,
            crate::entities::message::ThreadEntryKind::Note,
        )
        .await;
    assert!(
        refused.is_err(),
        "a message must not cross into another company's thread"
    );

    let _ = CompanyPersistence::delete(&fixture.persistence, foreign_company).await;
    fixture.cleanup().await;
}

/// The reason no provider key lives on `threads`: one conversation can be carried by email and by
/// Slack at the same time, and each side keys it its own way.
#[tokio::test]
async fn one_thread_is_reachable_through_several_bindings() {
    let Some(fixture) = Fixture::new("thread_bindings").await else {
        return;
    };

    let rfc = format!("<multi-{}@partner.test>", fixture.suffix);
    fixture
        .persistence
        .create_message(&inbound_email(
            fixture.thread.id,
            email_metadata(&rfc),
            "Over mail",
        ))
        .await
        .unwrap();

    // A Slack binding on the same channel binds the same thread under its own conversation key.
    let slack = fixture.slack_binding(&format!("C{}", fixture.suffix)).await;
    let slack_key = ExternalThreadKey::parse("1712345678.000100").unwrap();
    let mut connection = fixture.pool.acquire().await.unwrap();
    external::upsert_external_thread(
        &mut connection,
        external::ExternalThreadMapping {
            company_id: fixture.company_id,
            target: crate::entities::address::AddressTarget::Desk(fixture.channel_id),
            binding_id: slack,
            key: &slack_key,
            thread_id: fixture.thread.id,
        },
    )
    .await
    .unwrap();

    let bindings: Vec<Uuid> =
        sqlx::query_scalar("SELECT DISTINCT binding_id FROM external_threads WHERE thread_id = $1")
            .bind(fixture.thread.id)
            .fetch_all(&fixture.pool)
            .await
            .unwrap();
    assert_eq!(bindings.len(), 2, "one thread, two provider interfaces");
    assert!(
        bindings.contains(&fixture.email_binding().await),
        "the mail side is bound through the channel's own email interface"
    );
    assert!(bindings.contains(&slack.as_uuid()));

    // The other half of the invariant: within one binding a conversation key names exactly one
    // thread, so a second thread cannot claim it.
    let rival = fixture.extra_thread(fixture.channel_id, "Rival").await;
    let collision = external::upsert_external_thread(
        &mut connection,
        external::ExternalThreadMapping {
            company_id: fixture.company_id,
            target: crate::entities::address::AddressTarget::Desk(fixture.channel_id),
            binding_id: slack,
            key: &slack_key,
            thread_id: rival.id,
        },
    )
    .await;
    assert!(
        matches!(collision, Err(AppError::Conflict(_))),
        "a second thread claimant must receive the typed collision: {collision:?}"
    );
    let bound: Uuid = sqlx::query_scalar(
        "SELECT thread_id FROM external_threads WHERE binding_id = $1 AND external_thread_key = $2",
    )
    .bind(slack.as_uuid())
    .bind(slack_key.as_str())
    .fetch_one(&fixture.pool)
    .await
    .unwrap();
    assert_eq!(
        bound, fixture.thread.id,
        "a conversation key keeps the thread it was first bound to"
    );

    drop(connection);
    fixture.cleanup().await;
}

/// Redelivery is the ordinary case and must be free; a *changed* redelivery is a fault and must be
/// loud, because the alternative is rewriting a message an agent has already answered.
#[tokio::test]
async fn identical_redelivery_is_reused_and_changed_content_collides() {
    let Some(fixture) = Fixture::new("redelivery").await else {
        return;
    };

    let rfc = format!("<redeliver-{}@partner.test>", fixture.suffix);
    let first = fixture
        .persistence
        .create_message(&inbound_email(
            fixture.thread.id,
            email_metadata(&rfc),
            "Original body",
        ))
        .await
        .unwrap();

    let again = fixture
        .persistence
        .create_message(&inbound_email(
            fixture.thread.id,
            email_metadata(&rfc),
            "Original body",
        ))
        .await
        .unwrap();
    assert_eq!(again.canonical_id, first.canonical_id);
    assert_eq!(again.id, first.id, "and the same association");

    // The quoted-history strip differs per thread, so a different *clean* body is still the same
    // delivered payload -- this is precisely why `clean_text_body` is not hashed.
    let restripped = fixture
        .persistence
        .create_message(&inbound_email(
            fixture.thread.id,
            email_metadata(&rfc),
            "Original body\n\n> quoted",
        ))
        .await
        .unwrap();
    assert_eq!(restripped.canonical_id, first.canonical_id);

    // A changed raw body under a key the provider has already used is not a redelivery.
    let changed = fixture
        .persistence
        .create_message(&inbound_email(
            fixture.thread.id,
            EmailMessageMetadata::new(MessageId::from(rfc.clone()))
                .raw_bodies(Some("tampered".into()), None),
            "Original body",
        ))
        .await;
    assert!(
        matches!(changed, Err(AppError::Conflict(_))),
        "expected a typed collision, got {changed:?}"
    );

    let canonical_rows: i64 =
        sqlx::query_scalar("SELECT COUNT(*) FROM messages WHERE company_id = $1")
            .bind(fixture.company_id)
            .fetch_one(&fixture.pool)
            .await
            .unwrap();
    assert_eq!(canonical_rows, 1);

    fixture.cleanup().await;
}

/// Mail arrives out of order all the time. The reply names the same conversation as the root it
/// answers, so whichever lands first creates the binding and the other joins it.
#[tokio::test]
async fn a_reply_arriving_before_its_root_creates_the_thread_the_root_joins() {
    let Some(fixture) = Fixture::new("reply_before_root").await else {
        return;
    };

    let root_id = format!("<root-{}@partner.test>", fixture.suffix);
    let reply_id = format!("<reply-{}@partner.test>", fixture.suffix);

    fixture
        .persistence
        .create_message(&inbound_email(
            fixture.thread.id,
            email_metadata(&reply_id)
                .in_reply_to(Some(MessageId::from(root_id.clone())))
                .references(vec![MessageId::from(root_id.clone())]),
            "The reply",
        ))
        .await
        .unwrap();

    // The root now arrives. Its own id is its *conversation* key, which is the key the reply
    // already registered -- so thread resolution finds the reply's thread before it ever looks at
    // a message key, which is the order `resolve_thread` walks.
    let found = fixture
        .persistence
        .thread_for_thread_keys(
            fixture.email_binding_of(fixture.channel_id).await,
            &[ExternalThreadKey::parse(root_id.as_str()).unwrap()],
        )
        .await
        .unwrap()
        .expect("the reply's conversation must be findable by the root's id");
    assert_eq!(found, fixture.thread.id);

    fixture
        .persistence
        .create_message(&inbound_email(found, email_metadata(&root_id), "The root"))
        .await
        .unwrap();

    let conversations: i64 = sqlx::query_scalar(
        "SELECT COUNT(*) FROM external_threads WHERE company_id = $1 AND thread_id = $2",
    )
    .bind(fixture.company_id)
    .bind(fixture.thread.id)
    .fetch_one(&fixture.pool)
    .await
    .unwrap();
    assert_eq!(conversations, 1, "one conversation, not one per message");

    let joined: i64 =
        sqlx::query_scalar("SELECT COUNT(*) FROM thread_messages WHERE thread_id = $1")
            .bind(fixture.thread.id)
            .fetch_one(&fixture.pool)
            .await
            .unwrap();
    assert_eq!(joined, 2, "both messages are in the one thread");

    fixture.cleanup().await;
}

/// A provider key means nothing on its own: it is a fact about one *interface*. The same
/// Message-ID reaching two of a company's channels is two facts, so it dedups within each binding
/// and collides across none -- which is what lets one channel's agent mail another without the two
/// halves of that exchange fighting over one row.
#[tokio::test]
async fn provider_message_keys_collide_only_inside_one_binding() {
    let Some(fixture) = Fixture::new("key_scope").await else {
        return;
    };

    let rfc = format!("<shared-{}@partner.test>", fixture.suffix);
    let second_channel = fixture.extra_channel("sibling").await;
    let second_thread = fixture.extra_thread(second_channel, "Subject").await;

    let first = fixture
        .persistence
        .create_message(&inbound_email(
            fixture.thread.id,
            email_metadata(&rfc),
            "Addressed to both",
        ))
        .await
        .unwrap();
    let second = fixture
        .persistence
        .create_message(&inbound_email(
            second_thread.id,
            email_metadata(&rfc),
            "Addressed to both",
        ))
        .await
        .unwrap();

    assert_ne!(
        first.canonical_id, second.canonical_id,
        "a different binding is a different provider fact, so the key dedups within it only"
    );

    let mappings: Vec<(Uuid, Uuid)> = sqlx::query_as(
        r#"SELECT binding_id, message_id FROM external_messages
           WHERE company_id = $1 AND external_message_key = $2"#,
    )
    .bind(fixture.company_id)
    .bind(&rfc)
    .fetch_all(&fixture.pool)
    .await
    .unwrap();
    assert_eq!(
        mappings.len(),
        2,
        "the same key on two bindings is two facts, not a collision"
    );
    assert_ne!(mappings[0].0, mappings[1].0, "one row per binding");
    assert_ne!(
        mappings[0].1, mappings[1].1,
        "each naming the message that binding actually carried"
    );

    // Each channel resolves the key to its own thread.
    assert_eq!(
        fixture
            .persistence
            .thread_for_message_keys(
                fixture.email_binding_of(fixture.channel_id).await,
                &[ExternalMessageKey::parse(rfc.as_str()).unwrap()],
            )
            .await
            .unwrap()
            .unwrap(),
        fixture.thread.id
    );
    assert_eq!(
        fixture
            .persistence
            .thread_for_message_keys(
                fixture.email_binding_of(second_channel).await,
                &[ExternalMessageKey::parse(rfc.as_str()).unwrap()],
            )
            .await
            .unwrap()
            .unwrap(),
        second_thread.id
    );

    // And the constraint itself: a second mapping for the same key on the same binding is refused.
    let duplicate = sqlx::query(
        r#"INSERT INTO external_messages (
               id, company_id, binding_id, external_message_key, message_id
           ) VALUES ($1, $2, $3, $4, $5)"#,
    )
    .bind(Uuid::new_v4())
    .bind(fixture.company_id)
    .bind(mappings[0].0)
    .bind(&rfc)
    .bind(mappings[0].1)
    .execute(&fixture.pool)
    .await;
    assert!(duplicate.is_err());

    fixture.cleanup().await;
}

/// Stored JSON is untrusted input, read back long after it was written. A payload this build does
/// not understand has to reach the caller as an error, never as a panic in a request handler.
#[tokio::test]
async fn unreadable_stored_json_surfaces_as_an_application_error() {
    let Some(fixture) = Fixture::new("bad_json").await else {
        return;
    };

    let stored = fixture
        .persistence
        .create_message(
            &inbound_email(
                fixture.thread.id,
                email_metadata(&format!("<attach-{}@partner.test>", fixture.suffix)),
                "With an attachment",
            )
            .with_attachments(vec![AttachmentMetadata {
                filename: "invoice.pdf".into(),
                content_type: "application/pdf".into(),
                sha256_hash: "abc123".into(),
                size_bytes: 4096,
                storage_key: None,
                source: None,
            }]),
        )
        .await
        .unwrap();
    assert_eq!(stored.attachments.as_ref().map(Vec::len), Some(1));

    // The database refuses an envelope of the wrong shape outright.
    let rejected = sqlx::query("UPDATE messages SET attachments = $2 WHERE id = $1")
        .bind(stored.canonical_id.as_uuid())
        .bind(serde_json::json!([{ "filename": "loose.pdf" }]))
        .execute(&fixture.pool)
        .await;
    assert!(
        rejected.is_err(),
        "a bare array is not a versioned envelope"
    );

    // A *structurally* valid envelope from a newer writer passes the constraint and must then fail
    // the decode rather than the process.
    sqlx::query("UPDATE messages SET attachments = $2 WHERE id = $1")
        .bind(stored.canonical_id.as_uuid())
        .bind(serde_json::json!({ "version": "1", "items": [{ "filename": "loose.pdf" }] }))
        .execute(&fixture.pool)
        .await
        .unwrap();

    let read = fixture
        .persistence
        .list_thread_message_views(fixture.thread.id)
        .await;
    assert!(
        matches!(read, Err(AppError::Internal(_))),
        "expected an application error, got {read:?}"
    );

    fixture.cleanup().await;
}

/// The author of a message is a principal, and the addresses a reader renders are a projection
/// over the handles that principal was named by.
#[tokio::test]
async fn a_message_records_its_author_as_a_principal_and_projects_its_recipients() {
    let Some(fixture) = Fixture::new("author_projection").await else {
        return;
    };

    let stored = fixture
        .persistence
        .create_message(&inbound_email(
            fixture.thread.id,
            email_metadata(&format!("<author-{}@partner.test>", fixture.suffix)),
            "Body",
        ))
        .await
        .unwrap();

    assert_eq!(
        stored
            .author
            .identity
            .as_ref()
            .map(|identity| identity.subject().as_str()),
        Some("sender@partner.test")
    );
    let participant_subjects = |kind| {
        stored
            .participants
            .iter()
            .filter(|participant| participant.kind == kind)
            .map(|participant| participant.identity.subject().as_str())
            .collect::<Vec<_>>()
    };
    assert_eq!(
        participant_subjects(MessageParticipantKind::To),
        vec!["primary@example.com"]
    );
    assert_eq!(
        participant_subjects(MessageParticipantKind::Cc),
        vec!["watcher@partner.test"]
    );
    let extension = fixture
        .persistence
        .get_message_protocol_extension(stored.company_id, stored.canonical_id)
        .await
        .unwrap();
    assert_eq!(
        extension
            .email_metadata()
            .map(|metadata| metadata.rfc_message_id.as_str()),
        Some(format!("<author-{}@partner.test>", fixture.suffix).as_str())
    );

    let kind: String =
        sqlx::query_scalar("SELECT kind FROM principals WHERE company_id = $1 AND id = $2")
            .bind(fixture.company_id)
            .bind(stored.author.principal_id.as_uuid())
            .fetch_one(&fixture.pool)
            .await
            .unwrap();
    assert_eq!(kind, "external", "a stranger's mailbox is an outside actor");

    fixture.cleanup().await;
}

/// Participant rows are written by one statement. They still come out one per handle per role, in
/// the order each role stated them: a handle repeated in `To:` lands once, the same handle in `Cc:`
/// lands there as well, and a message with no participants writes none.
#[tokio::test]
async fn participants_keep_their_order_within_each_role_and_a_repeated_handle_lands_once() {
    let Some(fixture) = Fixture::new("participant_rows").await else {
        return;
    };
    let rows = |message_id: CanonicalMessageId| {
        sqlx::query_scalar::<_, String>(
            r#"SELECT participant.kind || ':' || participant.position || ':' || identity.subject
               FROM message_participants AS participant
               JOIN participant_identities AS identity
                 ON identity.company_id = participant.company_id
                AND identity.id = participant.participant_identity_id
               WHERE participant.company_id = $1 AND participant.message_id = $2
               ORDER BY participant.kind, participant.position"#,
        )
        .bind(fixture.company_id)
        .bind(message_id.as_uuid())
        .fetch_all(&fixture.pool)
    };

    let mut write = inbound_email(
        fixture.thread.id,
        email_metadata(&format!("<participants-{}@partner.test>", fixture.suffix)),
        "Body",
    );
    write.participants = vec![
        participant(MessageParticipantKind::Sender, "sender@partner.test"),
        participant(MessageParticipantKind::To, "first@example.com"),
        participant(MessageParticipantKind::To, "second@example.com"),
        participant(MessageParticipantKind::To, "first@example.com"),
        participant(MessageParticipantKind::To, "third@example.com"),
        participant(MessageParticipantKind::Cc, "first@example.com"),
    ];
    let stored = fixture.persistence.create_message(&write).await.unwrap();
    assert_eq!(
        rows(stored.canonical_id).await.unwrap(),
        vec![
            "cc:0:first@example.com",
            "sender:0:sender@partner.test",
            "to:0:first@example.com",
            "to:1:second@example.com",
            "to:2:third@example.com",
        ]
    );

    let note = fixture
        .persistence
        .create_message(&MessageWrite::internal(
            fixture.thread.id,
            MessageAuthorWrite::Platform,
            "Note",
            "No one is addressed.",
            MessageDirection::Inbound,
            MessageRole::System,
            CorrelationId::new(),
        ))
        .await
        .expect("a message with no participants is stored");
    assert!(rows(note.canonical_id).await.unwrap().is_empty());

    fixture.cleanup().await;
}

/// A schedule prompt, an approval note and an agent's answer are complete messages with no mail
/// behind them at all -- no address, no Message-ID, no recipients.
#[tokio::test]
async fn a_message_no_transport_carried_needs_no_email_fields() {
    let Some(fixture) = Fixture::new("internal_message").await else {
        return;
    };

    let note = fixture
        .persistence
        .create_message(&MessageWrite::internal(
            fixture.thread.id,
            MessageAuthorWrite::Platform,
            "[HITL Granted]: Refund",
            "Human approval GRANTED.",
            MessageDirection::Inbound,
            MessageRole::System,
            CorrelationId::new(),
        ))
        .await
        .unwrap();

    assert!(note.participants.is_empty());
    assert_eq!(note.author.display(), "System");
    assert!(
        fixture
            .persistence
            .get_message_protocol_extension(note.company_id, note.canonical_id)
            .await
            .unwrap()
            .email_metadata()
            .is_none()
    );

    let kind: String =
        sqlx::query_scalar("SELECT kind FROM principals WHERE company_id = $1 AND id = $2")
            .bind(fixture.company_id)
            .bind(note.author.principal_id.as_uuid())
            .fetch_one(&fixture.pool)
            .await
            .unwrap();
    assert_eq!(kind, "system");

    // The platform is one actor per company, however many notes it writes.
    let second = fixture
        .persistence
        .create_message(&MessageWrite::internal(
            fixture.thread.id,
            MessageAuthorWrite::Platform,
            "[HITL Rejected]: Refund",
            "Human approval REJECTED.",
            MessageDirection::Inbound,
            MessageRole::System,
            CorrelationId::new(),
        ))
        .await
        .unwrap();
    assert_eq!(second.author.principal_id, note.author.principal_id);

    // Nothing correlated it, so nothing claims a provider key for it either.
    let mapped: i64 =
        sqlx::query_scalar("SELECT COUNT(*) FROM external_messages WHERE company_id = $1")
            .bind(fixture.company_id)
            .fetch_one(&fixture.pool)
            .await
            .unwrap();
    assert_eq!(mapped, 0);

    fixture.cleanup().await;
}

/// The idempotency guard: an answer already in the thread means the run happened, and an outbound
/// relay entry -- the conversation handed to another channel -- is not that answer.
#[tokio::test]
async fn find_outbound_reply_after_sees_answers_and_ignores_relayed_mail() {
    let Some(fixture) = Fixture::new("outbound_reply").await else {
        return;
    };

    let trigger = fixture
        .persistence
        .create_message(&inbound_email(
            fixture.thread.id,
            email_metadata(&format!("<trigger-{}@partner.test>", fixture.suffix)),
            "Please answer",
        ))
        .await
        .unwrap();

    assert!(
        fixture
            .persistence
            .find_outbound_reply_after(fixture.thread.id, trigger.canonical_id)
            .await
            .unwrap()
            .is_none(),
        "nothing has answered yet"
    );

    let relay_rfc = format!("<relay-{}@partner.test>", fixture.suffix);
    let relay = fixture
        .persistence
        .create_message(&MessageWrite {
            structured: None,
            id: CanonicalMessageId::random(),
            thread_id: fixture.thread.id,
            author: observed("primary@example.com", IdentityProvenance::Agent),
            subject: "Relayed".into(),
            clean_text_body: "Handed to another channel".into(),
            attachments: Vec::new(),
            direction: MessageDirection::Outbound,
            role: MessageRole::Agent,
            audience: crate::entities::message::MessageAudience::ExternalConversation,
            entry_kind: crate::entities::message::ThreadEntryKind::Delegation,
            correlation_id: CorrelationId::new(),
            participants: vec![participant(
                MessageParticipantKind::To,
                "target@partner.test",
            )],
            correlation: MessageCorrelation::Email(email_metadata(&relay_rfc)),
            created_at: Utc::now(),
        })
        .await
        .unwrap();

    assert!(
        fixture
            .persistence
            .find_outbound_reply_after(fixture.thread.id, trigger.canonical_id)
            .await
            .unwrap()
            .is_none(),
        "a relay entry is the conversation moving on, not the agent answering"
    );

    let answer = fixture
        .persistence
        .create_message(&MessageWrite {
            structured: None,
            id: CanonicalMessageId::random(),
            thread_id: fixture.thread.id,
            author: observed("primary@example.com", IdentityProvenance::Agent),
            subject: "Re: Subject".into(),
            clean_text_body: "Here is the answer".into(),
            attachments: Vec::new(),
            direction: MessageDirection::Outbound,
            role: MessageRole::Agent,
            audience: crate::entities::message::MessageAudience::ExternalConversation,
            entry_kind: crate::entities::message::ThreadEntryKind::Conversation,
            correlation_id: CorrelationId::new(),
            participants: vec![participant(
                MessageParticipantKind::To,
                "sender@partner.test",
            )],
            correlation: MessageCorrelation::Email(email_metadata(&format!(
                "<answer-{}@partner.test>",
                fixture.suffix
            ))),
            created_at: Utc::now() + chrono::Duration::seconds(1),
        })
        .await
        .unwrap();

    let found = fixture
        .persistence
        .find_outbound_reply_after(fixture.thread.id, trigger.canonical_id)
        .await
        .unwrap()
        .expect("the answer must be found");
    assert_eq!(found.canonical_id, answer.canonical_id);
    assert_ne!(found.canonical_id, relay.canonical_id);

    fixture.cleanup().await;
}

/// The last association of a message is what a live column marks a thread by.
#[tokio::test]
async fn a_deleted_association_takes_an_orphaned_payload_with_it() {
    let Some(fixture) = Fixture::new("orphan_cleanup").await else {
        return;
    };

    let second_channel = fixture.extra_channel("mirror").await;
    let second_thread = fixture.extra_thread(second_channel, "Subject").await;
    let stored = fixture
        .persistence
        .create_message(&inbound_email(
            fixture.thread.id,
            email_metadata(&format!("<orphan-{}@partner.test>", fixture.suffix)),
            "Body",
        ))
        .await
        .unwrap();
    fixture
        .persistence
        .associate_message(
            second_thread.id,
            stored.canonical_id,
            crate::entities::message::ThreadEntryKind::Conversation,
        )
        .await
        .unwrap();

    sqlx::query("DELETE FROM thread_messages WHERE id = $1")
        .bind(stored.id)
        .execute(&fixture.pool)
        .await
        .unwrap();
    let surviving: i64 = sqlx::query_scalar("SELECT COUNT(*) FROM messages WHERE id = $1")
        .bind(stored.canonical_id.as_uuid())
        .fetch_one(&fixture.pool)
        .await
        .unwrap();
    assert_eq!(surviving, 1, "another thread still holds it");

    sqlx::query("DELETE FROM thread_messages WHERE message_id = $1")
        .bind(stored.canonical_id.as_uuid())
        .execute(&fixture.pool)
        .await
        .unwrap();
    let remaining: i64 = sqlx::query_scalar("SELECT COUNT(*) FROM messages WHERE id = $1")
        .bind(stored.canonical_id.as_uuid())
        .fetch_one(&fixture.pool)
        .await
        .unwrap();
    assert_eq!(remaining, 0, "the last association takes the payload");

    fixture.cleanup().await;
}

async fn owner_principal(fixture: &Fixture) -> crate::entities::transport::PrincipalId {
    crate::entities::transport::PrincipalId::new(
        sqlx::query_scalar::<_, Uuid>(
            "SELECT id FROM principals WHERE company_id = $1 AND user_id = $2",
        )
        .bind(fixture.company_id)
        .bind(fixture.owner_id)
        .fetch_one(&fixture.pool)
        .await
        .unwrap(),
    )
}

/// A note on the fixture's thread; returns its command id, which names the `internal_notes` row.
async fn note(fixture: &Fixture) -> Uuid {
    let command_id = Uuid::new_v4();
    fixture
        .persistence
        .create_internal_note(
            &AddInternalNote {
                company_id: fixture.company_id,
                target: crate::entities::address::AddressTarget::Desk(fixture.channel_id),
                thread_id: fixture.thread.id,
                text: "Checked with finance.".into(),
                command_id,
                supersedes_note_id: None,
                provenance: InternalNoteProvenance::Api,
            },
            owner_principal(fixture).await,
        )
        .await
        .unwrap();
    command_id
}

/// fix-app 05 batch 4: an internal note's message is filed in the note's own thread. The key is
/// deferred like the note's message key, so the violation is reported at commit.
#[tokio::test]
async fn message_thread_fk_internal_note_message_is_filed_in_its_own_thread() {
    // Its own database: disabling the audit trigger locks `internal_notes` until the commit.
    let Some(fixture) = Fixture::isolated("note_thread_fk").await else {
        return;
    };
    let command = note(&fixture).await;
    let rival = fixture.extra_thread(fixture.channel_id, "Rival").await;
    let mut tx = fixture.pool.begin().await.unwrap();
    // Only the audit trigger stands between this test and a moved note; the key must hold alone.
    sqlx::query("ALTER TABLE internal_notes DISABLE TRIGGER internal_notes_immutable")
        .execute(&mut *tx)
        .await
        .unwrap();
    let moved = sqlx::query(
        "UPDATE internal_notes SET thread_id = $3 WHERE company_id = $1 AND command_id = $2",
    )
    .bind(fixture.company_id)
    .bind(command)
    .bind(rival.id)
    .execute(&mut *tx)
    .await
    .unwrap();
    assert_eq!(moved.rows_affected(), 1);
    let refused = tx.commit().await.unwrap_err();
    assert_eq!(
        refused.as_database_error().unwrap().constraint(),
        Some("internal_notes_thread_message_fk"),
        "{refused}"
    );
    fixture.cleanup().await;
}

/// fix-app 05 batch 3: a provider conversation maps into a thread of the binding's own channel.
#[tokio::test]
async fn channel_path_fk_external_thread_stays_on_its_binding_channel() {
    let Some(fixture) = Fixture::new("external_thread_channel").await else {
        return;
    };
    let slack = fixture.slack_binding(&format!("C{}", fixture.suffix)).await;
    let other_channel = fixture.extra_channel("other").await;
    let elsewhere = fixture.extra_thread(other_channel, "Elsewhere").await;
    let insert = |channel: Uuid, thread: Uuid| {
        sqlx::query(
            "INSERT INTO external_threads (id, company_id, channel_id, binding_id, external_thread_key, thread_id) \
             VALUES ($1, $2, $3, $4, $5, $6)",
        )
        .bind(Uuid::new_v4())
        .bind(fixture.company_id)
        .bind(channel)
        .bind(slack.as_uuid())
        .bind(format!("1712345678.{}", Uuid::new_v4().simple()))
        .bind(thread)
    };
    for (channel, thread, constraint) in [
        // The binding's channel named, the thread from another channel.
        (
            fixture.channel_id,
            elsewhere.id,
            "external_threads_thread_fk",
        ),
        // The thread's channel named, the binding from another channel.
        (other_channel, elsewhere.id, "external_threads_binding_fk"),
    ] {
        let error = insert(channel, thread)
            .execute(&fixture.pool)
            .await
            .unwrap_err();
        assert_eq!(
            error.as_database_error().unwrap().constraint(),
            Some(constraint),
            "{error}"
        );
    }
    insert(fixture.channel_id, fixture.thread.id)
        .execute(&fixture.pool)
        .await
        .unwrap();
    fixture.cleanup().await;
}

async fn scoped_count(fixture: &Fixture, table: &str) -> i64 {
    sqlx::query_scalar(&format!(
        "SELECT count(*) FROM {table} WHERE company_id = $1"
    ))
    .bind(fixture.company_id)
    .fetch_one(&fixture.pool)
    .await
    .unwrap()
}

/// External threads and internal notes leave with their channel (raw SQL; the application refuses
/// a channel with conversations earlier) and with their company.
#[tokio::test]
async fn channel_path_fk_external_threads_and_notes_leave_with_channel_and_company() {
    for whole_company in [false, true] {
        let Some(fixture) = Fixture::new("external_thread_delete").await else {
            return;
        };
        let slack = fixture.slack_binding(&format!("C{}", fixture.suffix)).await;
        let mut connection = fixture.pool.acquire().await.unwrap();
        external::upsert_external_thread(
            &mut connection,
            external::ExternalThreadMapping {
                company_id: fixture.company_id,
                target: crate::entities::address::AddressTarget::Desk(fixture.channel_id),
                binding_id: slack,
                key: &ExternalThreadKey::parse("1712345678.000200").unwrap(),
                thread_id: fixture.thread.id,
            },
        )
        .await
        .unwrap();
        drop(connection);
        note(&fixture).await;
        assert_eq!(scoped_count(&fixture, "external_threads").await, 1);
        assert_eq!(scoped_count(&fixture, "internal_notes").await, 1);
        if whole_company {
            fixture.cleanup().await;
        } else {
            sqlx::query("DELETE FROM channels WHERE company_id = $1 AND id = $2")
                .bind(fixture.company_id)
                .bind(fixture.channel_id)
                .execute(&fixture.pool)
                .await
                .unwrap();
        }
        assert_eq!(scoped_count(&fixture, "external_threads").await, 0);
        assert_eq!(scoped_count(&fixture, "internal_notes").await, 0);
        if whole_company {
            let left: i64 = sqlx::query_scalar("SELECT count(*) FROM companies WHERE id = $1")
                .bind(fixture.company_id)
                .fetch_one(&fixture.pool)
                .await
                .unwrap();
            assert_eq!(left, 0, "the company deletion went through");
        } else {
            fixture.cleanup().await;
        }
    }
}

#[path = "jsonb_row_context_tests.rs"]
mod jsonb_row_context_tests;
