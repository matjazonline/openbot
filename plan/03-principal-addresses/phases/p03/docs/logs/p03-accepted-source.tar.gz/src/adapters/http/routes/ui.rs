//! `/ui` — the mailbox reader: channels on the left, that channel's threads next to them, and the
//! selected thread's messages on the right.
//!
//! Every handler here renders one column of [`crate::adapters::http::pages::mailbox`]; the columns
//! are swapped independently over htmx. Thread paging reuses the cursor helpers in
//! [`super::channel`] so both thread lists page identically.

use std::{
    collections::{HashMap, HashSet},
    convert::Infallible,
    str::FromStr,
    sync::Arc,
};

use axum::{
    Form, Router,
    extract::{Query, State},
    http::HeaderMap,
    response::{
        Html, IntoResponse, Response,
        sse::{Event, KeepAlive, Sse},
    },
    routing::get,
};
use serde::Deserialize;
use tokio_stream::{Stream, StreamExt};
use tracing::{instrument, warn};
use uuid::Uuid;

use crate::adapters::http::app_state::AppState;
use crate::adapters::http::auth::AuthenticatedUser;
use crate::adapters::http::pages;
use crate::app_error::AppError;
use crate::app_error::AppResult;
use crate::application::ports::thread::qualified_email_identity;
use crate::application::thread_activity::ThreadActivityReader;
use crate::entities::company::Company;
use crate::entities::company::CompanyAccess;
use crate::entities::company_member::CompanyMembership;
use crate::entities::message::CanonicalMessageId;
use crate::entities::thread::Thread;
use crate::entities::thread_activity::ThreadActivity;
use crate::entities::user::User;
use crate::entities::user::Viewer;
use crate::entities::value_objects::EmailAddress;
use crate::infra::config::AppConfig;
use crate::infra::events::MailboxEvent;
use crate::infra::events::MailboxEvents;
use crate::use_cases::channel::ChannelUseCases;
use crate::use_cases::company::CompanyUseCases;
use crate::use_cases::thread::CanonicalMessageIngress;
use crate::use_cases::thread::IngressOrigin;
use crate::use_cases::thread::ReplyDelivery;
use crate::use_cases::thread::{ReadableInbox, ThreadUseCases};

pub(super) mod inbox;
use crate::use_cases::user::UserUseCases;
pub(super) use inbox::InboxSelection;

use super::{
    channel::{ThreadListQuery, ThreadListResponse, load_thread_page},
    live_updates::{Wake, thread_wake_ups},
};

#[path = "ui_message.rs"]
mod message;

pub fn router() -> Router<AppState> {
    Router::new()
        .route("/ui", get(mailbox_page))
        .route("/ui/threads", get(thread_column_fragment))
        .route("/ui/threads/list", get(thread_page_fragment))
        .route("/ui/messages", get(message_pane_fragment))
        .route("/ui/message", get(message::page))
        .route("/ui/events", get(thread_message_stream))
        .route("/ui/threads/events", get(thread_column_stream))
        .route("/ui/compose", get(compose_form).post(create_thread))
        .route("/ui/reply", get(reply_form).post(send_reply))
        .merge(super::ui_internal_notes::router())
}

/// What the mailbox shell has selected, all optional so `/ui` alone is a valid entry point.
#[derive(Debug, Clone, Deserialize)]
pub struct MailboxQuery {
    pub company_id: Option<Uuid>,
    #[serde(flatten)]
    pub inbox: InboxSelection,
    pub thread_id: Option<Uuid>,
}

#[derive(Debug, Clone, Deserialize)]
pub struct ChannelQuery {
    pub company_id: Uuid,
    #[serde(flatten)]
    pub inbox: InboxSelection,
}

#[derive(Debug, Clone, Deserialize)]
pub struct ThreadPageQuery {
    pub company_id: Uuid,
    #[serde(flatten)]
    pub inbox: InboxSelection,
    pub cursor: Option<String>,
    pub limit: Option<usize>,
}

#[derive(Debug, Clone, Deserialize)]
pub struct ThreadQuery {
    pub company_id: Uuid,
    #[serde(flatten)]
    pub inbox: InboxSelection,
    pub thread_id: Uuid,
}

/// A channel whose thread column to stream, plus the newest thread the column was rendered with.
#[derive(Debug, Clone, Deserialize)]
pub struct ChannelStreamQuery {
    pub company_id: Uuid,
    #[serde(flatten)]
    pub inbox: InboxSelection,
    pub after: Option<String>,
}

/// A thread to stream, plus the newest message the page was rendered with.
#[derive(Debug, Clone, Deserialize)]
pub struct ThreadStreamQuery {
    pub company_id: Uuid,
    #[serde(flatten)]
    pub inbox: InboxSelection,
    pub thread_id: Uuid,
    pub after: Option<String>,
}

#[derive(Debug, Clone, Deserialize)]
pub struct ComposeForm {
    pub company_id: Uuid,
    #[serde(flatten)]
    pub inbox: InboxSelection,
    pub subject: Option<String>,
    pub text_body: Option<String>,
    /// Present only when the "deliver by email" toggle is on.
    pub deliver: Option<String>,
}

/// A further message in a thread that is already open; its subject comes from the thread.
#[derive(Debug, Clone, Deserialize)]
pub struct ReplyForm {
    pub company_id: Uuid,
    #[serde(flatten)]
    pub inbox: InboxSelection,
    pub thread_id: Uuid,
    pub reply_to_message_id: Option<Uuid>,
    pub text_body: Option<String>,
    /// Present only when the "deliver by email" toggle is on.
    pub deliver: Option<String>,
}

/// How the "deliver by email" toggle arrives on both send forms.
fn delivery_requested(deliver: Option<&str>) -> bool {
    matches!(deliver, Some("true") | Some("on"))
}

/// Delivering means the agent's reply is really emailed; otherwise it stays in the mailbox.
fn delivery_mode(deliver: bool) -> ReplyDelivery {
    if deliver {
        ReplyDelivery::Send
    } else {
        ReplyDelivery::InAppOnly
    }
}

/// A management request's company: explicit IDs use the one-row manager check (404/403).
/// The list only fills the switcher and supplies the default when nothing is requested.
pub(super) async fn load_managed_company(
    company_use_cases: &CompanyUseCases,
    user_id: Uuid,
    requested: Option<Uuid>,
) -> AppResult<(Vec<Company>, Option<CompanyAccess>)> {
    let selected = match requested {
        Some(id) => Some(company_use_cases.managed_company(user_id, id).await?),
        None => None,
    };
    let managed = company_use_cases.list_managed_companies(user_id).await?;
    let selected = selected.or_else(|| managed.first().cloned());
    let companies = managed.into_iter().map(|access| access.company).collect();
    Ok((companies, selected))
}

/// The company a *read* is scoped to, from the companies the caller may see rather than only the
/// ones they own -- an invited member reads their team's mail, but still administers nothing.
///
/// An explicitly requested company is authorized on its own (`readable_company`); the list fills
/// the switcher and supplies the default.
pub(super) async fn load_readable_company(
    company_use_cases: &CompanyUseCases,
    user_id: Uuid,
    requested: Option<Uuid>,
) -> AppResult<(Vec<Company>, Option<CompanyAccess>)> {
    let accessible = company_use_cases.list_accessible_companies(user_id).await?;
    let selected = match requested {
        Some(id) => Some(company_use_cases.readable_company(user_id, id).await?),
        None => accessible.first().cloned(),
    };

    let companies = accessible.into_iter().map(|a| a.company).collect();
    Ok((companies, selected))
}

fn empty_thread_page() -> ThreadListResponse {
    ThreadListResponse {
        threads: Vec::new(),
        next_cursor: None,
        has_more: false,
    }
}

/// What each thread in a rendered page is doing, in one batched lookup.
///
/// Every column render goes through this rather than asking per row: a page is up to 50 threads,
/// and a query each would be 50 round trips for a badge most of them do not have.
async fn page_activity(
    activity_reader: &dyn ThreadActivityReader,
    company_id: Uuid,
    threads: &[Thread],
) -> AppResult<HashMap<Uuid, ThreadActivity>> {
    let ids: Vec<Uuid> = threads.iter().map(|thread| thread.id).collect();
    Ok(activity_reader
        .thread_activity(company_id, &ids)
        .await?
        .into_iter()
        .filter_map(|(thread_id, summary)| summary.activity.map(|activity| (thread_id, activity)))
        .collect())
}

/// Thread ids whose activity badges a newly connected column may already be displaying.
async fn first_page_thread_ids(
    thread_use_cases: &ThreadUseCases,
    viewer: &Viewer,
    channel: &ReadableInbox,
) -> AppResult<HashSet<Uuid>> {
    Ok(thread_use_cases
        .list_inbox_threads(viewer, channel.into(), None, STREAM_BATCH_LIMIT)
        .await?
        .into_iter()
        .map(|thread| thread.id)
        .collect())
}

pub(super) async fn render_message_pane(
    thread_use_cases: &ThreadUseCases,
    activity_reader: &dyn ThreadActivityReader,
    company_id: Uuid,
    channel: &ReadableInbox,
    thread: &Thread,
    viewer: &Viewer,
    error: Option<&str>,
) -> AppResult<String> {
    let messages = thread_use_cases
        .get_thread_history(
            viewer,
            crate::use_cases::thread::ThreadReadScope::new(channel, thread.id),
        )
        .await?;
    let activity = activity_reader
        .thread_runs(company_id, thread.id, viewer.user_id)
        .await?;
    let viewer_membership = thread_use_cases
        .principal_access_for_user(company_id, viewer.user_id)
        .await?
        .map_or(CompanyMembership::None, |access| access.membership);
    thread_use_cases
        .readable_inbox(viewer, channel.scope())
        .await?;
    Ok(pages::message_pane(&pages::MessagePane {
        company_id,
        inbox: channel,
        thread,
        messages: &messages,
        viewer_email: &viewer.email,
        activity: &activity,
        error,
        viewer_membership,
    }))
}

/// GET /ui - The full mailbox shell for the selected company / channel / thread (Protected).
#[instrument(skip_all)]
#[expect(
    clippy::too_many_arguments,
    reason = "Axum handlers receive request state and extractors as parameters"
)]
async fn mailbox_page(
    State(company_use_cases): State<Arc<CompanyUseCases>>,
    State(channel_use_cases): State<Arc<ChannelUseCases>>,
    State(thread_use_cases): State<Arc<ThreadUseCases>>,
    State(activity_reader): State<Arc<dyn ThreadActivityReader>>,
    State(user_use_cases): State<Arc<UserUseCases>>,
    State(config): State<Arc<AppConfig>>,
    user: AuthenticatedUser,
    viewer: Viewer,
    Query(query): Query<MailboxQuery>,
) -> AppResult<Html<String>> {
    let account = load_account(&user_use_cases, user.id).await?;
    let account_email = EmailAddress::from(account.email.as_str());
    let mailbox_user = workspace_user(&account, &account_email, &config);

    let (companies, access) =
        load_readable_company(&company_use_cases, user.id, query.company_id).await?;
    let Some(access) = access else {
        return Ok(Html(pages::mailbox_no_company_page(&mailbox_user)));
    };
    let mailbox_user = mailbox_user.with_company_membership(access.membership);
    let company = access.company;

    let channels = channel_use_cases
        .list_readable_channels(&viewer, company.id)
        .await?;
    let mut direct = thread_use_cases.direct_inboxes(&viewer, company.id).await?;
    let direct_truncated = direct.len() > 200;
    direct.truncate(200);
    let mut inboxes: Vec<_> = channels.into_iter().map(ReadableInbox::from).collect();
    inboxes.extend(direct);
    let selected = match query.inbox.target()? {
        Some(target) => Some(
            thread_use_cases
                .readable_inbox(
                    &viewer,
                    crate::use_cases::thread::InboxReadScope {
                        company_id: company.id,
                        target,
                    },
                )
                .await?,
        ),
        None => inboxes.first().cloned(),
    };
    let selected_channel = selected.as_ref();

    let thread_page = match selected_channel {
        Some(channel) => {
            load_thread_page(
                &thread_use_cases,
                &viewer,
                channel,
                &ThreadListQuery::default(),
            )
            .await?
        }
        None => empty_thread_page(),
    };

    let selected_thread = match (selected_channel, query.thread_id) {
        (Some(channel), Some(thread_id)) => {
            thread_use_cases
                .readable_thread(&viewer, channel.company_id(), channel.target(), thread_id)
                .await?
        }
        (Some(_), None) => thread_page.threads.first().cloned(),
        (None, _) => None,
    };

    let detail_html = match (selected_channel, &selected_thread) {
        (Some(channel), Some(thread)) => {
            render_message_pane(
                &thread_use_cases,
                activity_reader.as_ref(),
                company.id,
                channel,
                thread,
                &viewer,
                None,
            )
            .await?
        }
        (Some(_), None) => pages::empty_detail_pane(
            "Select a thread, or use New Thread to start a new one.",
            pages::FragmentSwap::Inline,
        ),
        (None, _) => {
            pages::empty_detail_pane("Select a desk to get started.", pages::FragmentSwap::Inline)
        }
    };

    let activity =
        page_activity(activity_reader.as_ref(), company.id, &thread_page.threads).await?;
    if let Some(inbox) = selected_channel {
        thread_use_cases
            .readable_inbox(&viewer, inbox.scope())
            .await?;
    } else {
        company_use_cases
            .readable_company(viewer.user_id, company.id)
            .await?;
    }
    Ok(Html(pages::mailbox_page(&pages::MailboxPage {
        user: &mailbox_user,
        company: &company,
        companies: &companies,
        app_domain_name: &config.app_domain_name,
        inboxes: &inboxes,
        selected_inbox: selected_channel,
        direct_truncated,
        threads: &thread_page.threads,
        next_cursor: thread_page.next_cursor.as_deref(),
        selected_thread_id: selected_thread.as_ref().map(|thread| thread.id),
        activity: &activity,
        detail_html: &detail_html,
    })))
}

/// GET /ui/threads - The thread column for a channel, clearing the detail pane (Protected).
#[instrument(skip_all)]
async fn thread_column_fragment(
    State(_channel_use_cases): State<Arc<ChannelUseCases>>,
    State(thread_use_cases): State<Arc<ThreadUseCases>>,
    State(activity_reader): State<Arc<dyn ThreadActivityReader>>,
    State(config): State<Arc<AppConfig>>,
    viewer: Viewer,
    Query(query): Query<ChannelQuery>,
) -> AppResult<Html<String>> {
    let channel = thread_use_cases
        .readable_inbox(&viewer, query.inbox.scope(query.company_id)?)
        .await?;

    let page = load_thread_page(
        &thread_use_cases,
        &viewer,
        &channel,
        &ThreadListQuery::default(),
    )
    .await?;

    let activity = page_activity(activity_reader.as_ref(), query.company_id, &page.threads).await?;
    thread_use_cases
        .readable_inbox(&viewer, channel.scope())
        .await?;
    let column = pages::thread_column(&pages::ThreadColumn {
        company_id: query.company_id,
        inbox: &channel,
        app_domain_name: &config.app_domain_name,
        threads: &page.threads,
        next_cursor: page.next_cursor.as_deref(),
        selected_thread_id: None,
        activity: &activity,
    });
    let detail = pages::empty_detail_pane(
        "Select a thread, or use New Thread to start a new one.",
        pages::FragmentSwap::OutOfBand,
    );
    let actions = pages::channel_actions(
        query.company_id,
        channel.desk(),
        pages::FragmentSwap::OutOfBand,
    );

    Ok(Html(format!("{column}{detail}{actions}")))
}

/// GET /ui/threads/list - One older page of threads, appended to the open column (Protected).
#[instrument(skip_all)]
async fn thread_page_fragment(
    State(_channel_use_cases): State<Arc<ChannelUseCases>>,
    State(thread_use_cases): State<Arc<ThreadUseCases>>,
    State(activity_reader): State<Arc<dyn ThreadActivityReader>>,
    State(config): State<Arc<AppConfig>>,
    viewer: Viewer,
    Query(query): Query<ThreadPageQuery>,
) -> AppResult<Html<String>> {
    let channel = thread_use_cases
        .readable_inbox(&viewer, query.inbox.scope(query.company_id)?)
        .await?;

    let page = load_thread_page(
        &thread_use_cases,
        &viewer,
        &channel,
        &ThreadListQuery {
            limit: query.limit,
            cursor: query.cursor,
        },
    )
    .await?;

    let activity = page_activity(activity_reader.as_ref(), query.company_id, &page.threads).await?;
    thread_use_cases
        .readable_inbox(&viewer, channel.scope())
        .await?;
    Ok(Html(pages::thread_list_fragment(
        &pages::ThreadColumn {
            company_id: query.company_id,
            inbox: &channel,
            app_domain_name: &config.app_domain_name,
            threads: &page.threads,
            next_cursor: page.next_cursor.as_deref(),
            selected_thread_id: None,
            activity: &activity,
        },
        pages::FragmentSwap::OutOfBand,
    )))
}

/// GET /ui/messages - The messages of one thread (Protected).
#[instrument(skip_all)]
async fn message_pane_fragment(
    State(_channel_use_cases): State<Arc<ChannelUseCases>>,
    State(thread_use_cases): State<Arc<ThreadUseCases>>,
    State(activity_reader): State<Arc<dyn ThreadActivityReader>>,
    viewer: Viewer,
    Query(query): Query<ThreadQuery>,
) -> AppResult<Html<String>> {
    let channel = thread_use_cases
        .readable_inbox(&viewer, query.inbox.scope(query.company_id)?)
        .await?;
    let thread = thread_use_cases
        .readable_thread(
            &viewer,
            channel.company_id(),
            channel.target(),
            query.thread_id,
        )
        .await?
        .ok_or_else(|| AppError::NotFound("Thread not found".into()))?;

    Ok(Html(
        render_message_pane(
            &thread_use_cases,
            activity_reader.as_ref(),
            query.company_id,
            &channel,
            &thread,
            &viewer,
            None,
        )
        .await?,
    ))
}

/// How far ahead of a reader one wake-up may catch them up. A reader further behind than this
/// gets the rest on the next event, rather than one query loading an unbounded backlog.
const STREAM_BATCH_LIMIT: usize = 50;

/// Where a live stream resumes from, in order of authority.
///
/// `Last-Event-ID` is the browser's own record of the last bubble it rendered, replayed
/// automatically when a dropped connection is re-established — so it beats anything the page was
/// rendered with. The `after` parameter is that page render's own high-water mark, which covers a
/// message landing between the render and the browser connecting. With neither, the thread streams
/// from its start, which is right for a thread that rendered empty.
fn resume_cursor<C: FromStr>(headers: &HeaderMap, after: Option<&str>) -> Option<C> {
    headers
        .get("last-event-id")
        .and_then(|value| value.to_str().ok())
        .or(after)
        .and_then(|raw| raw.parse().ok())
}

/// GET /ui/events - The open thread's messages as they are persisted (Protected).
///
/// Each event is one rendered chat bubble, appended to `#message-scroll` by htmx's SSE extension.
/// The `id:` on every event is that message's cursor, which is what makes reconnects resume
/// exactly where the reader left off.
#[instrument(skip_all)]
async fn thread_message_stream(
    State(_channel_use_cases): State<Arc<ChannelUseCases>>,
    State(thread_use_cases): State<Arc<ThreadUseCases>>,
    State(activity_reader): State<Arc<dyn ThreadActivityReader>>,
    State(events): State<MailboxEvents>,
    viewer: Viewer,
    headers: HeaderMap,
    Query(query): Query<ThreadStreamQuery>,
) -> AppResult<Sse<impl Stream<Item = Result<Event, Infallible>>>> {
    // Authorize the stream path; each application message batch repeats current access and level
    // checks, so a long-lived connection never caches a knowledge grant.
    let channel = thread_use_cases
        .readable_inbox(&viewer, query.inbox.scope(query.company_id)?)
        .await?;
    let thread = thread_use_cases
        .readable_thread(
            &viewer,
            channel.company_id(),
            channel.target(),
            query.thread_id,
        )
        .await?
        .ok_or_else(|| AppError::NotFound("Thread not found".into()))?;

    let mut cursor = resume_cursor(&headers, query.after.as_deref());
    let thread_id = thread.id;
    let mut wake_ups = Box::pin(thread_wake_ups(&events, "messages", thread_id));

    let stream = async_stream::stream! {
        // Both start true so a connect emits the reader's backlog and the current activity, rather
        // than leaving a freshly opened thread blank until something happens to change.
        let mut pending_messages = true;
        let mut pending_activity = true;

        loop {
            if pending_activity {
                pending_activity = false;
                match activity_reader.thread_runs(query.company_id, thread_id, viewer.user_id)
                    .await
                {
                    // Activity is state, not an append: it carries no cursor and is re-read whole
                    // every time, which is also what makes it correct after a reconnect. A thread
                    // with no run renders as an empty strip, clearing whatever was there.
                    Ok(activity) => {
                        if thread_use_cases.readable_inbox(&viewer, channel.scope()).await.is_err() { return; }
                        let run_access = pages::RunLinkAccess::Authorized(&activity.inspectable);
                        let html = format!("{}{}", pages::thread_activity_strip(&activity, query.company_id, run_access), pages::thread_run_attribution_updates(&activity, query.company_id, run_access));
                        yield Ok(Event::default()
                            .event("activity")
                            .data(html));
                    }
                    Err(_) => {
                        warn!(%thread_id, "Thread activity query failed");
                        return;
                    }
                }
            }

            if pending_messages {
                match thread_use_cases
                    .get_thread_messages_after(&viewer, crate::use_cases::thread::ThreadReadScope::new(&channel, thread_id), cursor, STREAM_BATCH_LIMIT)
                    .await
                {
                    Ok(messages) => {
                        let ids: Vec<_> = messages.iter().flat_map(|message| message.run_ids.iter().copied()).collect();
                        let inspectable = match activity_reader.inspectable_runs(query.company_id, viewer.user_id, &ids).await {
                            Ok(ids) => ids,
                            Err(_) => { warn!(%thread_id, "Message run visibility query failed"); return; }
                        };
                        if thread_use_cases.readable_inbox(&viewer, channel.scope()).await.is_err() { return; }
                        for message in &messages {
                            cursor = Some(message.cursor());
                            yield Ok(Event::default()
                                .id(message.cursor().to_string())
                                .event("message")
                                .data(pages::message_bubble_chat(
                                    message,
                                    Some(&viewer.email),
                                    pages::MessageScope {
                                        company_id: query.company_id,
                                        target: channel.target(),
                                    },
                                    pages::RunLinkAccess::Authorized(&inspectable),
                                )));
                        }
                        // A full batch means the reader is still behind; keep going rather than
                        // waiting for an event that may never come.
                        pending_messages = messages.len() == STREAM_BATCH_LIMIT;
                        if pending_messages {
                            continue;
                        }
                    }
                    // Ending the stream makes the browser reconnect with `Last-Event-ID`, which
                    // resumes from the same cursor -- the right response to a transient failure.
                    Err(_) => {
                        warn!(%thread_id, "Message stream query failed");
                        return;
                    }
                }
            }

            match wake_ups.next().await {
                Some(Wake::Event(MailboxEvent::MessageCommitted(_))) => { pending_messages = true; pending_activity = true; },
                Some(Wake::Event(MailboxEvent::ActivityChanged(_))) => pending_activity = true,
                // Thread-scoped wake_ups filters these out before they reach this stream; a resync
                // arrives as `Lagged`, and a run on this thread reaches it as activity.
                Some(Wake::Event(
                    MailboxEvent::AttentionChanged(_)
                    | MailboxEvent::NotificationChanged(_)
                    | MailboxEvent::WorkflowRunChanged(_)
                    | MailboxEvent::Resync,
                )) => {}
                // Something was missed and there is no telling what, so redo both.
                Some(Wake::Lagged) => {
                    pending_messages = true;
                    pending_activity = true;
                }
                None => return,
            }
        }
    };

    // Without the heartbeat an idle stream looks dead to the proxy in front of the app and is
    // dropped after a minute or two.
    Ok(Sse::new(stream).keep_alive(KeepAlive::default()))
}

/// GET /ui/threads/events - The channel's thread column as threads are touched (Protected).
///
/// Each event is one rendered thread card, inserted at the top of `#thread-list`. A thread that
/// receives a message is bumped to the top of the column, so "insert at top, drop the stale copy"
/// is the whole reordering — and it leaves any older pages the reader loaded on demand in place,
/// which re-rendering the first page would not.
#[instrument(skip_all)]
#[expect(
    clippy::too_many_arguments,
    reason = "Axum handlers receive request state and extractors as parameters"
)]
async fn thread_column_stream(
    State(_channel_use_cases): State<Arc<ChannelUseCases>>,
    State(thread_use_cases): State<Arc<ThreadUseCases>>,
    State(activity_reader): State<Arc<dyn ThreadActivityReader>>,
    State(events): State<MailboxEvents>,
    State(config): State<Arc<AppConfig>>,
    viewer: Viewer,
    headers: HeaderMap,
    Query(query): Query<ChannelStreamQuery>,
) -> AppResult<Sse<impl Stream<Item = Result<Event, Infallible>>>> {
    // Authorize the stream path; application row reads repeat current access and level checks.
    let channel = thread_use_cases
        .readable_inbox(&viewer, query.inbox.scope(query.company_id)?)
        .await?;

    let company_id = query.company_id;
    // Owned, because the stream outlives this handler's borrow of the config.
    let app_domain_name = config.app_domain_name.clone();
    let mut cursor = resume_cursor(&headers, query.after.as_deref());
    let target = channel.target();
    let mut wake_ups = Box::pin(super::live_updates::inbox_wake_ups(
        &events, "threads", target,
    ));
    // Subscribe first, then snapshot every badge that can already be on screen. An activity
    // change during this query stays buffered; one before the connection is recovered by the
    // snapshot itself.
    let initial_stale_badges = first_page_thread_ids(&thread_use_cases, &viewer, &channel).await?;

    let stream = async_stream::stream! {
        let mut pending_rows = true;
        // Threads whose badge is out of date. Kept as a set of ids rather than a flag because a
        // status change must redraw *only* that badge: re-sending the row would insert it at the
        // top of the column and move a thread for no reason a reader could see.
        let mut stale_badges = initial_stale_badges;

        loop {
            if !stale_badges.is_empty() {
                let ids: Vec<Uuid> = stale_badges.drain().collect();
                match activity_reader.thread_activity(company_id, &ids).await {
                    Ok(activity) => {
                        if thread_use_cases.readable_inbox(&viewer, channel.scope()).await.is_err() { return; }
                        for id in ids {
                            // A thread absent from the map has no run, and an empty payload is
                            // what clears its badge.
                            yield Ok(Event::default()
                                .event(pages::thread_activity_event(id))
                                .data(pages::thread_activity_mark(
                                    activity.get(&id).and_then(|summary| summary.activity),
                                )));
                        }
                    }
                    Err(_) => {
                        warn!(%target, "Thread activity query failed");
                        return;
                    }
                }
            }

            if pending_rows {
                match thread_use_cases
                    .inbox_threads_after(&viewer, (&channel).into(), cursor, STREAM_BATCH_LIMIT)
                    .await
                {
                    Ok(threads) => {
                        // A streamed row must arrive with its badge already on it, or a thread
                        // bumped mid-run would blink back to idle until its next run change.
                        let ids: Vec<Uuid> = threads.iter().map(|thread| thread.id).collect();
                        let activity = match page_activity(
                            activity_reader.as_ref(),
                            company_id,
                            &threads,
                        )
                        .await
                        {
                            Ok(activity) => activity,
                            Err(_) => {
                                warn!(%target, "Thread activity query failed");
                                return;
                            }
                        };
                        // Who spoke last, so the client can mark an agent's reply and stay quiet
                        // about a person's message. Only streamed rows need it.
                        let last_roles = match thread_use_cases.thread_last_roles(&ids).await {
                            Ok(roles) => roles,
                            Err(_) => {
                                warn!(%target, "Thread last-role query failed");
                                return;
                            }
                        };

                        if thread_use_cases.readable_inbox(&viewer, channel.scope()).await.is_err() { return; }
                        // Oldest first, so the newest is inserted last and ends up on top.
                        for thread in &threads {
                            cursor = Some(thread.cursor());
                            yield Ok(Event::default()
                                .id(thread.cursor().to_string())
                                .event("thread")
                                // Selection is a per-browser fact the server cannot know, so the
                                // row streams unselected and the client re-applies the highlight.
                                .data(pages::thread_row_fragment(
                                    company_id,
                                    &channel,
                                    thread,
                                    false,
                                    pages::ThreadRowMarks {
                                        activity: activity.get(&thread.id).copied(),
                                        last_role: last_roles.get(&thread.id).copied(),
                                        from_other_channel: pages::opened_by_another_channel(
                                            thread,
                                            &app_domain_name,
                                        ),
                                    },
                                )));
                        }
                        pending_rows = threads.len() == STREAM_BATCH_LIMIT;
                        if pending_rows {
                            continue;
                        }
                    }
                    Err(_) => {
                        warn!(%target, "Thread column stream query failed");
                        return;
                    }
                }
            }

            match wake_ups.next().await {
                Some(Wake::Event(MailboxEvent::MessageCommitted(_))) => pending_rows = true,
                Some(Wake::Event(MailboxEvent::ActivityChanged(scope))) => {
                    stale_badges.insert(scope.thread_id);
                }
                // Channel-scoped wake_ups filters these out before they reach this stream; a resync
                // arrives as `Lagged`, and a run on one of its threads reaches it as activity.
                Some(Wake::Event(
                    MailboxEvent::AttentionChanged(_)
                    | MailboxEvent::NotificationChanged(_)
                    | MailboxEvent::WorkflowRunChanged(_)
                    | MailboxEvent::Resync,
                )) => {}
                // What was missed is unknown, so redraw the rows and every badge the column is
                // likely to be showing rather than leave a stale spinner or a stale badge behind.
                Some(Wake::Lagged) => {
                    pending_rows = true;
                    match first_page_thread_ids(&thread_use_cases, &viewer, &channel).await {
                        Ok(ids) => stale_badges.extend(ids),
                        Err(_) => {
                            warn!(%target, "Thread column catch-up query failed");
                            return;
                        }
                    }
                }
                None => return,
            }
        }
    };

    Ok(Sse::new(stream).keep_alive(KeepAlive::default()))
}

/// GET /ui/compose - The new-thread form for the selected channel (Protected).
#[instrument(skip_all)]
async fn compose_form(
    State(company_use_cases): State<Arc<CompanyUseCases>>,
    State(thread_use_cases): State<Arc<ThreadUseCases>>,
    State(user_use_cases): State<Arc<UserUseCases>>,
    State(config): State<Arc<AppConfig>>,
    viewer: Viewer,
    Query(query): Query<ChannelQuery>,
) -> AppResult<Html<String>> {
    let (company, channel) = inbox::load_viewable_inbox(
        &company_use_cases,
        &thread_use_cases,
        &viewer,
        query.company_id,
        query.inbox,
    )
    .await?;
    let sender_email = sender_email(&user_use_cases, viewer.user_id).await?;

    Ok(Html(pages::compose_pane(&pages::ComposePane {
        company_id: company.id,
        inbox: &channel,
        channel_address: &inbox::send_address(&channel, &company, &config.app_domain_name)?,
        sender_email: &sender_email,
        subject: "",
        text_body: "",
        deliver: false,
        error: None,
    })))
}

/// POST /ui/compose - Start a new thread by feeding the composed message into the channel.
///
/// The message takes exactly the inbound path a real email would, so channel rules (participants,
/// spam, agents) apply unchanged; the toggle only decides whether the agent's reply is actually
/// delivered by email. That path is also why the guard here is the *read* guard: a participant who
/// is not the company's owner composes from the mailbox exactly as they would by email, and the
/// channel's own participant rules still decide whether the message lands.
#[instrument(skip_all)]
#[expect(
    clippy::too_many_arguments,
    reason = "Axum handlers receive request state and extractors as parameters"
)]
async fn create_thread(
    State(company_use_cases): State<Arc<CompanyUseCases>>,
    State(_channel_use_cases): State<Arc<ChannelUseCases>>,
    State(thread_use_cases): State<Arc<ThreadUseCases>>,
    State(activity_reader): State<Arc<dyn ThreadActivityReader>>,
    State(user_use_cases): State<Arc<UserUseCases>>,
    State(config): State<Arc<AppConfig>>,
    viewer: Viewer,
    Form(form): Form<ComposeForm>,
) -> AppResult<Response> {
    let (company, channel) = inbox::load_viewable_inbox(
        &company_use_cases,
        &thread_use_cases,
        &viewer,
        form.company_id,
        form.inbox,
    )
    .await?;
    let sender_email = sender_email(&user_use_cases, viewer.user_id).await?;
    let address = inbox::send_address(&channel, &company, &config.app_domain_name)?;

    let subject = form.subject.unwrap_or_default();
    let text_body = form.text_body.unwrap_or_default();
    let deliver = delivery_requested(form.deliver.as_deref());

    let compose_error = |message: String| {
        Html(pages::compose_pane(&pages::ComposePane {
            company_id: company.id,
            inbox: &channel,
            channel_address: address.as_str(),
            sender_email: &sender_email,
            subject: &subject,
            text_body: &text_body,
            deliver,
            error: Some(&message),
        }))
        .into_response()
    };

    if subject.trim().is_empty() || text_body.trim().is_empty() {
        return Ok(compose_error(
            "Subject and message are both required.".to_string(),
        ));
    }

    let author = qualified_email_identity(sender_email.as_str())?;
    let ingress = CanonicalMessageIngress::new(
        company.id,
        channel.target(),
        author,
        &text_body,
        IngressOrigin::TrustedApplication,
    )
    .with_subject(&subject)
    .with_reply_delivery(delivery_mode(deliver));

    let ingest = match thread_use_cases.ingest_canonical(ingress).await {
        Ok(ingest) => ingest,
        Err(err) => return Ok(compose_error(format!("Failed to send message: {err}"))),
    };

    let Some(thread) = ingest.thread.clone() else {
        let reason = ingest.reason().unwrap_or("The desk rejected this message.");
        return Ok(compose_error(reason.to_string()));
    };

    sent_message_response(
        &thread_use_cases,
        activity_reader.as_ref(),
        company.id,
        &channel,
        &config.app_domain_name,
        &thread,
        &viewer,
    )
    .await
}

/// GET /ui/reply - The new-message form for the open thread (Protected).
#[instrument(skip_all)]
async fn reply_form(
    State(company_use_cases): State<Arc<CompanyUseCases>>,
    State(_channel_use_cases): State<Arc<ChannelUseCases>>,
    State(thread_use_cases): State<Arc<ThreadUseCases>>,
    State(user_use_cases): State<Arc<UserUseCases>>,
    State(config): State<Arc<AppConfig>>,
    viewer: Viewer,
    Query(query): Query<ThreadQuery>,
) -> AppResult<Html<String>> {
    let (company, channel) = inbox::load_viewable_inbox(
        &company_use_cases,
        &thread_use_cases,
        &viewer,
        query.company_id,
        query.inbox,
    )
    .await?;
    let thread = thread_use_cases
        .readable_thread(
            &viewer,
            channel.company_id(),
            channel.target(),
            query.thread_id,
        )
        .await?
        .ok_or_else(|| AppError::NotFound("Thread not found".into()))?;
    let sender_email = sender_email(&user_use_cases, viewer.user_id).await?;

    Ok(Html(pages::reply_pane(&pages::ReplyPane {
        company_id: company.id,
        inbox: &channel,
        thread: &thread,
        channel_address: &inbox::send_address(&channel, &company, &config.app_domain_name)?,
        sender_email: &sender_email,
        text_body: "",
        deliver: false,
        error: None,
    })))
}

/// POST /ui/reply - Send a further message into an open thread.
///
/// Like Compose, the message takes the inbound path a real email would; the threading headers are
/// what keep it in this conversation instead of starting a new one.
#[instrument(skip_all)]
#[expect(
    clippy::too_many_arguments,
    reason = "Axum handlers receive request state and extractors as parameters"
)]
async fn send_reply(
    State(company_use_cases): State<Arc<CompanyUseCases>>,
    State(_channel_use_cases): State<Arc<ChannelUseCases>>,
    State(thread_use_cases): State<Arc<ThreadUseCases>>,
    State(activity_reader): State<Arc<dyn ThreadActivityReader>>,
    State(user_use_cases): State<Arc<UserUseCases>>,
    State(config): State<Arc<AppConfig>>,
    viewer: Viewer,
    Form(form): Form<ReplyForm>,
) -> AppResult<Response> {
    let (company, channel) = inbox::load_viewable_inbox(
        &company_use_cases,
        &thread_use_cases,
        &viewer,
        form.company_id,
        form.inbox,
    )
    .await?;
    let thread = thread_use_cases
        .readable_thread(
            &viewer,
            channel.company_id(),
            channel.target(),
            form.thread_id,
        )
        .await?
        .ok_or_else(|| AppError::NotFound("Thread not found".into()))?;
    let sender_email = sender_email(&user_use_cases, viewer.user_id).await?;
    let address = inbox::send_address(&channel, &company, &config.app_domain_name)?;

    let text_body = form.text_body.unwrap_or_default();
    let deliver = delivery_requested(form.deliver.as_deref());

    let reply_error = |message: String| {
        Html(pages::reply_pane(&pages::ReplyPane {
            company_id: company.id,
            inbox: &channel,
            thread: &thread,
            channel_address: address.as_str(),
            sender_email: &sender_email,
            text_body: &text_body,
            deliver,
            error: Some(&message),
        }))
        .into_response()
    };

    if text_body.trim().is_empty() {
        return Ok(reply_error("A message is required.".to_string()));
    }

    let reply_to_message_id = match form.reply_to_message_id {
        Some(id) => Some(CanonicalMessageId::new(id)),
        None => thread_use_cases.latest_thread_message_id(thread.id).await?,
    };

    let author = qualified_email_identity(sender_email.as_str())?;
    let mut ingress = CanonicalMessageIngress::new(
        company.id,
        channel.target(),
        author,
        &text_body,
        IngressOrigin::TrustedApplication,
    )
    .with_target_thread(thread.id)
    .with_reply_delivery(delivery_mode(deliver));

    if let Some(reply_to) = reply_to_message_id {
        ingress = ingress.with_reply_to_message(reply_to);
    }

    let ingest = match thread_use_cases.ingest_canonical(ingress).await {
        Ok(ingest) => ingest,
        Err(err) => return Ok(reply_error(format!("Failed to send message: {err}"))),
    };

    let Some(sent_thread) = ingest.thread.clone() else {
        let reason = ingest.reason().unwrap_or("The desk rejected this message.");
        return Ok(reply_error(reason.to_string()));
    };

    sent_message_response(
        &thread_use_cases,
        activity_reader.as_ref(),
        company.id,
        &channel,
        &config.app_domain_name,
        &sent_thread,
        &viewer,
    )
    .await
}

/// What both send forms return: the thread's messages, with its column refreshed beside them.
async fn sent_message_response(
    thread_use_cases: &ThreadUseCases,
    activity_reader: &dyn ThreadActivityReader,
    company_id: Uuid,
    channel: &ReadableInbox,
    app_domain_name: &str,
    thread: &Thread,
    viewer: &Viewer,
) -> AppResult<Response> {
    let pane = render_message_pane(
        thread_use_cases,
        activity_reader,
        company_id,
        channel,
        thread,
        viewer,
        None,
    )
    .await?;
    let page = load_thread_page(
        thread_use_cases,
        viewer,
        channel,
        &ThreadListQuery::default(),
    )
    .await?;
    let activity = page_activity(activity_reader, company_id, &page.threads).await?;
    thread_use_cases
        .readable_inbox(viewer, channel.scope())
        .await?;
    let refreshed_list = pages::thread_list_oob(&pages::ThreadColumn {
        company_id,
        inbox: channel,
        app_domain_name,
        threads: &page.threads,
        next_cursor: page.next_cursor.as_deref(),
        selected_thread_id: Some(thread.id),
        activity: &activity,
    });

    Ok((
        [(
            "HX-Push-Url",
            format!(
                "/ui?company_id={}&{}&thread_id={}",
                company_id,
                pages::inbox_target_query(channel.target()),
                thread.id
            ),
        )],
        Html(format!("{pane}{refreshed_list}")),
    )
        .into_response())
}

/// The signed-in account itself, needed both for the top bar and as the sender of composed mail.
/// The signed-in account as every `/ui` shell renders it.
///
/// The address is passed in rather than derived here because the caller already needs it as an
/// [`EmailAddress`] of its own, and the shell borrows both for the length of the render.
/// The signed-in reader as the `/ui` chrome shows them.
///
/// Operator status is settled here rather than at each call site, so every workspace's account
/// menu offers the same set of entries -- the alternative is one page deciding differently from
/// the next about who is an operator.
pub(super) fn workspace_user<'a>(
    account: &'a User,
    account_email: &'a EmailAddress,
    config: &AppConfig,
) -> pages::MailboxUser<'a> {
    pages::MailboxUser {
        id: account.id,
        username: &account.username,
        email: account_email,
        avatar_url: account.avatar_url.as_ref(),
        is_operator: crate::adapters::http::auth::caller_for(account, config).is_operator(),
        company_membership: CompanyMembership::None,
    }
}

pub(super) async fn load_account(user_use_cases: &UserUseCases, user_id: Uuid) -> AppResult<User> {
    user_use_cases
        .get_user_by_id(user_id)
        .await?
        .ok_or_else(|| AppError::NotFound("User not found".into()))
}

/// The signed-in user's own address — composed mail is always sent as them.
async fn sender_email(user_use_cases: &UserUseCases, user_id: Uuid) -> AppResult<String> {
    Ok(load_account(user_use_cases, user_id).await?.email)
}

#[cfg(test)]
#[path = "ui_stream_tests.rs"]
pub(super) mod stream_tests;
