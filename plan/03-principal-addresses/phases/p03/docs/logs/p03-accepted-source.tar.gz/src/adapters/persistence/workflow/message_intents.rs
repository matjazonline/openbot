//! Trigger payloads feed run admission, which checks the immutable message stamp against the
//! admitted knowledge ceiling. This is an internal execution read, not a viewer endpoint.
//! The workflow-admission intent queue (p08 D1.3/D1.4). Claims are fair per company and fenced by
//! a per-claim generation; every later write names it, so a stale worker changes nothing.
use super::*;
use crate::application::workflow::message_admission::*;
use crate::application::workflow::triggers::MessageTriggerInput;
use crate::domain::entities::correlation::CorrelationId;
use crate::domain::entities::message::CanonicalMessageId;
use crate::domain::entities::transport::RecipientRole;
use chrono::{DateTime, Utc};

struct OutcomeWrite {
    name: &'static str,
    run: Option<Uuid>,
    reason: Option<&'static str>,
    role_refusal: Option<serde_json::Value>,
}

impl TryFrom<BindingOutcome> for OutcomeWrite {
    type Error = AppError;
    fn try_from(outcome: BindingOutcome) -> AppResult<Self> {
        Ok(match outcome {
            BindingOutcome::Admitted(run) => Self {
                name: "admitted",
                run: Some(run.as_uuid()),
                reason: None,
                role_refusal: None,
            },
            BindingOutcome::Refused(reason) => Self {
                name: "refused",
                run: None,
                reason: Some(reason),
                role_refusal: None,
            },
            BindingOutcome::Failed(reason) => Self {
                name: "failed",
                run: None,
                reason: Some(reason),
                role_refusal: None,
            },
            BindingOutcome::RoleRefused(refusal) => Self {
                name: "refused",
                run: None,
                reason: Some(refusal.kind.code()),
                role_refusal: Some(serde_json::to_value(refusal).map_err(|_| invalid())?),
            },
        })
    }
}

#[derive(sqlx::FromRow)]
struct IntentRow {
    company_id: Uuid,
    id: Uuid,
    claim_generation: Uuid,
    message_id: Uuid,
    channel_id: Option<Uuid>,
    principal_id: Option<Uuid>,
    thread_id: Uuid,
    role: String,
    mentioned: bool,
    admissible: bool,
    origin: String,
    reply_to_message_id: Option<Uuid>,
    reply_settled: bool,
    responder_principal_id: Option<Uuid>,
    delivery_policy: String,
    correlation_id: Uuid,
    attempts: i16,
    created_at: DateTime<Utc>,
    replies_to_workflow: bool,
}

impl IntentRow {
    fn claimed(self, worker: MessageIntentWorkerId) -> AppResult<ClaimedIntent> {
        let role = match self.role.as_str() {
            "to" => RecipientRole::To,
            "cc" => RecipientRole::Cc,
            _ => return Err(invalid()),
        };
        Ok(ClaimedIntent {
            claim: IntentClaim {
                company: CompanyId::new(self.company_id),
                intent: self.id,
                worker,
                generation: self.claim_generation,
            },
            message: CanonicalMessageId::new(self.message_id),
            target: AddressTarget::from_parts(
                self.channel_id,
                self.principal_id
                    .map(crate::entities::transport::PrincipalId::new),
            )
            .ok_or_else(invalid)?,
            thread: self.thread_id,
            facts: MessageFacts {
                role,
                mentioned: self.mentioned,
                replies_to_workflow: self.replies_to_workflow,
            },
            admissible: self.admissible,
            in_app: self.origin == "application",
            reply_to: self.reply_to_message_id.map(CanonicalMessageId::new),
            reply_settled: self.reply_settled,
            responder: self.responder_principal_id,
            delivery_policy: DeliveryPolicy::parse(&self.delivery_policy)?,
            correlation: CorrelationId::from(self.correlation_id),
            attempts: self.attempts,
            accepted_at: self.created_at,
        })
    }
}

#[derive(sqlx::FromRow)]
struct CandidateRow {
    id: Uuid,
    configuration_revision: i64,
    run_as_user_id: Uuid,
    message_trigger: String,
}

impl CandidateRow {
    fn candidate(self) -> AppResult<CandidateBinding> {
        Ok(CandidateBinding {
            id: WorkflowBindingId::new(self.id),
            revision: BindingRevision::new(
                u64::try_from(self.configuration_revision).map_err(|_| invalid())?,
            )
            .ok_or_else(invalid)?,
            run_as: WorkflowActor::authenticated(self.run_as_user_id).map_err(|_| invalid())?,
            trigger: self.message_trigger.parse().map_err(|_| invalid())?,
        })
    }
}

/// The eligibility read; `$4` narrows it to one binding for a `Stale` re-read.
const CANDIDATES: &str = "SELECT binding.id, configuration.revision AS configuration_revision, \
       configuration.run_as_user_id, configuration.message_trigger \
     FROM workflow_bindings AS binding \
     JOIN workflow_message_intents AS intent ON intent.company_id = binding.company_id AND intent.id = $2 \
     LEFT JOIN workflow_escalation_notice_targets AS notice_target ON notice_target.company_id=intent.company_id AND notice_target.message_id=intent.message_id \
     LEFT JOIN channel_reply_contexts AS response ON response.company_id=intent.company_id \
       AND response.intent_id=intent.id AND response.binding_id=binding.id \
     JOIN workflow_binding_revisions AS configuration ON configuration.company_id = binding.company_id \
       AND configuration.binding_id = binding.id \
       AND configuration.revision = COALESCE(response.binding_revision,binding.configuration_revision) \
     WHERE binding.company_id = $1 \
       AND (response.intent_id IS NOT NULL OR (binding.active AND binding.activated_at <= intent.created_at)) \
       AND configuration.message_trigger IS NOT NULL \
       AND binding.channel_id IS NOT DISTINCT FROM intent.channel_id \
       AND binding.principal_id IS NOT DISTINCT FROM intent.principal_id \
       AND (binding.thread_id IS NULL OR binding.thread_id = intent.thread_id) \
       AND ($3::uuid IS NULL OR binding.id = $3) \
       AND (notice_target.intent_id IS NULL OR (notice_target.intent_id=intent.id \
         AND binding.id=notice_target.binding_id AND binding.active \
         AND binding.configuration_revision=notice_target.binding_revision AND configuration.revision=notice_target.binding_revision \
         AND workflow_escalation_target_admissible(notice_target))) \
       AND NOT EXISTS (SELECT 1 FROM workflow_message_intent_bindings AS outcome \
         WHERE outcome.company_id = binding.company_id AND outcome.intent_id = intent.id \
           AND outcome.binding_id = binding.id) \
     ORDER BY binding.id";

/// The claim's fence, held for the statement that writes under it.
const FENCE: &str = "SELECT id FROM workflow_message_intents WHERE company_id = $1 AND id = $2 \
     AND state = 'claimed' AND worker_id = $3 AND claim_generation = $4 \
     AND lease_expires_at > clock_timestamp() FOR UPDATE";

const EXPIRE_SET: &str = "state=CASE WHEN EXISTS(SELECT 1 FROM workflow_message_intent_bindings AS binding \
    WHERE binding.company_id=intent.company_id AND binding.intent_id=intent.id AND binding.outcome='admitted') \
      OR workflow_escalation_intent_source_retired(intent.company_id,intent.id) THEN 'done' ELSE 'failed' END, \
    outcome=CASE WHEN EXISTS(SELECT 1 FROM workflow_message_intent_bindings AS binding \
    WHERE binding.company_id=intent.company_id AND binding.intent_id=intent.id AND binding.outcome='admitted') THEN 'admitted' \
      WHEN workflow_escalation_intent_source_retired(intent.company_id,intent.id) THEN 'notification_source_retired' ELSE NULL END, \
    worker_id=NULL,claim_generation=NULL,lease_expires_at=NULL,updated_at=clock_timestamp()";

#[derive(sqlx::FromRow)]
struct ExpiryTarget {
    company_id: Uuid,
    id: Uuid,
    notice: bool,
}

#[derive(sqlx::FromRow)]
pub(super) struct ExpiredRow {
    company_id: Uuid,
    id: Uuid,
    state: String,
}

impl ExpiredRow {
    pub(super) fn failure(self) -> Option<FailedIntent> {
        (self.state == "failed").then_some(FailedIntent {
            company: CompanyId::new(self.company_id),
            intent: self.id,
        })
    }
}

#[async_trait]
impl MessageIntentQueue for PostgresPersistence {
    async fn fail_expired_intents(&self, page: u16) -> AppResult<Vec<FailedIntent>> {
        // Discover one bounded mixed page. Never hold an intent row and then
        // acquire company/case ownership to publish its handling failure.
        let targets:Vec<ExpiryTarget>=sqlx::query_as("SELECT intent.company_id,intent.id,target.intent_id IS NOT NULL AS notice \
            FROM workflow_message_intents AS intent LEFT JOIN workflow_escalation_notice_targets AS target \
              ON target.company_id=intent.company_id AND target.message_id=intent.message_id \
            WHERE intent.state='claimed' AND intent.attempts>=$1 AND intent.lease_expires_at<=clock_timestamp() \
            ORDER BY intent.lease_expires_at,intent.company_id,intent.id LIMIT $2")
            .bind(MAX_INTENT_ATTEMPTS).bind(i64::from(page)).fetch_all(&self.pool).await?;
        let mut failures = Vec::new();
        let mut companies = Vec::new();
        let mut intents = Vec::new();
        for target in targets {
            if target.notice {
                if let Some(failed) = escalation_handling::expire_intent(
                    self,
                    CompanyId::new(target.company_id),
                    target.id,
                )
                .await?
                {
                    failures.push(failed);
                }
            } else {
                companies.push(target.company_id);
                intents.push(target.id);
            }
        }
        if !intents.is_empty() {
            failures.extend(
                expire_ordinary_on(&self.pool, &companies, &intents)
                    .await?
                    .into_iter()
                    .filter_map(ExpiredRow::failure),
            );
        }
        Ok(failures)
    }

    async fn claim_intents(
        &self,
        worker: MessageIntentWorkerId,
        page: u16,
    ) -> AppResult<Vec<ClaimedIntent>> {
        // Rank per company before the page limit, so one tenant's backlog cannot fill every page;
        // the outer lock skips rows another worker holds (p08 F008). A claim whose last lease
        // lapsed is not claimable: `fail_expired_intents` ends it.
        let rows = sqlx::query_as::<_, IntentRow>(
            "WITH available AS ( \
               SELECT company_id, id, available_at, \
                 row_number() OVER (PARTITION BY company_id ORDER BY available_at, id) AS rank \
               FROM workflow_message_intents \
               WHERE (state = 'pending' AND available_at <= clock_timestamp()) \
                  OR (state = 'claimed' AND attempts < $4 AND lease_expires_at <= clock_timestamp()) \
             ), picked AS ( \
               SELECT company_id, id FROM available WHERE rank <= $3 \
               ORDER BY available_at, id LIMIT $2 \
             ), locked AS ( \
               SELECT intent.company_id, intent.id FROM workflow_message_intents AS intent \
               JOIN picked ON picked.company_id = intent.company_id AND picked.id = intent.id \
               WHERE (intent.state = 'pending' AND intent.available_at <= clock_timestamp()) \
                  OR (intent.state = 'claimed' AND intent.attempts < $4 \
                      AND intent.lease_expires_at <= clock_timestamp()) \
               FOR UPDATE OF intent SKIP LOCKED \
             ) \
             UPDATE workflow_message_intents AS intent SET state = 'claimed', worker_id = $1, \
               claim_generation = gen_random_uuid(), attempts = intent.attempts + 1, \
               lease_expires_at = clock_timestamp() + make_interval(secs => $5), \
               updated_at = clock_timestamp() \
             FROM locked WHERE intent.company_id = locked.company_id AND intent.id = locked.id \
             RETURNING intent.company_id, intent.id, intent.claim_generation, intent.message_id, \
               intent.channel_id, intent.principal_id, intent.thread_id, intent.role, intent.mentioned, intent.admissible, \
               intent.origin, intent.reply_to_message_id, intent.reply_settled, \
               intent.responder_principal_id, \
               intent.delivery_policy, intent.correlation_id, intent.attempts, intent.created_at, \
               EXISTS (SELECT 1 FROM workflow_message_destinations AS target \
                 WHERE target.company_id = intent.company_id \
                   AND target.message_id = intent.reply_to_message_id \
                   AND target.thread_id = intent.thread_id) AS replies_to_workflow",
        )
        .bind(worker.0)
        .bind(i64::from(page))
        .bind(i64::from(MESSAGE_INTENTS_PER_COMPANY))
        .bind(MAX_INTENT_ATTEMPTS)
        .bind(MESSAGE_INTENT_LEASE.as_secs_f64())
        .fetch_all(&self.pool)
        .await?;
        let mut claimed: Vec<_> = rows
            .into_iter()
            .map(|row| row.claimed(worker))
            .collect::<AppResult<_>>()?;
        claimed.sort_by_key(|intent| intent.accepted_at);
        Ok(claimed)
    }

    async fn candidate_bindings(&self, intent: &ClaimedIntent) -> AppResult<Vec<CandidateBinding>> {
        sqlx::query_as::<_, CandidateRow>(CANDIDATES)
            .bind(intent.claim.company.as_uuid())
            .bind(intent.claim.intent)
            .bind(None::<Uuid>)
            .fetch_all(&self.pool)
            .await?
            .into_iter()
            .map(CandidateRow::candidate)
            .collect()
    }

    async fn candidate_binding(
        &self,
        intent: &ClaimedIntent,
        binding: WorkflowBindingId,
    ) -> AppResult<Option<CandidateBinding>> {
        sqlx::query_as::<_, CandidateRow>(CANDIDATES)
            .bind(intent.claim.company.as_uuid())
            .bind(intent.claim.intent)
            .bind(Some(binding.as_uuid()))
            .fetch_optional(&self.pool)
            .await?
            .map(CandidateRow::candidate)
            .transpose()
    }

    async fn trigger_input(&self, intent: &ClaimedIntent) -> AppResult<MessageTriggerInput> {
        trigger_input_on(
            &mut *self.pool.acquire().await?,
            intent.claim.company,
            intent.message,
        )
        .await
    }

    async fn record_binding_outcome(
        &self,
        claim: IntentClaim,
        binding: &CandidateBinding,
        outcome: BindingOutcome,
    ) -> AppResult<bool> {
        let outcome = OutcomeWrite::try_from(outcome)?;
        let written = sqlx::query(&format!(
            "WITH fence AS ({FENCE}) \
             INSERT INTO workflow_message_intent_bindings \
               (company_id, intent_id, binding_id, binding_revision, outcome, run_id, reason, role_refusal) \
             SELECT $1, fence.id, $5, $6, $7, $8, $9, $10 FROM fence \
             ON CONFLICT (company_id, intent_id, binding_id) DO NOTHING"
        ))
        .bind(claim.company.as_uuid())
        .bind(claim.intent)
        .bind(claim.worker.0)
        .bind(claim.generation)
        .bind(binding.id.as_uuid())
        .bind(revision(binding.revision.get())?)
        .bind(outcome.name)
        .bind(outcome.run)
        .bind(outcome.reason)
        .bind(outcome.role_refusal)
        .execute(&self.pool)
        .await?;
        if written.rows_affected() == 1 {
            return Ok(true);
        }
        // Either the claim was lost, or this binding already has an outcome under this claim's
        // own earlier write (a retried statement); only the fence decides.
        fence_holds(&self.pool, claim).await
    }

    async fn settle_reply(&self, claim: IntentClaim) -> AppResult<bool> {
        let settled = sqlx::query(&format!(
            "WITH fence AS ({FENCE}) \
             UPDATE workflow_message_intents AS intent SET reply_settled = true, \
               updated_at = clock_timestamp() \
             FROM fence WHERE intent.company_id = $1 AND intent.id = fence.id"
        ))
        .bind(claim.company.as_uuid())
        .bind(claim.intent)
        .bind(claim.worker.0)
        .bind(claim.generation)
        .execute(&self.pool)
        .await?;
        Ok(settled.rows_affected() == 1)
    }

    async fn finish_intent(&self, claim: IntentClaim, matched: Option<RunId>) -> AppResult<bool> {
        let mut db = self.pool.acquire().await?;
        if escalation_handling::has_intent_on(&mut db, claim).await? {
            drop(db);
            return escalation_handling::finish_intent(self, claim, matched).await;
        }
        finish_on(&mut db, claim, matched).await
    }

    async fn defer_intent(&self, claim: IntentClaim, deferral: IntentDeferral) -> AppResult<bool> {
        // Spends the attempt: exponential backoff from 2 s, and the last attempt fails.
        let transient = format!(
            "WITH fence AS ({FENCE}) \
             UPDATE workflow_message_intents AS intent SET worker_id = NULL, \
               claim_generation = NULL, lease_expires_at = NULL, updated_at = clock_timestamp(), \
               state = CASE WHEN intent.attempts >= $5 THEN 'failed' ELSE 'pending' END, \
               available_at = clock_timestamp() + make_interval(secs => 2 * power(2, intent.attempts - 1)) \
             FROM fence WHERE intent.company_id = $1 AND intent.id = fence.id"
        );
        // Attempt-neutral: returns the claim's attempt and doubles the delay with the reply's age,
        // never past its park grace (p08 F014, F020).
        let not_yet = format!(
            "WITH fence AS ({FENCE}) \
             UPDATE workflow_message_intents AS intent SET worker_id = NULL, \
               claim_generation = NULL, lease_expires_at = NULL, updated_at = clock_timestamp(), \
               state = 'pending', attempts = intent.attempts - 1, \
               available_at = least(clock_timestamp() + greatest(interval '2 seconds', \
                 clock_timestamp() - intent.created_at), \
                 intent.created_at + make_interval(secs => $5)) \
             FROM fence WHERE intent.company_id = $1 AND intent.id = fence.id"
        );
        let deferred = match deferral {
            IntentDeferral::Transient => sqlx::query(&transient)
                .bind(claim.company.as_uuid())
                .bind(claim.intent)
                .bind(claim.worker.0)
                .bind(claim.generation)
                .bind(MAX_INTENT_ATTEMPTS),
            IntentDeferral::NotYet => sqlx::query(&not_yet)
                .bind(claim.company.as_uuid())
                .bind(claim.intent)
                .bind(claim.worker.0)
                .bind(claim.generation)
                .bind(REPLY_PARK_GRACE.as_secs_f64()),
        }
        .execute(&self.pool)
        .await?;
        Ok(deferred.rows_affected() == 1)
    }
}

pub(super) async fn finish_on(
    db: &mut PgConnection,
    claim: IntentClaim,
    matched: Option<RunId>,
) -> AppResult<bool> {
    let finished = sqlx::query(&format!(
        "WITH fence AS ({FENCE}) \
         UPDATE workflow_message_intents AS intent SET state = 'done', worker_id = NULL, \
           claim_generation = NULL, lease_expires_at = NULL, updated_at = clock_timestamp(), \
           matched_run_id = $5, \
           outcome = CASE WHEN $5::uuid IS NOT NULL THEN 'matched' \
             WHEN EXISTS (SELECT 1 FROM workflow_message_intent_bindings AS outcome \
               WHERE outcome.company_id = intent.company_id AND outcome.intent_id = intent.id \
                 AND outcome.outcome = 'admitted') THEN 'admitted' \
             WHEN workflow_escalation_intent_source_retired(intent.company_id,intent.id) THEN 'notification_source_retired' ELSE 'none' END \
         FROM fence WHERE intent.company_id = $1 AND intent.id = fence.id"
    ))
    .bind(claim.company.as_uuid())
    .bind(claim.intent)
    .bind(claim.worker.0)
    .bind(claim.generation)
    .bind(matched.map(RunId::as_uuid))
    .execute(db)
    .await?;
    Ok(finished.rows_affected() == 1)
}

async fn expire_ordinary_on(
    pool: &sqlx::PgPool,
    companies: &[Uuid],
    intents: &[Uuid],
) -> AppResult<Vec<ExpiredRow>> {
    Ok(sqlx::query_as(&format!("UPDATE workflow_message_intents AS intent SET {EXPIRE_SET} \
        WHERE ctid IN(SELECT current.ctid FROM workflow_message_intents AS current \
          JOIN unnest($2::uuid[],$3::uuid[]) AS selected(company_id,intent_id) \
            ON selected.company_id=current.company_id AND selected.intent_id=current.id \
          WHERE current.state='claimed' AND current.attempts>=$1 AND current.lease_expires_at<=clock_timestamp() \
            AND NOT EXISTS(SELECT 1 FROM workflow_escalation_notice_targets WHERE company_id=current.company_id AND message_id=current.message_id) \
          FOR UPDATE OF current SKIP LOCKED) RETURNING intent.company_id,intent.id,intent.state"))
        .bind(MAX_INTENT_ATTEMPTS).bind(companies).bind(intents).fetch_all(pool).await?)
}

pub(super) async fn expire_on(
    db: &mut PgConnection,
    company: CompanyId,
    intent: Uuid,
) -> AppResult<Option<ExpiredRow>> {
    Ok(sqlx::query_as(&format!("UPDATE workflow_message_intents AS intent SET {EXPIRE_SET} \
        WHERE intent.company_id=$1 AND intent.id=$2 AND intent.state='claimed' AND intent.attempts>=$3 \
          AND intent.lease_expires_at<=clock_timestamp() RETURNING intent.company_id,intent.id,intent.state"))
        .bind(company.as_uuid()).bind(intent).bind(MAX_INTENT_ATTEMPTS).fetch_optional(db).await?)
}

async fn fence_holds(pool: &sqlx::PgPool, claim: IntentClaim) -> AppResult<bool> {
    Ok(sqlx::query_scalar::<_, bool>(
        "SELECT EXISTS(SELECT 1 FROM workflow_message_intents WHERE company_id = $1 AND id = $2 \
           AND state = 'claimed' AND worker_id = $3 AND claim_generation = $4 \
           AND lease_expires_at > clock_timestamp())",
    )
    .bind(claim.company.as_uuid())
    .bind(claim.intent)
    .bind(claim.worker.0)
    .bind(claim.generation)
    .fetch_one(pool)
    .await?)
}

/// The canonical producer input and admission audience proof use the same source read.
#[derive(sqlx::FromRow)]
struct MessageInputRow {
    subject: String,
    clean_text_body: String,
    sender: Option<String>,
}
pub(super) async fn trigger_input_on(
    db: &mut PgConnection,
    company: CompanyId,
    message: CanonicalMessageId,
) -> AppResult<MessageTriggerInput> {
    let row = sqlx::query_as::<_, MessageInputRow>(
            "SELECT message.subject, message.clean_text_body, \
               COALESCE((SELECT identity.subject FROM message_participants AS participant \
                  JOIN participant_identities AS identity ON identity.company_id = participant.company_id \
                    AND identity.id = participant.participant_identity_id \
                 WHERE participant.company_id = message.company_id AND participant.message_id = message.id \
                   AND participant.kind = 'sender' ORDER BY participant.position LIMIT 1), \
                 (SELECT principal.display_label FROM principals AS principal \
                 WHERE principal.company_id = message.company_id AND principal.id = message.author_principal_id)) AS sender \
             FROM messages AS message WHERE message.company_id = $1 AND message.id = $2",
        )
        .bind(company.as_uuid())
        .bind(message.as_uuid())
        .fetch_optional(db)
        .await?
        .ok_or_else(missing)?;
    Ok(MessageTriggerInput::new(
        message,
        &row.clean_text_body,
        &row.subject,
        row.sender.as_deref().unwrap_or_default(),
    ))
}
