use super::*;
use binding::{BindingConfiguration, ConfiguredBinding};
use rows::{VERSION_COLUMNS, VersionRow};
use serde_json::Value;

#[derive(sqlx::FromRow)]
struct BindingRow {
    company_id: Uuid,
    id: Uuid,
    state_revision: i64,
    configuration_revision: i64,
    active: bool,
    channel_id: Option<Uuid>,
    principal_id: Option<Uuid>,
    thread_id: Option<Uuid>,
    version_id: Uuid,
    params: Value,
    resources: Value,
    run_as_user_id: Uuid,
    message_trigger: Option<String>,
    escalation: Option<Value>,
}

/// The stored message trigger column, refused rather than guessed when unreadable.
pub(super) fn message_trigger(stored: Option<&str>) -> AppResult<Option<MessageTrigger>> {
    stored
        .map(|name| name.parse::<MessageTrigger>().map_err(|_| invalid()))
        .transpose()
}

pub(super) fn read_binding(
    db: &mut PgConnection,
    company: CompanyId,
    id: WorkflowBindingId,
) -> impl Future<Output = AppResult<Option<BindingState>>> + '_ {
    read_binding_at(db, company, id, None)
}

pub(super) async fn read_binding_at(
    db: &mut PgConnection,
    company: CompanyId,
    id: WorkflowBindingId,
    selected: Option<BindingRevision>,
) -> AppResult<Option<BindingState>> {
    let row = sqlx::query_as::<_, BindingRow>(
        "SELECT binding.company_id, binding.id, binding.state_revision, \
         configuration.revision AS configuration_revision, binding.active, binding.channel_id, binding.principal_id, binding.thread_id, \
         configuration.version_id, configuration.params, configuration.resources, \
         configuration.run_as_user_id, configuration.message_trigger, configuration.escalation \
         FROM workflow_bindings AS binding JOIN workflow_binding_revisions AS configuration \
           ON configuration.company_id = binding.company_id AND configuration.binding_id = binding.id \
           AND configuration.revision = COALESCE($3,binding.configuration_revision) \
         WHERE binding.company_id = $1 AND binding.id = $2",
    ).bind(company.as_uuid()).bind(id.as_uuid())
        .bind(selected.map(|value| revision(value.get())).transpose()?)
        .fetch_optional(&mut *db).await?;
    let Some(row) = row else { return Ok(None) };
    let bundle = read_version(db, company, VersionId::new(row.version_id)).await?;
    let association = association_from_columns(association::AssociationColumns {
        channel_id: row.channel_id,
        principal_id: row.principal_id,
        thread_id: row.thread_id,
    })?;
    let configuration = ConfiguredBinding::new(
        BindingConfiguration {
            escalation: row
                .escalation
                .map(serde_json::from_value)
                .transpose()
                .map_err(|_| invalid())?,
            company_id: CompanyId::new(row.company_id),
            id: WorkflowBindingId::new(row.id),
            revision: BindingRevision::new(
                u64::try_from(row.configuration_revision).map_err(|_| invalid())?,
            )
            .ok_or_else(invalid)?,
            params: row.params,
            resources: serde_json::from_value(row.resources).map_err(|_| invalid())?,
            run_as: WorkflowActor::authenticated(row.run_as_user_id).map_err(|_| invalid())?,
            message_trigger: message_trigger(row.message_trigger.as_deref())?,
        },
        bundle,
    )
    .map_err(|_| invalid())?;
    Ok(Some(BindingState {
        configuration: Arc::new(configuration),
        association,
        active: row.active,
        revision: BindingStateRevision::new(
            u64::try_from(row.state_revision).map_err(|_| invalid())?,
        )
        .ok_or_else(invalid)?,
    }))
}

pub(super) async fn read_version(
    db: &mut PgConnection,
    company: CompanyId,
    version: VersionId,
) -> AppResult<Arc<PublishedBundle>> {
    sqlx::query_as::<_, VersionRow>(&format!(
        "SELECT {VERSION_COLUMNS} FROM workflow_versions WHERE company_id = $1 AND id = $2"
    ))
    .bind(company.as_uuid())
    .bind(version.as_uuid())
    .fetch_optional(db)
    .await?
    .ok_or_else(missing)?
    .restore()
    .map(|command| command.bundle)
}
