//! Selection and frozen admission ownership. Publication is a later durable owner.
use super::*;
use crate::application::workflow::channel_reply::{
    ChannelReplies, ChannelReplyContract, ChannelReplySettings, ConfigureChannelReply,
    ConfigureResponder, ReplySettingsRevision, ReplyText, SelectedResponder,
};
use serde_json::Value;

#[derive(sqlx::FromRow)]
struct SettingsRow {
    revision: i64,
    binding_id: Option<Uuid>,
    binding_revision: Option<i64>,
    contract: Option<Value>,
    approval_policy: Option<Value>,
}

impl SettingsRow {
    fn settings(self) -> AppResult<ChannelReplySettings> {
        let responder = match (self.binding_id, self.binding_revision, self.contract) {
            (None, None, None) => None,
            (Some(binding), Some(revision), Some(contract)) => Some(SelectedResponder {
                binding: WorkflowBindingId::new(binding),
                configuration_revision: BindingRevision::new(
                    u64::try_from(revision).map_err(|_| invalid())?,
                )
                .ok_or_else(invalid)?,
                contract: serde_json::from_value(contract).map_err(|_| invalid())?,
            }),
            _ => return Err(invalid()),
        };
        Ok(ChannelReplySettings {
            revision: ReplySettingsRevision::try_from(
                u64::try_from(self.revision).map_err(|_| invalid())?,
            )
            .map_err(|_| invalid())?,
            responder,
            approval_policy: self
                .approval_policy
                .map(serde_json::from_value)
                .transpose()
                .map_err(|_| invalid())?,
        })
    }
}

pub(super) async fn settings_on(
    db: &mut PgConnection,
    company: CompanyId,
    target: AddressTarget,
) -> AppResult<Option<ChannelReplySettings>> {
    sqlx::query_as::<_, SettingsRow>(
        "SELECT revision,binding_id,binding_revision,contract,approval_policy FROM channel_reply_settings \
         WHERE company_id=$1 AND channel_id IS NOT DISTINCT FROM $2::uuid AND principal_id IS NOT DISTINCT FROM $3::uuid",
    )
    .bind(company.as_uuid())
    .bind(target.desk_id())
    .bind(target.principal_id().map(|id| id.as_uuid()))
    .fetch_optional(db)
    .await?
    .map(SettingsRow::settings)
    .transpose()
}

/// Only the just-created native binding is selected, inside provisioning's savepoint.
/// Caller authorization and account locks already belong to the provisioning transaction.
pub(super) async fn bootstrap_native_on(
    tx: &mut Transaction<'_, Postgres>,
    company: CompanyId,
    target: AddressTarget,
    actor: WorkflowActor,
    binding: WorkflowBindingId,
) -> AppResult<()> {
    authorize_settings(tx, company, target, actor).await?;
    if settings_on(tx, company, target).await?.is_some() {
        return Err(conflict());
    }
    let binding_state = binding_rows::read_binding(tx, company, binding)
        .await?
        .ok_or_else(missing)?;
    if binding_state.configuration.run_as() != actor {
        return Err(conflict());
    }
    let request = ConfigureChannelReply {
        company,
        target,
        actor,
        expected: None,
        responder: Some(ConfigureResponder {
            binding,
            expected_binding_revision: binding_state.revision,
            contract: native_contract(),
        }),
        approval_policy: None,
    };
    let state = ChannelReplySettings {
        revision: ReplySettingsRevision::try_from(1).expect("initial revision"),
        responder: selected_on(tx, &request).await?,
        approval_policy: None,
    };
    write_settings(tx, &request, &state).await
}

#[async_trait]
impl ChannelReplies for PostgresPersistence {
    async fn channel_reply_settings(
        &self,
        company: CompanyId,
        target: AddressTarget,
        actor: WorkflowActor,
    ) -> AppResult<Option<ChannelReplySettings>> {
        let mut tx = self.pool.begin().await?;
        authorize_settings(&mut tx, company, target, actor).await?;
        let settings = settings_on(&mut tx, company, target).await?;
        tx.commit().await?;
        Ok(settings)
    }

    async fn configure_channel_reply(
        &self,
        request: ConfigureChannelReply,
    ) -> AppResult<ChannelReplySettings> {
        let mut tx = self.pool.begin().await?;
        let state = configure_reply_on(&mut tx, &request).await?;
        tx.commit().await?;
        Ok(state)
    }
}

/// One responder configuration on the caller's transaction: the accounts it names, the channel
/// row, the expected revision, the selection and reviewer checks, then the write.
/// `configure_channel_reply` and a department desk following its lead (01DEP-P03-D9) both
/// configure through it.
pub(super) async fn configure_reply_on(
    tx: &mut Transaction<'_, Postgres>,
    request: &ConfigureChannelReply,
) -> AppResult<ChannelReplySettings> {
    let approval_accounts = lock_settings_accounts(tx, request).await?;
    authorize_settings(tx, request.company, request.target, request.actor).await?;
    let reviewer_ids = request
        .approval_policy
        .as_ref()
        .map_or(&[][..], |policy| policy.reviewers());
    if super::approval_accounts::resolve_on(tx, request.company, reviewer_ids).await?
        != approval_accounts
    {
        return Err(missing());
    }
    let query = match request.target {
        AddressTarget::Desk(_) => {
            "SELECT id FROM channels WHERE company_id=$1 AND id=$2 FOR UPDATE"
        }
        AddressTarget::Principal(_) => {
            "SELECT id FROM principals WHERE company_id=$1 AND id=$2 AND kind='agent' FOR UPDATE"
        }
    };
    let id = match request.target {
        AddressTarget::Desk(id) => id,
        AddressTarget::Principal(id) => id.as_uuid(),
    };
    sqlx::query(query)
        .bind(request.company.as_uuid())
        .bind(id)
        .fetch_optional(&mut **tx)
        .await?
        .ok_or_else(missing)?;
    let current = settings_on(tx, request.company, request.target).await?;
    if current.as_ref().map(|value| value.revision) != request.expected {
        return Err(conflict());
    }
    let responder = selected_on(tx, request).await?;
    validate_reviewers(tx, request).await?;
    let next = request
        .expected
        .map_or(0, ReplySettingsRevision::get)
        .checked_add(1)
        .ok_or_else(conflict)?;
    let state = ChannelReplySettings {
        revision: ReplySettingsRevision::try_from(next).map_err(|_| conflict())?,
        responder,
        approval_policy: request.approval_policy.clone(),
    };
    write_settings(tx, request, &state).await?;
    tracing::info!(company=%request.company.as_uuid(),target=%request.target,
        revision=next,"Channel responder configured");
    Ok(state)
}

/// The reply a provisioned native workflow sends: its body, under the subject "Response".
pub(super) fn native_contract() -> ChannelReplyContract {
    ChannelReplyContract {
        format_version: 1,
        subject: ReplyText::Literal {
            literal: "Response".into(),
        },
        body: ReplyText::Reference {
            r#ref: "/input/body"
                .to_owned()
                .try_into()
                .expect("native response reference"),
        },
    }
}

async fn lock_settings_accounts(
    db: &mut PgConnection,
    request: &ConfigureChannelReply,
) -> AppResult<Vec<super::approval_accounts::PrincipalAccount>> {
    let mut accounts = vec![request.actor.user_id()];
    let reviewer_ids = request
        .approval_policy
        .as_ref()
        .map_or(&[][..], |policy| policy.reviewers());
    let approval_accounts =
        super::approval_accounts::resolve_on(db, request.company, reviewer_ids).await?;
    accounts.extend(approval_accounts.iter().map(|mapping| mapping.user_id));
    if let Some(responder) = &request.responder {
        let run_as: Option<Uuid> = sqlx::query_scalar("SELECT revision.run_as_user_id FROM workflow_bindings AS binding \
            JOIN workflow_binding_revisions AS revision ON revision.company_id=binding.company_id AND revision.binding_id=binding.id \
            AND revision.revision=binding.configuration_revision WHERE binding.company_id=$1 AND binding.id=$2")
            .bind(request.company.as_uuid()).bind(responder.binding.as_uuid()).fetch_optional(&mut *db).await?;
        accounts.extend(run_as);
    }
    accounts.sort_unstable();
    accounts.dedup();
    let locked: Vec<Uuid> =
        sqlx::query_scalar("SELECT id FROM users WHERE id=ANY($1) ORDER BY id FOR SHARE")
            .bind(&accounts)
            .fetch_all(db)
            .await?;
    if locked != accounts {
        return Err(missing());
    }
    Ok(approval_accounts)
}

async fn authorize_settings(
    tx: &mut Transaction<'_, Postgres>,
    company: CompanyId,
    target: AddressTarget,
    actor: WorkflowActor,
) -> AppResult<()> {
    sqlx::query("SET LOCAL lock_timeout = '5s'")
        .execute(&mut **tx)
        .await?;
    sqlx::query("SET LOCAL statement_timeout = '20s'")
        .execute(&mut **tx)
        .await?;
    authority::authorize_company(tx, company, actor).await?;
    association::authorize_association(tx, company, actor, RelatedAssociation::inbox(target)).await
}

async fn validate_reviewers(
    db: &mut Transaction<'_, Postgres>,
    request: &ConfigureChannelReply,
) -> AppResult<()> {
    let Some(policy) = &request.approval_policy else {
        return Ok(());
    };
    for principal in policy.reviewers() {
        let user: Uuid = sqlx::query_scalar(
            "SELECT user_id FROM principals WHERE company_id=$1 AND id=$2 AND kind='person'",
        )
        .bind(request.company.as_uuid())
        .bind(principal)
        .fetch_optional(&mut **db)
        .await?
        .ok_or_else(missing)?;
        let actor = WorkflowActor::authenticated(user)?;
        let reviewer = authority::authorize_reviewer_on(db, request.company, actor).await?;
        if !reviewer.privileged {
            return Err(AppError::BadRequest(
                "Final reply reviewers must be company admins".into(),
            ));
        }
        association::authorize_association(
            db,
            request.company,
            actor,
            RelatedAssociation::inbox(request.target),
        )
        .await?;
    }
    Ok(())
}

async fn selected_on(
    tx: &mut Transaction<'_, Postgres>,
    request: &ConfigureChannelReply,
) -> AppResult<Option<SelectedResponder>> {
    let Some(selection) = &request.responder else {
        return Ok(None);
    };
    let state = binding_rows::read_binding(tx, request.company, selection.binding)
        .await?
        .ok_or_else(missing)?;
    if !state.active
        || state.revision != selection.expected_binding_revision
        || state.association != RelatedAssociation::inbox(request.target)
        || state.configuration.message_trigger().is_none()
    {
        return Err(conflict());
    }
    let configuration = &state.configuration;
    authority::authorize_company(tx, request.company, configuration.run_as()).await?;
    association::authorize_association(
        tx,
        request.company,
        configuration.run_as(),
        RelatedAssociation::inbox(request.target),
    )
    .await?;
    bindings::verify_selection(tx, configuration).await?;
    resources::check_readiness(tx, configuration.as_ref().into()).await?;
    selection.contract.validate(
        configuration
            .bundle()
            .compiled()
            .graph()
            .definition()
            .output_schema
            .as_ref()
            .unwrap_or(&Value::Bool(true)),
    )?;
    Ok(Some(SelectedResponder {
        binding: selection.binding,
        configuration_revision: configuration.revision(),
        contract: selection.contract.clone(),
    }))
}

async fn write_settings(
    tx: &mut Transaction<'_, Postgres>,
    request: &ConfigureChannelReply,
    state: &ChannelReplySettings,
) -> AppResult<()> {
    let selection = state.responder.as_ref();
    let contract = selection
        .map(|value| serde_json::to_value(&value.contract))
        .transpose()
        .map_err(|_| invalid())?;
    let conflict = match request.target {
        AddressTarget::Desk(_) => "company_id,channel_id",
        AddressTarget::Principal(_) => "company_id,principal_id",
    };
    let query = format!(
        "INSERT INTO channel_reply_settings(company_id,channel_id,revision,binding_id,binding_revision,contract,approval_policy,principal_id) \
         VALUES($1,$2,$3,$4,$5,$6,$7,$8) ON CONFLICT({conflict}) DO UPDATE \
         SET revision=EXCLUDED.revision,binding_id=EXCLUDED.binding_id,\
         binding_revision=EXCLUDED.binding_revision,contract=EXCLUDED.contract,approval_policy=EXCLUDED.approval_policy"
    );
    sqlx::query(&query)
        .bind(request.company.as_uuid())
        .bind(request.target.desk_id())
        .bind(revision(state.revision.get())?)
        .bind(selection.map(|value| value.binding.as_uuid()))
        .bind(
            selection
                .map(|value| revision(value.configuration_revision.get()))
                .transpose()?,
        )
        .bind(contract)
        .bind(
            state
                .approval_policy
                .as_ref()
                .map(serde_json::to_value)
                .transpose()
                .map_err(|_| invalid())?,
        )
        .bind(request.target.principal_id().map(|id| id.as_uuid()))
        .execute(&mut **tx)
        .await
        .map_err(write_error)?;
    Ok(())
}

pub(super) async fn frozen_revision(
    db: &mut PgConnection,
    company: CompanyId,
    binding: WorkflowBindingId,
    trigger: &TriggerRef,
) -> AppResult<Option<BindingRevision>> {
    let TriggerSource::Message { message_id } = trigger.source() else {
        return Ok(None);
    };
    sqlx::query_scalar::<_, i64>(
        "SELECT binding_revision FROM channel_reply_contexts WHERE company_id=$1 AND intent_id=$2 \
         AND binding_id=$3 AND message_id=$4",
    )
    .bind(company.as_uuid())
    .bind(trigger.trigger_id().as_uuid())
    .bind(binding.as_uuid())
    .bind(message_id.as_uuid())
    .fetch_optional(db)
    .await?
    .map(|value| {
        BindingRevision::new(u64::try_from(value).map_err(|_| invalid())?).ok_or_else(invalid)
    })
    .transpose()
}

pub(super) async fn link_run(
    tx: &mut Transaction<'_, Postgres>,
    command: &PreparedAdmission,
    run: RunId,
) -> AppResult<()> {
    let Some(AdmissionClaim::Message(claim)) = command.admission_claim() else {
        return Ok(());
    };
    let linked = sqlx::query_scalar::<_,Uuid>(
        "INSERT INTO channel_reply_runs(company_id,intent_id,run_id,binding_id,binding_revision) \
         SELECT company_id,intent_id,$3,binding_id,binding_revision FROM channel_reply_contexts \
         WHERE company_id=$1 AND intent_id=$2 AND binding_id=$4 AND binding_revision=$5 \
         ON CONFLICT(company_id,intent_id) DO UPDATE SET run_id=channel_reply_runs.run_id RETURNING run_id",
    )
    .bind(claim.company.as_uuid())
    .bind(claim.intent)
    .bind(run.as_uuid())
    .bind(command.binding().id().as_uuid())
    .bind(revision(command.binding().revision().get())?)
    .fetch_optional(&mut **tx)
    .await?;
    if linked.is_some_and(|saved| saved != run.as_uuid()) {
        return Err(conflict());
    }
    Ok(())
}
