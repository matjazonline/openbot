//! One in-memory identity directory shared by every test that needs principals.
//!
//! Principal ids are *derived* from the qualified identity rather than allocated, so a test can
//! write a channel grant or a thread participant for an address before anything has observed it —
//! which is what lets fixture channels stay plain data instead of needing a live directory.

use std::{
    collections::{HashMap, HashSet},
    sync::{Arc, Mutex},
};

use async_trait::async_trait;
use chrono::Utc;
use sha2::{Digest, Sha256};
use uuid::Uuid;

use crate::adapters::protocols::email::EmailIdentity;
use crate::app_error::AppError;
use crate::app_error::AppResult;
use crate::application::ports::participant::IdentityObservation;
use crate::application::ports::participant::PrincipalAccessPersistence;
use crate::entities::channel::ChannelAccessMode;
use crate::entities::channel::PUBLIC_PARTICIPANT;
use crate::entities::company::CompanyAccess;
use crate::entities::company_member::CompanyMembership;
use crate::entities::participant::ChannelPrincipalGrant;
use crate::entities::participant::GrantProvenance;
use crate::entities::participant::IdentityProvenance;
use crate::entities::participant::IdentityStatus;
use crate::entities::participant::Principal;
use crate::entities::participant::PrincipalAccessContext;
use crate::entities::participant::PrincipalCapability;
use crate::entities::participant::PrincipalGrantAuthority;
use crate::entities::participant::PrincipalIdentity;
use crate::entities::participant::PrincipalKind;
use crate::entities::transport::ParticipantIdentityId;
use crate::entities::transport::PrincipalId;
use crate::entities::transport::QualifiedIdentity;
use crate::entities::transport::TransportKind;
use crate::entities::value_objects::EmailAddress;
use crate::use_cases::participant::IdentityDirectory;
use crate::use_cases::participant::IdentityResolution;

/// The principal a qualified identity resolves to inside this directory.
///
/// A digest of the tenant-qualified key, so the mapping is stable across runs and across the two
/// halves of a test that seed a grant and then send a message.
pub fn principal_for_identity(company_id: Uuid, identity: &QualifiedIdentity) -> PrincipalId {
    let mut digest = Sha256::new();
    digest.update(company_id.as_bytes());
    digest.update(b":");
    digest.update(identity.transport().as_str().as_bytes());
    digest.update(b":");
    digest.update(identity.namespace().as_str().as_bytes());
    digest.update(b":");
    digest.update(identity.subject().as_str().as_bytes());
    let bytes: [u8; 16] = digest.finalize()[..16]
        .try_into()
        .expect("sha256 yields at least 16 bytes");
    PrincipalId::new(Uuid::from_bytes(bytes))
}

/// The principal an email address resolves to. Panics on an unparseable address, because a test
/// fixture that cannot name its own actor has a typo rather than a scenario.
pub fn principal_for_email(company_id: Uuid, address: &str) -> PrincipalId {
    let identity = EmailIdentity::parse(EmailAddress::from(address))
        .expect("test fixture email address is parseable")
        .qualify_default();
    principal_for_identity(company_id, &identity)
}

/// The access policy a channel form's email allowlist produces, mirroring `channel_access` and
/// `insert_email_allowlist_grants` in the persistence writer: every entered address gets both
/// capabilities, and `@public` is an access *mode* on the channel rather than a grant.
pub fn email_allowlist_policy(
    company_id: Uuid,
    participant_emails: Option<&[EmailAddress]>,
) -> (ChannelAccessMode, Vec<ChannelPrincipalGrant>) {
    let listed: Vec<&str> = participant_emails
        .unwrap_or_default()
        .iter()
        .map(|email| email.trim())
        .filter(|email| !email.is_empty())
        .collect();
    let is_public = listed
        .iter()
        .any(|email| email.eq_ignore_ascii_case(PUBLIC_PARTICIPANT));
    let grants = email_allowlist_grants(company_id, &listed);
    let mode = if is_public {
        ChannelAccessMode::Public
    } else if grants.is_empty() {
        ChannelAccessMode::Team
    } else {
        ChannelAccessMode::Allowlist
    };
    (mode, grants)
}

/// The grants alone, for a fixture that already states its access mode literally.
pub fn email_allowlist_grants(company_id: Uuid, addresses: &[&str]) -> Vec<ChannelPrincipalGrant> {
    let mut seen = HashSet::new();
    addresses
        .iter()
        .map(|address| address.trim().to_lowercase())
        .filter(|address| {
            !address.is_empty()
                && !address.eq_ignore_ascii_case(PUBLIC_PARTICIPANT)
                && seen.insert(address.clone())
        })
        .flat_map(|address| {
            let principal_id = principal_for_email(company_id, &address);
            [PrincipalCapability::Participate, PrincipalCapability::View].map(|capability| {
                ChannelPrincipalGrant {
                    principal_id,
                    capability,
                    provenance: GrantProvenance::ConfiguredAllowlist,
                    created_at: Utc::now(),
                }
            })
        })
        .collect()
}

/// How a test states who is on a company's team.
///
/// Production answers this by joining a principal to its `company_members` row, inside the same
/// query that resolves the identity. An in-memory directory has no join to make, so the scenario's
/// own company double answers instead — which keeps the team stated once, where the test already
/// listed it. It is deliberately test-only: nothing in production decides anything from an address.
#[async_trait]
pub trait TeamFixture: Send + Sync {
    /// What the account behind this address is to the company.
    async fn membership_for_email(
        &self,
        company_id: Uuid,
        email: &str,
    ) -> AppResult<CompanyMembership>;

    /// What this signed-in account is to the company.
    async fn company_access(
        &self,
        user_id: Uuid,
        company_id: Uuid,
    ) -> AppResult<Option<CompanyAccess>>;
}

#[derive(Default)]
struct DirectoryState {
    principals: HashMap<(Uuid, PrincipalId), Principal>,
    identities: HashMap<(Uuid, QualifiedIdentity), PrincipalIdentity>,
    users: HashMap<(Uuid, Uuid), (PrincipalId, bool)>,
    direct_inboxes: HashMap<(Uuid, Uuid), Vec<crate::application::ports::participant::DirectInbox>>,
}

/// An `IdentityDirectory` + `PrincipalAccessPersistence` backed by a `HashMap`.
///
/// Identities and principals live here; membership comes from the scenario's [`TeamFixture`], so
/// a test states its team once and both halves of an access context agree.
pub struct InMemoryParticipantDirectory {
    team: Option<Arc<dyn TeamFixture>>,
    state: Mutex<DirectoryState>,
}

impl Default for InMemoryParticipantDirectory {
    fn default() -> Self {
        Self::new()
    }
}

impl InMemoryParticipantDirectory {
    pub fn new() -> Self {
        Self {
            team: None,
            state: Mutex::new(DirectoryState::default()),
        }
    }

    /// Answer memberships out of the same company double the rest of the test uses. Without one,
    /// every resolved actor is an outsider.
    pub fn with_team(mut self, team: Arc<dyn TeamFixture>) -> Self {
        self.team = Some(team);
        self
    }

    /// State a loaded target independently of sender identity observations.
    pub fn insert_principal(&self, principal: Principal) {
        self.state
            .lock()
            .unwrap()
            .principals
            .insert((principal.company_id, principal.id), principal);
    }

    /// State an explicit viewer's listing response. Unconfigured listings remain errors, so
    /// a fixture cannot silently claim to cover this port or invent a principal's address.
    pub fn insert_direct_inbox(
        &self,
        viewer: Uuid,
        inbox: crate::application::ports::participant::DirectInbox,
    ) {
        self.state
            .lock()
            .unwrap()
            .direct_inboxes
            .entry((inbox.principal.company_id, viewer))
            .or_default()
            .push(inbox);
    }

    /// Attach an account to its company principal, the way company/invite bootstrap does.
    pub fn with_user(self, company_id: Uuid, user_id: Uuid, email: &str) -> Self {
        let principal_id = principal_for_email(company_id, email);
        self.state
            .lock()
            .unwrap()
            .users
            .insert((company_id, user_id), (principal_id, true));
        self
    }

    /// Model a later address installation that cleared proof while preserving team membership.
    pub fn revoke_user_email_proof(&self, company_id: Uuid, user_id: Uuid) {
        if let Some((_, verified)) = self
            .state
            .lock()
            .unwrap()
            .users
            .get_mut(&(company_id, user_id))
        {
            *verified = false;
        }
    }

    /// Number of identities actually observed by a write. Policy tests use this to prove a
    /// rejected ingress performed only lookups.
    pub fn identity_count(&self) -> usize {
        self.state.lock().unwrap().identities.len()
    }

    async fn membership_for_subject(
        &self,
        company_id: Uuid,
        identity: &QualifiedIdentity,
    ) -> AppResult<CompanyMembership> {
        if identity.transport() != TransportKind::Email {
            return Ok(CompanyMembership::None);
        }
        match &self.team {
            Some(team) => {
                team.membership_for_email(company_id, identity.subject().as_str())
                    .await
            }
            None => Ok(CompanyMembership::None),
        }
    }

    fn upsert(
        &self,
        company_id: Uuid,
        identity: &QualifiedIdentity,
        display_label: Option<String>,
        provenance: IdentityProvenance,
        claim_metadata: crate::entities::participant::IdentityClaimMetadata,
    ) -> PrincipalIdentity {
        let mut state = self.state.lock().unwrap();
        state
            .identities
            .entry((company_id, identity.clone()))
            .or_insert_with(|| PrincipalIdentity {
                id: ParticipantIdentityId::random(),
                company_id,
                principal_id: principal_for_identity(company_id, identity),
                transport: identity.transport(),
                namespace: identity.namespace().clone(),
                subject: identity.subject().clone(),
                display_label,
                status: IdentityStatus::Observed,
                claim_metadata,
                provenance,
                created_at: Utc::now(),
                updated_at: Utc::now(),
            })
            .clone()
    }

    fn principal_from(
        &self,
        identity: &PrincipalIdentity,
        membership: CompanyMembership,
    ) -> Principal {
        Principal {
            id: identity.principal_id,
            company_id: identity.company_id,
            kind: if membership.is_team() {
                PrincipalKind::Person
            } else {
                PrincipalKind::External
            },
            user_id: None,
            agent_id: None,
            open_to_public: false,
            settings_revision: 1,
            historical_person_user_id: None,
            display_label: identity
                .display_label
                .clone()
                .unwrap_or_else(|| identity.subject.as_str().to_string()),
            created_at: identity.created_at,
            updated_at: identity.updated_at,
        }
    }
}

#[async_trait]
impl IdentityDirectory for InMemoryParticipantDirectory {
    async fn resolve_or_create_external_identity(
        &self,
        company_id: Uuid,
        observation: IdentityObservation,
    ) -> AppResult<IdentityResolution> {
        let identity = self.upsert(
            company_id,
            &observation.identity,
            observation.display_label,
            observation.provenance,
            observation.claim_metadata,
        );
        let membership = self
            .membership_for_subject(company_id, &observation.identity)
            .await?;
        Ok(IdentityResolution {
            principal: self.principal_from(&identity, membership),
            identity,
        })
    }
}

#[async_trait]
impl PrincipalAccessPersistence for InMemoryParticipantDirectory {
    async fn direct_inboxes(
        &self,
        company: Uuid,
        user: Uuid,
        limit: usize,
    ) -> AppResult<Vec<crate::application::ports::participant::DirectInbox>> {
        self.state
            .lock()
            .unwrap()
            .direct_inboxes
            .get(&(company, user))
            .map(|inboxes| inboxes.iter().take(limit.min(201)).cloned().collect())
            .ok_or_else(|| {
                AppError::Internal("direct inbox listing is outside this fixture".into())
            })
    }

    async fn principal_by_id(
        &self,
        company: Uuid,
        principal: PrincipalId,
    ) -> AppResult<Option<Principal>> {
        if let Some(stored) = self
            .state
            .lock()
            .unwrap()
            .principals
            .get(&(company, principal))
            .cloned()
        {
            return Ok(Some(stored));
        }
        let found = self
            .state
            .lock()
            .unwrap()
            .identities
            .iter()
            .find(|((scope, _), identity)| *scope == company && identity.principal_id == principal)
            .map(|((_, qualified), identity)| (qualified.clone(), identity.clone()));
        let Some((qualified, identity)) = found else {
            return Ok(None);
        };
        let membership = self.membership_for_subject(company, &qualified).await?;
        Ok(Some(self.principal_from(&identity, membership)))
    }

    async fn access_context_for_identity(
        &self,
        company_id: Uuid,
        identity: &QualifiedIdentity,
    ) -> AppResult<PrincipalAccessContext> {
        let known = self
            .state
            .lock()
            .unwrap()
            .identities
            .get(&(company_id, identity.clone()))
            .cloned();
        // Test fixtures state ACL principals and team membership without running the database
        // bootstrap that would have inserted their identity rows. Derive the same stable principal
        // for a read, but do not put it in `state`: a policy lookup must remain observable as
        // read-only, and accepted-message tests still resolve the same actor their grants name.
        let membership = self.membership_for_subject(company_id, identity).await?;
        Ok(PrincipalAccessContext {
            access_level: crate::entities::access_level::fixture_level(membership),
            principal_id: Some(
                known
                    .map(|known| known.principal_id)
                    .unwrap_or_else(|| principal_for_identity(company_id, identity)),
            ),
            membership,
            grant_authority: PrincipalGrantAuthority::Available,
        })
    }

    async fn access_context_for_user(
        &self,
        company_id: Uuid,
        user_id: Uuid,
    ) -> AppResult<Option<PrincipalAccessContext>> {
        let principal = self
            .state
            .lock()
            .unwrap()
            .users
            .get(&(company_id, user_id))
            .copied();
        let Some((principal_id, verified)) = principal else {
            return Ok(None);
        };
        let membership = match &self.team {
            Some(team) => team
                .company_access(user_id, company_id)
                .await?
                .map(|access| access.membership)
                .unwrap_or(CompanyMembership::None),
            None => CompanyMembership::None,
        };
        Ok(Some(PrincipalAccessContext {
            access_level: crate::entities::access_level::fixture_level(membership),
            principal_id: Some(principal_id),
            membership,
            grant_authority: if verified {
                PrincipalGrantAuthority::Available
            } else {
                PrincipalGrantAuthority::WithheldUnverifiedEmail
            },
        }))
    }
}

/// A directory that fails every call, for tests asserting that an outage propagates instead of
/// becoming an authorization verdict.
pub struct FailingParticipantDirectory;

fn outage() -> AppError {
    AppError::Internal("participant directory is unavailable".into())
}

#[async_trait]
impl IdentityDirectory for FailingParticipantDirectory {
    async fn resolve_or_create_external_identity(
        &self,
        _company_id: Uuid,
        _observation: IdentityObservation,
    ) -> AppResult<IdentityResolution> {
        Err(outage())
    }
}

#[async_trait]
impl PrincipalAccessPersistence for FailingParticipantDirectory {
    async fn direct_inboxes(
        &self,
        _company: Uuid,
        _user: Uuid,
        _limit: usize,
    ) -> AppResult<Vec<crate::application::ports::participant::DirectInbox>> {
        Err(crate::app_error::AppError::Internal(
            "direct inbox listing is outside this fixture".into(),
        ))
    }

    async fn principal_by_id(
        &self,
        _company: Uuid,
        _principal: PrincipalId,
    ) -> AppResult<Option<Principal>> {
        Err(outage())
    }

    async fn access_context_for_identity(
        &self,
        _company_id: Uuid,
        _identity: &QualifiedIdentity,
    ) -> AppResult<PrincipalAccessContext> {
        Err(outage())
    }

    async fn access_context_for_user(
        &self,
        _company_id: Uuid,
        _user_id: Uuid,
    ) -> AppResult<Option<PrincipalAccessContext>> {
        Err(outage())
    }
}
