//! One in-memory canonical message store, shared by every test that needs threads and messages.
//!
//! It exists because five near-identical hand-written doubles used to drift apart, and because the
//! canonical store has behaviour a naive `Vec<Message>` cannot stand in for: a payload is stored
//! once and associated with many threads, a redelivered provider key resolves to the message
//! already stored, and a *changed* redelivery is refused. A double that got any of those wrong
//! would let the ingest tests pass over bugs the real store rejects.
//!
//! Principal ids are derived from the handle rather than allocated, matching
//! [`crate::use_cases::participant::test_support`], so a fixture can name an actor before anything
//! has observed it.

use crate::entities::address::AddressTarget;
use std::{
    collections::{HashMap, HashSet},
    sync::{Arc, Mutex},
};

use async_trait::async_trait;
use chrono::{DateTime, Utc};
use sha2::{Digest, Sha256};
use uuid::Uuid;

use crate::app_error::AppError;
use crate::app_error::AppResult;
use crate::application::ports::channel::ChannelPersistence;
use crate::application::ports::integration::BindingStatusChange;
use crate::application::ports::integration::BindingWrite;
use crate::application::ports::integration::ChannelBindingPersistence;
use crate::application::ports::integration::InboundEndpoint;
use crate::application::ports::participant::IdentityObservation;
use crate::application::ports::thread::MessageAuthorWrite;
use crate::application::ports::thread::MessageCorrelation;
use crate::application::ports::thread::MessageParticipantWrite;
use crate::application::ports::thread::MessageWrite;
use crate::application::ports::thread::ThreadPersistence;
use crate::application::settings::ThreadSettings;
use crate::entities::correlation::CorrelationId;
use crate::entities::creation::CreationProvenance;
use crate::entities::cursor::MessageCursor;
use crate::entities::cursor::ThreadCursor;
use crate::entities::email_message::EmailMessageMetadata;
use crate::entities::internal_note::AddInternalNote;
use crate::entities::internal_note::InternalNoteView;
use crate::entities::internal_note::TombstoneInternalNote;
use crate::entities::message::AttachmentMetadata;
use crate::entities::message::CanonicalMessageId;
use crate::entities::message::Message;
use crate::entities::message::MessageAuthor;
use crate::entities::message::MessageDirection;
use crate::entities::message::MessageParticipant;
use crate::entities::message::MessageParticipantKind;
use crate::entities::message::MessageRole;
use crate::entities::message_view::AgentHistoryMessage;
use crate::entities::message_view::AuthorView;
use crate::entities::message_view::EmailReplyContext;
use crate::entities::message_view::MessageAuditView;
use crate::entities::message_view::THREAD_HISTORY_LIMIT;
use crate::entities::message_view::ThreadMessageView;
use crate::entities::participant::IdentityClaimMetadata;
use crate::entities::participant::IdentityProvenance;
use crate::entities::thread::Thread;
use crate::entities::thread::ThreadParticipantProjection;
use crate::entities::transport::BindingAccessPolicy;
use crate::entities::transport::BindingAccessSnapshot;
use crate::entities::transport::BindingAuditEvent;
use crate::entities::transport::BindingDeliveryPolicy;
use crate::entities::transport::BindingStatus;
use crate::entities::transport::ChannelBinding;
use crate::entities::transport::ChannelBindingId;
use crate::entities::transport::EndpointNamespace;
use crate::entities::transport::ExternalEndpointKey;
use crate::entities::transport::ExternalMessageKey;
use crate::entities::transport::ExternalThreadKey;
use crate::entities::transport::ParticipantIdentityId;
use crate::entities::transport::PrincipalId;
use crate::entities::transport::QualifiedIdentity;
use crate::entities::transport::TransportKind;
use crate::entities::value_objects::EmailAddress;
use crate::entities::value_objects::MessageId;
use crate::entities::value_objects::ThreadIndex;
use crate::transport::CommitDisposition;
use crate::transport::DeliveryCreation;
use crate::transport::ExternalCorrelationStore;
use crate::transport::InboundCommitOutcome;
use crate::transport::InboundCommitRequest;
use crate::transport::InboundEnvelope;
use crate::transport::InboundMessageCommitter;
use crate::transport::NewStandaloneDelivery;
use crate::transport::StandaloneDeliveryEnqueuer;
use crate::transport::ThreadTarget;
use crate::use_cases::company::CompanyPersistence;
use crate::use_cases::participant::ParticipantPersistence;
use crate::use_cases::participant::test_support::principal_for_email;
use crate::use_cases::participant::test_support::principal_for_identity;
use crate::use_cases::thread::InboundIngestPorts;
use crate::use_cases::thread::ThreadStores;
use crate::use_cases::thread::ThreadUseCases;

impl ThreadUseCases {
    pub fn for_test(
        thread_persistence: Arc<InMemoryThreads>,
        channel_persistence: Arc<dyn ChannelPersistence>,
        company_persistence: Arc<dyn CompanyPersistence>,
        participant_persistence: Arc<dyn ParticipantPersistence>,
        config: Arc<ThreadSettings>,
    ) -> Self {
        let ingest = InMemoryIngress::ports(thread_persistence.clone());
        let renderers = Arc::new(
            crate::transport::ports::TransportRenderers::new()
                .register(Arc::new(
                    crate::adapters::protocols::email::EmailRenderer::new(&config.mail_domain),
                ))
                .expect("one renderer registers"),
        );
        Self::new(
            ThreadStores {
                threads: thread_persistence,
                channels: channel_persistence,
                companies: company_persistence,
                participants: participant_persistence,
            },
            ingest,
            renderers,
            config,
        )
    }
}

/// One stored canonical payload.
#[derive(Clone)]
struct Canonical {
    id: CanonicalMessageId,
    author: MessageAuthor,
    subject: String,
    clean_text_body: String,
    attachments: Option<Vec<AttachmentMetadata>>,
    direction: MessageDirection,
    role: MessageRole,
    audience: crate::entities::message::MessageAudience,
    correlation_id: CorrelationId,
    participants: Vec<MessageParticipant>,
    email: Option<EmailMessageMetadata>,
}

impl Canonical {
    /// What must be identical for a repeated provider key to count as a redelivery.
    ///
    /// The same choice the database makes in `canonical_message_hash`: everything the sender
    /// actually sent, and deliberately *not* `clean_text_body`, which is derived per thread.
    fn delivered_payload(
        &self,
    ) -> (
        &str,
        &MessageDirection,
        &MessageRole,
        &Option<EmailMessageMetadata>,
    ) {
        (&self.subject, &self.direction, &self.role, &self.email)
    }
}

/// One thread's membership of a canonical payload.
#[derive(Clone, Copy)]
struct Association {
    id: Uuid,
    thread_id: Uuid,
    message_id: CanonicalMessageId,
    entry_kind: crate::entities::message::ThreadEntryKind,
    created_at: DateTime<Utc>,
}

/// Provider keys are unique per binding; this double has one channel-shaped binding per channel,
/// so the key is scoped by channel.
#[derive(Clone, PartialEq, Eq, Hash)]
struct ProviderKey {
    target: AddressTarget,
    key: String,
}

#[derive(Default)]
struct Store {
    binding_targets: HashMap<ChannelBindingId, AddressTarget>,
    threads: Vec<Thread>,
    canonical: Vec<Canonical>,
    associations: Vec<Association>,
    external_messages: HashMap<ProviderKey, CanonicalMessageId>,
    external_threads: HashMap<ProviderKey, Uuid>,
    /// Deliveries queued alongside a message, so a test can assert that an answer was not only
    /// recorded but actually handed to a transport.
    standalone_deliveries: Vec<NewStandaloneDelivery>,
    notes: HashMap<Uuid, (CanonicalMessageId, InternalNoteView)>,
    note_commands: HashMap<Uuid, (String, CanonicalMessageId)>,
    tombstone_commands: HashMap<Uuid, (String, Uuid)>,
    /// Every commit request handed to the double, so a test can assert what the plan asked for
    /// rather than only what the double chose to make of it.
    commits: Vec<InboundCommitRequest>,
}

/// An in-memory [`ThreadPersistence`].
#[derive(Clone, Default)]
pub struct InMemoryThreads {
    store: Arc<Mutex<Store>>,
    company_id: Uuid,
}

impl InMemoryThreads {
    pub fn queued_standalone_deliveries(&self) -> Vec<NewStandaloneDelivery> {
        self.store.lock().unwrap().standalone_deliveries.clone()
    }
}

impl InMemoryThreads {
    pub fn new() -> Self {
        Self::default()
    }

    /// Threads and messages this double attributes to one company, so derived principal ids match
    /// what a fixture's identity directory produces for the same company.
    pub fn for_company(company_id: Uuid) -> Self {
        Self {
            store: Arc::new(Mutex::new(Store::default())),
            company_id,
        }
    }

    /// Every commit request this double was handed, in order.
    pub fn committed_requests(&self) -> Vec<InboundCommitRequest> {
        self.store.lock().unwrap().commits.clone()
    }

    pub fn threads(&self) -> Vec<Thread> {
        self.store.lock().unwrap().threads.clone()
    }

    /// Every stored message, oldest association first.
    pub fn messages(&self) -> Vec<Message> {
        let store = self.store.lock().unwrap();
        let mut messages: Vec<Message> = store
            .associations
            .iter()
            .filter_map(|association| self.read(&store, association))
            .collect();
        messages.sort_by_key(Message::cursor);
        messages
    }

    /// The stable ids policy reads, derived from the addresses a fixture states -- the mirror of
    /// what `insert_thread_email_principals` writes in production.
    fn principals_for(&self, participant_emails: &[EmailAddress]) -> Vec<PrincipalId> {
        participant_emails
            .iter()
            .map(|email| principal_for_email(self.company_id, email))
            .collect()
    }

    fn read(&self, store: &Store, association: &Association) -> Option<Message> {
        let canonical = store
            .canonical
            .iter()
            .find(|canonical| canonical.id == association.message_id)?;
        Some(Message {
            access_level: crate::entities::access_level::AccessLevel::PUBLIC,
            response_contract: None,
            id: association.id,
            canonical_id: canonical.id,
            company_id: self.company_id,
            thread_id: association.thread_id,
            author: canonical.author.clone(),
            subject: canonical.subject.clone(),
            clean_text_body: canonical.clean_text_body.clone(),
            attachments: canonical.attachments.clone(),
            direction: canonical.direction,
            role: canonical.role,
            audience: canonical.audience,
            entry_kind: association.entry_kind,
            correlation_id: canonical.correlation_id,
            participants: canonical.participants.clone(),
            created_at: association.created_at,
        })
    }

    /// One thread's stored messages, oldest first.
    fn thread_messages(&self, thread_id: Uuid) -> Vec<Message> {
        let store = self.store.lock().unwrap();
        let mut messages: Vec<Message> = store
            .associations
            .iter()
            .filter(|association| association.thread_id == thread_id)
            .filter_map(|association| self.read(&store, association))
            .collect();
        messages.sort_by_key(Message::cursor);
        messages
    }

    fn thread_target(store: &Store, thread_id: Uuid) -> AppResult<AddressTarget> {
        store
            .threads
            .iter()
            .find(|thread| thread.id == thread_id)
            .map(|thread| thread.target)
            .ok_or_else(|| AppError::NotFound(format!("Thread {thread_id} was not found")))
    }

    fn resolve_author(&self, author: &MessageAuthorWrite) -> MessageAuthor {
        match author {
            MessageAuthorWrite::Observed(observation) => MessageAuthor {
                principal_id: principal_for_identity(self.company_id, &observation.identity),
                identity_id: Some(identity_id_for(&observation.identity)),
                label: observation
                    .display_label
                    .clone()
                    .unwrap_or_else(|| observation.identity.subject().as_str().to_string()),
                identity: Some(observation.identity.clone()),
            },
            MessageAuthorWrite::Principal(principal_id) => MessageAuthor {
                principal_id: *principal_id,
                identity_id: None,
                label: principal_id.to_string(),
                identity: None,
            },
            // Mirrors the writer's upsert: the agent's principal is stable per agent, so two
            // answers from one agent read as one author.
            MessageAuthorWrite::Agent(agent) => MessageAuthor {
                principal_id: PrincipalId::new(agent.agent_id),
                identity_id: None,
                label: agent.display_label.clone(),
                identity: None,
            },
            MessageAuthorWrite::Platform => MessageAuthor {
                principal_id: PrincipalId::new(self.company_id),
                identity_id: None,
                label: "System".to_string(),
                identity: None,
            },
        }
    }

    /// Positions assigned per kind from the order given, duplicates dropped -- the same rule the
    /// SQL writer applies, and what makes a rendered header reproducible.
    pub(crate) fn resolve_participants(
        participants: &[MessageParticipantWrite],
    ) -> Vec<MessageParticipant> {
        let mut resolved: Vec<MessageParticipant> = Vec::with_capacity(participants.len());
        for participant in participants {
            if resolved
                .iter()
                .any(|seen| seen.kind == participant.kind && seen.identity == participant.identity)
            {
                continue;
            }
            let position = resolved
                .iter()
                .filter(|seen| seen.kind == participant.kind)
                .count() as u16;
            resolved.push(MessageParticipant {
                kind: participant.kind,
                position,
                identity_id: identity_id_for(&participant.identity),
                identity: participant.identity.clone(),
            });
        }
        resolved
    }
}

/// A stable identity id for a handle, derived so two sightings of one address agree.
fn identity_id_for(identity: &QualifiedIdentity) -> ParticipantIdentityId {
    let mut digest = Sha256::new();
    digest.update(b"identity:");
    digest.update(identity.transport().as_str().as_bytes());
    digest.update(b":");
    digest.update(identity.namespace().as_str().as_bytes());
    digest.update(b":");
    digest.update(identity.subject().as_str().as_bytes());
    let bytes: [u8; 16] = digest.finalize()[..16]
        .try_into()
        .expect("sha256 yields at least 16 bytes");
    ParticipantIdentityId::new(Uuid::from_bytes(bytes))
}

#[async_trait]
impl ThreadPersistence for InMemoryThreads {
    async fn thread_access_levels(
        &self,
        company_id: Uuid,
        thread_ids: &[Uuid],
    ) -> AppResult<HashMap<Uuid, crate::entities::access_level::AccessLevel>> {
        Ok(thread_ids
            .iter()
            .map(|id| {
                let level = self
                    .thread_messages(*id)
                    .iter()
                    .filter(|message| message.company_id == company_id)
                    .map(|message| message.access_level)
                    .max()
                    .unwrap_or(crate::entities::access_level::AccessLevel::PUBLIC);
                (*id, level)
            })
            .collect())
    }
    async fn create_thread(
        &self,
        company_id: Uuid,
        target: AddressTarget,
        subject: &str,
        participant_emails: &[EmailAddress],
    ) -> AppResult<Thread> {
        let thread = Thread {
            id: Uuid::new_v4(),
            company_id,
            target,
            subject: subject.to_string(),
            participant_principal_ids: self.principals_for(participant_emails),
            participant_projection: ThreadParticipantProjection {
                identities: participant_emails
                    .iter()
                    .map(|email| {
                        super::qualified_email_identity(email.as_str())
                            .expect("test participant address is parseable")
                    })
                    .collect(),
            },
            created_at: Utc::now(),
            updated_at: Utc::now(),
        };
        self.store.lock().unwrap().threads.push(thread.clone());
        Ok(thread)
    }

    async fn get_thread_by_id(&self, company_id: Uuid, id: Uuid) -> AppResult<Option<Thread>> {
        Ok(self
            .store
            .lock()
            .unwrap()
            .threads
            .iter()
            .find(|thread| thread.company_id == company_id && thread.id == id)
            .cloned())
    }

    async fn list_threads_by_target(
        &self,
        company_id: Uuid,
        target: AddressTarget,
        before: Option<ThreadCursor>,
        limit: usize,
    ) -> AppResult<Vec<Thread>> {
        let mut threads: Vec<Thread> = self
            .store
            .lock()
            .unwrap()
            .threads
            .iter()
            .filter(|thread| thread.belongs_to(company_id, target))
            .filter(|thread| before.is_none_or(|cursor| thread.cursor() < cursor))
            .cloned()
            .collect();
        threads.sort_by_key(|thread| std::cmp::Reverse(thread.cursor()));
        threads.truncate(limit);
        Ok(threads)
    }

    async fn list_threads_updated_after(
        &self,
        company_id: Uuid,
        target: AddressTarget,
        after: Option<ThreadCursor>,
        limit: usize,
    ) -> AppResult<Vec<Thread>> {
        let mut threads: Vec<Thread> = self
            .store
            .lock()
            .unwrap()
            .threads
            .iter()
            .filter(|thread| thread.belongs_to(company_id, target))
            .filter(|thread| after.is_none_or(|cursor| thread.cursor() > cursor))
            .cloned()
            .collect();
        threads.sort_by_key(Thread::cursor);
        threads.truncate(limit);
        Ok(threads)
    }

    async fn update_thread_participants(
        &self,
        company_id: Uuid,
        id: Uuid,
        participant_emails: &[EmailAddress],
    ) -> AppResult<Thread> {
        let mut store = self.store.lock().unwrap();
        let thread = store
            .threads
            .iter_mut()
            .find(|thread| thread.company_id == company_id && thread.id == id)
            .ok_or_else(|| AppError::NotFound(format!("Thread {id} was not found")))?;
        thread.participant_principal_ids = participant_emails
            .iter()
            .map(|email| principal_for_email(self.company_id, email))
            .collect();
        thread.participant_projection.identities = participant_emails
            .iter()
            .map(|email| {
                super::qualified_email_identity(email.as_str())
                    .expect("test participant address is parseable")
            })
            .collect();
        Ok(thread.clone())
    }

    async fn get_thread_message(
        &self,
        thread_id: Uuid,
        message_id: CanonicalMessageId,
    ) -> AppResult<Option<Message>> {
        let store = self.store.lock().unwrap();
        Ok(store
            .associations
            .iter()
            .find(|association| {
                association.thread_id == thread_id && association.message_id == message_id
            })
            .and_then(|association| self.read(&store, association)))
    }

    async fn find_thread_for_message(
        &self,
        company_id: Uuid,
        target: AddressTarget,
        message_id: CanonicalMessageId,
    ) -> AppResult<Option<Thread>> {
        let store = self.store.lock().unwrap();
        let thread_ids: Vec<Uuid> = store
            .associations
            .iter()
            .filter(|association| association.message_id == message_id)
            .map(|association| association.thread_id)
            .collect();
        Ok(store
            .threads
            .iter()
            .find(|thread| thread.belongs_to(company_id, target) && thread_ids.contains(&thread.id))
            .cloned())
    }

    async fn get_message_protocol_extension(
        &self,
        _company_id: Uuid,
        message_id: CanonicalMessageId,
    ) -> AppResult<crate::application::ports::thread::ProtocolExtension> {
        let metadata = self
            .store
            .lock()
            .unwrap()
            .canonical
            .iter()
            .find(|message| message.id == message_id)
            .and_then(|message| message.email.clone());
        Ok(metadata.map_or_else(
            crate::application::ports::thread::ProtocolExtension::none,
            crate::application::ports::thread::ProtocolExtension::email,
        ))
    }

    async fn find_thread_by_thread_index(
        &self,
        company_id: Uuid,
        target: AddressTarget,
        thread_index: &ThreadIndex,
    ) -> AppResult<Option<Thread>> {
        let ancestors = thread_index.ancestor_chain().unwrap_or_default();
        let store = self.store.lock().unwrap();
        let matched = store
            .associations
            .iter()
            .filter_map(|association| {
                let canonical = store
                    .canonical
                    .iter()
                    .find(|canonical| canonical.id == association.message_id)?;
                let stored = canonical.email.as_ref()?.thread_index.as_ref()?;
                ancestors
                    .contains(stored)
                    .then_some((stored.len(), association))
            })
            .max_by_key(|(length, association)| (*length, association.created_at))
            .map(|(_, association)| association.thread_id);

        Ok(matched.and_then(|thread_id| {
            store
                .threads
                .iter()
                .find(|thread| thread.id == thread_id && thread.belongs_to(company_id, target))
                .cloned()
        }))
    }

    async fn count_recent_messages(
        &self,
        thread_id: Uuid,
        _duration_secs: i64,
    ) -> AppResult<usize> {
        Ok(self
            .store
            .lock()
            .unwrap()
            .associations
            .iter()
            .filter(|association| association.thread_id == thread_id)
            .count())
    }

    async fn create_message(&self, write: &MessageWrite) -> AppResult<Message> {
        let author = self.resolve_author(&write.author);
        let participants = Self::resolve_participants(&write.participants);
        let mut store = self.store.lock().unwrap();
        let target = Self::thread_target(&store, write.thread_id)?;

        let incoming = Canonical {
            // The producer's own id, exactly as `insert_message_on` uses it. Minting one here
            // instead made every delivery a producer built against `write.id` name a message this
            // double had not stored.
            id: write.id,
            author,
            subject: write.subject.clone(),
            clean_text_body: write.clean_text_body.clone(),
            attachments: (!write.attachments.is_empty()).then(|| write.attachments.clone()),
            direction: write.direction,
            role: write.role,
            audience: write.audience,
            correlation_id: write.correlation_id,
            participants,
            email: write.email_metadata().cloned(),
        };

        let canonical_id = match &write.correlation {
            MessageCorrelation::Email(metadata) => {
                let message_key = ProviderKey {
                    target,
                    key: metadata.rfc_message_id.as_str().to_string(),
                };
                let thread_key = ProviderKey {
                    target,
                    key: metadata.conversation_root_key().as_str().to_string(),
                };
                let canonical_id = match store.external_messages.get(&message_key).copied() {
                    Some(existing_id) => {
                        let existing = store
                            .canonical
                            .iter()
                            .find(|canonical| canonical.id == existing_id)
                            .expect("a mapped provider key names a stored message");
                        if existing.delivered_payload() != incoming.delivered_payload() {
                            return Err(AppError::Conflict(format!(
                                "provider message key '{}' already stores canonical message {} \
                                 with different content",
                                message_key.key, existing_id
                            )));
                        }
                        existing_id
                    }
                    None => {
                        let id = incoming.id;
                        store.canonical.push(incoming);
                        store.external_messages.insert(message_key, id);
                        id
                    }
                };
                store
                    .external_threads
                    .entry(thread_key)
                    .or_insert(write.thread_id);
                canonical_id
            }
            MessageCorrelation::Internal => {
                let id = incoming.id;
                store.canonical.push(incoming);
                id
            }
        };

        let association = associate(
            &mut store,
            write.thread_id,
            canonical_id,
            write.entry_kind,
            write.created_at,
        );
        let message = self
            .read(&store, &association)
            .expect("the association was just written");
        bump_thread(&mut store, write.thread_id);
        Ok(message)
    }

    async fn associate_message(
        &self,
        thread_id: Uuid,
        message: CanonicalMessageId,
        entry_kind: crate::entities::message::ThreadEntryKind,
    ) -> AppResult<Message> {
        let mut store = self.store.lock().unwrap();
        Self::thread_target(&store, thread_id)?;
        if !store
            .canonical
            .iter()
            .any(|canonical| canonical.id == message)
        {
            return Err(AppError::NotFound(format!(
                "Message {message} was not found"
            )));
        }
        let association = associate(&mut store, thread_id, message, entry_kind, Utc::now());
        let read = self
            .read(&store, &association)
            .expect("the association was just written");
        bump_thread(&mut store, thread_id);
        Ok(read)
    }

    async fn find_outbound_reply_after(
        &self,
        thread_id: Uuid,
        answering: CanonicalMessageId,
    ) -> AppResult<Option<Message>> {
        let store = self.store.lock().unwrap();
        let Some(answered) = store
            .associations
            .iter()
            .find(|association| {
                association.thread_id == thread_id && association.message_id == answering
            })
            .copied()
        else {
            return Ok(None);
        };
        let mut candidates: Vec<Message> = store
            .associations
            .iter()
            .filter(|association| association.thread_id == thread_id)
            .filter(|association| {
                (association.created_at, association.id) > (answered.created_at, answered.id)
            })
            .filter_map(|association| self.read(&store, association))
            .filter(|message| message.direction == MessageDirection::Outbound)
            .collect();
        candidates.sort_by_key(Message::cursor);
        Ok(candidates.pop())
    }

    async fn list_thread_message_views(
        &self,
        thread_id: Uuid,
    ) -> AppResult<Vec<ThreadMessageView>> {
        let mut messages = self.thread_messages(thread_id);
        // The newest window, then oldest-first, exactly as the SQL read does it.
        if messages.len() > THREAD_HISTORY_LIMIT {
            messages.drain(..messages.len() - THREAD_HISTORY_LIMIT);
        }
        Ok(messages.iter().map(thread_message_view).collect())
    }

    async fn list_thread_message_views_after(
        &self,
        thread_id: Uuid,
        after: Option<MessageCursor>,
        limit: usize,
    ) -> AppResult<Vec<ThreadMessageView>> {
        let mut messages = self.thread_messages(thread_id);
        messages.retain(|message| after.is_none_or(|cursor| message.cursor() > cursor));
        messages.truncate(limit.min(THREAD_HISTORY_LIMIT));
        Ok(messages.iter().map(thread_message_view).collect())
    }

    async fn get_thread_message_view(
        &self,
        thread_id: Uuid,
        message_id: CanonicalMessageId,
    ) -> AppResult<Option<ThreadMessageView>> {
        Ok(self
            .thread_messages(thread_id)
            .iter()
            .find(|message| message.canonical_id == message_id)
            .map(thread_message_view))
    }

    async fn list_agent_history(&self, thread_id: Uuid) -> AppResult<Vec<AgentHistoryMessage>> {
        let mut messages = self.thread_messages(thread_id);
        let private_note_messages: HashSet<_> = self
            .store
            .lock()
            .unwrap()
            .notes
            .values()
            .map(|(message_id, _)| *message_id)
            .collect();
        messages.retain(|message| !private_note_messages.contains(&message.canonical_id));
        if messages.len() > THREAD_HISTORY_LIMIT {
            messages.drain(..messages.len() - THREAD_HISTORY_LIMIT);
        }
        Ok(messages
            .iter()
            .map(|message| AgentHistoryMessage {
                access_level: message.access_level,
                role: message.role,
                audience: message.audience,
                entry_kind: message.entry_kind,
                author_display: message.author.display().to_string(),
                subject: message.subject.clone(),
                body: message.clean_text_body.clone(),
            })
            .collect())
    }

    async fn latest_email_reply_context(
        &self,
        thread_id: Uuid,
    ) -> AppResult<Option<EmailReplyContext>> {
        let store = self.store.lock().unwrap();
        let association = store
            .associations
            .iter()
            .filter(|association| association.thread_id == thread_id)
            .max_by_key(|association| (association.created_at, association.id));
        Ok(association.and_then(|association| {
            let message = self.read(&store, association)?;
            let metadata = store
                .canonical
                .iter()
                .find(|canonical| canonical.id == association.message_id)
                .and_then(|canonical| canonical.email.as_ref());
            Some(EmailReplyContext {
                canonical_id: message.canonical_id,
                author_email: message_sender_email(&message),
                rfc_message_id: metadata.map(|email| email.rfc_message_id.clone()),
                references: metadata
                    .map(|email| email.references.clone())
                    .unwrap_or_default(),
                cc: message_email_recipients(&message, MessageParticipantKind::Cc),
            })
        }))
    }

    /// The Postgres rule restated over the store: the newest inbound, external, conversation turn
    /// with an email author and email headers. Internal notes and agent turns never answer.
    async fn latest_replyable_email_context(
        &self,
        thread_id: Uuid,
    ) -> AppResult<Option<EmailReplyContext>> {
        use crate::entities::message::{MessageAudience, ThreadEntryKind};

        let store = self.store.lock().unwrap();
        let mut associations: Vec<_> = store
            .associations
            .iter()
            .filter(|association| {
                association.thread_id == thread_id
                    && association.entry_kind == ThreadEntryKind::Conversation
            })
            .collect();
        associations.sort_by_key(|association| (association.created_at, association.id));
        Ok(associations.into_iter().rev().find_map(|association| {
            let message = self.read(&store, association)?;
            if message.direction != MessageDirection::Inbound
                || message.audience != MessageAudience::ExternalConversation
            {
                return None;
            }
            let author_email = message_sender_email(&message)?;
            let metadata = store
                .canonical
                .iter()
                .find(|canonical| canonical.id == association.message_id)
                .and_then(|canonical| canonical.email.as_ref())?;
            Some(EmailReplyContext {
                canonical_id: message.canonical_id,
                author_email: Some(author_email),
                rfc_message_id: Some(metadata.rfc_message_id.clone()),
                references: metadata.references.clone(),
                cc: message_email_recipients(&message, MessageParticipantKind::Cc),
            })
        }))
    }

    async fn latest_thread_rfc_message_id(&self, thread_id: Uuid) -> AppResult<Option<MessageId>> {
        let store = self.store.lock().unwrap();
        let mut associations: Vec<_> = store
            .associations
            .iter()
            .filter(|association| association.thread_id == thread_id)
            .collect();
        associations.sort_by_key(|a| (a.created_at, a.id));
        for association in associations.into_iter().rev() {
            if let Some(canonical) = store
                .canonical
                .iter()
                .find(|canonical| canonical.id == association.message_id)
                && let Some(email) = canonical.email.as_ref()
            {
                return Ok(Some(email.rfc_message_id.clone()));
            }
        }
        Ok(None)
    }

    async fn get_message_audit(
        &self,
        _company_id: Uuid,
        _association_id: Uuid,
    ) -> AppResult<Option<MessageAuditView>> {
        // Only the diagnostic pane reads this, and no in-memory test exercises it. Stated rather
        // than defaulted, so a test that starts needing it fails here instead of seeing "no such
        // message" and concluding the authorization worked.
        unimplemented!("MessageAuditView is exercised against the database, not this double")
    }

    async fn create_internal_note(
        &self,
        command: &AddInternalNote,
        actor: PrincipalId,
    ) -> AppResult<ThreadMessageView> {
        let fingerprint = format!(
            "{}:{}:{}:{}:{}:{:?}",
            command.company_id,
            command.target,
            command.thread_id,
            command.text.trim(),
            actor,
            command.supersedes_note_id
        );
        let existing_command = {
            self.store
                .lock()
                .unwrap()
                .note_commands
                .get(&command.command_id)
                .cloned()
        };
        if let Some((existing, message_id)) = existing_command {
            if existing != fingerprint {
                return Err(AppError::Conflict(
                    "Internal-note command id was already used with different parameters.".into(),
                ));
            }
            return self
                .get_thread_message_view(command.thread_id, message_id)
                .await?
                .ok_or_else(|| AppError::Internal("Stored internal note is missing.".into()));
        }
        let write = MessageWrite::internal(
            command.thread_id,
            MessageAuthorWrite::Principal(actor),
            "Internal note",
            command.text.trim(),
            MessageDirection::Inbound,
            MessageRole::Human,
            CorrelationId::new(),
        );
        let message = self.create_message(&write).await?;
        let note = InternalNoteView {
            id: Uuid::new_v4(),
            author_principal_id: actor,
            provenance: command.provenance,
            supersedes_note_id: command.supersedes_note_id,
            superseded_by_note_id: None,
            tombstoned_at: None,
        };
        let mut store = self.store.lock().unwrap();
        if let Some(previous) = command.supersedes_note_id {
            let Some((_, old)) = store.notes.get_mut(&previous) else {
                return Err(AppError::Conflict(
                    "Only an active note can be corrected.".into(),
                ));
            };
            if !old.is_active() {
                return Err(AppError::Conflict(
                    "Only an active note can be corrected.".into(),
                ));
            }
            old.superseded_by_note_id = Some(note.id);
        }
        store
            .note_commands
            .insert(command.command_id, (fingerprint, message.canonical_id));
        store
            .notes
            .insert(note.id, (message.canonical_id, note.clone()));
        drop(store);
        let mut view = thread_message_view(&message);
        view.internal_note = Some(note);
        Ok(view)
    }

    async fn tombstone_internal_note(
        &self,
        command: &TombstoneInternalNote,
        actor: PrincipalId,
    ) -> AppResult<InternalNoteView> {
        let fingerprint = format!(
            "{}:{}:{}:{}:{}",
            command.company_id, command.target, command.thread_id, command.note_id, actor
        );
        let mut store = self.store.lock().unwrap();
        if let Some((existing, note_id)) = store.tombstone_commands.get(&command.command_id) {
            if existing != &fingerprint || *note_id != command.note_id {
                return Err(AppError::Conflict(
                    "Tombstone command id was already used with different parameters.".into(),
                ));
            }
            return store
                .notes
                .get(&command.note_id)
                .map(|(_, note)| note.clone())
                .ok_or_else(|| AppError::NotFound("Internal note not found.".into()));
        }
        let note = store
            .notes
            .get_mut(&command.note_id)
            .ok_or_else(|| AppError::NotFound("Internal note not found.".into()))?;
        if note.1.tombstoned_at.is_some() {
            return Err(AppError::Conflict(
                "That internal note has already been removed.".into(),
            ));
        }
        note.1.tombstoned_at = Some(Utc::now());
        let result = note.1.clone();
        store
            .tombstone_commands
            .insert(command.command_id, (fingerprint, command.note_id));
        Ok(result)
    }
}

/// The email-shaped stored message projected the way the SQL reads project it.
fn thread_message_view(message: &Message) -> ThreadMessageView {
    ThreadMessageView {
        restricted: false,
        access_level: message.access_level,
        response_contract: message.response_contract.clone(),
        id: message.id,
        canonical_id: message.canonical_id,
        thread_id: message.thread_id,
        run_ids: Vec::new(),
        author: AuthorView {
            principal_id: message.author.principal_id,
            label: message.author.label.clone(),
            handle: message
                .author
                .identity
                .as_ref()
                .map(|identity| identity.subject().as_str().to_string()),
            transport: message
                .author
                .identity
                .as_ref()
                .map(|identity| identity.transport()),
        },
        subject: message.subject.clone(),
        body: message.clean_text_body.clone(),
        attachments: message.attachments.clone().unwrap_or_default(),
        direction: message.direction,
        role: message.role,
        audience: message.audience,
        entry_kind: message.entry_kind,
        internal_note: None,
        created_at: message.created_at,
    }
}

/// Attach a payload to a thread, returning the association a thread already had if it has one.
fn associate(
    store: &mut Store,
    thread_id: Uuid,
    message_id: CanonicalMessageId,
    entry_kind: crate::entities::message::ThreadEntryKind,
    created_at: DateTime<Utc>,
) -> Association {
    if let Some(existing) = store.associations.iter().find(|association| {
        association.thread_id == thread_id && association.message_id == message_id
    }) {
        return *existing;
    }
    let association = Association {
        id: Uuid::new_v4(),
        thread_id,
        message_id,
        entry_kind,
        created_at,
    };
    store.associations.push(association);
    association
}

fn bump_thread(store: &mut Store, thread_id: Uuid) {
    if let Some(thread) = store
        .threads
        .iter_mut()
        .find(|thread| thread.id == thread_id)
    {
        thread.updated_at = Utc::now();
    }
}

/// The email-shaped description of one *stored* message, for tests that render history or scan
/// it rather than write it.
///
/// Deliberately keeps the shape the pre-canonical `Message` had: a test scenario reads best when
/// it states a sender, a Message-ID and a recipient list, and turning those into an author
/// principal, a participant projection and an email extension is exactly the mapping production
/// does. `Default` supplies everything a scenario does not care about.
#[derive(Debug, Clone)]
pub struct EmailMessageDraft {
    pub id: Uuid,
    pub thread_id: Uuid,
    pub message_id: MessageId,
    pub in_reply_to: Option<MessageId>,
    pub references_list: Vec<MessageId>,
    pub sender: EmailAddress,
    pub recipients_to: Vec<EmailAddress>,
    pub recipients_cc: Vec<EmailAddress>,
    pub subject: String,
    pub clean_text_body: String,
    pub raw_text_body: Option<String>,
    pub raw_html_body: Option<String>,
    pub attachments: Option<Vec<AttachmentMetadata>>,
    pub direction: MessageDirection,
    pub role: MessageRole,
    pub thread_index: Option<ThreadIndex>,
    pub created_at: DateTime<Utc>,
}

impl Default for EmailMessageDraft {
    fn default() -> Self {
        Self {
            id: Uuid::new_v4(),
            thread_id: Uuid::new_v4(),
            message_id: MessageId::from("<draft@example.com>"),
            in_reply_to: None,
            references_list: Vec::new(),
            sender: EmailAddress::from("sender@example.com"),
            recipients_to: Vec::new(),
            recipients_cc: Vec::new(),
            subject: "Subject".to_string(),
            clean_text_body: String::new(),
            raw_text_body: None,
            raw_html_body: None,
            attachments: None,
            direction: MessageDirection::Inbound,
            role: MessageRole::Human,
            thread_index: None,
            created_at: Utc::now(),
        }
    }
}

/// The stored message a draft describes.
pub fn stored_email(draft: EmailMessageDraft) -> Message {
    let sender = super::qualified_email_identity(draft.sender.as_str())
        .expect("test fixture sender address is parseable");
    let mut participants = vec![MessageParticipantWrite::new(
        MessageParticipantKind::Sender,
        sender.clone(),
    )];
    for (kind, addresses) in [
        (MessageParticipantKind::To, &draft.recipients_to),
        (MessageParticipantKind::Cc, &draft.recipients_cc),
    ] {
        for address in addresses {
            participants.push(MessageParticipantWrite::new(
                kind,
                super::qualified_email_identity(address.as_str())
                    .expect("test fixture recipient address is parseable"),
            ));
        }
    }

    Message {
        access_level: crate::entities::access_level::AccessLevel::PUBLIC,
        response_contract: None,
        id: draft.id,
        canonical_id: CanonicalMessageId::random(),
        company_id: Uuid::nil(),
        thread_id: draft.thread_id,
        author: MessageAuthor {
            principal_id: principal_for_identity(Uuid::nil(), &sender),
            identity_id: Some(identity_id_for(&sender)),
            label: draft.sender.as_str().to_string(),
            identity: Some(sender),
        },
        subject: draft.subject,
        clean_text_body: draft.clean_text_body,
        attachments: draft.attachments,
        direction: draft.direction,
        role: draft.role,
        audience: crate::entities::message::MessageAudience::ExternalConversation,
        entry_kind: crate::entities::message::ThreadEntryKind::Conversation,
        correlation_id: CorrelationId::new(),
        participants: InMemoryThreads::resolve_participants(&participants),
        created_at: draft.created_at,
    }
}

fn message_email_recipients(message: &Message, kind: MessageParticipantKind) -> Vec<EmailAddress> {
    let mut selected: Vec<_> = message
        .participants
        .iter()
        .filter(|participant| participant.kind == kind)
        .filter(|participant| participant.identity.transport() == TransportKind::Email)
        .collect();
    selected.sort_by_key(|participant| participant.position);
    selected
        .into_iter()
        .map(|participant| EmailAddress::from(participant.identity.subject().as_str()))
        .collect()
}

fn message_sender_email(message: &Message) -> Option<EmailAddress> {
    message_email_recipients(message, MessageParticipantKind::Sender)
        .into_iter()
        .next()
        .or_else(|| {
            message
                .author
                .identity
                .as_ref()
                .filter(|identity| identity.transport() == TransportKind::Email)
                .map(|identity| EmailAddress::from(identity.subject().as_str()))
        })
}

/// The stored message a draft describes, as a page reads it.
///
/// Projected from [`stored_email`] rather than built beside it, so a fixture and the thing it
/// stands for cannot drift.
pub fn stored_email_view(draft: EmailMessageDraft) -> ThreadMessageView {
    thread_message_view(&stored_email(draft))
}

impl InMemoryThreads {
    /// Which conversation these provider keys belong to, through the external maps.
    ///
    /// Conversation bindings first, then message keys: the same order the SQL reader uses, so
    /// reply-before-root resolves here too.
    fn find_thread_by_keys(&self, target: AddressTarget, keys: &[String]) -> Option<Thread> {
        let store = self.store.lock().unwrap();
        for key in keys {
            let key = ProviderKey {
                target,
                key: key.clone(),
            };
            if let Some(thread_id) = store.external_threads.get(&key).copied() {
                return store
                    .threads
                    .iter()
                    .find(|thread| thread.id == thread_id)
                    .cloned();
            }
        }
        for key in keys {
            let key = ProviderKey {
                target,
                key: key.clone(),
            };
            let Some(canonical_id) = store.external_messages.get(&key).copied() else {
                continue;
            };
            let thread_id = store
                .associations
                .iter()
                .filter(|association| association.message_id == canonical_id)
                .max_by_key(|association| association.created_at)
                .map(|association| association.thread_id);
            if let Some(thread_id) = thread_id {
                return store
                    .threads
                    .iter()
                    .find(|thread| thread.id == thread_id)
                    .cloned();
            }
        }
        None
    }

    /// The canonical message a provider key already names in one channel.
    fn message_for_key(&self, target: AddressTarget, key: &str) -> Option<CanonicalMessageId> {
        self.store
            .lock()
            .unwrap()
            .external_messages
            .get(&ProviderKey {
                target,
                key: key.to_string(),
            })
            .copied()
    }
}

/// The ingest ports, backed by the same in-memory stores a fixture asserts against.
///
/// **Not transactional, and deliberately so.** Atomicity is a property of the SQL committer and is
/// tested against a real database; what this double provides is the same *ordering* and the same
/// dedup rule, so a policy test can run the whole pipeline without one. A test that cares whether
/// a partial commit is possible is a database test by definition.
///
/// One synthetic email binding per channel, with the channel's own id, so a binding-qualified key
/// and a channel-qualified key are the same fact here -- which is exactly what production means by
/// "email is a deployment transport and every channel has one interface".
#[derive(Clone)]
pub struct InMemoryIngress {
    threads: Arc<InMemoryThreads>,
}

impl InMemoryIngress {
    pub fn new(threads: Arc<InMemoryThreads>) -> Self {
        Self { threads }
    }

    /// The ports [`ThreadUseCases::for_test`] wires, all reading the store given here.
    pub fn ports(threads: Arc<InMemoryThreads>) -> InboundIngestPorts {
        let ingress = Arc::new(Self::new(threads));
        InboundIngestPorts {
            committer: ingress.clone(),
            correlation: ingress.clone(),
            bindings: ingress.clone(),
            standalone_deliveries: ingress,
        }
    }
}

#[async_trait]
impl StandaloneDeliveryEnqueuer for InMemoryIngress {
    async fn enqueue_standalone_delivery(
        &self,
        delivery: NewStandaloneDelivery,
    ) -> AppResult<DeliveryCreation> {
        let mut store = self.threads.store.lock().unwrap();
        if let Some(existing) = store.standalone_deliveries.iter().find(|queued| {
            queued.transport == delivery.transport
                && queued.idempotency_key == delivery.idempotency_key
        }) {
            return Ok(DeliveryCreation::Absorbed(existing.id));
        }
        let id = delivery.id;
        store.standalone_deliveries.push(delivery);
        Ok(DeliveryCreation::Created(id))
    }
}

impl InMemoryIngress {
    /// The channel a synthetic binding stands for.
    fn target_of(&self, binding_id: ChannelBindingId) -> AddressTarget {
        self.threads
            .store
            .lock()
            .unwrap()
            .binding_targets
            .get(&binding_id)
            .copied()
            .unwrap_or(AddressTarget::Desk(binding_id.as_uuid()))
    }

    fn binding_of(channel_id: Uuid) -> ChannelBinding {
        ChannelBinding {
            id: ChannelBindingId::new(channel_id),
            company_id: Uuid::nil(),
            target: AddressTarget::Desk(channel_id),
            installation_id: None,
            transport: TransportKind::Email,
            namespace: EndpointNamespace::parse("email").expect("a valid namespace"),
            external_endpoint_key: ExternalEndpointKey::parse(channel_id.to_string())
                .expect("a UUID is a valid endpoint key"),
            display_label: format!("{channel_id}@test"),
            access_policy: BindingAccessPolicy::TargetAcl,
            delivery_policy: BindingDeliveryPolicy::ReplyAndInitiate,
            status: BindingStatus::Active,
            disabled_reason: None,
            created_by: CreationProvenance::system(),
            access_snapshot: BindingAccessSnapshot::deployment_endpoint(),
            created_at: Utc::now(),
            updated_at: Utc::now(),
        }
    }
}

#[async_trait]
impl ChannelBindingPersistence for InMemoryIngress {
    async fn create_binding(&self, _write: BindingWrite) -> AppResult<ChannelBinding> {
        Err(AppError::Internal(
            "This double serves the one email interface every channel already has".into(),
        ))
    }

    async fn active_bindings_for_target(
        &self,
        company_id: Uuid,
        target: AddressTarget,
    ) -> AppResult<Vec<ChannelBinding>> {
        let id = match target {
            AddressTarget::Desk(id) => ChannelBindingId::new(id),
            AddressTarget::Principal(_) => {
                let mut store = self.threads.store.lock().unwrap();
                match store
                    .binding_targets
                    .iter()
                    .find(|(_, stored)| **stored == target)
                {
                    Some((id, _)) => *id,
                    None => {
                        let id = ChannelBindingId::new(Uuid::new_v4());
                        store.binding_targets.insert(id, target);
                        id
                    }
                }
            }
        };
        let mut binding = Self::binding_of(id.as_uuid());
        binding.company_id = company_id;
        binding.target = target;
        Ok(vec![binding])
    }

    async fn find_active_binding_by_endpoint(
        &self,
        _endpoint: &InboundEndpoint,
    ) -> AppResult<Option<ChannelBinding>> {
        Ok(None)
    }

    async fn list_bindings_for_company(&self, _company_id: Uuid) -> AppResult<Vec<ChannelBinding>> {
        Ok(Vec::new())
    }

    async fn get_binding(
        &self,
        _company_id: Uuid,
        binding_id: ChannelBindingId,
    ) -> AppResult<Option<ChannelBinding>> {
        let mut binding = Self::binding_of(binding_id.as_uuid());
        binding.target = self.target_of(binding_id);
        Ok(Some(binding))
    }

    async fn set_binding_status(&self, _change: BindingStatusChange) -> AppResult<ChannelBinding> {
        Err(AppError::Internal(
            "This double does not change binding status".into(),
        ))
    }

    async fn list_binding_audit_events(
        &self,
        _company_id: Uuid,
        _binding_id: ChannelBindingId,
        _limit: i64,
    ) -> AppResult<Vec<BindingAuditEvent>> {
        Ok(Vec::new())
    }
}

#[async_trait]
impl ExternalCorrelationStore for InMemoryIngress {
    async fn thread_for_thread_keys(
        &self,
        binding_id: ChannelBindingId,
        thread_keys: &[ExternalThreadKey],
    ) -> AppResult<Option<Uuid>> {
        let keys: Vec<String> = thread_keys
            .iter()
            .map(|key| key.as_str().to_string())
            .collect();
        Ok(self
            .threads
            .find_thread_by_keys(self.target_of(binding_id), &keys)
            .map(|thread| thread.id))
    }

    async fn thread_for_message_keys(
        &self,
        binding_id: ChannelBindingId,
        message_keys: &[ExternalMessageKey],
    ) -> AppResult<Option<Uuid>> {
        let keys: Vec<String> = message_keys
            .iter()
            .map(|key| key.as_str().to_string())
            .collect();
        Ok(self
            .threads
            .find_thread_by_keys(self.target_of(binding_id), &keys)
            .map(|thread| thread.id))
    }

    async fn message_for_external_key(
        &self,
        binding_id: ChannelBindingId,
        message_key: &ExternalMessageKey,
    ) -> AppResult<Option<CanonicalMessageId>> {
        Ok(self
            .threads
            .message_for_key(self.target_of(binding_id), message_key.as_str()))
    }
}

#[async_trait]
impl InboundMessageCommitter for InMemoryIngress {
    async fn commit_inbound(
        &self,
        request: InboundCommitRequest,
    ) -> AppResult<InboundCommitOutcome> {
        self.threads
            .store
            .lock()
            .unwrap()
            .commits
            .push(request.clone());
        let mut thread_ids = Vec::with_capacity(request.associations.len());
        for association in &request.associations {
            let emails: Vec<EmailAddress> = association
                .principals
                .iter()
                .filter_map(|intent| match &intent.reference {
                    crate::transport::ThreadPrincipalReference::Observed(identity)
                        if intent.role
                            == crate::entities::participant::ThreadPrincipalRole::Participant
                            && identity.transport() == TransportKind::Email =>
                    {
                        Some(EmailAddress::from(identity.subject().as_str()))
                    }
                    _ => None,
                })
                .collect();
            let thread_id = match &association.target {
                ThreadTarget::Existing(thread_id) => {
                    if !emails.is_empty() {
                        let thread = self
                            .threads
                            .get_thread_by_id(request.company_id, *thread_id)
                            .await?
                            .ok_or_else(|| AppError::NotFound("Thread was not found".into()))?;
                        let mut participants: Vec<EmailAddress> = thread
                            .participant_projection
                            .subjects_for(TransportKind::Email)
                            .into_iter()
                            .map(EmailAddress::from)
                            .collect();
                        for handle in &emails {
                            if !participants
                                .iter()
                                .any(|existing| existing.eq_ignore_ascii_case(handle))
                            {
                                participants.push(handle.clone());
                            }
                        }
                        self.threads
                            .update_thread_participants(
                                request.company_id,
                                *thread_id,
                                &participants,
                            )
                            .await?;
                    }
                    *thread_id
                }
                ThreadTarget::Create { subject } => {
                    self.threads
                        .create_thread(
                            request.company_id,
                            association.address_target,
                            subject,
                            &emails,
                        )
                        .await?
                        .id
                }
            };
            {
                let mut store = self.threads.store.lock().unwrap();
                let thread = store
                    .threads
                    .iter_mut()
                    .find(|thread| thread.id == thread_id)
                    .unwrap();
                for principal in
                    association
                        .principals
                        .iter()
                        .filter_map(|intent| match intent.reference {
                            crate::transport::ThreadPrincipalReference::Known(principal) => {
                                Some(principal)
                            }
                            _ => None,
                        })
                {
                    if !thread.participant_principal_ids.contains(&principal) {
                        thread.participant_principal_ids.push(principal);
                    }
                }
            }
            thread_ids.push(thread_id);
        }

        let envelope = &request.envelope;
        // Asked before the write, because `create_message` returns the stored message either way:
        // whether this delivery is the first one is what the caller needs to know.
        let already_stored = self
            .threads
            .message_for_key(
                self.target_of(envelope.source.binding_id),
                envelope.source.message_key.as_str(),
            )
            .is_some();
        let write = inbound_message_write(envelope, thread_ids[0]);
        // `create_message` is where the double's dedup lives: a repeated provider key returns the
        // stored message, and one carrying different content is refused.
        let stored = self.threads.create_message(&write).await?;
        let mut association_by_channel = std::collections::HashMap::new();
        association_by_channel.insert(request.associations[0].address_target, stored.id);
        for (association, thread_id) in request.associations.iter().zip(&thread_ids).skip(1) {
            let message = self
                .threads
                .associate_message(*thread_id, stored.canonical_id, write.entry_kind)
                .await?;
            association_by_channel.insert(association.address_target, message.id);
        }
        // The double stores no intent rows. It names each association's intent the same way on
        // every delivery, so a redelivery reports the first delivery's intents, as the SQL
        // committer does (p08 D1.3).
        let intent_ids = request
            .intents
            .iter()
            .map(|intent| {
                Uuid::from_u128(
                    stored.canonical_id.as_uuid().as_u128()
                        ^ match intent.target {
                            AddressTarget::Desk(id) => id.as_u128(),
                            AddressTarget::Principal(id) => id.as_uuid().as_u128() ^ 1,
                        },
                )
            })
            .collect();
        Ok(InboundCommitOutcome {
            disposition: if already_stored {
                CommitDisposition::Duplicate
            } else {
                CommitDisposition::Created
            },
            message_id: stored.canonical_id,
            thread_ids,
            intent_ids,
            delivery_ids: Vec::new(),
        })
    }
}

/// The producer vocabulary for one arriving message, mirroring what the SQL committer projects.
fn inbound_message_write(envelope: &InboundEnvelope, thread_id: Uuid) -> MessageWrite {
    let mut participants = vec![MessageParticipantWrite::new(
        MessageParticipantKind::Sender,
        envelope.author.clone(),
    )];
    for addressed in &envelope.addressed {
        participants.push(MessageParticipantWrite::new(
            addressed.role.participant_kind(),
            addressed.identity.clone(),
        ));
    }
    MessageWrite {
        structured: None,
        id: CanonicalMessageId::random(),
        thread_id,
        author: MessageAuthorWrite::Observed(IdentityObservation {
            identity: envelope.author.clone(),
            display_label: None,
            claim_metadata: IdentityClaimMetadata::observation(),
            provenance: match envelope.author.transport() {
                TransportKind::Email | TransportKind::Slack => IdentityProvenance::TransportIngress,
            },
        }),
        subject: envelope.content.subject().to_string(),
        clean_text_body: envelope.content.body_text().to_string(),
        attachments: envelope.attachments.to_vec(),
        direction: MessageDirection::Inbound,
        role: if envelope.directives.source_target.is_some() {
            MessageRole::Agent
        } else {
            MessageRole::Human
        },
        audience: if envelope.directives.source_target.is_some() {
            crate::entities::message::MessageAudience::InternalOnly
        } else {
            crate::entities::message::MessageAudience::ExternalConversation
        },
        entry_kind: if envelope.directives.source_target.is_some() {
            crate::entities::message::ThreadEntryKind::Delegation
        } else {
            crate::entities::message::ThreadEntryKind::Conversation
        },
        correlation_id: envelope.correlation_id,
        participants,
        correlation: match envelope.extension.email_metadata() {
            Some(metadata) => MessageCorrelation::Email(metadata.clone()),
            None => MessageCorrelation::Internal,
        },
        created_at: Utc::now(),
    }
}

impl crate::use_cases::thread::ThreadUseCases {
    /// Ingest one mail exactly as the SMTP listener does: through the email adapter, with the
    /// verdicts a verifying boundary established, as external transport traffic.
    ///
    /// Tests reach for this rather than assembling an envelope by hand so that the address
    /// grammar, the bounds and the policy facts are the ones production applies -- a fixture that
    /// built its own envelope could not fail the way a real message fails.
    pub async fn ingest_test_email(
        &self,
        payload: crate::adapters::protocols::email::parser::RawInboundPayload,
    ) -> AppResult<crate::use_cases::thread::InboundIngestResult> {
        self.ingest_test_email_as(
            payload,
            crate::use_cases::thread::IngressOrigin::ExternalTransport,
        )
        .await
    }

    /// The same, for a message an authenticated route composed instead.
    pub async fn ingest_test_email_as(
        &self,
        payload: crate::adapters::protocols::email::parser::RawInboundPayload,
        origin: crate::use_cases::thread::IngressOrigin,
    ) -> AppResult<crate::use_cases::thread::InboundIngestResult> {
        use crate::adapters::protocols::email::{
            EmailIngressAdapter, EmailIngressTrust, VerifiedEmailAuth,
        };
        let trust = match origin {
            crate::use_cases::thread::IngressOrigin::ExternalTransport => {
                EmailIngressTrust::Verified(VerifiedEmailAuth {
                    spf: payload.spf,
                    dkim: payload.dkim,
                    dmarc: payload.dmarc,
                    spam_score: payload.spam_score,
                })
            }
            _ => EmailIngressTrust::Application,
        };
        let accepted =
            EmailIngressAdapter::new(&self.settings.mail_domain).accept(payload, trust)?;
        self.ingest(accepted.into_inbound(origin, crate::use_cases::thread::ReplyDelivery::Send))
            .await
    }
}
