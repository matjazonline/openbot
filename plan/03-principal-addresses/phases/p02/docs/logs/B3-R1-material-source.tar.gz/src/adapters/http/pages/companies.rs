//! Company settings, team members and invitations.
use super::team_levels::{LEVEL_HELP, LevelControl, level_control, level_options};
use crate::entities::access_level::{AccessLevel, LevelActor, LevelTarget};

use super::*;

pub fn companies_page(companies: &[Company]) -> String {
    let list_html = company_list_fragment(companies);

    let content = format!(
        r##"
        <div class="flex items-center justify-between mb-6">
            <div>
                <h2 class="text-2xl font-bold text-base-content">Company Accounts</h2>
                <p class="text-base-content/70 text-sm mt-1">Manage your organization profiles and indexed slugs</p>
            </div>
            <button id="company-form-toggle" type="button" aria-controls="company-form-card" aria-expanded="false"
                data-action="toggle-form-card" data-card="company-form-card"
                class="px-4 py-2 bg-primary hover:bg-primary/90 text-primary-content text-sm font-semibold rounded-lg shadow-md shadow-primary/20 transition cursor-pointer">
                Add Company
            </button>
        </div>

        <div id="response-message" class="mb-6"></div>

        <!-- Create Company Card -->
        <div id="company-form-card" class="hidden bg-base-100 border border-base-300 rounded-xl p-5 mb-8">
            <h3 class="text-md font-semibold text-base-content mb-3 flex items-center gap-2">
                <span class="text-primary">+</span> Add New Company
            </h3>
            <form hx-post="/companies" hx-target="#company-list" hx-swap="innerHTML" class="space-y-4"
                data-after-request="reset-and-collapse" data-card="company-form-card" data-toggle="company-form-toggle">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label for="company_name" class="block text-xs font-medium text-base-content/80 mb-1">Company Name</label>
                        <input type="text" id="company_name" name="name" required
                            data-input="slugify" data-slug-target="company_slug"
                            class="w-full px-3.5 py-2 bg-base-200 border border-base-300 rounded-lg text-base-content text-sm placeholder-base-content/60 focus:outline-none focus:ring-2 focus:ring-primary"
                            placeholder="Acme Corporation">
                    </div>
                    <div>
                        <label for="company_slug" class="block text-xs font-medium text-base-content/80 mb-1">Slug (Indexed)</label>
                        <input type="text" id="company_slug" name="slug" required
                            class="w-full px-3.5 py-2 bg-base-200 border border-base-300 rounded-lg text-base-content text-sm placeholder-base-content/60 focus:outline-none focus:ring-2 focus:ring-primary font-mono"
                            placeholder="acme-corporation">
                    </div>
                </div>
                <div class="flex justify-end">
                    <button type="submit"
                        class="px-5 py-2 bg-primary hover:bg-primary/90 text-primary-content text-sm font-semibold rounded-lg shadow-md shadow-primary/20 transition cursor-pointer">
                        Create Company
                    </button>
                </div>
            </form>
        </div>

        <!-- Company List Section -->
        <div>
            <h3 class="text-sm font-semibold uppercase tracking-wider text-base-content/70 mb-3">Your Companies</h3>
            <div id="company-list" class="space-y-3">
                {list_html}
            </div>
        </div>
    "##,
    );

    base_layout("Companies", &content)
}

pub fn company_list_fragment(companies: &[Company]) -> String {
    if companies.is_empty() {
        return r##"
            <div class="bg-base-100 border border-dashed border-base-300 rounded-xl p-8 text-center">
                <p class="text-base-content/70 text-sm">No companies registered yet. Use Add Company to create your first one.</p>
            </div>
        "##
        .to_string();
    }

    companies.iter().map(company_row_fragment).collect()
}

pub fn company_row_fragment(company: &Company) -> String {
    let created_at_str = super::format_date(company.created_at);
    format!(
        r##"
        <div id="company-{id}" data-action="select-company" data-company-id="{id}" class="bg-base-100 border border-base-300 rounded-xl p-4 md:p-5 flex items-center justify-between hover:border-base-content/30 transition shadow-sm cursor-pointer">
            <div>
                <div class="flex items-center gap-3">
                    <h4 class="text-md font-semibold text-base-content">{name}</h4>
                    <span class="px-2.5 py-0.5 rounded-full text-xs font-mono bg-primary/10 text-primary border border-primary/40">/{slug}</span>
                    <span id="selected-badge-{id}" class="hidden px-2 py-0.5 rounded text-[10px] font-semibold bg-success/10 text-base-content border border-success/40 uppercase tracking-wider">Active</span>
                </div>
                <p class="text-xs text-base-content/70 mt-1">Added {created_at_str}</p>
            </div>
            <div class="flex items-center gap-2">
                <a href="/companies/{id}/agents" data-action="select-company" data-company-id="{id}"
                    class="px-3 py-1.5 text-xs font-medium bg-info/10 hover:bg-info/20 text-base-content border border-info/40 rounded-lg transition">
                    Agents
                </a>
                <a href="/companies/{id}/channels" data-action="select-company" data-company-id="{id}"
                    class="px-3 py-1.5 text-xs font-medium bg-success/10 hover:bg-success/20 text-base-content border border-success/40 rounded-lg transition">
                    Desks
                </a>
                <a href="/companies/{id}/invites" data-action="select-company" data-company-id="{id}"
                    class="px-3 py-1.5 text-xs font-medium bg-primary/10 hover:bg-primary/20 text-primary border border-primary/40 rounded-lg transition">
                    Invites & Team
                </a>
                <button hx-get="/companies/{id}/edit" hx-target="#company-{id}" hx-swap="outerHTML" data-action="isolate"
                    class="px-3 py-1.5 text-xs font-medium bg-base-300 hover:bg-base-content/15 text-base-content rounded-lg transition cursor-pointer">
                    Edit
                </button>
                <button hx-delete="/companies/{id}" hx-target="#company-{id}" hx-swap="outerHTML" hx-confirm="Are you sure you want to delete '{name}'?" data-action="isolate"
                    data-after-request="clear-cached-company" data-company-id="{id}"
                    class="px-3 py-1.5 text-xs font-medium bg-error/10 hover:bg-error/20 text-base-content border border-error/40 rounded-lg transition cursor-pointer">
                    Delete
                </button>
            </div>
        </div>
        "##,
        id = company.id,
        name = escape_html_attr(&company.name),
        slug = escape_html_text(&company.slug),
        created_at_str = created_at_str,
    )
}

pub fn company_edit_fragment(company: &Company) -> String {
    format!(
        r##"
        <form id="company-{id}" hx-put="/companies/{id}" hx-target="#company-{id}" hx-swap="outerHTML"
            class="bg-base-100 border border-primary/40 rounded-xl p-4 md:p-5 space-y-4 shadow-lg">
            <!-- A save sets every column, so the picture -- which is picked in `/ui`, not here --
                 rides along rather than being cleared by a rename. -->
            <input type="hidden" name="avatar_url" value="{avatar_url}">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label class="block text-xs font-medium text-base-content/80 mb-1">Company Name</label>
                    <input type="text" name="name" value="{name}" required
                        data-input="slugify"
                        class="w-full px-3.5 py-2 bg-base-200 border border-base-300 rounded-lg text-base-content text-sm focus:outline-none focus:ring-2 focus:ring-primary">
                </div>
                <div>
                    <label class="block text-xs font-medium text-base-content/80 mb-1">Slug (Indexed)</label>
                    <input type="text" name="slug" value="{slug}" required
                        class="w-full px-3.5 py-2 bg-base-200 border border-base-300 rounded-lg text-base-content text-sm focus:outline-none focus:ring-2 focus:ring-primary font-mono">
                </div>
            </div>
            <div class="flex items-center justify-end gap-2">
                <button type="button" hx-get="/companies/{id}/cancel" hx-target="#company-{id}" hx-swap="outerHTML"
                    class="px-3 py-1.5 text-xs font-medium bg-base-300 hover:bg-base-content/15 text-base-content rounded-lg transition cursor-pointer">
                    Cancel
                </button>
                <button type="submit"
                    class="px-4 py-1.5 text-xs font-semibold bg-primary hover:bg-primary/90 text-primary-content rounded-lg transition cursor-pointer">
                    Save Changes
                </button>
            </div>
        </form>
        "##,
        id = company.id,
        name = escape_html_attr(&company.name),
        slug = escape_html_attr(&company.slug),
        avatar_url = escape_html_attr(company.avatar_url.as_deref().unwrap_or("")),
    )
}

pub fn company_invites_page(
    company: &Company,
    invites: &[CompanyInvite],
    members: &[CompanyMember],
    actor: LevelActor,
) -> String {
    let invites_html = company_invite_list_fragment(company.id, invites, actor);
    let team_html = company_team_list_fragment(company.id, members, actor);

    let content = format!(
        r##"
        <div class="flex items-center justify-between mb-6">
            <div>
                <a href="/companies" class="text-xs text-primary hover:text-primary font-medium mb-1 inline-block">&larr; Back to Companies</a>
                <h2 class="text-2xl font-bold text-base-content">{company_name} Management</h2>
                <p class="text-base-content/70 text-sm mt-0.5">Manage email invites and view team members for <span class="font-mono text-primary">/{slug}</span></p>
            </div>
        </div>

        <div id="response-message" class="mb-6"></div>

        {create_invite}

        <!-- Invites List Section -->
        <div class="mb-10">
            <h3 class="text-sm font-semibold uppercase tracking-wider text-base-content/70 mb-3">Email Invites</h3>
            <div id="invite-list" class="space-y-3">
                {invites_html}
            </div>
        </div>

        <!-- Team Members Section -->
        <div>
            <h3 class="text-sm font-semibold uppercase tracking-wider text-base-content/70 mb-3">Company Team</h3>
            <div id="team-list" class="space-y-3">
                {team_html}
            </div>
        </div>
        "##,
        company_name = escape_html_text(&company.name),
        slug = escape_html_text(&company.slug),
        invites_html = invites_html,
        team_html = team_html,
        create_invite = legacy_invite_create(company.id, actor),
    );

    base_layout(&format!("Manage {}", company.name), &content)
}

pub fn company_invite_list_fragment(
    company_id: Uuid,
    invites: &[CompanyInvite],
    actor: LevelActor,
) -> String {
    if invites.is_empty() {
        return r##"
            <div class="bg-base-100 border border-dashed border-base-300 rounded-xl p-6 text-center">
                <p class="text-base-content/70 text-sm">No email invites sent yet.</p>
            </div>
        "##
        .to_string();
    }

    invites
        .iter()
        .map(|inv| company_invite_row_fragment(company_id, inv, actor))
        .collect()
}

pub fn company_invite_row_fragment(
    company_id: Uuid,
    invite: &CompanyInvite,
    actor: LevelActor,
) -> String {
    let created_at_str = super::format_date(invite.created_at);
    let status_badge = match invite.status.as_str() {
        "accepted" => {
            r#"<span class="px-2.5 py-0.5 rounded-full text-xs font-medium bg-success/10 text-base-content border border-success/40">Accepted</span>"#
        }
        "declined" => {
            r#"<span class="px-2.5 py-0.5 rounded-full text-xs font-medium bg-error/10 text-base-content border border-error/40">Declined</span>"#
        }
        _ => {
            r#"<span class="px-2.5 py-0.5 rounded-full text-xs font-medium bg-warning/10 text-base-content border border-warning/40">Pending</span>"#
        }
    };

    format!(
        r##"
        <div id="invite-{invite_id}" class="bg-base-100 border border-base-300 rounded-xl p-4 md:p-5 flex items-center justify-between hover:border-base-content/30 transition shadow-sm">
            <div>
                <div class="flex items-center gap-3">
                    <span class="text-md font-semibold text-base-content">{email}</span>
                    <span class="px-2.5 py-0.5 rounded-full text-xs font-medium bg-primary/10 text-primary border border-primary/40">{role}</span>
                    {status_badge}
                </div>
                <p class="text-xs text-base-content/70 mt-1">Invited on {created_at_str}</p>
            </div>
            {level}
            {actions}
        </div>
        "##,
        invite_id = invite.id,
        email = escape_html_attr(&invite.email),
        role = invite.role.label(),
        status_badge = status_badge,
        created_at_str = created_at_str,
        level = if invite.status == "pending" {
            level_control(LevelControl {
                actor,
                target: LevelTarget::Assignable(invite.access_level),
                current: invite.access_level,
                endpoint: &format!("/companies/{company_id}/invites/{}/level", invite.id),
                swap_target: &format!("#invite-{}", invite.id),
            })
        } else {
            format!("<p>{}</p>", invite.access_level.label())
        },
        actions = if actor.membership.is_owner() {
            format!(
                r##"            <div class="flex items-center gap-2">
                <button hx-get="/companies/{company_id}/invites/{invite_id}/edit" hx-target="#invite-{invite_id}" hx-swap="outerHTML"
                    class="px-3 py-1.5 text-xs font-medium bg-base-300 hover:bg-base-content/15 text-base-content rounded-lg transition cursor-pointer">
                    Edit
                </button>
                <button hx-delete="/companies/{company_id}/invites/{invite_id}" hx-target="#invite-{invite_id}" hx-swap="outerHTML" hx-confirm="Are you sure you want to cancel invite for '{email}'?"
                    class="px-3 py-1.5 text-xs font-medium bg-error/10 hover:bg-error/20 text-base-content border border-error/40 rounded-lg transition cursor-pointer">
                    Delete
                </button>
            </div>"##,
                invite_id = invite.id,
                email = escape_html_attr(&invite.email)
            )
        } else {
            String::new()
        },
    )
}

pub fn company_invite_edit_fragment(
    company_id: Uuid,
    invite: &CompanyInvite,
    actor: LevelActor,
) -> String {
    if !actor.membership.is_owner() || invite.status != "pending" {
        return company_invite_row_fragment(company_id, invite, actor);
    }

    format!(
        r##"
        <form id="invite-{invite_id}" hx-put="/companies/{company_id}/invites/{invite_id}" hx-target="#invite-{invite_id}" hx-swap="outerHTML"
            class="bg-base-100 border border-primary/40 rounded-xl p-4 md:p-5 flex items-center gap-3 shadow-lg">
            <input type="email" name="email" value="{email}" required
                class="flex-1 px-3.5 py-2 bg-base-200 border border-base-300 rounded-lg text-base-content text-sm focus:outline-none focus:ring-2 focus:ring-primary">
            <select name="role" class="px-3.5 py-2 bg-base-200 border border-base-300 rounded-lg text-base-content text-sm">
                {role_options}
            </select>
            <select aria-label="Access level" name="access_level" class="select">{levels}</select>
            <div class="flex items-center gap-2">
                <button type="button" hx-get="/companies/{company_id}/invites/{invite_id}/cancel" hx-target="#invite-{invite_id}" hx-swap="outerHTML"
                    class="px-3 py-1.5 text-xs font-medium bg-base-300 hover:bg-base-content/15 text-base-content rounded-lg transition cursor-pointer">
                    Cancel
                </button>
                <button type="submit"
                    class="px-4 py-1.5 text-xs font-semibold bg-primary hover:bg-primary/90 text-primary-content rounded-lg transition cursor-pointer">
                    Save
                </button>
            </div>
        </form>
        "##,
        company_id = company_id,
        invite_id = invite.id,
        email = escape_html_attr(&invite.email),
        role_options = company_access_role_options(invite.role),
        levels = level_options(
            actor,
            LevelTarget::Assignable(invite.access_level),
            invite.access_level
        ),
    )
}

pub fn company_team_list_fragment(
    company_id: Uuid,
    members: &[CompanyMember],
    actor: LevelActor,
) -> String {
    if members.is_empty() {
        return r##"
            <div class="bg-base-100 border border-dashed border-base-300 rounded-xl p-6 text-center">
                <p class="text-base-content/70 text-sm">No team members joined yet.</p>
            </div>
        "##
        .to_string();
    }

    members
        .iter()
        .map(|m| company_team_row_fragment(company_id, m, actor))
        .collect()
}

pub fn company_team_row_fragment(
    company_id: Uuid,
    member: &CompanyMember,
    actor: LevelActor,
) -> String {
    let created_at_str = super::format_date(member.created_at);
    let username_display = member.username.as_deref().unwrap_or("Unknown User");
    let email_display = member.email.as_deref().unwrap_or("");

    format!(
        r##"
        <div id="member-{user_id}" class="bg-base-100 border border-base-300 rounded-xl p-4 md:p-5 flex items-center justify-between hover:border-base-content/30 transition shadow-sm">
            <div>
                <div class="flex items-center gap-3">
                    <h4 class="text-md font-semibold text-base-content">{username}</h4>
                    <span class="text-xs text-base-content/70">({email})</span>
                    {role_form}
                </div>
                <p class="text-xs text-base-content/70 mt-1">Joined {created_at_str}</p>
            </div>
            {level}
            {remove}
        </div>
        "##,
        user_id = member.user_id,
        username = escape_html_attr(username_display),
        email = escape_html_text(email_display),
        role_form = if actor.membership.is_owner() {
            format!(
                r##"                    <form hx-put="/companies/{company_id}/team/{user_id}" hx-target="#member-{user_id}" hx-swap="outerHTML" class="flex items-center gap-2">
                        <select name="role" class="px-2.5 py-1 bg-base-200 border border-base-300 rounded-lg text-base-content text-xs">
                            {role_options}
                        </select>
                        <button type="submit" class="px-2.5 py-1 text-xs font-medium bg-primary hover:bg-primary/90 text-primary-content rounded-lg">Save</button>
                    </form>"##,
                user_id = member.user_id,
                role_options = company_access_role_options(member.role)
            )
        } else {
            format!("<span>{}</span>", member.role.label())
        },
        remove = if actor.membership.is_owner() {
            format!(
                r##"            <div class="flex items-center gap-2">
                <button hx-delete="/companies/{company_id}/team/{user_id}" hx-target="#member-{user_id}" hx-swap="outerHTML" hx-confirm="Remove '{username}' from company team?"
                    class="px-3 py-1.5 text-xs font-medium bg-error/10 hover:bg-error/20 text-base-content border border-error/40 rounded-lg transition cursor-pointer">
                    Remove
                </button>
            </div>"##,
                user_id = member.user_id,
                username = escape_html_attr(username_display)
            )
        } else {
            String::new()
        },
        level = level_control(LevelControl {
            actor,
            target: LevelTarget::Assignable(member.access_level),
            current: member.access_level,
            endpoint: &format!("/companies/{company_id}/team/{}/level", member.user_id),
            swap_target: &format!("#member-{}", member.user_id)
        }),
        created_at_str = created_at_str,
    )
}

fn company_access_role_options(selected: CompanyAccessRole) -> String {
    CompanyAccessRole::ALL
        .into_iter()
        .map(|role| {
            format!(
                r#"<option value="{}"{}>{}</option>"#,
                role.as_str(),
                if role == selected { " selected" } else { "" },
                role.label(),
            )
        })
        .collect()
}

pub fn user_invites_page(user_email: &str, invites: &[CompanyInvite]) -> String {
    let list_html = user_invite_list_fragment(invites);

    let content = format!(
        r##"
        <div class="flex items-center justify-between mb-6">
            <div>
                <h2 class="text-2xl font-bold text-base-content">Your Invitations</h2>
                <p class="text-base-content/70 text-sm mt-1">Company invitations sent to <span class="font-mono text-primary">{user_email}</span></p>
            </div>
        </div>

        <div id="response-message" class="mb-6"></div>

        <div>
            <div id="user-invites-list" class="space-y-3">
                {list_html}
            </div>
        </div>
        "##,
        user_email = escape_html_text(user_email),
        list_html = list_html,
    );

    base_layout("My Invites", &content)
}

pub fn user_invite_list_fragment(invites: &[CompanyInvite]) -> String {
    if invites.is_empty() {
        return r##"
            <div class="bg-base-100 border border-dashed border-base-300 rounded-xl p-8 text-center">
                <p class="text-base-content/70 text-sm">You have no pending or past company invitations.</p>
            </div>
        "##
        .to_string();
    }

    invites.iter().map(user_invite_row_fragment).collect()
}

pub fn user_invite_row_fragment(invite: &CompanyInvite) -> String {
    let company_name = invite.company_name.as_deref().unwrap_or("Unknown Company");
    let created_at_str = super::format_date(invite.created_at);

    let action_buttons = match invite.status.as_str() {
        "accepted" => r#"<span class="px-3 py-1.5 rounded-lg text-xs font-semibold bg-success/10 text-base-content border border-success/40">Accepted</span>"#.to_string(),
        "declined" => r#"<span class="px-3 py-1.5 rounded-lg text-xs font-semibold bg-error/10 text-base-content border border-error/40">Declined</span>"#.to_string(),
        _ => format!(
            r##"
            <button hx-post="/invites/{invite_id}/accept" hx-target="#user-invite-{invite_id}" hx-swap="outerHTML"
                class="px-3.5 py-1.5 text-xs font-semibold bg-success hover:bg-success/90 text-success-content rounded-lg transition cursor-pointer shadow-md shadow-success/20">
                Accept
            </button>
            <button hx-post="/invites/{invite_id}/decline" hx-target="#user-invite-{invite_id}" hx-swap="outerHTML"
                class="px-3.5 py-1.5 text-xs font-semibold bg-error/10 hover:bg-error/20 text-base-content border border-error/40 rounded-lg transition cursor-pointer">
                Decline
            </button>
            "##,
            invite_id = invite.id
        ),
    };

    format!(
        r##"
        <div id="user-invite-{invite_id}" class="bg-base-100 border border-base-300 rounded-xl p-4 md:p-5 flex items-center justify-between hover:border-base-content/30 transition shadow-sm">
            <div>
                <div class="flex items-center gap-3">
                    <h4 class="text-md font-semibold text-base-content">{company_name}</h4>
                </div>
                <p class="text-xs text-base-content/70 mt-1">Invited to {email} as {role} on {created_at_str}</p>
            </div>
            <div class="flex items-center gap-2">
                {action_buttons}
            </div>
        </div>
        "##,
        invite_id = invite.id,
        company_name = escape_html_text(company_name),
        email = escape_html_attr(&invite.email),
        role = invite.role.label(),
        created_at_str = created_at_str,
        action_buttons = action_buttons,
    )
}

fn legacy_invite_create(company_id: Uuid, actor: LevelActor) -> String {
    if !actor.membership.is_owner() {
        return String::new();
    }
    format!(
        r##"        <!-- Create Invite Card -->
        <div class="bg-base-100 border border-base-300 rounded-xl p-5 mb-8">
            <h3 class="text-md font-semibold text-base-content mb-3 flex items-center gap-2">
                <span class="text-primary">+</span> Invite User by Email
            </h3>
            <form hx-post="/companies/{company_id}/invites" hx-target="#invite-list" hx-swap="innerHTML" class="flex gap-3"
                data-after-request="reset-form">
                <input type="email" name="email" required placeholder="colleague@example.com"
                    class="flex-1 px-3.5 py-2 bg-base-200 border border-base-300 rounded-lg text-base-content text-sm placeholder-base-content/60 focus:outline-none focus:ring-2 focus:ring-primary">
                <select name="role" class="px-3.5 py-2 bg-base-200 border border-base-300 rounded-lg text-base-content text-sm">
                    {role_options}
                </select>
                <select aria-label="Access level" name="access_level" class="select">{levels}</select>
                <button type="submit"
                    class="px-5 py-2 bg-primary hover:bg-primary/90 text-primary-content text-sm font-semibold rounded-lg shadow-md shadow-primary/20 transition cursor-pointer">
                    Send Invite
                </button>
            </form>
            <p class="text-xs opacity-60">{LEVEL_HELP}</p>
        </div>

"##,
        role_options = company_access_role_options(CompanyAccessRole::Member),
        levels = level_options(
            actor,
            LevelTarget::Assignable(AccessLevel::PUBLIC),
            AccessLevel::PUBLIC
        )
    )
}
