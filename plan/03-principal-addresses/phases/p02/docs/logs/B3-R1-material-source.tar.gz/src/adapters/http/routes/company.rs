use std::sync::Arc;

use axum::{
    Form, Json, Router,
    extract::{Path, State},
    http::StatusCode,
    response::{Html, IntoResponse},
    routing::{get, put},
};
use serde::{Deserialize, Serialize};
use tracing::instrument;
use uuid::Uuid;

use crate::{
    adapters::http::{app_state::AppState, auth::AuthenticatedUser, pages},
    app_error::{AppError, AppResult},
    entities::{company::Company, value_objects::AvatarUrl},
    use_cases::company::{CompanyUseCases, CompanyWrite},
};

pub fn router() -> Router<AppState> {
    Router::new()
        .route("/companies", get(list_companies).post(create_company))
        .route(
            "/companies/{id}",
            put(update_company).delete(delete_company),
        )
        .route("/companies/{id}/edit", get(edit_company_form))
        .route("/companies/{id}/cancel", get(cancel_company_edit))
        .route(
            "/api/companies",
            get(list_companies_json).post(create_company_json),
        )
        .route(
            "/api/companies/{id}",
            put(update_company_json).delete(delete_company_json),
        )
}

#[derive(Debug, Clone, Default, Deserialize)]
pub struct CompanyForm {
    pub name: String,
    pub slug: String,
    /// The company's picture. A save carries what it was sent, so the edit form keeps the stored
    /// URL in a hidden field rather than dropping the picture on every rename.
    pub avatar_url: Option<String>,
    pub default_add_3rd_party: Option<bool>,
}

impl CompanyForm {
    /// The submitted company as a write, with the avatar parsed rather than taken as typed --
    /// it ends up in an `<img src>` on every page that shows the company.
    fn write(&self) -> AppResult<CompanyWrite> {
        Ok(CompanyWrite {
            name: self.name.clone(),
            slug: self.slug.clone(),
            channel_defaults: crate::entities::company::CompanyChannelDefaults {
                add_3rd_party: self.default_add_3rd_party.unwrap_or(false),
            },
            avatar_url: parsed_avatar(self.avatar_url.as_deref())?,
        })
    }
}

/// A submitted avatar field, refused rather than stored when it is not a URL a page may render.
fn parsed_avatar(submitted: Option<&str>) -> AppResult<Option<AvatarUrl>> {
    match submitted {
        Some(value) => AvatarUrl::parse(value).map_err(AppError::BadRequest),
        None => Ok(None),
    }
}

#[derive(Debug, Clone, Serialize)]
pub struct CompanyResponse {
    pub success: bool,
    pub company: Company,
}

/// GET /companies - Full HTML page listing all user companies (Protected).
#[instrument(skip_all)]
async fn list_companies(
    State(company_use_cases): State<Arc<CompanyUseCases>>,
    user: AuthenticatedUser,
) -> AppResult<Html<String>> {
    let companies = company_use_cases.list_user_companies(user.id).await?;

    Ok(Html(pages::companies_page(&companies)))
}

/// POST /companies - HTMX create company form submission (Protected).
#[instrument(skip_all)]
async fn create_company(
    State(company_use_cases): State<Arc<CompanyUseCases>>,
    user: AuthenticatedUser,
    Form(form): Form<CompanyForm>,
) -> AppResult<Html<String>> {
    let created = match form.write() {
        Ok(write) => company_use_cases.create_company(user.id, write).await,
        Err(err) => Err(err),
    };

    Ok(match created {
        Ok(_) => {
            let companies = company_use_cases.list_user_companies(user.id).await?;
            Html(pages::company_list_fragment(&companies))
        }
        Err(err @ (AppError::BadRequest(_) | AppError::Conflict(_))) => {
            let error_html = pages::error_alert(&format!("Failed to create company: {err}"));
            let companies = company_use_cases.list_user_companies(user.id).await?;
            Html(format!(
                "{}{}",
                error_html,
                pages::company_list_fragment(&companies)
            ))
        }
        Err(error) => return Err(error),
    })
}

/// GET /companies/{id}/edit - Returns inline edit form fragment (Protected).
///
/// The owner's form; 404 for someone else's company, 403 for an admin or member, an error status
/// for a failed read.
#[instrument(skip_all)]
async fn edit_company_form(
    State(company_use_cases): State<Arc<CompanyUseCases>>,
    user: AuthenticatedUser,
    Path(id): Path<Uuid>,
) -> AppResult<Html<String>> {
    let company = company_use_cases.owned_company(user.id, id).await?;
    Ok(Html(pages::company_edit_fragment(&company)))
}

/// GET /companies/{id}/cancel - Cancels edit and returns single row fragment (Protected).
#[instrument(skip_all)]
async fn cancel_company_edit(
    State(company_use_cases): State<Arc<CompanyUseCases>>,
    user: AuthenticatedUser,
    Path(id): Path<Uuid>,
) -> AppResult<Html<String>> {
    let company = company_use_cases.owned_company(user.id, id).await?;
    Ok(Html(pages::company_row_fragment(&company)))
}

/// PUT /companies/{id} - Handles HTMX company update form submission (Protected).
///
/// Who may save is answered with a status before the form is read; only a rejected form or a
/// failed write after that is shown inline.
#[instrument(skip_all)]
async fn update_company(
    State(company_use_cases): State<Arc<CompanyUseCases>>,
    user: AuthenticatedUser,
    Path(id): Path<Uuid>,
    Form(form): Form<CompanyForm>,
) -> AppResult<Html<String>> {
    company_use_cases.owned_company(user.id, id).await?;
    let saved = match form.write() {
        Ok(write) => {
            company_use_cases
                .update_company_for_user(user.id, id, write)
                .await
        }
        Err(err) => Err(err),
    };

    Ok(match saved {
        Ok(company) => Html(pages::company_row_fragment(&company)),
        Err(err @ (AppError::BadRequest(_) | AppError::Conflict(_))) => {
            Html(pages::error_alert(&format!("Update failed: {err}")))
        }
        Err(error) => return Err(error),
    })
}

/// DELETE /companies/{id} - Handles HTMX company deletion (Protected).
///
/// A refusal or a failure is an error status, never an empty 200 that reads as "deleted".
#[instrument(skip_all)]
async fn delete_company(
    State(company_use_cases): State<Arc<CompanyUseCases>>,
    user: AuthenticatedUser,
    Path(id): Path<Uuid>,
) -> AppResult<Html<String>> {
    company_use_cases
        .delete_company_for_user(user.id, id)
        .await?;
    Ok(Html(String::new()))
}

/// JSON API: List companies for active user (Protected).
async fn list_companies_json(
    State(company_use_cases): State<Arc<CompanyUseCases>>,
    user: AuthenticatedUser,
) -> AppResult<impl IntoResponse> {
    let companies = company_use_cases.list_user_companies(user.id).await?;
    Ok((StatusCode::OK, Json(companies)))
}

/// JSON API: Create company (Protected).
async fn create_company_json(
    State(company_use_cases): State<Arc<CompanyUseCases>>,
    user: AuthenticatedUser,
    Json(payload): Json<CompanyForm>,
) -> AppResult<impl IntoResponse> {
    let company = company_use_cases
        .create_company(user.id, payload.write()?)
        .await?;
    Ok((
        StatusCode::CREATED,
        Json(CompanyResponse {
            success: true,
            company,
        }),
    ))
}

/// JSON API: Update company (Protected).
pub(super) async fn update_company_json(
    State(company_use_cases): State<Arc<CompanyUseCases>>,
    _user: AuthenticatedUser,
    Path(id): Path<Uuid>,
    Json(payload): Json<CompanyForm>,
) -> AppResult<impl IntoResponse> {
    let company = company_use_cases
        .update_company_for_user(_user.id, id, payload.write()?)
        .await?;
    Ok((
        StatusCode::OK,
        Json(CompanyResponse {
            success: true,
            company,
        }),
    ))
}

/// JSON API: Delete company (Protected).
async fn delete_company_json(
    State(company_use_cases): State<Arc<CompanyUseCases>>,
    _user: AuthenticatedUser,
    Path(id): Path<Uuid>,
) -> AppResult<impl IntoResponse> {
    company_use_cases
        .delete_company_for_user(_user.id, id)
        .await?;
    Ok(StatusCode::NO_CONTENT)
}

#[cfg(test)]
mod tests {
    use chrono::Utc;

    use super::*;

    #[test]
    fn companies_page_renders_htmx_crud_elements() {
        let company = Company {
            channel_defaults: Default::default(),
            id: Uuid::new_v4(),
            user_id: Uuid::new_v4(),
            name: "Test Corp".to_string(),
            slug: "test-corp".into(),
            avatar_url: None,
            created_at: Utc::now(),
        };

        let page_html = pages::companies_page(std::slice::from_ref(&company));
        assert!(page_html.contains("Test Corp"));
        assert!(page_html.contains("/test-corp"));
        assert!(page_html.contains("hx-post=\"/companies\""));
        assert!(page_html.contains("id=\"company-form-toggle\""));
        assert!(page_html.contains("id=\"company-form-card\" class=\"hidden"));
        assert!(page_html.contains("aria-expanded=\"false\""));
        assert!(page_html.contains("id=\"nav-channels\""));
        assert!(page_html.contains(">Desks</a>"));
        assert!(page_html.find(">Desks</a>") < page_html.find(">Agents</a>"));
        assert!(page_html.find(">Agents</a>") < page_html.find(">Account</summary>"));
        assert!(page_html.contains(">Account</summary>"));
        assert!(page_html.find(">Account</summary>") < page_html.find(">Companies</a>"));
        assert!(page_html.find(">Companies</a>") < page_html.find(">My Invites</a>"));
        assert!(page_html.contains("href=\"/ui/invites\""));
        assert!(page_html.contains("action=\"/logout\""));
        assert!(page_html.contains(r##"data-action="select-company""##));

        let edit_fragment = pages::company_edit_fragment(&company);
        assert!(edit_fragment.contains("hx-put="));
        assert!(edit_fragment.contains("value=\"Test Corp\""));
    }

    #[test]
    fn a_classic_save_carries_the_picture_it_was_sent_and_refuses_one_no_page_could_render() {
        let form = |avatar_url: Option<&str>| CompanyForm {
            name: "Test Corp".to_string(),
            slug: "test-corp".to_string(),
            avatar_url: avatar_url.map(str::to_string),
            ..CompanyForm::default()
        };

        let kept = form(Some("https://cdn.example.com/acme.png"))
            .write()
            .expect("an http URL is a picture a page may show");
        assert_eq!(
            kept.avatar_url,
            Some(AvatarUrl::from("https://cdn.example.com/acme.png"))
        );

        // The page this form lives on has no picker, so it sends the stored URL in a hidden
        // field -- and a company saved from a form that carries none has no picture.
        assert_eq!(form(None).write().expect("no picture").avatar_url, None);
        assert_eq!(form(Some("")).write().expect("no picture").avatar_url, None);

        // A tampered field is refused rather than stored: it ends up in an `<img src>`.
        assert!(form(Some("javascript:alert(1)")).write().is_err());

        let company = Company {
            channel_defaults: Default::default(),
            id: Uuid::new_v4(),
            user_id: Uuid::new_v4(),
            name: "Test Corp".to_string(),
            slug: "test-corp".into(),
            avatar_url: Some(AvatarUrl::from("https://cdn.example.com/acme.png")),
            created_at: Utc::now(),
        };
        assert!(pages::company_edit_fragment(&company).contains(
            r#"<input type="hidden" name="avatar_url" value="https://cdn.example.com/acme.png">"#
        ));
    }

    #[test]
    fn cached_company_client_nav_and_row_rendering() {
        let cid = Uuid::new_v4();
        let company = Company {
            channel_defaults: Default::default(),
            id: cid,
            user_id: Uuid::new_v4(),
            name: "Acme Corp".to_string(),
            slug: "acme-corp".into(),
            avatar_url: None,
            created_at: Utc::now(),
        };

        let row_html = pages::company_row_fragment(&company);
        assert!(row_html.contains(&format!(
            r##"data-action="select-company" data-company-id="{cid}""##
        )));
        assert!(row_html.contains(&format!("selected-badge-{}", cid)));

        let base_html = pages::base_layout("Test Title", "<p>Test Content</p>");
        assert!(base_html.contains("id=\"nav-channels\""));
        assert!(base_html.contains("action=\"/logout\""));
        assert!(!base_html.contains(">Sign In</a>"));
        assert!(!base_html.contains(">Sign Up</a>"));
        assert!(base_html.contains("/assets/app.js"));

        let script = pages::application_javascript();
        assert!(script.contains("localStorage.getItem('cached_company_id')"));
        assert!(script.contains("autoDetectAndSyncCompany"));
    }
}

#[cfg(test)]
#[path = "company_authorization_tests.rs"]
mod authorization_tests;
