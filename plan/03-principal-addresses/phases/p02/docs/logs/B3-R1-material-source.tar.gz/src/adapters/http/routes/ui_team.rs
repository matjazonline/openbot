//! `/ui/companies/{company_id}/team` — the Team tab of the Companies workspace: who is in the
//! selected company, and who has been invited to it.
//!
//! There is no Team workspace any more; a team only means anything as the team *of* a company, so
//! its list and its panes are drawn inside that company's own pane by
//! [`super::ui_companies::companies_page`], which calls [`team_tab_body`] here. Every fragment
//! and every write is nested under the company it belongs to, and all of them go through the same
//! [`CompanyInviteUseCases`] the classic `/companies/{id}/invites` page uses, so the two UIs
//! cannot drift on who may change a team.

use std::sync::Arc;

use axum::{
    Form, Router,
    extract::{FromRequestParts, Path, Query},
    http::request::Parts,
    response::{Html, IntoResponse, Redirect, Response},
    routing::{get, post, put},
};
use serde::Deserialize;
use tracing::instrument;
use uuid::Uuid;

use crate::{
    adapters::http::{
        app_state::AppState,
        auth::{AuthError, AuthenticatedUser},
        pages::{self, TeamRole, TeamSelection},
    },
    app_error::{AppError, AppResult},
    entities::{
        company::{Company, CompanyAccess},
        company_invite::CompanyInvite,
        company_member::{CompanyAccessRole, CompanyMember, CompanyMembership},
        value_objects::{AvatarUrl, EmailAddress},
    },
    infra::config::AppConfig,
    use_cases::{
        company::CompanyUseCases, company_invite::CompanyInviteUseCases, user::UserUseCases,
    },
};

use super::ui::workspace_user;

pub fn router() -> Router<AppState> {
    Router::new()
        .route("/ui/team", get(team_redirect))
        .route("/ui/companies/{company_id}/team/new", get(invite_form_pane))
        .route("/ui/companies/{company_id}/team/close", get(close_pane))
        .route(
            "/ui/companies/{company_id}/team/invites",
            post(create_invite),
        )
        .route(
            "/ui/companies/{company_id}/team/invites/{invite_id}",
            get(invite_pane).put(update_invite).delete(delete_invite),
        )
        .route(
            "/ui/companies/{company_id}/team/members/{user_id}",
            get(member_pane).put(update_member_role),
        )
        .route(
            "/ui/companies/{company_id}/team/members/{user_id}/avatar",
            put(set_member_avatar),
        )
        .route(
            "/ui/companies/{company_id}/team/members/{user_id}/level",
            put(set_member_level),
        )
        .route(
            "/ui/companies/{company_id}/team/invites/{invite_id}/level",
            put(set_invite_level),
        )
        // Removal. A POST rather than a DELETE, kept from when it carried who took over the
        // member's legacy work, which went with the legacy runtime (p08 B4b).
        .route(
            "/ui/companies/{company_id}/team/members/{user_id}/removal",
            post(remove_member),
        )
}

#[cfg(test)]
mod trace_tests {
    use super::*;
    use std::{
        io::Write,
        sync::{Arc, Mutex},
    };
    use tower::ServiceExt;
    use tracing_subscriber::fmt::format::FmtSpan;

    struct Capture(Arc<Mutex<Vec<u8>>>);

    impl Write for Capture {
        fn write(&mut self, bytes: &[u8]) -> std::io::Result<usize> {
            self.0.lock().unwrap().extend_from_slice(bytes);
            Ok(bytes.len())
        }

        fn flush(&mut self) -> std::io::Result<()> {
            Ok(())
        }
    }

    #[tokio::test(flavor = "current_thread")]
    async fn security_trace_redaction_team_query_is_not_a_handler_span_field() {
        let output = Arc::new(Mutex::new(Vec::new()));
        let subscriber = tracing_subscriber::fmt()
            .with_ansi(false)
            .with_span_events(FmtSpan::NEW)
            .with_writer({
                let output = output.clone();
                move || Capture(output.clone())
            })
            .finish();
        let _guard = tracing::subscriber::set_default(subscriber);
        let app = Router::new().route("/ui/team", get(team_redirect));
        let marker = "12345678-1234-1234-1234-123456789abc";
        let request = axum::http::Request::builder()
            .uri(format!("/ui/team?company_id={marker}"))
            .body(axum::body::Body::empty())
            .unwrap();
        let response = app.oneshot(request).await.unwrap();
        assert_eq!(response.status(), axum::http::StatusCode::SEE_OTHER);

        let log = String::from_utf8(output.lock().unwrap().clone()).unwrap();
        assert!(log.contains("team_redirect"), "{log}");
        assert!(!log.contains(marker), "query value leaked into span: {log}");
    }
}

/// What the Team tab has selected, all optional so the tab alone is a valid entry point.
///
/// It arrives as part of [`super::ui_companies::WorkspaceQuery`] rather than being parsed here:
/// the tab and the company it sits in are one page, and so are one query.
#[derive(Debug, Clone, Copy, Default)]
pub struct TeamRequest {
    /// The selected member's `user_id`, which is what removing one takes.
    pub member_id: Option<Uuid>,
    pub invite_id: Option<Uuid>,
    /// Whether the pane should hold the invite form instead of a person.
    pub creating: bool,
}

/// The company a stale `/ui/team` link named, if it named one at all.
#[derive(Debug, Clone, Deserialize)]
pub struct LegacyTeamQuery {
    pub company_id: Option<Uuid>,
}

#[derive(Debug, Clone, Deserialize)]
pub struct InviteForm {
    pub email: String,
    pub access_level: Option<crate::entities::access_level::AccessLevel>,
    #[serde(default)]
    pub role: Option<CompanyAccessRole>,
}

#[derive(Debug, Clone, Deserialize)]
pub struct MemberRoleForm {
    pub role: CompanyAccessRole,
}

/// The avatar field from a member's own pane. Blank means "back to my initial", which is why it is
/// a plain `String` rather than an `Option`.
#[derive(Debug, Clone, Deserialize)]
pub struct AvatarForm {
    pub avatar_url: String,
}

/// Only validation/conflict refusals belong in a successful editable fragment.
/// Authorization, missing rows and infrastructure failures keep their typed HTTP outcome.
fn inline_team_mutation_error(error: AppError) -> AppResult<String> {
    match error {
        AppError::BadRequest(_) | AppError::Conflict(_) => Ok(error.to_string()),
        error => Err(error),
    }
}

const NO_SELECTION: &str = "Select someone to see their access, or invite a new person.";

/// The use cases and the caller every Team handler starts from.
///
/// Extracted as one value rather than four `State`s per handler: each of these routes needs the
/// same set, and a handler's own parameters should be what makes it different from its siblings.
struct Workspace {
    company_use_cases: Arc<CompanyUseCases>,
    invite_use_cases: Arc<CompanyInviteUseCases>,
    user_use_cases: Arc<UserUseCases>,
    config: Arc<AppConfig>,
    user_id: Uuid,
}

impl FromRequestParts<AppState> for Workspace {
    type Rejection = AuthError;

    async fn from_request_parts(
        parts: &mut Parts,
        state: &AppState,
    ) -> Result<Self, Self::Rejection> {
        let user = AuthenticatedUser::from_request_parts(parts, state).await?;

        Ok(Self {
            company_use_cases: state.company_use_cases.clone(),
            invite_use_cases: state.company_invite_use_cases.clone(),
            user_use_cases: state.user_use_cases.clone(),
            config: state.config.clone(),
            user_id: user.id,
        })
    }
}

impl Workspace {
    /// The company a request is scoped to and what the caller is to it: any member may open the
    /// team (404 for anyone else); what they may change is [`TeamView::require_owner`]'s call.
    async fn scoped_company(&self, company_id: Uuid) -> AppResult<CompanyAccess> {
        self.company_use_cases
            .readable_company(self.user_id, company_id)
            .await
    }

    fn view<'a>(&'a self, access: &'a CompanyAccess) -> TeamView<'a> {
        TeamView {
            invite_use_cases: &self.invite_use_cases,
            user_id: self.user_id,
            company: &access.company,
            membership: access.membership,
            access_level: access.access_level,
        }
    }
}

/// The Team tab's body for one company, as the Companies workspace embeds it.
///
/// It builds from the same [`TeamView`] the fragments below do, so the list's entries and the
/// panes they click through to cannot drift on what a member or an invite is allowed to do.
pub(super) async fn team_tab_body(
    invite_use_cases: &CompanyInviteUseCases,
    user_id: Uuid,
    access: &CompanyAccess,
    request: TeamRequest,
) -> AppResult<String> {
    let view = TeamView {
        invite_use_cases,
        user_id,
        company: &access.company,
        membership: access.membership,
        access_level: access.access_level,
    };
    let members = view.members().await?;
    let invites = view.invites().await?;

    // Only the owner has an invite form to open, so a member's `?new=1` is an ordinary empty tab
    // rather than a pane full of buttons the server would refuse.
    let creating = request.creating && view.role().manages();
    let selected = if creating {
        TeamSelection::None
    } else {
        view.selection(&members, &invites, request.member_id, request.invite_id)
    };

    let pane_html = if creating {
        view.invite_create_pane("", CompanyAccessRole::Member, None)
    } else {
        view.selected_pane(&members, &invites, selected).await?
    };

    Ok(pages::team_tab(
        &view.list(&members, &invites, selected),
        &pane_html,
    ))
}

/// GET /ui/team - Where the Team workspace used to be (Protected).
///
/// The team lives in its company's pane now, so a stale link is answered with the company it named
/// rather than a 404; without one there is nothing to show, and the Companies workspace is where a
/// company gets picked.
#[instrument(skip_all)]
async fn team_redirect(Query(query): Query<LegacyTeamQuery>) -> Redirect {
    match query.company_id {
        Some(company_id) => Redirect::to(&pages::team_url(company_id, TeamSelection::None)),
        None => Redirect::to("/ui/companies"),
    }
}

/// GET /ui/companies/{company_id}/team/new - The invite form for the pane (Protected).
///
/// The list comes with it, deselected: the form belongs to nobody, so leaving whoever was open
/// before it lit would say the pane is showing a person it is not.
#[instrument(skip_all)]
async fn invite_form_pane(
    workspace: Workspace,
    Path(company_id): Path<Uuid>,
) -> AppResult<Response> {
    let company = workspace.scoped_company(company_id).await?;
    let view = workspace.view(&company);
    view.require_owner()?;

    view.invite_form_response().await
}

/// GET /ui/companies/{company_id}/team/close - Dismiss whichever form the pane holds (Protected).
///
/// What Cancel does: the pane goes back to its placeholder and the list loses its highlight, so
/// cancelling a form and closing a person both leave the tab in the same state as arriving at it
/// with nothing selected.
#[instrument(skip_all)]
async fn close_pane(workspace: Workspace, Path(company_id): Path<Uuid>) -> AppResult<Response> {
    let company = workspace.scoped_company(company_id).await?;
    workspace.view(&company).cleared_response().await
}

/// GET /ui/companies/{company_id}/team/members/{user_id} - One member's access (Protected).
#[instrument(skip_all)]
async fn member_pane(
    workspace: Workspace,
    Path((company_id, user_id)): Path<(Uuid, Uuid)>,
) -> AppResult<Html<String>> {
    let company = workspace.scoped_company(company_id).await?;
    let view = workspace.view(&company);
    let member = view.member(user_id).await?;

    Ok(Html(view.member_pane(&member, None).await?))
}

/// PUT /ui/companies/{company_id}/team/members/{user_id}/avatar - Save your own picture (Protected).
///
/// An avatar belongs to the account, not to the membership, so this refuses any `user_id` but the
/// caller's -- being the company owner does not make somebody else's picture yours to set.
#[instrument(skip_all)]
async fn set_member_avatar(
    workspace: Workspace,
    Path((company_id, user_id)): Path<(Uuid, Uuid)>,
    Form(form): Form<AvatarForm>,
) -> AppResult<Response> {
    if user_id != workspace.user_id {
        return Err(AppError::BadRequest(
            "You can only change your own avatar.".into(),
        ));
    }

    let company = workspace.scoped_company(company_id).await?;
    let view = workspace.view(&company);

    let avatar_url = match AvatarUrl::parse(&form.avatar_url) {
        Ok(avatar_url) => avatar_url,
        Err(message) => {
            let member = view.member(user_id).await?;
            return Ok(Html(
                view.member_pane_with_draft(&member, Some(&form.avatar_url), Some(&message))
                    .await?,
            )
            .into_response());
        }
    };

    let saved = match workspace
        .user_use_cases
        .set_avatar(user_id, avatar_url.as_ref())
        .await
    {
        Ok(saved) => saved,
        Err(err) => {
            let err = inline_team_mutation_error(err)?;
            let member = view.member(user_id).await?;
            return Ok(Html(
                view.member_pane_with_draft(
                    &member,
                    Some(&form.avatar_url),
                    Some(&format!("Failed to save avatar: {err}")),
                )
                .await?,
            )
            .into_response());
        }
    };

    // Re-read the member so the pane and the list both show what was just stored, and send the
    // top bar's own avatar along -- it is chrome no pane swap would otherwise touch.
    let member = view.member(user_id).await?;
    let saved_email = EmailAddress::from(saved.email.as_str());
    let pane = format!(
        "{}{}",
        view.member_pane(&member, None).await?,
        pages::account_chip(
            &workspace_user(&saved, &saved_email, &workspace.config),
            pages::FragmentSwap::OutOfBand,
        ),
    );

    view.saved_response(TeamSelection::Member(user_id), pane)
        .await
}

/// GET /ui/companies/{company_id}/team/invites/{invite_id} - One invite for the pane (Protected).
#[instrument(skip_all)]
async fn invite_pane(
    workspace: Workspace,
    Path((company_id, invite_id)): Path<(Uuid, Uuid)>,
) -> AppResult<Html<String>> {
    let company = workspace.scoped_company(company_id).await?;
    let view = workspace.view(&company);
    let invite = view.invite(invite_id).await?;

    Ok(Html(view.invite_pane(&invite, None, None, None)))
}

/// POST /ui/companies/{company_id}/team/invites - Invite someone from the form (Protected).
#[instrument(skip_all)]
async fn create_invite(
    workspace: Workspace,
    Path(company_id): Path<Uuid>,
    Form(form): Form<InviteForm>,
) -> AppResult<Response> {
    let company = workspace.scoped_company(company_id).await?;
    let view = workspace.view(&company);

    let created = view
        .invite_use_cases
        .create_company_invite(crate::use_cases::company_invite::CreateCompanyInvite {
            actor_id: view.user_id,
            company_id: view.company.id,
            email: form.email.to_string().into(),
            role: form.role.unwrap_or_default(),
            access_level: form
                .access_level
                .unwrap_or(crate::entities::access_level::AccessLevel::PUBLIC),
        })
        .await;

    match created {
        Ok(invite) => {
            let pane = view.invite_pane(&invite, None, None, None);
            view.saved_response(TeamSelection::Invite(invite.id), pane)
                .await
        }
        Err(err) => {
            let err = inline_team_mutation_error(err)?;
            Ok(Html(view.invite_create_pane(
                &form.email,
                form.role.unwrap_or_default(),
                Some(&format!("Failed to send invite: {err}")),
            ))
            .into_response())
        }
    }
}

/// PUT /ui/companies/{company_id}/team/invites/{invite_id} - Save one address (Protected).
#[instrument(skip_all)]
async fn update_invite(
    workspace: Workspace,
    Path((company_id, invite_id)): Path<(Uuid, Uuid)>,
    Form(form): Form<InviteForm>,
) -> AppResult<Response> {
    let company = workspace.scoped_company(company_id).await?;
    let view = workspace.view(&company);
    let stored = view.invite(invite_id).await?;

    let saved = view
        .invite_use_cases
        .update_company_invite(crate::use_cases::company_invite::UpdateCompanyInvite {
            actor_id: view.user_id,
            company_id: view.company.id,
            invite_id,
            email: form.email.to_string().into(),
            role: form.role,
            access_level: form.access_level,
        })
        .await;

    match saved {
        Ok(invite) => {
            let pane = view.invite_pane(&invite, None, None, None);
            view.saved_response(TeamSelection::Invite(invite.id), pane)
                .await
        }
        Err(err) => {
            let err = inline_team_mutation_error(err)?;
            Ok(Html(view.invite_pane(
                &stored,
                Some(&form.email),
                Some(form.role.unwrap_or(stored.role)),
                Some(&format!("Failed to save invite: {err}")),
            ))
            .into_response())
        }
    }
}

/// DELETE /ui/companies/{company_id}/team/invites/{invite_id} - Withdraw an invite (Protected).
#[instrument(skip_all)]
async fn delete_invite(
    workspace: Workspace,
    Path((company_id, invite_id)): Path<(Uuid, Uuid)>,
) -> AppResult<Response> {
    let company = workspace.scoped_company(company_id).await?;
    let view = workspace.view(&company);
    view.invite_use_cases
        .delete_company_invite(view.user_id, view.company.id, invite_id)
        .await?;

    view.cleared_response().await
}

/// PUT /ui/companies/{company_id}/team/members/{user_id} - Change access role (Protected).
#[instrument(skip_all)]
async fn update_member_role(
    workspace: Workspace,
    Path((company_id, user_id)): Path<(Uuid, Uuid)>,
    Form(form): Form<MemberRoleForm>,
) -> AppResult<Response> {
    let company = workspace.scoped_company(company_id).await?;
    let view = workspace.view(&company);

    match view
        .invite_use_cases
        .update_company_team_member_role(view.user_id, view.company.id, user_id, form.role)
        .await
    {
        Ok(member) => {
            let pane = view.member_pane(&member, None).await?;
            view.saved_response(TeamSelection::Member(user_id), pane)
                .await
        }
        Err(err) => {
            let err = inline_team_mutation_error(err)?;
            let member = view.member(user_id).await?;
            Ok(Html(
                view.member_pane(
                    &member,
                    Some(&format!("Failed to change access role: {err}")),
                )
                .await?,
            )
            .into_response())
        }
    }
}

/// POST /ui/companies/{company_id}/team/members/{user_id}/removal - Remove someone (Protected).
#[instrument(skip_all)]
async fn remove_member(
    workspace: Workspace,
    Path((company_id, user_id)): Path<(Uuid, Uuid)>,
) -> AppResult<Response> {
    let company = workspace.scoped_company(company_id).await?;
    let view = workspace.view(&company);

    // Validation refusals remain editable when the target is a visible member.
    if let Err(err) = view
        .invite_use_cases
        .remove_company_team_member(view.user_id, view.company.id, user_id)
        .await
    {
        let err = inline_team_mutation_error(err)?;
        let member = view.member(user_id).await?;
        return Ok(Html(
            view.member_pane(&member, Some(&format!("Failed to remove member: {err}")))
                .await?,
        )
        .into_response());
    }

    view.cleared_response().await
}

/// Everything the tab renders from, so each handler names its data once.
struct TeamView<'a> {
    invite_use_cases: &'a CompanyInviteUseCases,
    user_id: Uuid,
    company: &'a Company,
    /// What the caller is to the company, from their membership row.
    membership: CompanyMembership,
    access_level: crate::entities::access_level::AccessLevel,
}

impl TeamView<'_> {
    /// What the caller may do here.
    ///
    /// Decided from their membership rather than by letting an unauthorized use-case call fail:
    /// the invite calls refuse a non-owner outright, so asking them first would turn an ordinary
    /// member's page load into an error.
    fn role(&self) -> TeamRole {
        if self.membership.is_owner() {
            TeamRole::Owner
        } else if self.membership == CompanyMembership::Admin {
            TeamRole::Admin
        } else {
            TeamRole::Member
        }
    }

    /// The owner manages invites and members; anyone else on the team sees it and is refused.
    fn require_owner(&self) -> AppResult<()> {
        match self.role() {
            TeamRole::Owner => Ok(()),
            TeamRole::Admin | TeamRole::Member => Err(AppError::Forbidden(
                "Only the company owner can manage invites and team members.".into(),
            )),
        }
    }

    async fn members(&self) -> AppResult<Vec<CompanyMember>> {
        self.invite_use_cases
            .list_company_team_members(self.user_id, self.company.id)
            .await
    }

    /// Only the owner may see invites, and the list hides the section for everyone else, so a
    /// member's list is empty rather than an error.
    async fn invites(&self) -> AppResult<Vec<CompanyInvite>> {
        match self.role() {
            TeamRole::Owner | TeamRole::Admin => {
                self.invite_use_cases
                    .list_company_invites(self.user_id, self.company.id)
                    .await
            }
            TeamRole::Member => Ok(Vec::new()),
        }
    }

    async fn member(&self, user_id: Uuid) -> AppResult<CompanyMember> {
        self.invite_use_cases
            .get_company_team_member(self.user_id, self.company.id, user_id)
            .await?
            .ok_or_else(|| AppError::NotFound("Team member not found".into()))
    }

    async fn invite(&self, invite_id: Uuid) -> AppResult<CompanyInvite> {
        self.invite_use_cases
            .get_company_invite(self.user_id, self.company.id, invite_id)
            .await?
            .ok_or_else(|| AppError::NotFound("Invite not found".into()))
    }

    /// Which list entry the query names, keeping only a selection that actually exists.
    fn selection(
        &self,
        members: &[CompanyMember],
        invites: &[CompanyInvite],
        member_id: Option<Uuid>,
        invite_id: Option<Uuid>,
    ) -> TeamSelection {
        if let Some(user_id) = member_id
            && members.iter().any(|member| member.user_id == user_id)
        {
            return TeamSelection::Member(user_id);
        }
        if let Some(invite_id) = invite_id
            && invites.iter().any(|invite| invite.id == invite_id)
        {
            return TeamSelection::Invite(invite_id);
        }
        TeamSelection::None
    }

    /// The pane one selection opens, or the placeholder when it opens nothing.
    async fn selected_pane(
        &self,
        members: &[CompanyMember],
        invites: &[CompanyInvite],
        selected: TeamSelection,
    ) -> AppResult<String> {
        let pane = match selected {
            TeamSelection::Member(user_id) => {
                match members.iter().find(|member| member.user_id == user_id) {
                    Some(member) => Some(self.member_pane(member, None).await?),
                    None => None,
                }
            }
            TeamSelection::Invite(invite_id) => invites
                .iter()
                .find(|invite| invite.id == invite_id)
                .map(|invite| self.invite_pane(invite, None, None, None)),
            TeamSelection::None => None,
        };

        Ok(pane.unwrap_or_else(|| {
            pages::team_settings_empty_pane(NO_SELECTION, pages::FragmentSwap::Inline)
        }))
    }

    fn list<'l>(
        &'l self,
        members: &'l [CompanyMember],
        invites: &'l [CompanyInvite],
        selected: TeamSelection,
    ) -> pages::TeamSettingsList<'l> {
        pages::TeamSettingsList {
            company: self.company,
            members,
            invites,
            selected,
            role: self.role(),
        }
    }

    async fn member_pane(&self, member: &CompanyMember, error: Option<&str>) -> AppResult<String> {
        self.member_pane_with_draft(member, None, error).await
    }

    /// The same pane with the avatar field kept as typed, for a save that was rejected.
    async fn member_pane_with_draft(
        &self,
        member: &CompanyMember,
        avatar_draft: Option<&str>,
        error: Option<&str>,
    ) -> AppResult<String> {
        Ok(pages::member_pane(&pages::MemberPane {
            company: self.company,
            member,
            role: self.role(),
            viewer_access_level: self.access_level,
            viewer_id: self.user_id,
            avatar_draft,
            error,
        }))
    }

    fn invite_pane(
        &self,
        invite: &CompanyInvite,
        email_draft: Option<&str>,
        role_draft: Option<CompanyAccessRole>,
        error: Option<&str>,
    ) -> String {
        pages::invite_pane(&pages::InvitePane {
            company: self.company,
            invite,
            role: self.role(),
            viewer_access_level: self.access_level,
            email_draft,
            role_draft,
            error,
        })
    }

    fn invite_create_pane(
        &self,
        email_draft: &str,
        role_draft: CompanyAccessRole,
        error: Option<&str>,
    ) -> String {
        pages::invite_create_pane(&pages::InviteCreatePane {
            company: self.company,
            email_draft,
            role_draft,
            error,
        })
    }

    /// The empty pane plus a list with nothing selected — what cancelling a form, closing a
    /// person, and every removal all leave behind.
    async fn cleared_response(&self) -> AppResult<Response> {
        self.refreshed_response(
            TeamSelection::None,
            pages::team_settings_empty_pane(NO_SELECTION, pages::FragmentSwap::Inline),
            pages::team_url(self.company.id, TeamSelection::None),
        )
        .await
    }

    /// The invite form plus a list with nothing lit — an invite is not somebody yet, so it is not
    /// a selection, which is why this cannot go through [`Self::saved_response`].
    async fn invite_form_response(&self) -> AppResult<Response> {
        self.refreshed_response(
            TeamSelection::None,
            self.invite_create_pane("", CompanyAccessRole::Member, None),
            pages::team_invite_form_url(self.company.id),
        )
        .await
    }

    /// What every successful write returns: the saved person's pane, with the list refreshed
    /// beside it so a new invite or a changed address shows up immediately.
    async fn saved_response(&self, selected: TeamSelection, pane: String) -> AppResult<Response> {
        let push_url = pages::team_url(self.company.id, selected);
        self.refreshed_response(selected, pane, push_url).await
    }

    /// One pane plus the list it belongs to, swapped out of band beside it, with the address bar
    /// moved to where that pane is reachable.
    ///
    /// The URL is passed in rather than derived from `selected`: the invite form lights nothing
    /// and still has an address of its own, so the two are not the same fact.
    async fn refreshed_response(
        &self,
        selected: TeamSelection,
        pane: String,
        push_url: String,
    ) -> AppResult<Response> {
        let members = self.members().await?;
        let invites = self.invites().await?;
        let list = pages::team_settings_list(
            &self.list(&members, &invites, selected),
            pages::FragmentSwap::OutOfBand,
        );

        Ok(([("HX-Push-Url", push_url)], Html(format!("{pane}{list}"))).into_response())
    }
}

#[cfg(test)]
#[path = "ui_team_authorization_tests.rs"]
mod authorization_tests;

#[path = "ui_team_levels.rs"]
mod levels;
use levels::{set_invite_level, set_member_level};
