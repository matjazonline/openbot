#!/usr/bin/env bash

set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
TEST_DIR="$(mktemp -d)"
trap 'rm -rf "$TEST_DIR"' EXIT
mkdir -p "$TEST_DIR/bin"

cat >"$TEST_DIR/bin/fly" <<'EOF'
#!/usr/bin/env bash
set -euo pipefail
rendered=()
for arg in "$@"; do
  case "$arg" in
    JWT_SECRET=*|AUTH_ATTEMPT_SECRET=*|CREDENTIAL_ENCRYPTION_KEYS=*) rendered+=("${arg%%=*}=<redacted>") ;;
    *) rendered+=("$arg") ;;
  esac
done
printf '%s\n' "${rendered[*]}" >>"$FLY_TEST_LOG"
if [[ "${1:-}" == "status" ]]; then
  [[ "${FLY_APP_EXISTS:-1}" == "1" ]]
  exit
fi
if [[ "${1:-}" == "secrets" && "${2:-}" == "list" ]]; then
  printf '%s\n' "$FLY_SECRET_JSON"
fi
if [[ "${1:-}" == "secrets" && "${2:-}" == "set" ]]; then
  jwt_secret=""
  auth_attempt_secret=""
  for arg in "$@"; do
    case "$arg" in
      JWT_SECRET=*) jwt_secret="${arg#*=}" ;;
      AUTH_ATTEMPT_SECRET=*) auth_attempt_secret="${arg#*=}" ;;
    esac
  done
  if [[ ${#auth_attempt_secret} -lt 32 || "$auth_attempt_secret" == "$jwt_secret" ]]; then
    echo "bootstrap omitted a strong independent authentication key" >&2
    exit 1
  fi
  printf '%s\n' 'authentication key is strong and independent' >>"$FLY_TEST_LOG"
fi
EOF
cat >"$TEST_DIR/bin/cargo" <<'EOF'
#!/usr/bin/env bash
exit 0
EOF
chmod +x "$TEST_DIR/bin/fly" "$TEST_DIR/bin/cargo"

export PATH="$TEST_DIR/bin:$PATH"
export FLY_TEST_LOG="$TEST_DIR/fly.log"

export FLY_APP_EXISTS=1
export FLY_SECRET_JSON='[{"Name":"DATABASE_URL"},{"Name":"JWT_SECRET"},{"Name":"AUTH_ATTEMPT_SECRET"},{"Name":"CREDENTIAL_ENCRYPTION_KEYS"}]'
if "$ROOT_DIR/scripts/deploy.sh" app >"$TEST_DIR/missing.out" 2>&1; then
  echo "deploy unexpectedly accepted a missing active-version secret" >&2
  exit 1
fi
grep -q "CREDENTIAL_ENCRYPTION_ACTIVE_VERSION" "$TEST_DIR/missing.out"
if grep -q '^deploy' "$FLY_TEST_LOG"; then
  echo "deploy ran after required-secret preflight failed" >&2
  exit 1
fi

# An otherwise complete existing deployment must refuse the missing new key.
: >"$FLY_TEST_LOG"
export FLY_SECRET_JSON='[{"Name":"DATABASE_URL"},{"Name":"JWT_SECRET"},{"Name":"CREDENTIAL_ENCRYPTION_KEYS"},{"Name":"CREDENTIAL_ENCRYPTION_ACTIVE_VERSION"}]'
if "$ROOT_DIR/scripts/deploy.sh" app >"$TEST_DIR/missing-auth.out" 2>&1; then
  echo "deploy unexpectedly accepted a missing authentication key" >&2
  exit 1
fi
grep -q "AUTH_ATTEMPT_SECRET" "$TEST_DIR/missing-auth.out"
if grep -q '^deploy' "$FLY_TEST_LOG"; then
  echo "deploy ran after authentication-key preflight failed" >&2
  exit 1
fi

: >"$FLY_TEST_LOG"
export FLY_APP_EXISTS=0
export FLY_SECRET_JSON='[{"Name":"DATABASE_URL"},{"Name":"AUTH_ATTEMPT_SECRET"},{"Name":"JWT_SECRET"},{"Name":"CREDENTIAL_ENCRYPTION_KEYS"},{"Name":"CREDENTIAL_ENCRYPTION_ACTIVE_VERSION"}]'
printf 'postgres://open_bots:password@db/open_bots\nrelay-user\nrelay-password\n' | \
  "$ROOT_DIR/scripts/deploy.sh" --bootstrap app >"$TEST_DIR/bootstrap.out" 2>&1
grep -q 'AUTH_ATTEMPT_SECRET=<redacted>' "$FLY_TEST_LOG"
grep -q 'authentication key is strong and independent' "$FLY_TEST_LOG"
grep -q 'CREDENTIAL_ENCRYPTION_KEYS=<redacted>' "$FLY_TEST_LOG"
grep -q 'CREDENTIAL_ENCRYPTION_ACTIVE_VERSION=1' "$FLY_TEST_LOG"
grep -q '^deploy$' "$FLY_TEST_LOG"

# A complete secret inventory also permits an ordinary deployment.
: >"$FLY_TEST_LOG"
export FLY_APP_EXISTS=1
"$ROOT_DIR/scripts/deploy.sh" app >"$TEST_DIR/normal.out" 2>&1
grep -q '^deploy$' "$FLY_TEST_LOG"

# Keep the production model/security gate mandatory alongside the deployment preflight. Runtime
# missing/tampered-model refusal is exercised by that gate against the built image, before DB I/O.
python3 - "$ROOT_DIR" <<'PY_MODEL_BUILD'
import json, re, sys
from pathlib import Path
root = Path(sys.argv[1])
dockerfile = (root / "Dockerfile").read_text()
runtime = re.split(r"^FROM .*\n", dockerfile, flags=re.MULTILINE)[-1]
users = re.findall(r"^USER\s+(\S+)", runtime, flags=re.MULTILINE)
assert users and users[-1] not in {"root", "0", "0:0"}, "runtime must run as non-root"
assert re.search(r"^COPY --from=model /knowledge-model /app/models/multilingual-e5-small$", runtime, re.MULTILINE), "runtime must include the verified model stage"
assert "python3 scripts/prepare-knowledge-model.py --destination /knowledge-model" in dockerfile, "model must be verified during image build"
manifest = json.loads((root / "assets/knowledge/model-manifest.json").read_text())
assert manifest["model_id"], "model identity must be pinned"
ci = (root / ".github/workflows/ci.yml").read_text()
assert "python3 scripts/check-knowledge-image.py --image openbot-knowledge-ci" in ci, "missing-model/non-root/runtime RSS checks must remain required in CI"
checker = (root / "scripts/check-knowledge-image.py").read_text()
assert "failed_startup(image, empty, MODEL)" in checker, "image gate must exercise missing-model startup refusal"
print("deployment model-stage/non-root/missing-model gate assertions passed")
PY_MODEL_BUILD

echo "deploy script tests passed"
