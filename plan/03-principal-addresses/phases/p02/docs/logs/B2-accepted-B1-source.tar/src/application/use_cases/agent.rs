use std::sync::Arc;

use async_trait::async_trait;
use tracing::{info, instrument};
use uuid::Uuid;

use crate::{
    app_error::{AppError, AppResult},
    application::workflow::WorkflowActor,
    domain::workflow::CompanyId,
    entities::{
        agent::{Agent, MAX_AGENT_SKILLS},
        company::Company,
        creation::CreationProvenance,
        department::{DepartmentId, DepartmentRole},
        user::{Caller, Viewer},
        value_objects::{AvatarUrl, ModelName, ModelProvider},
    },
    services::harness::{ClassificationRequest, TextClassifier},
    use_cases::{
        caller::require_operator,
        channel::{SlugKind, validate_slug},
        company::{CompanyPersistence, managed_company},
    },
};

/// An agent belonging to another company is reported exactly like a missing one, so an id probe
/// cannot tell a foreign agent from a nonexistent one. See [`managed_company`].
pub fn agent_not_found() -> AppError {
    AppError::NotFound("Agent not found in this company.".into())
}

/// Everything one agent write sets, so create and update cannot drift apart and so a caller
/// cannot transpose two same-typed arguments in a nine-parameter list.
///
/// Values reach persistence already normalized — see [`AgentWrite::normalize`]. Mirrors
/// [`crate::application::ports::channel::ChannelWrite`].
#[derive(Debug, Clone, Default)]
pub struct AgentWrite {
    pub name: String,
    pub slug: String,
    pub open_to_public: bool,
    pub confirm_spam_disabled: bool,
    pub provider: Option<String>,
    pub model: Option<String>,
    pub system_prompt: Option<String>,
    /// Short statement of what the agent is for, read by the agent directory tool.
    pub description: Option<String>,
    /// Ordered concrete capability bindings. `None` preserves the draft's bindings on update.
    pub tool_bindings: Option<Vec<crate::entities::agent_capability::AgentToolBinding>>,
    pub skill_ids: Vec<Uuid>,
    pub avatar_url: Option<AvatarUrl>,
    pub created_by: Option<CreationProvenance>,
}

impl AgentWrite {
    /// Trim the fields that have canonical forms and drop the blanks. Runs once, in the use case,
    /// so create and update store the same shape.
    pub(crate) fn normalize(&mut self) -> AppResult<()> {
        self.name = self.name.trim().to_string();
        self.slug = self.slug.trim().to_lowercase().replace(' ', "-");

        if self.name.is_empty() || self.slug.is_empty() {
            return Err(AppError::BadRequest(
                "The agent name and slug cannot be empty.".into(),
            ));
        }
        validate_slug(&self.slug, SlugKind::AgentSlug)?;

        for field in [
            &mut self.provider,
            &mut self.model,
            &mut self.system_prompt,
            &mut self.description,
        ] {
            if let Some(value) = field.as_mut() {
                *value = value.trim().to_string();
                if value.is_empty() {
                    *field = None;
                }
            }
        }

        if let Some(bindings) = &self.tool_bindings {
            crate::entities::agent_capability::validate_agent_bindings(bindings)
                .map_err(AppError::BadRequest)?;
        }
        deduplicate(&mut self.skill_ids);
        if self.skill_ids.len() > MAX_AGENT_SKILLS {
            return Err(AppError::BadRequest(format!(
                "An agent may carry at most {MAX_AGENT_SKILLS} skills."
            )));
        }

        Ok(())
    }
}

fn deduplicate<T: PartialEq>(values: &mut Vec<T>) {
    let mut index = 0;
    while index < values.len() {
        if values[..index].contains(&values[index]) {
            values.remove(index);
        } else {
            index += 1;
        }
    }
}

#[async_trait]
pub trait AgentPersistence: Send + Sync {
    /// The bare agent row and principal, without a desk, publication or placement: fixtures
    /// only. Production company agents are created through [`CompanyAgents`], and this being
    /// test-only is what keeps it that way (01DEP-P03-D1).
    #[cfg(test)]
    async fn create(&self, company_id: Uuid, write: AgentWrite) -> AppResult<Agent>;

    async fn create_library(&self, write: AgentWrite) -> AppResult<Agent>;

    async fn get_by_id(&self, id: Uuid) -> AppResult<Option<Agent>>;

    async fn list_by_company_id(&self, company_id: Uuid) -> AppResult<Vec<Agent>>;

    async fn list_library(&self) -> AppResult<Vec<Agent>>;

    async fn update(&self, id: Uuid, write: AgentWrite) -> AppResult<Agent>;

    async fn delete(&self, id: Uuid) -> AppResult<()>;
}

/// Where a new agent goes: a member of `department`, holding `role` there when one is named
/// (plan 01-departments 03C item 0).
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct AgentPlacement {
    pub department: DepartmentId,
    pub role: Option<DepartmentRole>,
}

/// A company agent as created: the agent and its default desk.
#[derive(Debug, Clone)]
pub struct CreatedAgent {
    pub agent: Agent,
    pub desk_id: Uuid,
}

/// The one way a company agent comes to exist (01DEP-P03-D1): the agent, its principal, its
/// first published version, its default desk at its slug and its placement, in one transaction
/// or not at all.
#[async_trait]
pub trait CompanyAgents: Send + Sync {
    async fn create(
        &self,
        actor: WorkflowActor,
        company: CompanyId,
        write: AgentWrite,
        placement: Option<AgentPlacement>,
    ) -> AppResult<CreatedAgent>;

    /// A copy of a library definition: its skills and workflow tool grants come with it.
    async fn copy_from_library(
        &self,
        actor: WorkflowActor,
        company: CompanyId,
        library_agent_id: Uuid,
        write: AgentWrite,
        placement: Option<AgentPlacement>,
    ) -> AppResult<CreatedAgent>;
}

#[derive(Debug, Clone, serde::Serialize, serde::Deserialize, PartialEq, Eq)]
pub struct ProvisioningWarning {
    pub code: String,
    pub message: String,
}

#[derive(Debug, Clone)]
pub struct ProvisionedAgent {
    pub agent: Agent,
    pub warnings: Vec<ProvisioningWarning>,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum SpamScanning {
    Available,
    Unavailable,
}

impl SpamScanning {
    pub(crate) fn check_public_ingress(self, open: bool, confirmed: bool) -> AppResult<()> {
        if open && self == Self::Unavailable && !confirmed {
            return Err(AppError::BadRequest(
                "Spam scanning is disabled in server configuration. Saving public mail access requires explicit confirmation (confirm_spam_disabled) that you are aware spam scanning is disabled.".into(),
            ));
        }
        Ok(())
    }
}

/// Whether one of `connections` enables `model` for `provider`, both compared canonically: the
/// model-selection rule agent writes and assistant provisioning (p08 D2.3) share.
pub(crate) fn model_allowed(
    connections: &[crate::entities::company::CompanyModelConnection],
    provider: &str,
    model: &str,
) -> bool {
    let provider = ModelProvider::canonical(provider);
    let model = ModelName::canonical(model);
    connections
        .iter()
        .any(|connection| connection.provider == provider && connection.models.contains(&model))
}

/// The model an agent pinned to the company default runs on: the default connection's first
/// model, when the connection has a key. A workflow runs an agent only on an explicit model.
pub fn pinned_default_model(
    connections: &[crate::entities::company::CompanyModelConnection],
) -> Option<(String, String)> {
    let connection = connections
        .iter()
        .find(|connection| connection.is_default && connection.has_api_key)?;
    let model = connection.models.first()?;
    Some((
        connection.provider.as_str().to_owned(),
        model.as_str().to_owned(),
    ))
}

/// One library definition as a company agent write: every stored field, with the provenance left
/// for [`AgentUseCases::create_agent_from_library`] to stamp with whoever picked it. Its workflow
/// tool grants are copied with its skills, in the creating transaction.
pub(super) fn library_agent_write(definition: &Agent) -> AgentWrite {
    AgentWrite {
        tool_bindings: None,
        name: definition.name.clone(),
        slug: definition.slug.clone(),
        open_to_public: false,
        confirm_spam_disabled: false,
        provider: definition.provider.clone(),
        model: definition.model.clone(),
        system_prompt: definition.system_prompt.clone(),
        description: definition.description.clone(),
        skill_ids: Vec::new(),
        avatar_url: definition.avatar_url.clone(),
        created_by: None,
    }
}

#[derive(Clone)]
pub struct AgentUseCases {
    spam_scanning: SpamScanning,
    company_persistence: Arc<dyn CompanyPersistence>,
    agent_persistence: Arc<dyn AgentPersistence>,
    draft_persistence: Arc<dyn crate::application::agent::AgentDraftPersistence>,
    /// What creates company agents. Optional so the many use cases that only read or edit agents
    /// can be built without the provisioning templates; creation refuses without it.
    company_agents: Option<Arc<dyn CompanyAgents>>,
    /// What writes a system prompt when an operator asks for one to be generated.
    ///
    /// Optional because every other use case here works without a model: a deployment that has
    /// not configured one still manages agents. The one path that needs it refuses rather than
    /// degrading.
    prompt_classifier: Option<Arc<dyn TextClassifier>>,
}

impl AgentUseCases {
    pub fn new(
        company_persistence: Arc<dyn CompanyPersistence>,
        agent_persistence: Arc<dyn AgentPersistence>,
        draft_persistence: Arc<dyn crate::application::agent::AgentDraftPersistence>,
        spam_scanning: SpamScanning,
    ) -> Self {
        Self {
            company_persistence,
            agent_persistence,
            draft_persistence,
            spam_scanning,
            company_agents: None,
            prompt_classifier: None,
        }
    }

    pub fn with_company_agents(mut self, company_agents: Arc<dyn CompanyAgents>) -> Self {
        self.company_agents = Some(company_agents);
        self
    }

    fn company_agents(&self) -> AppResult<&Arc<dyn CompanyAgents>> {
        self.company_agents
            .as_ref()
            .ok_or_else(|| AppError::Internal("agent creation is not configured".to_string()))
    }

    pub fn with_prompt_classifier(mut self, classifier: Arc<dyn TextClassifier>) -> Self {
        self.prompt_classifier = Some(classifier);
        self
    }

    /// The model that writes system prompts, or the reason there is none.
    fn prompt_classifier(&self) -> AppResult<&Arc<dyn TextClassifier>> {
        self.prompt_classifier.as_ref().ok_or_else(|| {
            AppError::Internal(
                "No agent harness is configured to generate a system prompt.".to_string(),
            )
        })
    }

    async fn verify_company_manager(&self, user_id: Uuid, company_id: Uuid) -> AppResult<()> {
        managed_company(self.company_persistence.as_ref(), user_id, company_id).await?;
        Ok(())
    }

    async fn validate_model_selection(
        &self,
        company_id: Uuid,
        write: &AgentWrite,
    ) -> AppResult<()> {
        if write.provider.is_none() || write.model.is_none() {
            return model_preparation::validate_model_selection(&[], write);
        }
        let connections = self
            .company_persistence
            .list_model_connections(company_id)
            .await?;
        model_preparation::validate_model_selection(&connections, write)
    }

    pub async fn list_company_model_connections(
        &self,
        user_id: Uuid,
        company_id: Uuid,
    ) -> AppResult<Vec<crate::entities::company::CompanyModelConnection>> {
        self.verify_company_manager(user_id, company_id).await?;
        self.company_persistence
            .list_model_connections(company_id)
            .await
    }

    /// Create a company agent with its default desk at its slug, placed in `placement` when one
    /// is named (01DEP-P03-D1).
    #[instrument(skip_all)]
    pub async fn create_agent(
        &self,
        user_id: Uuid,
        company_id: Uuid,
        write: AgentWrite,
        placement: Option<AgentPlacement>,
    ) -> AppResult<CreatedAgent> {
        let (_, write) = self
            .prepared_agent_write(user_id, company_id, write)
            .await?;
        info!(%company_id, "Creating agent");
        self.company_agents()?
            .create(
                WorkflowActor::authenticated(user_id)?,
                CompanyId::new(company_id),
                write,
                placement,
            )
            .await
    }

    /// Everything a create checks before it writes anything, answering with the normalized write.
    ///
    /// The Simple create path calls it so a bad handle or model pair is refused before a system
    /// prompt is generated for it.
    pub async fn validate_new_agent(
        &self,
        user_id: Uuid,
        company_id: Uuid,
        write: AgentWrite,
    ) -> AppResult<AgentWrite> {
        let (_, write) = self
            .prepared_agent_write(user_id, company_id, write)
            .await?;
        Ok(write)
    }

    /// The company a new agent belongs to, and the write itself normalized and checked.
    ///
    /// One place for "is this a valid new agent here", so the Simple path's check and the create
    /// that follows it cannot disagree about what will be accepted.
    async fn prepared_agent_write(
        &self,
        user_id: Uuid,
        company_id: Uuid,
        mut write: AgentWrite,
    ) -> AppResult<(Company, AgentWrite)> {
        let company =
            managed_company(self.company_persistence.as_ref(), user_id, company_id).await?;
        write.created_by = Some(CreationProvenance::user(user_id));
        write.normalize()?;
        self.spam_scanning
            .check_public_ingress(write.open_to_public, write.confirm_spam_disabled)?;
        self.validate_model_selection(company_id, &write).await?;
        Ok((company, write))
    }

    /// Create one company agent from a global library definition, with its default desk like
    /// every company agent.
    ///
    /// The definition is copied rather than referenced: the company owns what it creates and can
    /// edit it afterwards without the global entry changing under it.
    #[instrument(skip_all)]
    pub async fn create_agent_from_library(
        &self,
        user_id: Uuid,
        company_id: Uuid,
        library_agent_id: Uuid,
        placement: Option<AgentPlacement>,
    ) -> AppResult<ProvisionedAgent> {
        managed_company(self.company_persistence.as_ref(), user_id, company_id).await?;
        let definition = self
            .get_library_agent(library_agent_id)
            .await?
            .ok_or_else(agent_not_found)?;
        let connections = self
            .company_persistence
            .list_model_connections(company_id)
            .await?;
        let (write, mut warnings) =
            model_preparation::prepare_library_write(&definition, user_id, &connections)?;
        let inherited = definition.provider.is_none() && definition.model.is_none();
        let created = self
            .company_agents()?
            .copy_from_library(
                WorkflowActor::authenticated(user_id)?,
                CompanyId::new(company_id),
                library_agent_id,
                write,
                placement,
            )
            .await?;
        let agent = created.agent;
        if inherited && let (Some(provider), Some(model)) = (&agent.provider, &agent.model) {
            warnings.push(ProvisioningWarning {
                code: "library_model_pinned".into(),
                message: format!(
                    "'{}' answers its desk, which needs an explicit model, so it was created on the company's default: {provider} {model}.",
                    definition.name
                ),
            });
        }
        Ok(ProvisionedAgent { agent, warnings })
    }

    #[instrument(skip_all)]
    pub async fn list_company_agents(
        &self,
        user_id: Uuid,
        company_id: Uuid,
    ) -> AppResult<Vec<Agent>> {
        self.verify_company_manager(user_id, company_id).await?;
        self.agent_persistence.list_by_company_id(company_id).await
    }

    pub async fn list_library_agents(&self) -> AppResult<Vec<Agent>> {
        self.agent_persistence.list_library().await
    }

    pub async fn get_library_agent(&self, agent_id: Uuid) -> AppResult<Option<Agent>> {
        Ok(self
            .agent_persistence
            .get_by_id(agent_id)
            .await?
            .filter(Agent::is_library))
    }

    /// Authorize the library workspace before a transport validates its editable fields.
    /// The mutation methods repeat this guard so direct application callers cannot bypass it.
    pub fn authorize_library(&self, caller: &Caller) -> AppResult<()> {
        require_operator(caller)
    }

    /// Every library definition, for the operator workspace and its API. The same list every
    /// company picks from ([`Self::list_library_agents`]) is not what this guards: managing the
    /// library is the operator's, so reading it *as its manager* is too.
    pub async fn library_agents_for(&self, caller: &Caller) -> AppResult<Vec<Agent>> {
        self.authorize_library(caller)?;
        self.list_library_agents().await
    }

    /// One library definition, for the operator workspace and its API.
    pub async fn library_agent_for(
        &self,
        caller: &Caller,
        agent_id: Uuid,
    ) -> AppResult<Option<Agent>> {
        self.authorize_library(caller)?;
        self.get_library_agent(agent_id).await
    }

    /// Operator only: a global definition is offered to every company.
    pub async fn create_library_agent(
        &self,
        caller: &Caller,
        mut write: AgentWrite,
    ) -> AppResult<Agent> {
        self.authorize_library(caller)?;
        write.created_by = Some(CreationProvenance::system());
        write.normalize()?;
        self.agent_persistence.create_library(write).await
    }

    /// Operator only.
    pub async fn update_library_agent(
        &self,
        caller: &Caller,
        agent_id: Uuid,
        mut write: AgentWrite,
    ) -> AppResult<Agent> {
        self.authorize_library(caller)?;
        self.get_library_agent(agent_id)
            .await?
            .ok_or_else(agent_not_found)?;
        write.normalize()?;
        self.agent_persistence.update(agent_id, write).await
    }

    /// Operator only.
    pub async fn delete_library_agent(&self, caller: &Caller, agent_id: Uuid) -> AppResult<()> {
        self.authorize_library(caller)?;
        self.get_library_agent(agent_id)
            .await?
            .ok_or_else(agent_not_found)?;
        self.agent_persistence.delete(agent_id).await
    }

    #[instrument(skip_all)]
    pub async fn get_company_agent(
        &self,
        user_id: Uuid,
        company_id: Uuid,
        agent_id: Uuid,
    ) -> AppResult<Option<Agent>> {
        self.verify_company_manager(user_id, company_id).await?;
        let agent = self.agent_persistence.get_by_id(agent_id).await?;
        if let Some(ref ag) = agent
            && ag.company_id != Some(company_id)
        {
            return Ok(None);
        }
        Ok(agent)
    }

    /// One agent, if this viewer is on the company's team.
    ///
    /// The read counterpart of [`AgentUseCases::get_company_agent`]: that one is for the pages
    /// that *configure* agents and stays owner-or-admin, this one is what a rendered thread names as
    /// its responder, and an invited member reads that just as the owner does. Which channels the
    /// member may read at all is `Channel::viewer_access`'s question, asked before this one.
    #[instrument(skip_all)]
    pub async fn get_readable_agent(
        &self,
        viewer: &Viewer,
        company_id: Uuid,
        agent_id: Uuid,
    ) -> AppResult<Option<Agent>> {
        let is_team = self
            .company_persistence
            .company_access(viewer.user_id, company_id)
            .await?
            .is_some_and(|access| access.membership.is_team());
        if !is_team {
            return Ok(None);
        }

        Ok(self
            .agent_persistence
            .get_by_id(agent_id)
            .await?
            .filter(|agent| agent.company_id.is_none() || agent.company_id == Some(company_id)))
    }

    #[instrument(skip_all)]
    pub async fn update_agent(
        &self,
        user_id: Uuid,
        company_id: Uuid,
        request: crate::application::agent::CompanyAgentUpdate,
    ) -> AppResult<Agent> {
        let crate::application::agent::CompanyAgentUpdate {
            agent,
            expected_revision,
            mut write,
            tools,
        } = request;
        let agent_id = agent.as_uuid();
        self.verify_company_manager(user_id, company_id).await?;

        let stored = self
            .agent_persistence
            .get_by_id(agent_id)
            .await?
            .ok_or_else(agent_not_found)?;

        if stored.company_id != Some(company_id) {
            return Err(agent_not_found());
        }

        write.normalize()?;
        self.spam_scanning
            .check_public_ingress(write.open_to_public, write.confirm_spam_disabled)?;
        self.validate_model_selection(company_id, &write).await?;

        info!(%agent_id, %company_id, "Updating agent");

        self.draft_persistence
            .save_company_agent(crate::application::agent::SaveCompanyAgent {
                scope: crate::application::agent::AgentPublicationScope {
                    company: crate::domain::workflow::CompanyId::new(company_id),
                    actor: crate::application::workflow::WorkflowActor::authenticated(user_id)?,
                    agent,
                },
                expected_revision,
                write,
                tools,
            })
            .await
    }

    #[instrument(skip_all)]
    pub async fn delete_agent(
        &self,
        user_id: Uuid,
        company_id: Uuid,
        agent_id: Uuid,
    ) -> AppResult<()> {
        self.verify_company_manager(user_id, company_id).await?;

        let agent = self
            .agent_persistence
            .get_by_id(agent_id)
            .await?
            .ok_or_else(agent_not_found)?;

        if agent.company_id != Some(company_id) {
            return Err(agent_not_found());
        }

        info!("Deleting agent {} for company {}", agent_id, company_id);
        self.agent_persistence.delete(agent_id).await
    }

    #[instrument(skip_all)]
    /// Expand a plain-language description of an agent into a full system prompt, using the
    /// company's own LLM credentials.
    pub async fn generate_system_prompt(
        &self,
        user_id: Uuid,
        company_id: Uuid,
        instructions: &str,
        provider_override: Option<&str>,
        model_override: Option<&str>,
    ) -> AppResult<String> {
        self.verify_company_manager(user_id, company_id).await?;

        let connections = self
            .company_persistence
            .list_model_connections(company_id)
            .await?;
        let (provider, model) =
            model_preparation::prompt_model(&connections, provider_override, model_override)?;
        let api_key = self
            .company_persistence
            .model_api_key(company_id, &provider)
            .await?;
        let llm = PromptGeneratorLlm::resolve_explicit(&provider, &model, api_key.as_deref())?;

        generate_prompt_with(self.prompt_classifier()?.as_ref(), llm, instructions).await
    }

    /// Generate a library prompt from explicit operator settings (falling back to environment
    /// credentials), since a global definition has no company settings to inherit from.
    ///
    /// Operator only: it spends the deployment's own provider credentials.
    pub async fn generate_library_system_prompt(
        &self,
        caller: &Caller,
        instructions: &str,
        provider: Option<&str>,
        model: Option<&str>,
        api_key: Option<&str>,
    ) -> AppResult<String> {
        self.authorize_library(caller)?;
        let llm = PromptGeneratorLlm::resolve_global(provider, model, api_key)?;
        generate_prompt_with(self.prompt_classifier()?.as_ref(), llm, instructions).await
    }
}

async fn generate_prompt_with(
    classifier: &dyn TextClassifier,
    llm: PromptGeneratorLlm,
    instructions: &str,
) -> AppResult<String> {
    info!("Calling prompt generator");
    let response = classifier
        .complete(ClassificationRequest {
            system_prompt: PROMPT_GENERATOR_SYSTEM_PROMPT,
            user_prompt: instructions,
            provider: &llm.provider,
            model: &llm.model,
            api_key: &llm.api_key,
        })
        .await
        .map_err(|e| AppError::Internal(format!("AI generation call failed: {e}")))?;

    // Models like to wrap the prompt in a code fence despite being told not to.
    Ok(response
        .trim()
        .trim_start_matches("```")
        .trim_end_matches("```")
        .trim()
        .to_string())
}

const PROMPT_GENERATOR_SYSTEM_PROMPT: &str = "\
You are an expert AI prompt engineer specializing in crafting system prompts for autonomous AI agents.
Your task is to generate a comprehensive, clear, structured, and production-ready system prompt based on the user's instructions.

Guidelines:
- Define a clear role and primary objective for the agent.
- Outline specific instructions, guidelines, constraints, and tone of communication.
- Keep the prompt structured, concise, and unambiguous.
- Output ONLY the system prompt text itself. Do NOT include any intro/outro explanations, conversational filler, or markdown code blocks (```).";

/// The model that writes system prompts, resolved from explicit operator input or company-owned
/// settings. Deployment credentials are never shared with a company.
struct PromptGeneratorLlm {
    provider: ModelProvider,
    model: ModelName,
    api_key: String,
}

impl PromptGeneratorLlm {
    fn resolve_global(
        provider_override: Option<&str>,
        model_override: Option<&str>,
        api_key_override: Option<&str>,
    ) -> AppResult<Self> {
        let provider = non_empty(provider_override)
            .map(str::to_lowercase)
            .ok_or_else(|| {
                AppError::BadRequest(
                    "A provider is required to generate a global library prompt.".into(),
                )
            })?;
        let model = ModelName::canonical(
            non_empty(model_override)
                .unwrap_or_else(|| crate::model_providers::default_model_for(&provider)),
        );
        let api_key = non_empty(api_key_override)
            .ok_or_else(|| {
                AppError::BadRequest(format!(
                    "An API key is required to generate a prompt with provider '{provider}'."
                ))
            })?
            .to_string();
        Ok(Self {
            provider: ModelProvider::canonical(&provider),
            model,
            api_key,
        })
    }

    fn resolve_explicit(
        provider: &ModelProvider,
        model: &ModelName,
        api_key: Option<&str>,
    ) -> AppResult<Self> {
        // A company that has not finished configuring its provider is a caller problem, not a
        // server fault -- every sibling check in `generate_system_prompt` says so with a 400.
        let api_key = non_empty(api_key)
            .ok_or_else(|| AppError::BadRequest(format!(
                "API key is missing for provider '{provider}'. Please configure the company model connection."
            )))?
            .to_string();

        Ok(Self {
            provider: provider.clone(),
            model: model.clone(),
            api_key,
        })
    }
}

fn non_empty(value: Option<&str>) -> Option<&str> {
    value.map(str::trim).filter(|value| !value.is_empty())
}

#[cfg(test)]
#[path = "agent_tests.rs"]
mod tests;

/// Workflow names are already `TypeName`s; bound and de-duplicate like the SQL shape check.
pub(crate) fn validate_workflow_names(
    names: Option<&[crate::domain::workflow::TypeName]>,
    label: &str,
) -> AppResult<()> {
    let Some(names) = names else {
        return Ok(());
    };
    let unique: std::collections::BTreeSet<_> = names.iter().collect();
    if names.len() > 32 || unique.len() != names.len() {
        return Err(AppError::BadRequest(format!(
            "At most 32 distinct {label} are allowed."
        )));
    }
    Ok(())
}

pub(crate) mod model_preparation;

#[async_trait]
impl super::onboarding::OnboardingPromptGenerator for AgentUseCases {
    async fn generate(&self, request: super::onboarding::PromptRequest) -> AppResult<String> {
        let llm = PromptGeneratorLlm::resolve_explicit(
            &request.provider,
            &request.model,
            request.api_key.as_deref(),
        )?;
        generate_prompt_with(
            self.prompt_classifier()?.as_ref(),
            llm,
            &request.instructions,
        )
        .await
    }
}
