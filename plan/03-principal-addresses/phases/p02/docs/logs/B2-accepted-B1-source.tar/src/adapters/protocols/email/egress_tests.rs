//! What the email renderer freezes, and what the sender does with it.
//!
//! The renderer is the whole reason a retry cannot drift: everything about the mail is decided
//! here, from one envelope, with no I/O. So these tests pin the decisions — the `Re:` prefix, the
//! `Cc` filtering, the hop header, and above all the `Message-ID`, which the queue's idempotency
//! depends on being a pure function of the delivery's key.

use std::sync::{Arc, Mutex};

use async_trait::async_trait;

use super::*;
use crate::adapters::protocols::email::DeploymentMailTransports;
use crate::adapters::protocols::email::test_support::{RecordingTransport, RefusingTransport};
use crate::{
    entities::{
        message::CanonicalMessageId,
        transport::{AddressSelector, ChannelBindingId, DeliveryPurpose},
        value_objects::{ChannelSlug, CompanySlug},
    },
    transport::{
        CanonicalContent, ConversationAnchor, DeliveryComposer, DeliveryDestination,
        DeliveryIntent, DeliveryKey, DeliveryRecord, EmailThreading, MAX_DELIVERY_ATTEMPTS,
    },
};

const DOMAIN: &str = "mailagents.test";

fn renderer() -> EmailRenderer {
    EmailRenderer::new(DOMAIN)
}

/// A delivery ready to render: a reply from `support`, quoting one inbound mail.
fn envelope(context: EmailDeliveryContext) -> DeliveryEnvelope {
    let content = CanonicalContent::parse("Order 91", "On its way.").expect("bounded content");
    let destination = DeliveryDestination::External(
        crate::entities::transport::ExternalDestination::Email(context.recipient_to.clone()),
    );
    let message_id = CanonicalMessageId::random();
    let binding = ChannelBindingId::random();
    DeliveryEnvelope::new(
        crate::entities::transport::DeliveryId::random(),
        DeliveryIntent {
            message_id,
            source_binding_id: binding,
            destination: destination.clone(),
            purpose: DeliveryPurpose::WorkflowReply,
            key: DeliveryKey::parse("reply:task:abc:email:customer@example.com")
                .expect("a short key"),
        },
        TransportKind::Email,
        CorrelationId::new(),
        &content,
        crate::transport::DeliveryContext::Email(context),
    )
    .expect("an email context matches an email transport")
}

fn context(recipient: &str) -> EmailDeliveryContext {
    EmailDeliveryContext {
        from: EmailAddress::from(format!("support@acme.{DOMAIN}")),
        from_name: Some("Support".to_string()),
        recipient_to: EmailAddress::from(recipient),
        recipients_cc: Vec::new(),
        threading: EmailThreading::Received {
            in_reply_to: MessageId::from("<inbound@example.com>"),
            references: vec![MessageId::from("<root@example.com>")],
        },
        relay: Some(crate::transport::EmailRelayTrace {
            source_channel_id: Uuid::new_v4(),
            hop_count: 1,
            trace_channels: Vec::new(),
        }),
    }
}

/// The frozen mail one render produced.
fn frozen(parts: &[RenderedPart]) -> OutboundEmailV1 {
    parts[0]
        .payload
        .decode(TransportKind::Email, OUTBOUND_EMAIL_VERSION)
        .expect("the renderer wrote this payload")
}

/// The queue-then-deliver split rests on this: whoever queues a delivery derives the outbound
/// `Message-ID` from the part key and persists it *before* the worker sends, so both sides must
/// arrive at the same value from the same key. If this drifts, the message recorded in the thread
/// and the mail actually delivered stop matching, and replies stop threading.
#[test]
fn the_message_id_is_a_pure_function_of_the_delivery_key() {
    let renderer = renderer();
    let first = renderer
        .render(&envelope(context("customer@example.com")))
        .unwrap();
    let second = renderer
        .render(&envelope(context("customer@example.com")))
        .unwrap();

    assert_eq!(frozen(&first).message_id, frozen(&second).message_id);
    assert_eq!(first[0].key, second[0].key, "the part key is stable too");
    assert!(
        frozen(&first)
            .message_id
            .as_str()
            .ends_with(&format!("@{DOMAIN}>")),
        "the Message-ID is qualified by this deployment's domain"
    );

    // A different key is a different mail, or two logical deliveries would collide onto one
    // Message-ID and a recipient's client would thread them as one.
    let other = renderer.message_id_for(
        &EmailRenderer::part_key("reply:task:xyz:email:customer@example.com").unwrap(),
    );
    assert_ne!(frozen(&first).message_id, other);
}

/// Email freezes exactly one part. Not a limitation to be lifted: a mail has no length bound that
/// would justify splitting one answer, and doing so would break threading for every client.
#[test]
fn one_delivery_freezes_exactly_one_mail() {
    let parts = renderer()
        .render(&envelope(context("customer@example.com")))
        .unwrap();
    assert_eq!(parts.len(), 1);
    assert_eq!(parts[0].index.get(), 0);
}

/// `Re:` exactly once, however the subject arrived, and the parent appended to `References:` when
/// it is not already there.
#[test]
fn the_reply_subject_and_reference_chain_are_normalized() {
    let rendered = frozen(
        &renderer()
            .render(&envelope(context("c@example.com")))
            .unwrap(),
    );
    assert_eq!(rendered.subject, "Re: Order 91");
    assert_eq!(
        rendered.references,
        vec![
            MessageId::from("<root@example.com>"),
            MessageId::from("<inbound@example.com>"),
        ],
        "the parent joins the chain it answers"
    );

    assert_eq!(reply_subject("Re: Order 91"), "Re: Order 91");
    assert_eq!(reply_subject("RE: Order 91"), "RE: Order 91");
    assert_eq!(reply_subject("   "), "Re:");
}

/// An anchored conversation gets an RFC id, and it is derived here rather than by the producer.
///
/// A schedule firing answers nothing that was received. Every producer in that position used to
/// build its own `<schedule-run-...>` id, which is how an unbracketed UUID and a Slack timestamp
/// both ended up in live `In-Reply-To:` headers. The anchor is an opaque key; only this renderer
/// knows what one looks like on the wire.
#[test]
fn an_anchored_conversation_is_given_its_message_id_by_the_renderer() {
    let anchored = |key: &str| {
        frozen(
            &renderer()
                .render(&envelope(EmailDeliveryContext {
                    threading: EmailThreading::Anchored(ConversationAnchor::parse(key).unwrap()),
                    ..context("customer@example.com")
                }))
                .unwrap(),
        )
    };

    let run = anchored("schedule-run:0f9a");
    let parent = run
        .in_reply_to
        .clone()
        .expect("an anchored mail threads onto something");
    assert!(
        parent.as_str().starts_with('<') && parent.as_str().ends_with(&format!("@{DOMAIN}>")),
        "an anchor becomes a real RFC id, qualified by this deployment: {parent}"
    );
    assert_eq!(
        run.references,
        vec![parent.clone()],
        "the chain ends at the message In-Reply-To names, or clients thread it nowhere"
    );

    // Same slot, same conversation -- this is the whole reason the anchor is derived rather than
    // random. A second firing of one schedule files under the first.
    assert_eq!(
        anchored("schedule-run:0f9a").in_reply_to,
        Some(parent.clone())
    );
    assert_ne!(anchored("schedule-run:1b7c").in_reply_to, Some(parent));
}

/// A standalone notice threads onto nothing, so it emits neither header.
///
/// The arm exists so that "this answers nothing" is a thing a producer can *say*. Before it, a
/// notice about a message that carried no RFC id fabricated one from the canonical UUID, which put
/// an unbracketed value into `In-Reply-To:` that no client could match and no reply could resolve.
#[test]
fn a_standalone_notice_carries_no_threading_headers() {
    let notice = frozen(
        &renderer()
            .render(&envelope(EmailDeliveryContext {
                threading: EmailThreading::Standalone,
                ..context("customer@example.com")
            }))
            .unwrap(),
    );
    assert_eq!(notice.in_reply_to, None);
    assert!(notice.references.is_empty());
}

/// Received mail with no RFC id of its own is standalone, not anchored.
///
/// A turn that arrived over a transport with no headers gives a recipient nothing to thread onto.
/// Anchoring it would invent a conversation nobody is in.
#[test]
fn received_mail_without_an_rfc_id_threads_onto_nothing() {
    assert_eq!(
        EmailThreading::received(None, vec![MessageId::from("<root@example.com>")]),
        EmailThreading::Standalone
    );
}

/// The `Cc` line loses the recipient, the sender, and every address inside this deployment.
///
/// A platform address on a `Cc` line is an inbound message waiting to happen: the pipeline that
/// wanted one has its own delivery, and copying it here would deliver the answer twice.
#[test]
fn copied_addresses_drop_duplicates_and_this_deployment_s_own_mailboxes() {
    let rendered = frozen(
        &renderer()
            .render(&envelope(EmailDeliveryContext {
                recipients_cc: vec![
                    EmailAddress::from("Customer@Example.com"),
                    EmailAddress::from(format!("support@acme.{DOMAIN}")),
                    EmailAddress::from(format!("other@acme.{DOMAIN}")),
                    EmailAddress::from("manager@example.com"),
                    EmailAddress::from("manager@example.com"),
                ],
                ..context("customer@example.com")
            }))
            .unwrap(),
    );

    assert_eq!(
        rendered.recipients_cc,
        vec![EmailAddress::from("manager@example.com")]
    );
}

/// A channel's mail carries the hop budget; a platform notice deliberately carries none.
///
/// Without the header the receiving side has no hop count to continue, which is exactly what makes
/// a bounce or a stop notice unanswerable.
#[test]
fn only_a_relayed_message_carries_the_loop_control_headers() {
    let relayed = frozen(
        &renderer()
            .render(&envelope(context("c@example.com")))
            .unwrap(),
    );
    let headers = relayed.wire_headers();
    let value = |name: &str| {
        headers
            .iter()
            .find(|header| header.name == name)
            .map(|header| header.value.clone())
    };
    assert_eq!(value("Auto-Submitted").as_deref(), Some("auto-replied"));
    // The hop this mail *is*, not the hop it answers: ingress compares the received value against
    // its budget, so incrementing here is what makes the budget finite.
    assert_eq!(value("X-MailAgents-Hop-Count").as_deref(), Some("2"));
    assert!(value("X-MailAgents-Trace").is_some());

    let notice = frozen(
        &renderer()
            .render(&envelope(EmailDeliveryContext {
                relay: None,
                ..context("c@example.com")
            }))
            .unwrap(),
    );
    let notice_headers = notice.wire_headers();
    assert!(
        notice_headers
            .iter()
            .all(|header| !header.name.starts_with("X-MailAgents-")),
        "a notice must offer nothing to answer with"
    );
    assert!(
        notice_headers
            .iter()
            .any(|header| header.name == "Auto-Submitted"),
        "it is still auto-submitted, which is what stops it being answered"
    );
}

/// An internal hop costs exactly what an external one costs.
///
/// The relay is a transport, so what it hands the receiving channel has to be what the headers
/// would have carried. Handing over the pre-increment values instead makes an in-process hop free,
/// and the inter-channel loop budget is never spent -- which is a loop with no bound on it.
#[test]
fn the_internal_relay_and_the_wire_agree_on_the_hop_budget() {
    let relayed = frozen(
        &renderer()
            .render(&envelope(context(&format!("sales@acme.{DOMAIN}"))))
            .unwrap(),
    );
    let mail = relayed
        .as_relay_mail(crate::transport::test_support::relay_proof(Uuid::new_v4()))
        .expect("a channel's mail addressed to one of our channels can be relayed");
    assert_eq!(
        mail.target,
        &AddressSelector::Qualified {
            company: CompanySlug::new("acme"),
            channel: ChannelSlug::new("sales"),
        },
        "the adapter, not the application, reads its own address syntax"
    );
    let header = relayed
        .wire_headers()
        .into_iter()
        .find(|header| header.name == "X-MailAgents-Hop-Count")
        .expect("a relayed message carries its hop count");

    assert_eq!(header.value, mail.hop_count.to_string());
    assert!(
        mail.trace.contains(&mail.source_channel_id),
        "the sending channel joins the trace, or a return hop reads as an unexplained cycle"
    );
}

/// A mail addressed outside this deployment is never handed to the in-process relay.
///
/// `EmailSender` tries the relay before SMTP, so the address syntax has to be read once, here,
/// where the adapter owns it. If an external recipient still produced a relay mail, the relay
/// would have to re-parse the address to reject it -- two copies of the same decision, and the
/// one that drifts silently delivers a customer's reply into a channel instead of to them.
#[test]
fn a_mail_addressed_outside_this_deployment_carries_no_internal_target() {
    let external = frozen(
        &renderer()
            .render(&envelope(context("customer@example.com")))
            .unwrap(),
    );
    assert!(external.internal_target.is_none());
    assert!(
        external
            .as_relay_mail(crate::transport::test_support::relay_proof(Uuid::new_v4()))
            .is_none()
    );
}

/// A fan-out or context-only address selects no single channel, so it is not a direct relay.
///
/// Both are still valid mail -- they go out over SMTP and are ingested through the normal inbound
/// path, which is what resolves *several* recipient channels. The relay shortcut exists only for
/// the unambiguous one-channel case.
#[test]
fn only_one_unambiguous_channel_is_relayed_directly() {
    let fan_out = frozen(
        &renderer()
            .render(&envelope(context(&format!("sales+billing@acme.{DOMAIN}"))))
            .unwrap(),
    );
    assert!(fan_out.internal_target.is_none());

    let context_only = frozen(
        &renderer()
            .render(&envelope(context(&format!("sales.quiet@acme.{DOMAIN}"))))
            .unwrap(),
    );
    assert!(context_only.internal_target.is_none());
}

/// The renderer refuses a context it does not speak rather than reading the wrong arm.
#[test]
fn a_renderer_refuses_a_context_for_another_transport() {
    let content = CanonicalContent::parse("Subject", "Body").unwrap();
    let mismatch = DeliveryEnvelope::new(
        crate::entities::transport::DeliveryId::random(),
        DeliveryIntent {
            message_id: CanonicalMessageId::random(),
            source_binding_id: ChannelBindingId::random(),
            destination: DeliveryDestination::Binding(ChannelBindingId::random()),
            purpose: DeliveryPurpose::WorkflowReply,
            key: DeliveryKey::parse("mirror:key").unwrap(),
        },
        TransportKind::Slack,
        CorrelationId::new(),
        &content,
        crate::transport::DeliveryContext::Email(context("c@example.com")),
    );
    assert!(
        mismatch.is_err(),
        "an email context cannot ride a Slack delivery"
    );
}

/// A relay that fails gives no verdict, and the honest classification is ambiguity.
///
/// An accepted `DATA` whose final acknowledgement was lost is indistinguishable here from a refused
/// connection, so a retry is exactly how one message becomes two. This is the behaviour the shape
/// this replaces got wrong.
#[tokio::test]
async fn a_failed_submission_is_ambiguous_rather_than_retried() {
    let sender = EmailSender::new(
        DeploymentMailTransports::only(Arc::new(RefusingTransport)),
        Arc::new(NeverInternal::default()),
    );
    let parts = renderer()
        .render(&envelope(EmailDeliveryContext {
            relay: None,
            ..context("outsider@example.com")
        }))
        .unwrap();

    let outcome = sender.send(&record(), &parts[0]).await;
    assert!(
        matches!(outcome, ProviderSendOutcome::OutcomeUnknown { .. }),
        "a lost acknowledgement must not be re-sent: {outcome:?}"
    );
    assert!(!outcome.is_safely_retryable());
}

/// A successful submission names the `Message-ID` it went out under as the provider key, because
/// that is the value a recipient's `References:` header will quote back.
#[tokio::test]
async fn a_delivered_mail_reports_the_message_id_it_went_out_under() {
    let transport = Arc::new(RecordingTransport::default());
    let sender = EmailSender::new(
        DeploymentMailTransports::only(transport.clone()),
        Arc::new(NeverInternal::default()),
    );
    let parts = renderer()
        .render(&envelope(EmailDeliveryContext {
            relay: None,
            ..context("outsider@example.com")
        }))
        .unwrap();
    let expected = frozen(&parts).message_id;

    match sender.send(&record(), &parts[0]).await {
        ProviderSendOutcome::Delivered { provider_key } => assert_eq!(
            provider_key.map(|key| key.as_str().to_string()),
            Some(expected.as_str().to_string())
        ),
        other => panic!("a working relay delivers: {other:?}"),
    }
    assert_eq!(transport.sent().len(), 1);
}

/// A payload this build cannot read is terminal, not retryable: it will not become readable on the
/// fifth attempt, and spending five backoffs to reach the same verdict is pure delay.
#[tokio::test]
async fn an_unreadable_payload_is_terminal() {
    let sender = EmailSender::new(
        DeploymentMailTransports::only(Arc::new(RecordingTransport::default())),
        Arc::new(NeverInternal::default()),
    );
    let alien = RenderedPart {
        index: crate::transport::PartIndex::new(0),
        key: crate::transport::PartKey::parse("email:alien").unwrap(),
        payload: crate::transport::TransportPayload::encode(
            TransportKind::Email,
            OUTBOUND_EMAIL_VERSION + 1,
            &serde_json::json!({}),
        )
        .unwrap(),
        digest: ContentDigest::sha256_of(b"body"),
    };

    let outcome = sender.send(&record(), &alien).await;
    assert!(
        matches!(
            outcome,
            ProviderSendOutcome::Terminal {
                class: FailureClass::InvalidPayload,
                ..
            }
        ),
        "{outcome:?}"
    );
}

/// A recipient this deployment owns never reaches SMTP.
#[tokio::test]
async fn a_recipient_of_our_own_is_relayed_rather_than_posted() {
    let transport = Arc::new(RecordingTransport::default());
    let relay = Arc::new(NeverInternal::answering(RelayDisposition::Relayed));
    let sender = EmailSender::new(
        DeploymentMailTransports::only(transport.clone()),
        relay.clone(),
    );
    let parts = renderer()
        .render(&envelope(context("other@acme.mailagents.test")))
        .unwrap();
    let record = record();

    let outcome = sender.send(&record, &parts[0]).await;
    assert!(matches!(outcome, ProviderSendOutcome::Delivered { .. }));
    assert!(
        transport.sent().is_empty(),
        "an internal hop must not leave the building"
    );
    assert_eq!(
        *relay.claimed.lock().unwrap(),
        vec![crate::transport::InternalRelayProof::of(&record, &parts[0])],
        "the hop names exactly the claimed delivery and the part being sent"
    );
}

/// A refusal by one of our own channels is definite: the same channel will refuse the same message
/// next time, so it goes terminal rather than spending an attempt budget on it.
#[tokio::test]
async fn an_internal_refusal_is_terminal() {
    let relay = Arc::new(NeverInternal::answering(RelayDisposition::Refused(
        "Max inter-channel hop count reached".into(),
    )));
    let transport = Arc::new(RecordingTransport::default());
    let sender = EmailSender::new(DeploymentMailTransports::only(transport.clone()), relay);
    let parts = renderer()
        .render(&envelope(context("other@acme.mailagents.test")))
        .unwrap();

    let outcome = sender.send(&record(), &parts[0]).await;
    assert!(
        matches!(
            outcome,
            ProviderSendOutcome::Terminal {
                class: FailureClass::DestinationUnavailable,
                ..
            }
        ),
        "{outcome:?}"
    );
    assert!(
        transport.sent().is_empty(),
        "a refused internal hop is never washed through SMTP"
    );
}

/// The durable identity a sender is handed.
fn record() -> DeliveryRecord {
    DeliveryRecord {
        id: crate::entities::transport::DeliveryId::random(),
        company_id: Uuid::new_v4(),
        attribution: Some(crate::transport::DeliveryAttribution {
            channel_id: Uuid::new_v4(),
            message_id: CanonicalMessageId::random(),
            source_binding_id: ChannelBindingId::random(),
            destination_binding_id: ChannelBindingId::random(),
        }),
        external_destination: None,
        correlation_id: CorrelationId::new(),
        transport: TransportKind::Email,
        purpose: DeliveryPurpose::WorkflowReply,
        idempotency_key: DeliveryKey::parse("reply:task:abc:email:customer@example.com").unwrap(),
        attempt_count: 0,
        max_attempts: MAX_DELIVERY_ATTEMPTS,
        cancellation: None,
    }
}

/// A relay that answers however the test told it to, defaulting to "not one of ours", and
/// records the delivery part each hop claimed to be.
struct NeverInternal {
    disposition: Mutex<RelayDisposition>,
    claimed: Mutex<Vec<crate::transport::InternalRelayProof>>,
}

impl NeverInternal {
    fn answering(disposition: RelayDisposition) -> Self {
        Self {
            disposition: Mutex::new(disposition),
            claimed: Mutex::default(),
        }
    }
}

impl Default for NeverInternal {
    fn default() -> Self {
        Self::answering(RelayDisposition::NotInternal)
    }
}

#[async_trait]
impl InternalMailRelay for NeverInternal {
    async fn relay_internal(&self, mail: &InternalRelayMail<'_>) -> AppResult<RelayDisposition> {
        self.claimed.lock().unwrap().push(mail.proof);
        Ok(self.disposition.lock().unwrap().clone())
    }
}

/// The composer is what every producer goes through, and its key shape is what deduplication is
/// scoped by. Two purposes, two sources or two destinations are three different deliveries.
#[test]
fn a_delivery_key_separates_purpose_source_and_destination() {
    let destination = |address: &str| {
        DeliveryDestination::External(crate::entities::transport::ExternalDestination::Email(
            EmailAddress::from(address),
        ))
    };
    let key = |purpose, source: &str, address: &str| {
        crate::transport::delivery_key(purpose, source, &destination(address))
            .as_str()
            .to_string()
    };

    let base = key(DeliveryPurpose::WorkflowReply, "task:1", "a@example.com");
    assert_eq!(base, "workflow_reply:task:1:email:a@example.com");
    assert_ne!(
        base,
        key(DeliveryPurpose::WorkflowSend, "task:1", "a@example.com")
    );
    assert_ne!(
        base,
        key(DeliveryPurpose::WorkflowReply, "task:2", "a@example.com")
    );
    assert_ne!(
        base,
        key(DeliveryPurpose::WorkflowReply, "task:1", "b@example.com")
    );
    // Case-folded, so one recipient written two ways is one delivery rather than two.
    assert_eq!(
        base,
        key(DeliveryPurpose::WorkflowReply, "task:1", "A@Example.com")
    );

    // The composer type is the only thing that builds these in production; naming it here keeps
    // the import honest about that.
    let _: fn(
        std::sync::Arc<crate::transport::ports::TransportRenderers>,
        std::sync::Arc<dyn crate::application::ports::integration::ChannelBindingPersistence>,
    ) -> DeliveryComposer = DeliveryComposer::new;
}

/// One recording transport for one company's connected account, another for the deployment.
struct CompanyAccount {
    company_id: Uuid,
    company: Arc<RecordingTransport>,
    deployment: Arc<RecordingTransport>,
}

#[async_trait]
impl crate::adapters::protocols::email::mail::CompanyMailTransports for CompanyAccount {
    async fn transport_for(
        &self,
        company_id: Option<Uuid>,
    ) -> AppResult<Arc<dyn crate::adapters::protocols::email::mail::MailTransport>> {
        Ok(if company_id == Some(self.company_id) {
            self.company.clone()
        } else {
            self.deployment.clone()
        })
    }
}

/// fix-app 05 (FIXAPP-P05-G1-F2): every delivery now carries its company, but only a
/// channel-attributed delivery speaks through that company's connected account. A notice -- a
/// bounce, a decision notice -- belongs to the same company yet keeps leaving through the
/// deployment relay, from deployment addresses.
#[tokio::test]
async fn notification_delivery_tenant_notice_uses_the_deployment_relay() {
    let attributed = record();
    let accounts = Arc::new(CompanyAccount {
        company_id: attributed.company_id,
        company: Arc::new(RecordingTransport::default()),
        deployment: Arc::new(RecordingTransport::default()),
    });
    let sender = EmailSender::new(accounts.clone(), Arc::new(NeverInternal::default()));
    let parts = renderer()
        .render(&envelope(EmailDeliveryContext {
            relay: None,
            ..context("outsider@example.com")
        }))
        .unwrap();

    let notice = DeliveryRecord {
        attribution: None,
        external_destination: Some(crate::entities::transport::ExternalDestination::Email(
            "outsider@example.com".into(),
        )),
        purpose: DeliveryPurpose::Notification,
        ..attributed.clone()
    };
    assert_eq!(notice.sending_company(), None);
    assert!(matches!(
        sender.send(&notice, &parts[0]).await,
        ProviderSendOutcome::Delivered { .. }
    ));
    assert_eq!(accounts.deployment.sent().len(), 1);
    assert_eq!(accounts.company.sent().len(), 0);

    assert_eq!(attributed.sending_company(), Some(attributed.company_id));
    assert!(matches!(
        sender.send(&attributed, &parts[0]).await,
        ProviderSendOutcome::Delivered { .. }
    ));
    assert_eq!(accounts.company.sent().len(), 1);
}

#[test]
fn frozen_correlation_reads_the_payload_even_with_a_different_renderer_domain() {
    let original = renderer();
    let rendered = original
        .render(&envelope(context("customer@example.com")))
        .unwrap();
    let part = &rendered[0];
    let wire = frozen(&rendered);
    let after_rotation = EmailRenderer::new("new-domain.example");
    let correlation = after_rotation.rendered_correlation(part).unwrap();
    assert_eq!(
        correlation.provider_key.as_ref().unwrap().as_str(),
        wire.message_id.as_str()
    );
    let metadata = correlation.extension.email_metadata().unwrap();
    assert_eq!(metadata.rfc_message_id, wire.message_id);
    assert_eq!(metadata.in_reply_to, wire.in_reply_to);
    assert_eq!(metadata.references, wire.references);
    assert_eq!(metadata.references.last(), metadata.in_reply_to.as_ref());
}
#[test]
fn application_message_keys_are_owned_by_email_egress_and_qualified_by_company() {
    let nonce = Uuid::new_v4();
    let first = renderer()
        .application_message_key(&CompanySlug::from("acme"), nonce)
        .unwrap();
    assert_eq!(first.as_str(), format!("<{nonce}@acme.{DOMAIN}>"));
    assert_ne!(
        first,
        renderer()
            .application_message_key(&CompanySlug::from("other"), nonce)
            .unwrap()
    );
}
