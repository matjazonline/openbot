//! `address_resolution_`: an addressed local part resolves through the company's one address
//! namespace to a desk, a principal, a system address or nothing; a principal takes no message yet.
use super::*;
use crate::application::ports::channel::ChannelUpdate;
use crate::entities::address::{AddressTarget, ResolvedAddress};
use crate::entities::transport::PrincipalId;

/// The fixture's desks, plus principal addresses at these slugs in its company.
struct NamespaceChannels {
    desks: Arc<dyn ChannelPersistence>,
    principals: Vec<(Uuid, ChannelSlug)>,
}

#[async_trait]
impl ChannelPersistence for NamespaceChannels {
    async fn create(&self, company_id: Uuid, write: ChannelWrite) -> AppResult<Channel> {
        self.desks.create(company_id, write).await
    }

    async fn get_by_id(&self, id: Uuid) -> AppResult<Option<Channel>> {
        self.desks.get_by_id(id).await
    }

    async fn get_by_company_slug_and_channel_slug(
        &self,
        company_slug: &CompanySlug,
        channel_slug: &ChannelSlug,
    ) -> AppResult<Option<Channel>> {
        self.desks
            .get_by_company_slug_and_channel_slug(company_slug, channel_slug)
            .await
    }

    async fn list_by_company_id(&self, company_id: Uuid) -> AppResult<Vec<Channel>> {
        self.desks.list_by_company_id(company_id).await
    }

    async fn address_targets(
        &self,
        company_id: Uuid,
        slugs: &[ChannelSlug],
    ) -> AppResult<Vec<ResolvedAddress>> {
        let mut resolved = self.desks.address_targets(company_id, slugs).await?;
        resolved.extend(
            self.principals
                .iter()
                .filter(|(company, slug)| {
                    *company == company_id && slugs.iter().any(|named| named == slug)
                })
                .map(|(_, slug)| ResolvedAddress {
                    slug: slug.clone(),
                    target: AddressTarget::Principal(PrincipalId::random()),
                }),
        );
        Ok(resolved)
    }

    async fn list_departments(
        &self,
        company_id: Uuid,
    ) -> AppResult<Vec<crate::entities::department::Department>> {
        self.desks.list_departments(company_id).await
    }

    async fn update(&self, request: ChannelUpdate) -> AppResult<Channel> {
        self.desks.update(request).await
    }

    async fn delete(&self, id: Uuid) -> AppResult<()> {
        self.desks.delete(id).await
    }
}

/// The plain `support` desk fixture, with a person at `alice` in the same company.
fn fixture() -> ChannelFixture {
    let mut fixture = channel_fixture(TestChannel::default());
    let channels = Arc::new(NamespaceChannels {
        desks: fixture.use_cases.channel_persistence.clone(),
        principals: vec![(fixture.company_id, ChannelSlug::from("alice"))],
    });
    fixture.use_cases = ThreadUseCases::for_test(
        fixture.threads.clone(),
        channels,
        fixture.use_cases.company_persistence.clone(),
        fixture.participants.clone(),
        internal_test_settings(),
    );
    fixture
}

async fn ingest(fixture: &ChannelFixture, from: &str, to: &str) -> InboundIngestResult {
    fixture
        .use_cases
        .ingest_test_email(RawInboundPayload {
            to: to.into(),
            from: from.into(),
            subject: Some("Hello".into()),
            text: Some("Hello there".into()),
            ..Default::default()
        })
        .await
        .unwrap()
}

const TEAM: &str = "team@acme.com";
const OUTSIDER: &str = "stranger@elsewhere.test";

#[tokio::test]
async fn address_resolution_a_desk_is_admitted_and_a_person_is_refused_for_a_teammate() {
    let fixture = fixture();
    let desk = ingest(&fixture, TEAM, "support@acme.mailagents.com").await;
    assert!(desk.accepted, "{:?}", desk.reason());

    let person = ingest(&fixture, TEAM, "alice@acme.mailagents.com").await;
    assert!(!person.accepted);
    assert_eq!(
        person.reason(),
        Some("Direct messages to people and agents are not delivered yet")
    );
    let bounce = person.bounce_info().unwrap();
    assert!(bounce.invalid_slugs.is_empty());
    assert_eq!(
        bounce.principals,
        [PrincipalBounce {
            slug: "alice".into(),
            refusal: PrincipalRefusal::NotYetDeliverable,
        }]
    );
    let body = format_bounce_email_body(bounce, "mailagents.com");
    assert!(body.contains("direct messages to people and agents are not delivered yet"));
    assert!(body.contains("Person or agent: 'alice@acme.mailagents.com'"));
}

#[tokio::test]
async fn address_resolution_a_context_suffix_strips_for_a_desk_and_is_refused_for_a_person() {
    let fixture = fixture();
    let desk = ingest(&fixture, TEAM, "support+quiet@acme.mailagents.com").await;
    assert!(desk.accepted, "{:?}", desk.reason());

    let person = ingest(&fixture, TEAM, "alice+quiet@acme.mailagents.com").await;
    assert!(!person.accepted);
    assert_eq!(
        person.reason(),
        Some("A context suffix is not accepted on a person's or an agent's address")
    );
    assert_eq!(
        person.bounce_info().unwrap().principals[0].refusal,
        PrincipalRefusal::ContextSuffix
    );
}

#[tokio::test]
async fn address_resolution_a_desk_and_a_person_together_are_refused_whole() {
    let fixture = fixture();
    let before = fixture.durable_counts();
    let mixed = ingest(&fixture, TEAM, "support+alice@acme.mailagents.com").await;
    assert!(!mixed.accepted);
    assert_eq!(
        mixed.reason(),
        Some("Direct messages to people and agents are not delivered yet")
    );
    assert_eq!(
        fixture.durable_counts(),
        before,
        "nothing of the message is stored"
    );
}

#[tokio::test]
async fn address_resolution_a_stranger_cannot_tell_a_person_from_nobody() {
    let fixture = fixture();
    for to in ["alice", "alice+quiet", "support+alice"] {
        let person = ingest(&fixture, OUTSIDER, &format!("{to}@acme.mailagents.com")).await;
        let nobody = ingest(
            &fixture,
            OUTSIDER,
            &format!("{}@acme.mailagents.com", to.replace("alice", "nobody")),
        )
        .await;
        // Same kind, sentence, suggestions and bounce; only the slug the stranger typed and the
        // per-message key differ.
        let key = person.bounce_info().unwrap().source_message_key.clone();
        assert_eq!(
            person.rejection,
            nobody
                .rejection
                .as_ref()
                .map(|rejection| rejection_with_slug(rejection, "nobody", "alice", &key)),
            "{to}"
        );
        let person_bounce = person.bounce_info().unwrap();
        assert!(person_bounce.principals.is_empty(), "{to}");
        assert_eq!(
            format_bounce_email_body(person_bounce, "mailagents.com"),
            format_bounce_email_body(nobody.bounce_info().unwrap(), "mailagents.com")
                .replace("nobody", "alice"),
            "{to}"
        );
    }
}

/// A rejection with every occurrence of one typed slug swapped for another, under `key`.
fn rejection_with_slug(
    rejection: &IngestRejection,
    from: &str,
    to: &str,
    key: &ExternalMessageKey,
) -> IngestRejection {
    let mut rejection = rejection.clone();
    if let IngestRejection::Undeliverable(reason) = &mut rejection {
        reason.bounce.source_message_key = key.clone();
        let swap = |slug: &mut ChannelSlug| {
            if slug.as_str() == from {
                *slug = to.into();
            }
        };
        reason.bounce.invalid_slugs.iter_mut().for_each(swap);
        for suggestion in &mut reason.bounce.suggestions {
            swap(&mut suggestion.invalid_slug);
        }
    }
    rejection
}

#[tokio::test]
async fn address_resolution_an_internal_relay_to_a_person_is_refused_definitely() {
    let fixture = fixture();
    let disposition = relay_to(&fixture, "alice").await;
    assert!(
        matches!(
            &disposition,
            crate::transport::RelayDisposition::Refused(reason)
                if reason == "Direct messages to people and agents are not delivered yet"
        ),
        "{disposition:?}"
    );
}

/// One internal hop from the fixture's `support` desk to `{slug}` in the same company.
async fn relay_to(fixture: &ChannelFixture, slug: &str) -> crate::transport::RelayDisposition {
    let hop = InternalHop::new(
        fixture.channel_id,
        "support@acme.mailagents.com",
        &format!("{slug}@acme.mailagents.com"),
        "Hand-off",
        "Please take this",
    );
    relay_hop(&fixture.use_cases, &hop).await
}
