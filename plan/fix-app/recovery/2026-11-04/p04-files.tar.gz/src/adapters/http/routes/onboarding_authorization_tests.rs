use super::super::authorization_test_support::{Fixture, ScopeCase, denied};
use super::*;

#[tokio::test]
async fn onboarding_page_hides_foreign_companies_and_refuses_members() {
    let Some(f) = Fixture::new().await else {
        return;
    };
    for ScopeCase {
        companies,
        user,
        company_id: id,
        status,
        ..
    } in f.denial_cases()
    {
        denied(
            channel_step(
                State(companies),
                State(f.agents.clone()),
                State(f.users.clone()),
                State(f.config.clone()),
                Fixture::auth(user),
                Path(id),
            )
            .await,
            status,
            &f.foreign.name,
        )
        .await;
    }
}
