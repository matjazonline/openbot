use super::super::authorization_test_support::{Fixture, denied};
use super::*;
use axum::http::StatusCode;

fn workspace(f: &Fixture, user: Uuid) -> Workspace {
    Workspace {
        company_use_cases: f.companies.clone(),
        invite_use_cases: f.invites.clone(),
        user_use_cases: f.users.clone(),
        config: f.config.clone(),
        user_id: user,
    }
}

#[tokio::test]
async fn team_roles_come_from_membership_and_nonowners_get_forbidden() {
    let Some(f) = Fixture::new().await else {
        return;
    };
    denied(
        invite_form_pane(workspace(&f, f.owner.id), Path(f.foreign.id)).await,
        StatusCode::NOT_FOUND,
        &f.foreign.name,
    )
    .await;
    denied(
        invite_form_pane(workspace(&f, f.member.id), Path(f.company.id)).await,
        StatusCode::FORBIDDEN,
        &f.company.name,
    )
    .await;
    let access = f
        .companies
        .readable_company(f.member.id, f.company.id)
        .await
        .unwrap();
    let ws = workspace(&f, f.member.id);
    assert!(matches!(ws.view(&access).role(), TeamRole::Member));
    let mut authoritative = access.clone();
    authoritative.company.user_id = f.member.id;
    assert!(
        matches!(ws.view(&authoritative).role(), TeamRole::Member),
        "display owner id cannot elevate membership"
    );
    assert!(
        close_pane(ws, Path(f.company.id)).await.is_ok(),
        "members can read the team"
    );
}
