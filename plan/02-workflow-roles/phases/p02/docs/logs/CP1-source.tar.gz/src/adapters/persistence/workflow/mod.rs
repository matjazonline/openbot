//! PostgreSQL is the sole owner of workflow authoring and runtime records.
//!
//! Authorized controls acquire company authority before the run.
//! Runtime transitions lock the run before its executions, jobs/attempts, waits
//! and events. Discovery reads grant no authority. Reacquiring an already-owned
//! run is safe. A parent's park or round transition creates its child run in its own
//! transaction (07-D1 §D1.2), and a cancel cascade locks parent then child, never the
//! reverse. Child terminal transitions append a child-owned wakeup fact; parent
//! consumption must use a separate transaction.
//! Foreign-key checks count as locks too: never insert a parent reference while
//! completing the child. Parent linkage is immutable and established at creation.
mod action_authority;
pub mod action_dispatch;
mod action_receipts;
pub mod action_reconciliation;
mod action_uncertainty;
mod actions;
mod activation;
mod admission;
mod admission_binding;
mod admission_history;
mod admission_replay;
mod admission_source;
mod admission_write;
mod agent_authority;
mod agent_history;
mod agent_history_sessions;
pub(crate) mod agent_history_views;
mod agent_manifest;
mod agent_origin;
mod agent_preparation;
pub mod agent_publication;
pub(super) mod association;
mod authoring_reads;
pub(crate) mod authority;
mod batch;
mod batch_commit;
mod binding_rows;
mod bindings;
mod board_reads;
mod budget;
mod bundle_store;
mod capacity;
mod channel_question_replies;
mod channel_reply;
mod channel_reply_approvals;
mod channel_reply_binding_authority;
mod channel_reply_completion;
mod channel_reply_delivery;
mod channel_reply_proposals;
mod channel_reply_publication;
mod channel_reply_publish;
mod channel_reply_publish_authority;
mod channel_reply_publish_plan;
mod channel_reply_publish_read;
mod channel_reply_refusal;
mod channel_reply_resume;
pub(crate) mod channel_reply_views;
mod checkpoints;
pub mod child_publication;
mod child_waits;
mod children;
mod completion;
mod completion_job;
mod decisions;
mod definitions;
mod fair_polling;
mod fairness;
mod guard_failure;
mod history_reader;
pub mod http;
pub mod jev;
mod jev_assets;
pub(crate) mod knowledge;
mod knowledge_release;
mod lease;
mod lease_claim;
pub mod local_agents;
pub mod mcp;
mod memory_steps;
pub mod message;
mod message_intents;
mod metrics;
mod persistence_bound;
pub mod provisioning;
mod reads;
mod reply_waits;
mod resources;
pub(crate) mod role_binding;
mod role_views;
mod rows;
mod run_provenance;
mod run_views;
#[cfg(test)]
pub(crate) mod schedule_test_support;
mod schedules;
pub mod step_builtins;
#[cfg(test)]
mod tests;
/// The uncertain HTTP action the reconciliation route tests start from (P08-D3).
#[cfg(test)]
pub(crate) use tests::reconciliation_fixture;
pub mod tool_publication;
mod wait_commit;
mod waits;
mod wakeups;
mod workflow_tool_calls;
pub(in crate::adapters::persistence) mod workflow_tools;

use super::PostgresPersistence;
use crate::app_error::{AppError, AppResult};
use crate::application::workflow::{lifecycle::*, publication::*, templates::*, *};
use crate::domain::workflow::*;
use async_trait::async_trait;
use sqlx::{PgConnection, Postgres, Transaction};
use std::sync::Arc;
use uuid::Uuid;

/// The most continuations one workflow job may take, mirroring the SQL
/// `workflow_job_continuation_limit()` that the job guards and the CHECK use. A database test
/// asserts the two are equal. Every park that needs its job reopened refuses at this count.
pub(crate) const WORKFLOW_JOB_CONTINUATION_LIMIT: i16 = 63;

fn conflict() -> AppError {
    AppError::Conflict("Workflow lifecycle revision or command conflict".into())
}
fn missing() -> AppError {
    AppError::NotFound("Workflow resource".into())
}
fn invalid() -> AppError {
    AppError::Database("Invalid stored workflow record".into())
}
fn revision(value: u64) -> AppResult<i64> {
    i64::try_from(value).map_err(|_| conflict())
}
fn write_error(error: sqlx::Error) -> AppError {
    if error
        .as_database_error()
        .is_some_and(|error| error.is_unique_violation())
    {
        conflict()
    } else {
        error.into()
    }
}

mod polling;

mod recovery;

mod pending_recovery;

mod maintenance;

mod control_retry;
mod controls;
mod inspection;
mod message_outcomes;

mod token_budget;

mod jev_runtime;

#[cfg(test)]
mod agent_history_race_fixture;
mod agent_history_retention;
#[cfg(test)]
mod agent_history_retention_fixture;
mod storage;
mod storage_retention;

mod sample_capture;
pub use sample_capture::SampleCapture;

pub(crate) mod integration_authority;
