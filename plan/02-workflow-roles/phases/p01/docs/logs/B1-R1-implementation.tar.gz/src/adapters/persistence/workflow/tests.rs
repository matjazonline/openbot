use super::*;
#[path = "action_outcome_support.rs"]
mod action_outcome_support;
#[path = "admission_binding_tests.rs"]
mod admission_binding_tests;
#[path = "admission_tests.rs"]
mod admission_tests;
#[path = "approval_test_support.rs"]
mod approval_test_support;
#[path = "binding_association_tests.rs"]
mod binding_association_tests;
#[path = "binding_schema_tests.rs"]
mod binding_schema_tests;
#[path = "binding_tests.rs"]
mod binding_tests;
#[path = "child_publication_tests.rs"]
mod child_publication_tests;
#[path = "http_tests.rs"]
mod http_tests;
#[path = "jev_tests.rs"]
mod jev_tests;
#[path = "projection_test_support.rs"]
mod projection_test_support;
#[path = "role_binding_tests.rs"]
mod role_binding_tests;
pub(crate) use http_tests::reconciliation_fixture;
#[path = "local_agent_tests.rs"]
mod local_agent_tests;
#[path = "mcp_tests.rs"]
mod mcp_tests;
#[path = "message_tests.rs"]
mod message_tests;
#[path = "run_schema_tests.rs"]
mod run_schema_tests;
#[path = "schedule_tests.rs"]
mod schedule_tests;
use crate::adapters::persistence::test_support::{OwnDatabase, own_database};
use crate::adapters::workflow_source::WorkflowSourceDecoder;
use crate::application::use_cases::{
    company::{CompanyPersistence, CompanyWrite},
    user::UserPersistence,
};

/// Raw-schema fixtures explicitly own their root budget; SQL never decodes their bundle.
async fn seed_root_budget(
    db: &mut PgConnection,
    company: Uuid,
    run: Uuid,
) -> Result<(), sqlx::Error> {
    use crate::domain::workflow::{BudgetResource, RootBudgetLimits};
    let limits = RootBudgetLimits::default();
    sqlx::query("INSERT INTO workflow_root_budgets(company_id,root_run_id,activations,model_calls,repetitions) VALUES($1,$2,$3,$4,$5)")
        .bind(company).bind(run)
        .bind(limits.limit(BudgetResource::Activation) as i32)
        .bind(limits.limit(BudgetResource::ModelCall) as i32)
        .bind(limits.limit(BudgetResource::Repetition) as i32)
        .execute(&mut *db).await?;
    sqlx::query("INSERT INTO workflow_root_budget_usage(company_id,root_run_id) VALUES($1,$2)")
        .bind(company)
        .bind(run)
        .execute(db)
        .await?;
    Ok(())
}

/// The squashed init schema every fresh database applies (the only migration).
const INIT_SCHEMA: &str = include_str!("../../../../migrations/20260817000000_init_schema.sql");

/// The dollar-quoted body of public function `name` exactly as the init schema creates it,
/// which is the text PostgreSQL stores as `prosrc`. Catalog pins compare against this, so a
/// definition replaced outside the init schema shows up as a mismatch.
fn init_function_body(name: &str) -> &'static str {
    let start = INIT_SCHEMA
        .find(&format!("CREATE FUNCTION public.{name}("))
        .unwrap_or_else(|| panic!("the init schema defines {name}"));
    // Only this function's own statement: pg_dump opens the next object with a `-- Name:` header,
    // and a SQL-standard body has no dollar quote to find.
    let statement = &INIT_SCHEMA[start..];
    let statement = &statement[..statement.find("\n--\n-- Name: ").unwrap_or(statement.len())];
    let quoted = statement
        .find(" AS $")
        .unwrap_or_else(|| panic!("{name} has no dollar-quoted body in the init schema"));
    let quoted = &statement[quoted + 4..];
    let tag = &quoted[..quoted[1..].find('$').expect("a closed dollar tag") + 2];
    let body = &quoted[tag.len()..];
    &body[..body.find(tag).expect("the body's closing tag")]
}

/// S-F002: a SQL-standard body has no dollar quote; the helper names the function rather than
/// reading on into the next one.
#[test]
#[should_panic(expected = "valid_creation_provenance has no dollar-quoted body")]
fn init_function_body_refuses_a_function_without_a_dollar_quoted_body() {
    init_function_body("valid_creation_provenance");
}

// Deliberately permissive preflight: these tests prove the SQL owner performs
// current authorization itself rather than trusting the service's earlier read.
#[derive(Clone)]
struct Preflight;
#[async_trait]
impl WorkflowAuthorization for Preflight {
    async fn authorize(
        &self,
        _: CompanyId,
        _: WorkflowActor,
        _: RelatedAssociation,
        _: WorkflowOperation,
    ) -> AppResult<()> {
        Ok(())
    }
}
#[async_trait]
impl PublicationDirectory for Preflight {
    async fn capture(
        &self,
        _: WorkflowActor,
        _: &CompanyWorkflowDraft,
    ) -> AppResult<PublicationDependencies> {
        Ok(PublicationDependencies {
            snapshots: DependencySnapshots::default(),
            children: vec![],
        })
    }
}
/// Publication captures pinned children like every production composition must (WF-C001).
type Service = DefinitionService<
    Preflight,
    PostgresPersistence,
    WorkflowSourceDecoder,
    child_publication::ChildPublicationDirectory<Preflight>,
>;
struct Fixture {
    _db: Arc<OwnDatabase>,
    persistence: PostgresPersistence,
    target: DefinitionTarget,
}
/// Record a run-scoped event with the old boolean answer: stored or an identical duplicate is
/// `true`; unmatched ingress or a conflicting id reuse is `false`; invalid input is an error.
async fn recorded(
    p: &PostgresPersistence,
    event: crate::application::workflow::waits::WorkflowEvent,
) -> AppResult<bool> {
    use crate::application::workflow::waits::{EventIngress, WorkflowWaits};
    match p.record_event(event).await {
        Ok(EventIngress::Recorded | EventIngress::Duplicate) => Ok(true),
        Ok(EventIngress::Unmatched) | Err(AppError::Conflict(_)) => Ok(false),
        Err(error) => Err(error),
    }
}

impl Fixture {
    async fn publish_agent(
        &self,
        agent: Uuid,
    ) -> crate::application::agent::PublishedAgentRevision {
        self.try_publish_agent(agent).await.unwrap()
    }

    async fn try_publish_agent(
        &self,
        agent: Uuid,
    ) -> AppResult<crate::application::agent::PublishedAgentRevision> {
        use crate::application::agent::{
            AgentPublicationKey, AgentPublicationScope, AgentPublications, PublishAgent,
        };
        let scope = AgentPublicationScope {
            company: self.target.company,
            actor: self.target.actor,
            agent: crate::entities::agent_capability::AgentId::new(agent),
        };
        let preview = AgentPublications::preview_agent(&self.persistence, scope).await?;
        AgentPublications::publish_agent(
            &self.persistence,
            PublishAgent {
                scope,
                expected_draft_revision: preview.draft_revision,
                expected_active_revision: preview.active_revision,
                key: AgentPublicationKey::parse(format!(
                    "fixture:{}:{}:{}",
                    agent,
                    preview.draft_revision.get(),
                    preview
                        .active_revision
                        .map(|id| id.as_uuid().to_string())
                        .unwrap_or_else(|| "initial".into())
                ))
                .unwrap(),
            },
        )
        .await
    }

    async fn new() -> Self {
        let db = Arc::new(
            own_database()
                .await
                .expect("workflow SQL tests require a database"),
        );
        Self::in_database(db, "").await
    }
    async fn in_database(db: Arc<OwnDatabase>, suffix: &str) -> Self {
        // Runtime fault tests in this fixture rewrite frozen run data to simulate
        // expiry and corruption. The strict guard is verified in its own test.
        sqlx::query("ALTER TABLE workflow_runs DISABLE TRIGGER workflow_run_snapshot_immutable")
            .execute(&db.pool)
            .await
            .unwrap();
        let persistence = PostgresPersistence::new(db.pool.clone());
        let email = format!("workflow{suffix}@example.test");
        persistence
            .create_user(&format!("workflow_owner{suffix}"), &email, "hash")
            .await
            .unwrap();
        let user = persistence.get_by_email(&email).await.unwrap().unwrap();
        let company = CompanyPersistence::create(
            &persistence,
            user.id,
            CompanyWrite {
                name: "Workflow tests".into(),
                slug: format!("workflow-tests{suffix}"),
                ..Default::default()
            },
        )
        .await
        .unwrap();
        Self {
            _db: db,
            persistence,
            target: DefinitionTarget {
                company: CompanyId::new(company.id),
                actor: WorkflowActor::authenticated(user.id).unwrap(),
                workflow: WorkflowId::new(Uuid::from_u128(1)),
            },
        }
    }
    fn service(&self) -> Service {
        DefinitionService::new(
            Preflight,
            self.persistence.clone(),
            WorkflowSourceDecoder,
            child_publication::ChildPublicationDirectory {
                persistence: self.persistence.clone(),
                inner: Preflight,
            },
        )
    }
    /// Save and publish `source` as `workflow` (its `workflow_id` is overwritten), returning the
    /// published version; used to pin children below the fixture's own workflow.
    async fn publish_workflow(
        &self,
        workflow: WorkflowId,
        mut source: serde_json::Value,
    ) -> VersionId {
        source["workflow_id"] = serde_json::json!(workflow.to_string());
        let version = VersionId::new(Uuid::new_v4());
        self.publish_source(&self.service(), workflow, source.to_string(), version)
            .await
            .unwrap();
        version
    }
    /// Save `source` as the first draft of `workflow` and publish it as `version` through
    /// `service`, whose directory decides which dependencies the draft captures.
    async fn publish_source<C: PublicationDirectory>(
        &self,
        service: &DefinitionService<Preflight, PostgresPersistence, WorkflowSourceDecoder, C>,
        workflow: WorkflowId,
        source: String,
        version: VersionId,
    ) -> LifecycleResult<Arc<PublishedBundle>> {
        let target = DefinitionTarget {
            workflow,
            ..self.target
        };
        let mut draft = self.save(None);
        draft.target = target;
        draft.content.source = source;
        service.save(draft).await?;
        let mut publication = self.publish();
        publication.target = target;
        publication.version = version;
        publication.key =
            IdempotencyKey::parse(format!("publication-{}", workflow.as_uuid().simple())).unwrap();
        service.publish(publication).await
    }
    fn save(&self, expected: Option<DraftRevision>) -> SaveDraft {
        SaveDraft {
            target: self.target,
            expected,
            content: DraftContent {
                title: "Workflow".into(),
                description: "Description".into(),
                source: registry::example("data.map").unwrap().source,
            },
        }
    }
    fn publish(&self) -> PublishDraft {
        PublishDraft {
            target: self.target,
            expected: DraftRevision::new(1).unwrap(),
            version: VersionId::new(Uuid::new_v4()),
            key: IdempotencyKey::parse("publication").unwrap(),
        }
    }
}

#[tokio::test]
async fn workflow_sql_competing_edits_and_publication_replay() {
    let fixture = Fixture::new().await;
    let service = fixture.service();
    service.save(fixture.save(None)).await.unwrap();
    let publication = fixture.publish();
    let (first, second) = tokio::join!(
        service.publish(publication.clone()),
        service.publish(publication.clone())
    );
    let hash = first.unwrap().content_hash().as_str().to_owned();
    assert_eq!(second.unwrap().content_hash().as_str(), hash);
    let expected = DraftRevision::new(1).unwrap();
    let (first, second) = tokio::join!(
        service.save(fixture.save(Some(expected))),
        service.save(fixture.save(Some(expected)))
    );
    assert_eq!(usize::from(first.is_ok()) + usize::from(second.is_ok()), 1);
    service
        .archive(fixture.target, DraftRevision::new(2).unwrap())
        .await
        .unwrap();
    assert_eq!(
        service
            .publish(publication.clone())
            .await
            .unwrap()
            .content_hash()
            .as_str(),
        hash
    );
    assert!(
        fixture
            .persistence
            .selectable_version(fixture.target.company, publication.version)
            .await
            .unwrap()
            .is_none()
    );
    let count: i64 = sqlx::query_scalar(
        "SELECT count(*) FROM workflow_definition_events WHERE event_kind = 'published'",
    )
    .fetch_one(fixture.persistence.pool())
    .await
    .unwrap();
    assert_eq!(count, 1);
}

#[tokio::test]
async fn workflow_sql_revocation_and_failed_final_statement_roll_back() {
    let fixture = Fixture::new().await;
    let service = fixture.service();
    sqlx::query(
        "ALTER TABLE workflow_definition_events ADD CONSTRAINT reject_test_event CHECK (false)",
    )
    .execute(fixture.persistence.pool())
    .await
    .unwrap();
    assert!(service.save(fixture.save(None)).await.is_err());
    assert!(
        fixture
            .persistence
            .draft(fixture.target.company, fixture.target.workflow)
            .await
            .unwrap()
            .is_none()
    );
    sqlx::query("ALTER TABLE workflow_definition_events DROP CONSTRAINT reject_test_event")
        .execute(fixture.persistence.pool())
        .await
        .unwrap();
    service.save(fixture.save(None)).await.unwrap();
    let mut revocation = fixture.persistence.pool().begin().await.unwrap();
    crate::adapters::persistence::test_support::revoke_membership(
        &mut revocation,
        fixture.target.company.as_uuid(),
        fixture.target.actor.user_id(),
    )
    .await;
    let (published, ()) = tokio::join!(service.publish(fixture.publish()), async {
        crate::adapters::persistence::test_support::wait_until_a_backend_is_blocked(
            fixture.persistence.pool(),
        )
        .await;
        revocation.commit().await.unwrap();
    });
    assert!(published.is_err());
    let count: i64 = sqlx::query_scalar("SELECT count(*) FROM workflow_versions")
        .fetch_one(fixture.persistence.pool())
        .await
        .unwrap();
    assert_eq!(count, 0);
}

#[tokio::test]
async fn workflow_sql_publish_archive_compete_and_publication_audit_failure_rolls_back() {
    let fixture = Fixture::new().await;
    let service = fixture.service();
    service.save(fixture.save(None)).await.unwrap();
    sqlx::query("ALTER TABLE workflow_definition_events ADD CONSTRAINT reject_publication CHECK (event_kind <> 'published')")
        .execute(fixture.persistence.pool()).await.unwrap();
    let request = fixture.publish();
    assert!(service.publish(request.clone()).await.is_err());
    assert!(
        fixture
            .persistence
            .publication(fixture.target.company, &request.key)
            .await
            .unwrap()
            .is_none()
    );
    sqlx::query("ALTER TABLE workflow_definition_events DROP CONSTRAINT reject_publication")
        .execute(fixture.persistence.pool())
        .await
        .unwrap();
    let mut blocker = fixture.persistence.pool().begin().await.unwrap();
    sqlx::query("SELECT id FROM companies WHERE id = $1 FOR UPDATE")
        .bind(fixture.target.company.as_uuid())
        .execute(&mut *blocker)
        .await
        .unwrap();
    let (published, archived, ()) = tokio::join!(
        service.publish(request.clone()),
        service.archive(fixture.target, DraftRevision::new(1).unwrap()),
        async {
            crate::adapters::persistence::test_support::wait_until_backends_are_blocked(
                fixture.persistence.pool(),
                2,
            )
            .await;
            blocker.commit().await.unwrap();
        }
    );
    archived.unwrap();
    let saved = fixture
        .persistence
        .publication(fixture.target.company, &request.key)
        .await
        .unwrap();
    assert_eq!(saved.is_some(), published.is_ok());
    assert!(
        fixture
            .persistence
            .selectable_version(fixture.target.company, request.version)
            .await
            .unwrap()
            .is_none()
    );
    assert!(
        service
            .publish(PublishDraft {
                key: IdempotencyKey::parse("after-archive").unwrap(),
                ..fixture.publish()
            })
            .await
            .is_err()
    );
}

#[tokio::test]
async fn workflow_sql_corrupt_source_fails_and_cross_company_version_is_rejected() {
    let fixture = Fixture::new().await;
    let service = fixture.service();
    service.save(fixture.save(None)).await.unwrap();
    let request = fixture.publish();
    service.publish(request.clone()).await.unwrap();
    let other = CompanyPersistence::create(
        &fixture.persistence,
        fixture.target.actor.user_id(),
        CompanyWrite {
            name: "Other".into(),
            slug: "other".into(),
            ..Default::default()
        },
    )
    .await
    .unwrap();
    let error = sqlx::query("INSERT INTO workflow_versions \
        (company_id, workflow_id, id, draft_revision, command_key, actor_id, title, description, source, bundle, content_hash, agent_ids) \
        SELECT $1, workflow_id, id, draft_revision, command_key, actor_id, title, description, source, bundle, content_hash, agent_ids \
        FROM workflow_versions WHERE company_id = $2")
        .bind(other.id).bind(fixture.target.company.as_uuid()).execute(fixture.persistence.pool()).await.unwrap_err();
    assert!(
        error
            .as_database_error()
            .unwrap()
            .is_foreign_key_violation()
    );
    let mut corruption = fixture.persistence.pool().begin().await.unwrap();
    sqlx::query("ALTER TABLE workflow_versions DISABLE TRIGGER workflow_version_immutable")
        .execute(&mut *corruption)
        .await
        .unwrap();
    sqlx::query(
        "UPDATE workflow_versions SET source = source || E'\\n# corrupt' WHERE company_id = $1",
    )
    .bind(fixture.target.company.as_uuid())
    .execute(&mut *corruption)
    .await
    .unwrap();
    sqlx::query("ALTER TABLE workflow_versions ENABLE TRIGGER workflow_version_immutable")
        .execute(&mut *corruption)
        .await
        .unwrap();
    corruption.commit().await.unwrap();
    assert!(
        fixture
            .persistence
            .publication(fixture.target.company, &request.key)
            .await
            .is_err()
    );
    assert!(
        fixture
            .persistence
            .selectable_version(fixture.target.company, request.version)
            .await
            .is_err()
    );
}

#[tokio::test]
async fn workflow_sql_template_provenance_roundtrips_and_replay_reauthorizes() {
    let mut fixture = Fixture::new().await;
    fixture.target.workflow = WorkflowId::new(Uuid::new_v4());
    let example = registry::example("data.map").unwrap();
    let catalogue = TemplateCatalogue::build(
        &[TemplateOffer {
            id: TemplateId::parse("example").unwrap(),
            revision: TemplateRevision::new(1).unwrap(),
            title: "Example",
            description: "Description",
            source: &example.source,
            facts: &example.facts,
            dependencies: &std::collections::BTreeMap::from([(
                WorkflowId::new(Uuid::from_u128(1)),
                std::collections::BTreeSet::new(),
            )]),
        }],
        &WorkflowSourceDecoder,
    )
    .unwrap();
    let copied = TemplateCopyService::new(
        Preflight,
        fixture.persistence.clone(),
        WorkflowSourceDecoder,
    )
    .copy(
        &catalogue,
        CopyTemplateRequest::new(
            fixture.target.company,
            fixture.target.actor,
            TemplateId::parse("example").unwrap(),
            TemplateRevision::new(1).unwrap(),
            fixture.target.workflow,
        )
        .unwrap(),
    )
    .await
    .unwrap();
    let service = fixture.service();
    let mut edit = fixture.save(Some(copied.revision()));
    edit.content.source = copied.source().into();
    service.save(edit).await.unwrap();
    let saved = fixture
        .persistence
        .draft(fixture.target.company, fixture.target.workflow)
        .await
        .unwrap()
        .unwrap();
    assert_eq!(saved.draft.origin(), copied.origin());
    let request = PublishDraft {
        expected: DraftRevision::new(2).unwrap(),
        ..fixture.publish()
    };
    service.publish(request.clone()).await.unwrap();
    let published = fixture
        .persistence
        .publication(fixture.target.company, &request.key)
        .await
        .unwrap()
        .unwrap();
    assert_eq!(published.draft.origin(), copied.origin());
    crate::adapters::persistence::test_support::revoke_membership_now(
        fixture.persistence.pool(),
        fixture.target.company.as_uuid(),
        fixture.target.actor.user_id(),
    )
    .await;
    assert!(service.publish(request).await.is_err());
}

/// The listener's channels for workflow runs (p08 D4.1), on a connection of the test's own
/// database, so every notification it hears is the test's own.
async fn run_listener(pool: &sqlx::PgPool) -> sqlx::postgres::PgListener {
    let mut listener = sqlx::postgres::PgListener::connect_with(pool)
        .await
        .unwrap();
    listener
        .listen_all(["workflow_run_changed", "thread_activity"])
        .await
        .unwrap();
    listener
}

/// The next notification as `(channel, payload)`, failing rather than hanging.
async fn next_notification(
    listener: &mut sqlx::postgres::PgListener,
) -> (String, serde_json::Value) {
    let notification = tokio::time::timeout(std::time::Duration::from_secs(10), listener.recv())
        .await
        .expect("a notification arrives")
        .unwrap();
    (
        notification.channel().to_string(),
        serde_json::from_str(notification.payload()).unwrap_or(serde_json::Value::Null),
    )
}

/// Publish a marker on both channels and expect it next on each: whatever the statements before
/// it did, they notified nothing. Notifications arrive in commit order.
async fn assert_silent_until_marker(
    pool: &sqlx::PgPool,
    listener: &mut sqlx::postgres::PgListener,
) {
    sqlx::query("SELECT pg_notify('workflow_run_changed', '\"marker\"'), pg_notify('thread_activity', '\"marker\"')")
        .execute(pool)
        .await
        .unwrap();
    let mut heard = vec![
        next_notification(listener).await,
        next_notification(listener).await,
    ];
    heard.sort_by(|left, right| left.0.cmp(&right.0));
    assert_eq!(
        heard,
        [
            ("thread_activity".to_string(), serde_json::json!("marker")),
            (
                "workflow_run_changed".to_string(),
                serde_json::json!("marker")
            ),
        ],
        "nothing was notified before the marker"
    );
}

#[path = "jev_runtime_tests.rs"]
mod jev_runtime_tests;

#[path = "jev_assets_tests.rs"]
mod jev_assets_tests;

#[path = "jev_end_to_end_tests.rs"]
mod jev_end_to_end_tests;

// Fault-injection fixtures already disable the run snapshot guard. Keep the
// shared blob immutable while replacing only this fixture run's reference.
async fn replace_run_bundle(pool: &sqlx::PgPool, run: Uuid, bytes: &[u8]) {
    let mut tx = pool.begin().await.unwrap();
    let company = sqlx::query_scalar("SELECT company_id FROM workflow_runs WHERE id=$1")
        .bind(run)
        .fetch_one(&mut *tx)
        .await
        .unwrap();
    let digest = bundle_store::insert_on(&mut tx, CompanyId::new(company), bytes)
        .await
        .unwrap();
    sqlx::query("UPDATE workflow_runs SET bundle_digest=$2 WHERE id=$1")
        .bind(run)
        .bind(digest.as_bytes())
        .execute(&mut *tx)
        .await
        .unwrap();
    tx.commit().await.unwrap();
}

async fn seed_version_bundle(
    db: &mut PgConnection,
    company: Uuid,
    version: Uuid,
) -> Result<(), sqlx::Error> {
    sqlx::query(
        "INSERT INTO workflow_bundles(company_id,digest,bundle)
        SELECT company_id,sha256(bundle),bundle FROM workflow_versions WHERE company_id=$1 AND id=$2
        ON CONFLICT(company_id,digest) DO UPDATE SET bundle=EXCLUDED.bundle WHERE false",
    )
    .bind(company)
    .bind(version)
    .execute(db)
    .await?;
    Ok(())
}
