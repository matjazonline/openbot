use super::{Diagnostic, ParsedWorkflow};
use crate::application::workflow::publication::{AgentUseMode, RoleReference};
use crate::application::workflow::registry::ModelStep;
use crate::domain::workflow::Binding;

pub(super) fn references(parsed: &ParsedWorkflow) -> Result<Vec<RoleReference>, Diagnostic> {
    let mut roles = Vec::new();
    for (step, definition) in &parsed.definition.steps {
        let Some(kind) = ModelStep::of(definition.step_type.as_str()) else {
            continue;
        };
        let Some(binding) = definition.inputs.get("role") else {
            continue;
        };
        let role = match binding {
            Binding::Literal(value) => value.as_str().and_then(|value| value.parse().ok()),
            _ => None,
        }
        .ok_or_else(|| {
            let path = format!("/steps/{step}/with/role");
            Diagnostic::at(
                "registry.role",
                "Choose a literal department role: lead or reviewer",
                &path,
                super::input_span(&parsed.locations, &path),
            )
        })?;
        roles.push(RoleReference {
            step: step.clone(),
            role,
            mode: if kind.uses_capabilities() {
                AgentUseMode::Tools
            } else {
                AgentUseMode::ModelOnly
            },
        });
    }
    Ok(roles)
}
