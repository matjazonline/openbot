//! Human decisions (05-D1 amended by D2–D4). Lock order, the controls' order:
//! company `FOR SHARE` → member ⋈ principal `FOR SHARE` → run `FOR UPDATE` → association rows
//! `FOR SHARE` → execution → job → wait → decision. Workers take the run first and read
//! authority without locks at park; submission rechecks it under the locks.
use super::*;
use crate::application::workflow::{
    activation::*,
    decisions::*,
    waits::{ParkedWorkflow, WaitFailureReason},
};
use chrono::{DateTime, Utc};
use serde_json::{Value, json};
use std::time::Duration;

#[async_trait]
impl WorkflowDecisions for PostgresPersistence {
    async fn park_decision(
        &self,
        scope: ActivationRequest,
        notices: &DecisionNotices,
    ) -> AppResult<Option<ParkedWorkflow>> {
        tokio::time::timeout(Duration::from_secs(2), async {
            let mut tx = self.pool.begin().await?;
            reviewer_accounts::prelock_business_on(&mut tx, scope).await?;
            let parked = Box::pin(park_on(&mut tx, scope, notices)).await?;
            tx.commit().await?;
            Ok(parked)
        })
        .await
        .map_err(|_| lease::timed_out())?
    }
    async fn submit_decision(&self, command: SubmitDecision) -> AppResult<DecisionSubmission> {
        tokio::time::timeout(Duration::from_secs(2), async {
            let mut tx = self.pool.begin().await?;
            let submitted =
                Box::pin(submit_on(&mut tx, &command, self.channel_reply_notices())).await?;
            tx.commit().await.map_err(closed_at_commit)?;
            Ok(submitted)
        })
        .await
        .map_err(|_| lease::timed_out())?
    }
    async fn add_decision_comment(
        &self,
        command: AddDecisionComment,
    ) -> AppResult<DecisionComment> {
        command.validate()?;
        tokio::time::timeout(Duration::from_secs(2), async {
            let mut tx = self.pool.begin().await?;
            let comment = comment_on(&mut tx, &command).await?;
            tx.commit().await?;
            Ok(comment)
        })
        .await
        .map_err(|_| lease::timed_out())?
    }
    async fn read_decision(
        &self,
        company: CompanyId,
        actor: WorkflowActor,
        decision: DecisionId,
    ) -> AppResult<DecisionView> {
        tokio::time::timeout(Duration::from_secs(2), async {
            let mut tx = self.pool.begin().await?;
            let view = read_on(&mut tx, company, actor, decision).await?;
            tx.commit().await?;
            Ok(view)
        })
        .await
        .map_err(|_| lease::timed_out())?
    }
}

/// The deferred wait guard refuses a settlement that crossed a deadline before commit.
fn closed_at_commit(error: sqlx::Error) -> AppError {
    if error
        .as_database_error()
        .and_then(|database| database.code())
        .is_some_and(|code| code == "23514")
    {
        return closed();
    }
    AppError::from(error)
}
fn closed() -> AppError {
    AppError::Conflict("Workflow decision is closed".into())
}
fn stale() -> AppError {
    AppError::Conflict("Workflow decision revision or artifact is stale".into())
}

/// An eligible reviewer, and whether they take decision email (P08-Q8).
pub(super) struct Reviewer {
    principal_id: Uuid,
    email: String,
    decision_email: bool,
}
#[derive(sqlx::FromRow)]
struct ReviewerRow {
    user_id: Uuid,
    principal_id: Uuid,
    email: String,
}
#[derive(sqlx::FromRow)]
pub(super) struct NoticeContext {
    company_id: Uuid,
    title: String,
    company_label: String,
    correlation_id: Uuid,
}

async fn park_on(
    tx: &mut Transaction<'_, Postgres>,
    scope: ActivationRequest,
    notices: &DecisionNotices,
) -> AppResult<Option<ParkedWorkflow>> {
    let Some(run) = waits::lock(tx, scope, waits::LockPurpose::BusinessPark).await? else {
        return Ok(None);
    };
    if let Some(wait) = waits::row(tx, scope, waits::WaitSelection::Decision).await? {
        return Ok(Some(ParkedWorkflow {
            wait: WaitId::new(wait.id),
            deadline: wait.deadline,
        }));
    }
    let now = waits::now(tx).await?;
    if !matches!(run.state.as_str(), "queued" | "running") || run.deadline <= now {
        return Ok(None);
    }
    let binding = admission_binding::read_saved_binding(
        tx,
        scope.company,
        WorkflowBindingId::new(run.binding_id),
        scope.run.as_uuid(),
    )
    .await?;
    let pending_recovery::Pending::Ready(activation) =
        pending_recovery::activate(tx, scope).await?
    else {
        return Ok(None);
    };
    if binding
        .bundle()
        .compiled()
        .graph()
        .definition()
        .steps
        .get(&activation.step)
        .is_none_or(|step| step.step_type.as_str() != "decision.human")
    {
        return Ok(None);
    }
    // An unparsable deadline, or one already past, never parks (05-D2 §4.2).
    let spec = match specification(binding.bundle(), &activation) {
        Ok(spec) if spec.deadline > now => spec,
        _ => {
            pending_recovery::settle(tx, scope, pending_recovery::PendingFailure::InvalidInput)
                .await?;
            return Ok(None);
        }
    };
    let deadline = spec.deadline.min(run.deadline);
    let decision = Uuid::new_v4();
    let preparation = ReviewerPreparation {
        scope,
        notices,
        activation: &activation,
        spec: &spec,
        decision,
        deadline,
    };
    let Some(reviewers) = Box::pin(prepare_reviewers_on(tx, preparation)).await? else {
        return unavailable(tx, scope).await;
    };
    // Boxing keeps the compound transactional park below the stock test-thread stack budget.
    Box::pin(write_park_on(
        tx,
        DecisionPark {
            scope,
            decision,
            deadline,
            proposal_digest: &spec.proposal_digest,
            reviewers,
        },
    ))
    .await
}

struct DecisionPark<'a> {
    scope: ActivationRequest,
    decision: Uuid,
    deadline: DateTime<Utc>,
    proposal_digest: &'a str,
    reviewers: PreparedReviewers,
}

async fn write_park_on(
    tx: &mut Transaction<'_, Postgres>,
    write: DecisionPark<'_>,
) -> AppResult<Option<ParkedWorkflow>> {
    let DecisionPark {
        scope,
        decision,
        deadline,
        proposal_digest,
        reviewers,
    } = write;
    let wait = Uuid::new_v4();
    let intent = json!({"version":1,"kind":"wait_registered","wait_id":wait,"run_id":scope.run.as_uuid(),"execution_id":scope.execution.as_uuid()});
    let deadline: DateTime<Utc> = sqlx::query_scalar("INSERT INTO workflow_waits(company_id,run_id,execution_id,id,reason,deadline,created_at,notification_intent) VALUES($1,$2,$3,$4,'decision',$5,clock_timestamp(),$6) RETURNING deadline")
        .bind(scope.company.as_uuid()).bind(scope.run.as_uuid()).bind(scope.execution.as_uuid()).bind(wait).bind(deadline).bind(intent).fetch_one(&mut **tx).await?;
    sqlx::query("INSERT INTO workflow_decisions(company_id,run_id,execution_id,id,wait_id,subject_kind,proposal_digest) VALUES($1,$2,$3,$4,$5,'business',$6)")
        .bind(scope.company.as_uuid()).bind(scope.run.as_uuid()).bind(scope.execution.as_uuid()).bind(decision).bind(wait).bind(proposal_digest).execute(&mut **tx).await?;
    match reviewers {
        PreparedReviewers::Follow => follow_reviewers::park_on(tx, scope, decision).await?,
        PreparedReviewers::Synchronous {
            reviewers,
            composed,
        } => {
            insert_reviewers(tx, scope.company, decision, &reviewers, &composed).await?;
        }
    }
    completion_job::finish(tx, scope, completion_job::CompletionOwner::Pure).await?;
    sqlx::query("UPDATE workflow_runs SET state='waiting',waiting_reason='decision' WHERE company_id=$1 AND id=$2")
        .bind(scope.company.as_uuid()).bind(scope.run.as_uuid()).execute(&mut **tx).await?;
    waits::audit(tx, scope, "decision_opened").await?;
    Ok(Some(ParkedWorkflow {
        wait: WaitId::new(wait),
        deadline,
    }))
}

enum PreparedReviewers {
    Follow,
    Synchronous {
        reviewers: Vec<Reviewer>,
        composed: Vec<Option<crate::transport::NewStandaloneDelivery>>,
    },
}

struct ReviewerPreparation<'a> {
    scope: ActivationRequest,
    notices: &'a DecisionNotices,
    activation: &'a ActivatedExecution,
    spec: &'a DecisionSpecification,
    decision: Uuid,
    deadline: DateTime<Utc>,
}

async fn prepare_reviewers_on(
    tx: &mut Transaction<'_, Postgres>,
    request: ReviewerPreparation<'_>,
) -> AppResult<Option<PreparedReviewers>> {
    let ReviewerPreparation {
        scope,
        notices,
        activation,
        spec,
        decision,
        deadline,
    } = request;
    if follow_reviewers::enabled(spec.reviewers_follow_role, &spec.reviewers) {
        return Ok(Some(PreparedReviewers::Follow));
    }
    let selected = match super::reviewer_resolution::resolve_on(tx, scope, &spec.reviewers).await {
        Ok(selected) => selected,
        Err(AppError::BadRequest(_) | AppError::WorkflowRole(_)) => {
            return Ok(None);
        }
        Err(error) => return Err(error),
    };
    let mut reviewers = Vec::with_capacity(selected.len());
    for principal in selected {
        match eligible_reviewer(tx, scope, principal).await? {
            Some(reviewer) => reviewers.push(reviewer),
            None => return Ok(None),
        }
    }
    let context: NoticeContext = sqlx::query_as("SELECT run.company_id,version.title,company.name AS company_label,run.correlation_id FROM workflow_runs AS run JOIN workflow_versions AS version ON version.company_id=run.company_id AND version.workflow_id=run.workflow_id AND version.id=run.version_id JOIN companies AS company ON company.id=run.company_id WHERE run.company_id=$1 AND run.id=$2")
        .bind(scope.company.as_uuid()).bind(scope.run.as_uuid()).fetch_one(&mut **tx).await?;
    let composed = match compose_notices(
        notices,
        &reviewers,
        &context,
        &activation.step,
        decision,
        deadline,
    ) {
        Ok(deliveries) => deliveries,
        Err(AppError::BadRequest(_)) => return Ok(None),
        Err(error) => return Err(error),
    };
    Ok(Some(PreparedReviewers::Synchronous {
        reviewers,
        composed,
    }))
}

pub(super) async fn insert_reviewers(
    tx: &mut PgConnection,
    company: CompanyId,
    decision: Uuid,
    reviewers: &[Reviewer],
    composed: &[Option<crate::transport::NewStandaloneDelivery>],
) -> AppResult<()> {
    for (ordinal, (reviewer, delivery)) in reviewers.iter().zip(composed.iter()).enumerate() {
        // The delivery first, then the immutable reviewer row that carries its id (05-D3 §3.1);
        // an opted-out reviewer's row records the opt-out instead, which the guard checks against
        // the preference row this transaction holds `FOR SHARE` (P08-D4 F076).
        let notice = match delivery {
            Some(delivery) => {
                let crate::transport::DeliveryCreation::Created(notice) =
                    crate::adapters::persistence::delivery::enqueue::insert_standalone_delivery_on(
                        tx, delivery,
                    )
                    .await?
                else {
                    return Err(invalid());
                };
                Some(notice.as_uuid())
            }
            None => None,
        };
        sqlx::query("INSERT INTO workflow_decision_reviewers(company_id,decision_id,ordinal,principal_id,notice_delivery_id,notice_opted_out) VALUES($1,$2,$3,$4,$5,$6)")
            .bind(company.as_uuid()).bind(decision).bind(i16::try_from(ordinal).map_err(|_| invalid())?).bind(reviewer.principal_id).bind(notice).bind(notice.is_none()).execute(&mut *tx).await?;
    }
    Ok(())
}

/// Compose all notices before writing anything, so deterministic errors settle without a park.
/// A reviewer who opted out of decision email gets none (P08-Q8): `None` in their place.
pub(super) fn compose_notices(
    notices: &DecisionNotices,
    reviewers: &[Reviewer],
    context: &NoticeContext,
    step: &StepId,
    decision: Uuid,
    deadline: DateTime<Utc>,
) -> AppResult<Vec<Option<crate::transport::NewStandaloneDelivery>>> {
    reviewers
        .iter()
        .map(|reviewer| {
            if !reviewer.decision_email {
                return Ok(None);
            }
            notices
                .compose(&DecisionNotice {
                    company: context.company_id,
                    decision,
                    principal: reviewer.principal_id,
                    recipient: reviewer.email.clone().into(),
                    correlation: context.correlation_id,
                    workflow_title: &context.title,
                    step,
                    company_label: &context.company_label,
                    deadline,
                })
                .map(Some)
        })
        .collect()
}

/// `decision.reviewer_unavailable`: the run fails unrouted, nothing parks (05-D2 §7.1).
async fn unavailable(
    tx: &mut Transaction<'_, Postgres>,
    scope: ActivationRequest,
) -> AppResult<Option<ParkedWorkflow>> {
    pending_recovery::settle(
        tx,
        scope,
        pending_recovery::PendingFailure::ReviewerUnavailable,
    )
    .await?;
    Ok(None)
}

/// Park-time assignment check, configuration validation without locks (05-D2 §9.3): a company
/// member's person principal who can see the run's association; owner or admin on a
/// channel-less run. Submission rechecks the same rules under the §8 locks.
///
/// The reviewer's decision-email preference is read `FOR SHARE` after the member and principal
/// (P08-Q8): an opt-out recorded on the reviewer row stays true until the park commits. No row
/// is the default, email on.
async fn eligible_reviewer(
    db: &mut PgConnection,
    scope: ActivationRequest,
    principal: Uuid,
) -> AppResult<Option<Reviewer>> {
    let Some(row) = eligible_reviewer_row(db, scope, principal).await? else {
        return Ok(None);
    };
    let decision_email: Option<bool> = sqlx::query_scalar("SELECT decision_email_enabled FROM user_notification_preferences WHERE user_id=$1 FOR SHARE")
        .bind(row.user_id).fetch_optional(&mut *db).await?;
    Ok(Some(Reviewer {
        principal_id: row.principal_id,
        email: row.email,
        decision_email: decision_email.unwrap_or(true),
    }))
}

async fn eligible_reviewer_row(
    db: &mut PgConnection,
    scope: ActivationRequest,
    principal: Uuid,
) -> AppResult<Option<ReviewerRow>> {
    Ok(sqlx::query_as("SELECT principal.user_id,principal.id AS principal_id,account.email::text AS email FROM principals AS principal \
        JOIN company_members AS member ON member.company_id=principal.company_id AND member.user_id=principal.user_id \
        JOIN users AS account ON account.id=principal.user_id \
        JOIN companies AS company ON company.id=principal.company_id \
        JOIN workflow_runs AS run ON run.company_id=principal.company_id AND run.id=$3 \
        LEFT JOIN channels AS channel ON channel.company_id=run.company_id AND channel.id=run.channel_id \
        WHERE principal.company_id=$1 AND principal.id=$2 AND principal.kind='person' \
          AND (company.user_id=principal.user_id \
            OR (run.channel_id IS NULL AND member.role IN ('owner','admin')) \
            OR (run.channel_id IS NOT NULL AND (channel.access_mode IN ('team','public') \
              OR EXISTS (SELECT 1 FROM channel_principal_grants AS access_grant WHERE access_grant.company_id=$1 \
                AND access_grant.channel_id=run.channel_id AND access_grant.principal_id=principal.id \
                AND account.email_verified_at IS NOT NULL AND access_grant.capability='view')))) \
          AND (run.thread_id IS NULL OR EXISTS (SELECT 1 FROM threads AS thread WHERE thread.company_id=$1 \
            AND thread.channel_id=run.channel_id AND thread.id=run.thread_id)) \
        ORDER BY principal.id LIMIT 1 FOR SHARE OF member, principal, account")
        .bind(scope.company.as_uuid()).bind(principal).bind(scope.run.as_uuid()).fetch_optional(db).await?)
}

#[derive(sqlx::FromRow)]
struct DecisionHead {
    run_id: Uuid,
    execution_id: Uuid,
    submitted_at: Option<DateTime<Utc>>,
}
#[derive(sqlx::FromRow)]
struct DecisionRow {
    reply_proposal_id: Option<Uuid>,
    subject_kind: String,
    choice: Option<String>,
    revision: i64,
    proposal_digest: String,
    submitted_by: Option<Uuid>,
    command_key: Option<String>,
    command_fingerprint: Option<String>,
}
#[derive(sqlx::FromRow)]
struct RunAssociation {
    channel_id: Option<Uuid>,
    thread_id: Option<Uuid>,
}

/// Locks, in the documented order, everything a decision command reads, and rechecks current
/// authority. Missing, foreign or inaccessible records are a non-disclosing `NotFound`.
struct Locked {
    scope: ActivationRequest,
    run: waits::WaitRun,
    reviewer: authority::ReviewerAuthority,
}
enum DecisionPurpose {
    Read,
    Comment,
    Submit,
}

async fn lock_decision(
    tx: &mut Transaction<'_, Postgres>,
    company: CompanyId,
    actor: WorkflowActor,
    decision: DecisionId,
    purpose: DecisionPurpose,
) -> AppResult<Locked> {
    sqlx::query("SELECT set_config('lock_timeout','1000ms',true),set_config('statement_timeout','1000ms',true)").execute(&mut **tx).await?;
    let head: DecisionHead = sqlx::query_as(
        "SELECT run_id,execution_id,submitted_at FROM workflow_decisions WHERE company_id=$1 AND id=$2",
    )
    .bind(company.as_uuid())
    .bind(decision.0)
    .fetch_optional(&mut **tx)
    .await?
    .ok_or_else(missing)?;
    let job: Uuid = sqlx::query_scalar(
        "SELECT id FROM background_tasks WHERE company_id=$1 AND workflow_execution_id=$2 ",
    )
    .bind(company.as_uuid())
    .bind(head.execution_id)
    .fetch_optional(&mut **tx)
    .await?
    .ok_or_else(missing)?;
    let scope = ActivationRequest {
        company,
        run: RunId::new(head.run_id),
        execution: ExecutionId::new(head.execution_id),
        job: WorkflowJobId(job),
    };
    if matches!(purpose, DecisionPurpose::Submit)
        && head.submitted_at.is_none()
        && channel_reply_completion::root_on(tx, scope)
            .await?
            .is_some()
    {
        action_authority::prelock_accounts_on(
            tx,
            crate::application::workflow::actions::ActionScope {
                company,
                run: scope.run,
                execution: scope.execution,
            },
            Some(actor),
        )
        .await?;
    } else {
        // Display, discussion and recorded replays depend only on the current viewer.
        // Historical actor/policy/reviewer mappings are not current authorization facts.
        let viewer: Option<Uuid> = sqlx::query_scalar("SELECT id FROM users WHERE id=$1 FOR SHARE")
            .bind(actor.user_id())
            .fetch_optional(&mut **tx)
            .await?;
        viewer.ok_or_else(missing)?;
    }
    let reviewer = authority::authorize_reviewer_on(tx, company, actor).await?;
    // Run → execution → job, as `waits::lock`, but whatever the job's state: a settled
    // decision still answers reads and replays.
    let run: waits::WaitRun = sqlx::query_as("SELECT binding_id,state,deadline,max_steps FROM workflow_runs WHERE company_id=$1 AND id=$2 FOR UPDATE")
        .bind(company.as_uuid()).bind(head.run_id).fetch_one(&mut **tx).await?;
    authorize_run_association(tx, scope, actor, &reviewer).await?;
    sqlx::query(
        "SELECT id FROM workflow_executions WHERE company_id=$1 AND run_id=$2 AND id=$3 FOR UPDATE",
    )
    .bind(company.as_uuid())
    .bind(head.run_id)
    .bind(head.execution_id)
    .execute(&mut **tx)
    .await?;
    sqlx::query("SELECT id FROM background_tasks WHERE company_id=$1 AND id=$2 FOR UPDATE")
        .bind(company.as_uuid())
        .bind(job)
        .execute(&mut **tx)
        .await?;
    Ok(Locked {
        scope,
        run,
        reviewer,
    })
}

async fn authorize_run_association(
    db: &mut PgConnection,
    scope: ActivationRequest,
    actor: WorkflowActor,
    reviewer: &authority::ReviewerAuthority,
) -> AppResult<()> {
    let association: RunAssociation = sqlx::query_as(
        "SELECT channel_id,thread_id FROM workflow_runs WHERE company_id=$1 AND id=$2",
    )
    .bind(scope.company.as_uuid())
    .bind(scope.run.as_uuid())
    .fetch_one(&mut *db)
    .await?;
    let association = match (association.channel_id, association.thread_id) {
        (None, _) => {
            if !reviewer.privileged {
                return Err(missing());
            }
            RelatedAssociation::Company
        }
        (Some(channel), None) => RelatedAssociation::Channel(RelatedChannelId::new(channel)),
        (Some(channel), Some(thread)) => RelatedAssociation::Thread {
            channel_id: RelatedChannelId::new(channel),
            thread_id: RelatedThreadId::new(thread),
        },
    };
    association::authorize_association(db, scope.company, actor, association).await?;
    Ok(())
}

async fn submit_on(
    tx: &mut Transaction<'_, Postgres>,
    command: &SubmitDecision,
    notices: Option<&DecisionNotices>,
) -> AppResult<DecisionSubmission> {
    let Locked {
        scope,
        run,
        reviewer,
    } = lock_decision(
        tx,
        command.company,
        command.actor,
        command.decision,
        DecisionPurpose::Submit,
    )
    .await?;
    let wait = decision_wait(tx, scope, command.decision).await?;
    let row: DecisionRow = sqlx::query_as("SELECT reply_proposal_id,subject_kind,choice,revision,proposal_digest,submitted_by,command_key,command_fingerprint FROM workflow_decisions WHERE company_id=$1 AND id=$2 FOR UPDATE")
        .bind(scope.company.as_uuid()).bind(command.decision.0).fetch_one(&mut **tx).await?;
    if matches!(
        row.subject_kind.as_str(),
        "action_approval" | "token_allowance"
    ) && !reviewer.privileged
    {
        return Err(missing());
    }
    let fingerprint = command.fingerprint()?;
    if row.submitted_by.is_some() {
        return if row.submitted_by == Some(reviewer.principal)
            && row.command_key.as_deref() == Some(command.command_key.as_str())
            && row.command_fingerprint.as_deref() == Some(fingerprint.as_str())
        {
            Ok(DecisionSubmission {
                disposition: DecisionDisposition::Replayed,
                revision: row.revision,
                successor: if row.subject_kind == "token_allowance"
                    || (row.subject_kind == "action_approval"
                        && row.choice.as_deref() == Some("approve"))
                {
                    None
                } else {
                    successor_of(tx, scope).await?
                },
            })
        } else {
            Err(closed())
        };
    }
    let now = waits::now(tx).await?;
    if wait.reason != "decision"
        || wait.state != "waiting"
        || run.state != "waiting"
        || wait.deadline <= now
        || run.deadline <= now
    {
        return Err(closed());
    }
    let listed: bool = sqlx::query_scalar("SELECT EXISTS(SELECT 1 FROM workflow_decision_reviewers WHERE company_id=$1 AND decision_id=$2 AND principal_id=$3)")
        .bind(scope.company.as_uuid()).bind(command.decision.0).bind(reviewer.principal).fetch_one(&mut **tx).await?;
    if !listed {
        return Err(missing());
    }
    if row.reply_proposal_id.is_some() {
        channel_reply_approvals::require_clearance_on(tx, scope, command.actor.user_id()).await?;
    }
    if command.expected_revision != row.revision || command.expected_artifact != row.proposal_digest
    {
        return Err(stale());
    }
    if row.subject_kind == "token_allowance" {
        return tokens::submit(tx, scope, reviewer.principal, command, &fingerprint).await;
    }
    if row.subject_kind == "action_approval" {
        return approvals::submit(tx, scope, reviewer.principal, command, &fingerprint).await;
    }
    // Box the business completion phase; approvals never activate or complete this step.
    Box::pin(submit_business_on(
        tx,
        scope,
        &run,
        reviewer.principal,
        command,
        &fingerprint,
        notices,
    ))
    .await
}

async fn submit_business_on(
    tx: &mut Transaction<'_, Postgres>,
    scope: ActivationRequest,
    run: &waits::WaitRun,
    principal: Uuid,
    command: &SubmitDecision,
    fingerprint: &str,
    notices: Option<&DecisionNotices>,
) -> AppResult<DecisionSubmission> {
    let binding = admission_binding::read_saved_binding(
        tx,
        scope.company,
        WorkflowBindingId::new(run.binding_id),
        scope.run.as_uuid(),
    )
    .await?;
    let activation = activation::activate_on(tx, scope)
        .await?
        .ok_or_else(invalid)?;
    // Invalid choice, data or feedback: `BadRequest`, the transaction rolls back and the
    // decision stays open (R5).
    let completion = prepare_submission(binding.bundle(), &activation, command)?;
    sqlx::query("UPDATE workflow_decisions SET submitted_at=clock_timestamp(),submitted_by=$3,command_key=$4,command_fingerprint=$5,choice=$6,feedback=$7,data=$8,revision=revision+1 WHERE company_id=$1 AND id=$2 AND submitted_at IS NULL")
        .bind(scope.company.as_uuid()).bind(command.decision.0).bind(principal).bind(command.command_key.as_str()).bind(fingerprint).bind(&command.choice).bind(&command.feedback).bind(&command.data).execute(&mut **tx).await?;
    let revision = command.expected_revision + 1;
    follow_reviewers::withdraw_on(tx, scope.company, command.decision.0, &[]).await?;
    waits::audit(tx, scope, "decision_submitted").await?;
    let max_steps = u64::try_from(run.max_steps).map_err(|_| invalid())?;
    if activation.ordinal > max_steps
        || (activation.ordinal >= max_steps
            && matches!(completion.target, TransitionTarget::Step(_)))
    {
        wait_commit::fail(tx, scope, WaitFailureReason::ActivationLimit).await?;
        return Ok(DecisionSubmission {
            disposition: DecisionDisposition::Applied,
            revision,
            successor: None,
        });
    }
    let source_wait: Uuid = sqlx::query_scalar("UPDATE workflow_waits SET state='completed',settled_at=clock_timestamp() WHERE company_id=$1 AND run_id=$2 AND execution_id=$3 AND state='waiting' RETURNING id")
        .bind(scope.company.as_uuid()).bind(scope.run.as_uuid()).bind(scope.execution.as_uuid()).fetch_one(&mut **tx).await?;
    sqlx::query("UPDATE workflow_runs SET state='running',waiting_reason=NULL WHERE company_id=$1 AND id=$2")
        .bind(scope.company.as_uuid()).bind(scope.run.as_uuid()).execute(&mut **tx).await?;
    let successor = Box::pin(batch_commit::complete(
        tx,
        scope,
        batch_commit::CompletedStep {
            activated: &activation,
            graph: binding.bundle().compiled().graph(),
        },
        &completion,
        run.max_steps,
        completion_job::CompletionOwner::Parked(WaitId::new(source_wait)),
        notices,
    ))
    .await?;
    let successor = match successor {
        batch_commit::CompletionProgress::Advanced(next) => next,
        batch_commit::CompletionProgress::Parked => None,
        batch_commit::CompletionProgress::Refused => successor_of(tx, scope).await?,
    };
    Ok(DecisionSubmission {
        disposition: DecisionDisposition::Applied,
        revision,
        successor,
    })
}

async fn successor_of(
    db: &mut PgConnection,
    scope: ActivationRequest,
) -> AppResult<Option<ActivationRequest>> {
    let next: Option<Option<Uuid>> = sqlx::query_scalar("SELECT successor_execution_id FROM workflow_executions WHERE company_id=$1 AND run_id=$2 AND id=$3")
        .bind(scope.company.as_uuid()).bind(scope.run.as_uuid()).bind(scope.execution.as_uuid()).fetch_optional(&mut *db).await?;
    let Some(Some(next)) = next else {
        return Ok(None);
    };
    let job: Uuid = sqlx::query_scalar(
        "SELECT id FROM background_tasks WHERE company_id=$1 AND workflow_execution_id=$2 ",
    )
    .bind(scope.company.as_uuid())
    .bind(next)
    .fetch_one(db)
    .await?;
    Ok(Some(ActivationRequest {
        execution: ExecutionId::new(next),
        job: WorkflowJobId(job),
        ..scope
    }))
}

async fn comment_on(
    tx: &mut Transaction<'_, Postgres>,
    command: &AddDecisionComment,
) -> AppResult<DecisionComment> {
    let Locked {
        scope, reviewer, ..
    } = lock_decision(
        tx,
        command.company,
        command.actor,
        command.decision,
        DecisionPurpose::Comment,
    )
    .await?;
    let saved: Option<(i64, String)> = sqlx::query_as("SELECT sequence,body FROM workflow_decision_comments WHERE company_id=$1 AND decision_id=$2 AND author_principal_id=$3 AND command_key=$4")
        .bind(scope.company.as_uuid()).bind(command.decision.0).bind(reviewer.principal).bind(command.command_key.as_str()).fetch_optional(&mut **tx).await?;
    if let Some((sequence, body)) = saved {
        return if body == command.body {
            Ok(DecisionComment {
                disposition: DecisionDisposition::Replayed,
                sequence,
            })
        } else {
            Err(AppError::Conflict(
                "Workflow decision comment key was reused".into(),
            ))
        };
    }
    let wait = decision_wait(tx, scope, command.decision).await?;
    if wait.state != "waiting" {
        return Err(closed());
    }
    let last: i64 = sqlx::query_scalar("SELECT COALESCE(MAX(sequence),0) FROM workflow_decision_comments WHERE company_id=$1 AND decision_id=$2")
        .bind(scope.company.as_uuid()).bind(command.decision.0).fetch_one(&mut **tx).await?;
    if last >= MAX_DECISION_COMMENTS {
        return Err(AppError::Conflict(
            "Workflow decision comment limit reached".into(),
        ));
    }
    sqlx::query("INSERT INTO workflow_decision_comments(company_id,decision_id,sequence,author_principal_id,command_key,body) VALUES($1,$2,$3,$4,$5,$6)")
        .bind(scope.company.as_uuid()).bind(command.decision.0).bind(last + 1).bind(reviewer.principal).bind(command.command_key.as_str()).bind(&command.body).execute(&mut **tx).await?;
    Ok(DecisionComment {
        disposition: DecisionDisposition::Applied,
        sequence: last + 1,
    })
}

mod read;
use read::read_on;

#[path = "decision_approvals.rs"]
pub(super) mod approvals;

async fn decision_wait(
    db: &mut PgConnection,
    scope: ActivationRequest,
    decision: DecisionId,
) -> AppResult<waits::WaitRow> {
    sqlx::query_as("SELECT wait.id,wait.deadline,wait.reason,wait.state,wait.event_name,wait.correlation,wait.failure_code FROM workflow_decisions AS decision JOIN workflow_waits AS wait ON wait.company_id=decision.company_id AND wait.id=decision.wait_id WHERE decision.company_id=$1 AND decision.run_id=$2 AND decision.execution_id=$3 AND decision.id=$4 FOR UPDATE OF wait")
        .bind(scope.company.as_uuid()).bind(scope.run.as_uuid()).bind(scope.execution.as_uuid()).bind(decision.0).fetch_optional(db).await?.ok_or_else(missing)
}

#[path = "decision_tokens.rs"]
pub(super) mod tokens;
