use super::*;
use crate::adapters::workflow_source::decode;
use crate::application::agent::{
    ActionEffect, ActionRecovery, AgentKey, ApprovedActionPolicy, ModelSettings,
};
use crate::domain::workflow::{ResourceName, RunId, RunMetadata, TypeName, WorkflowId};
use uuid::Uuid;

#[path = "capabilities_tests.rs"]
mod capabilities_tests;

#[path = "role_tests.rs"]
mod role_tests;

#[path = "../agent_tests.rs"]
mod agent_tests;

#[path = "diagnostic_tests.rs"]
mod diagnostic_tests;

fn company() -> CompanyId {
    CompanyId::new(Uuid::from_u128(100))
}
fn name(value: &str) -> TypeName {
    TypeName::parse(value).unwrap()
}
fn source(kind: &str) -> Value {
    serde_json::from_str(&registry::example(kind).unwrap().source).unwrap()
}
fn agent() -> AgentReference {
    AgentReference {
        agent_id: crate::entities::agent_capability::AgentId::new(Uuid::from_u128(1)),
        company_id: company(),
        key: AgentKey::parse("assistant").unwrap(),
        uses: vec![AgentReferenceUse {
            step: StepId::parse("start").unwrap(),
            mode: AgentUseMode::Tools,
        }],
    }
}

fn definition() -> crate::application::agent::ResolvedAgentDefinition {
    crate::application::agent::ResolvedAgentDefinition {
        company_id: company(),
        agent_id: agent().agent_id,
        key: agent().key,
        instructions: "Answer using the supplied context".into(),
        model: ModelSettings {
            provider: name("test"),
            model: "scripted".into(),
            max_output_tokens: 1000,
        },
        tools: vec![],
        skills: vec![],
    }
}

fn resolved(
    definition: crate::application::agent::ResolvedAgentDefinition,
) -> crate::app_error::AppResult<ResolvedAgent> {
    use crate::application::agent::PublishedAgentRevision;
    use crate::entities::agent_capability::{
        AgentDraftRevision, AgentRevisionId, DependencyManifestId,
    };
    let digest = definition.content_hash()?;
    ResolvedAgent::from_revision(
        DependencyManifestId::new(Uuid::from_u128(90)),
        PublishedAgentRevision {
            id: AgentRevisionId::new(Uuid::from_u128(91)),
            draft_revision: AgentDraftRevision::new(1).unwrap(),
            definition,
            digest,
        },
    )
}
fn snapshots() -> DependencySnapshots {
    DependencySnapshots {
        agents: vec![agent()],
        ..Default::default()
    }
}
fn build(
    source: &Value,
    mut snapshots: DependencySnapshots,
) -> Result<PublishedBundle, Diagnostic> {
    // Fixture uses follow authored source; malformed-reference tests call freeze directly.
    if let Ok(decoded) = decode(&source.to_string())
        && let Ok(uses) = agent_reference_uses(&decoded)
    {
        for reference in &mut snapshots.agents {
            if let Some(usage) = uses.get(&reference.key) {
                reference.uses = usage.clone();
            }
        }
    }
    freeze(
        decode(&source.to_string())?,
        company(),
        VersionId::new(Uuid::from_u128(10)),
        snapshots,
        vec![],
    )
}
fn tool_snapshot(kind: &str) -> ToolSnapshot {
    ToolSnapshot {
        workflow: None,
        company_id: company(),
        contract: registry::example(kind).unwrap().facts.tools.remove(0),
        policy: ApprovedActionPolicy {
            capability: name("customer.read"),
            policy_revision: 1,
            effect: ActionEffect::Read,
            recovery: ActionRecovery::SafeRepeat,
        },
    }
}

#[test]
fn autonomous_agent_workflow_reference_hashes_identity_and_step_tools_without_behavior() {
    let source = source("agent.run");
    let facts = snapshots();
    let original = build(&source, facts.clone()).unwrap();
    let stored = store_bundle(&original).unwrap();
    let json = String::from_utf8(stored).unwrap();
    for field in [
        "instructions",
        "max_output_tokens",
        "required_tools",
        "system_prompt",
    ] {
        assert!(!json.contains(field), "workflow must not embed {field}");
    }
    let mut changed = facts.clone();
    changed.agents[0].agent_id =
        crate::entities::agent_capability::AgentId::new(Uuid::from_u128(2));
    assert_ne!(
        original.content_hash(),
        build(&source, changed).unwrap().content_hash()
    );
    let mut changed = facts;
    changed.tools.push(tool_snapshot("tool.call"));
    assert_ne!(
        original.content_hash(),
        build(&source, changed).unwrap().content_hash()
    );
    assert_eq!(
        original.content_hash(),
        build(&source, snapshots()).unwrap().content_hash()
    );
}

#[test]
fn workflow_publication_rejects_incomplete_foreign_duplicate_and_oversized_dependencies() {
    let source = source("agent.run");
    for variant in 0..5 {
        let mut facts = snapshots();
        match variant {
            0 => facts.agents.clear(),
            1 => facts.agents[0].company_id = CompanyId::new(Uuid::nil()),
            2 => facts.agents.push(agent()),
            3 => facts.agents[0].key = AgentKey::parse("unknown").unwrap(),
            _ => facts.agents = vec![agent(); MAX_DEPENDENCIES + 1],
        }
        assert!(build(&source, facts).is_err(), "variant {variant}");
    }
}

#[test]
fn autonomous_agent_workflow_reference_rejects_embedded_behavior_and_wrong_use_mode() {
    let source = source("agent.run");
    let bundle = build(&source, snapshots()).unwrap();
    let mut embedded = serde_json::to_value(bundle.snapshots()).unwrap();
    embedded["agents"][0]["instructions"] = json!("injected");
    assert!(serde_json::from_value::<DependencySnapshots>(embedded).is_err());
    let mut facts = snapshots();
    facts.agents[0].uses[0].mode = AgentUseMode::ModelOnly;
    assert!(
        freeze(
            decode(&source.to_string()).unwrap(),
            company(),
            VersionId::new(Uuid::from_u128(10)),
            facts,
            vec![]
        )
        .is_err()
    );
}

#[test]
fn workflow_publication_runtime_agent_selection_uses_only_frozen_catalogue() {
    let mut source = source("agent.run");
    source["parameter_schema"] = json!({"type":"object","required":["agent"],"properties":{"agent":{"type":"string","enum":["assistant"]}}});
    source["steps"]["start"]["with"]["agent"] = json!({"ref":"/params/agent"});
    let bundle = build(&source, snapshots()).unwrap();
    let outputs = BTreeMap::new();
    for selected in ["assistant", "unpublished"] {
        let params = json!({"agent":selected});
        let context = Context {
            input: &Value::Null,
            params: &params,
            step_outputs: &outputs,
            run: RunMetadata {
                run_id: RunId::new(Uuid::nil()),
                parent_run_id: None,
                deadline: None,
            },
        };
        let result = bundle.prepare_step_inputs(&StepId::parse("start").unwrap(), &context);
        assert_eq!(result.is_ok(), selected == "assistant");
        if let Err(error) = result {
            assert_eq!(
                &*error.field_path, "/params",
                "the closed enum rejects the undeclared selector before step evaluation"
            );
            assert!(error.span.line > 0);
        }
    }
}

#[test]
fn workflow_publication_mcp_contract_policy_and_resource_are_frozen_together() {
    let source = source("mcp.call");
    let facts = DependencySnapshots {
        tools: vec![tool_snapshot("mcp.call")],
        ..Default::default()
    };
    let bundle = build(&source, facts.clone()).unwrap();
    assert_eq!(bundle.manifest()["resources"][0]["kind"], "mcp");
    assert_eq!(
        bundle.manifest()["dependencies"]["tools"][0]["policy"]["recovery"],
        "safe_repeat"
    );
    for variant in 0..5 {
        let mut changed = facts.clone();
        match variant {
            0 => changed.tools[0].company_id = CompanyId::new(Uuid::nil()),
            1 => changed.tools[0].policy.policy_revision = 0,
            2 => {
                changed.tools[0].contract.connection = Some(ResourceName::parse("missing").unwrap())
            }
            3 => changed.tools[0].contract.name = name("missing"),
            _ => changed.tools.push(changed.tools[0].clone()),
        }
        assert!(build(&source, changed).is_err());
    }
    let mut later = facts;
    later.tools[0].policy.recovery = ActionRecovery::Reconcile;
    later.tools[0].policy.effect = ActionEffect::Write;
    later.tools[0].contract.output_schema = json!({"type":"object"});
    assert_ne!(
        bundle.content_hash(),
        build(&source, later).unwrap().content_hash()
    );
}

fn child_source() -> Value {
    let mut child = source("data.map");
    child["workflow_id"] = json!(Uuid::from_u128(2));
    child
}
fn child(source: &Value) -> Arc<PublishedBundle> {
    Arc::new(
        freeze(
            decode(&source.to_string()).unwrap(),
            company(),
            VersionId::new(Uuid::from_u128(3)),
            DependencySnapshots::default(),
            vec![],
        )
        .unwrap(),
    )
}
fn parent(
    source: &Value,
    children: Vec<Arc<PublishedBundle>>,
) -> Result<PublishedBundle, Diagnostic> {
    freeze(
        decode(&source.to_string())?,
        company(),
        VersionId::new(Uuid::from_u128(10)),
        DependencySnapshots::default(),
        children,
    )
}

#[test]
fn workflow_publication_children_pin_content_schemas_and_transitive_hashes() {
    let source = source("workflow.call");
    let child = child(&child_source());
    let bundle = parent(&source, vec![child.clone()]).unwrap();
    let old_hash = bundle.content_hash().clone();
    let mut edited = child_source();
    edited["limits"]["max_steps"] = json!(99);
    let later = super::tests::child(&edited);
    assert_ne!(child.content_hash(), later.content_hash());
    assert_ne!(
        bundle.content_hash(),
        parent(&source, vec![later]).unwrap().content_hash()
    );
    assert_eq!(bundle.content_hash(), &old_hash);
    assert!(Arc::ptr_eq(
        &bundle.children()[&VersionId::new(Uuid::from_u128(3))],
        &child
    ));
}

#[test]
fn workflow_publication_rejects_missing_duplicate_foreign_recursive_and_wrong_child_versions() {
    let source = source("workflow.call");
    let child = child(&child_source());
    assert!(parent(&source, vec![]).is_err());
    assert!(parent(&source, vec![child.clone(), child.clone()]).is_err());
    let foreign = Arc::new(
        freeze(
            decode(&child_source().to_string()).unwrap(),
            CompanyId::new(Uuid::nil()),
            VersionId::new(Uuid::from_u128(3)),
            DependencySnapshots::default(),
            vec![],
        )
        .unwrap(),
    );
    assert!(parent(&source, vec![foreign]).is_err());
    let mut wrong = source.clone();
    wrong["steps"]["start"]["child_version_id"] = json!(Uuid::from_u128(99));
    assert!(parent(&wrong, vec![child.clone()]).is_err());
    wrong = source.clone();
    wrong["steps"]["start"]["child_workflow_id"] = json!(Uuid::from_u128(99));
    assert!(parent(&wrong, vec![child.clone()]).is_err());
    wrong = source;
    wrong["workflow_id"] = json!(Uuid::from_u128(2));
    assert!(parent(&wrong, vec![child]).is_err());
}

#[test]
fn workflow_publication_rejects_deep_and_aggregate_schema_facts_before_copying() {
    let source = source("mcp.call");
    let mut facts = DependencySnapshots {
        tools: vec![tool_snapshot("mcp.call")],
        ..Default::default()
    };
    let mut schema = json!(true);
    for _ in 0..70 {
        schema = json!({"items":schema});
    }
    facts.tools[0].contract.input_schema = schema;
    assert!(build(&source, facts.clone()).is_err());
    facts.tools[0].contract.input_schema = json!({"description":"x".repeat(600_000)});
    facts.tools[0].contract.output_schema = json!({"description":"x".repeat(600_000)});
    assert!(build(&source, facts).is_err());
}

#[test]
fn workflow_publication_bounds_child_depth_and_pins_transitive_content() {
    let leaf = child(&child_source());
    let mut nested = leaf;
    for index in 1..=MAX_DEPENDENCY_DEPTH {
        let mut source = source("workflow.call");
        source["workflow_id"] = json!(Uuid::from_u128(1000 + index as u128));
        let definition = nested.compiled().graph().definition();
        source["steps"]["start"]["child_workflow_id"] = json!(definition.workflow_id);
        source["steps"]["start"]["child_version_id"] = json!(definition.version_id);
        let built = freeze(
            decode(&source.to_string()).unwrap(),
            company(),
            VersionId::new(Uuid::from_u128(2000 + index as u128)),
            DependencySnapshots::default(),
            vec![nested],
        );
        if index == MAX_DEPENDENCY_DEPTH {
            assert!(built.is_err());
            return;
        }
        nested = Arc::new(built.unwrap());
    }
}

#[test]
fn workflow_publication_rejects_conflicting_transitive_version_content() {
    let old = child(&child_source());
    let mut changed = child_source();
    changed["limits"]["max_steps"] = json!(99);
    let new = child(&changed);
    let mut intermediary = source("workflow.call");
    intermediary["workflow_id"] = json!(Uuid::from_u128(4));
    let intermediary = Arc::new(
        freeze(
            decode(&intermediary.to_string()).unwrap(),
            company(),
            VersionId::new(Uuid::from_u128(5)),
            DependencySnapshots::default(),
            vec![new],
        )
        .unwrap(),
    );
    let mut root = source("workflow.call");
    root["steps"]["second"] = root["steps"]["start"].clone();
    root["steps"]["start"]["routes"]["success"] = json!("second");
    root["steps"]["second"]["child_workflow_id"] = json!(Uuid::from_u128(4));
    root["steps"]["second"]["child_version_id"] = json!(Uuid::from_u128(5));
    assert!(parent(&root, vec![old, intermediary]).is_err());
}

#[test]
fn workflow_publication_dependency_errors_name_the_problem_and_source_field() {
    let mut facts = snapshots();
    facts.agents[0].company_id = CompanyId::new(Uuid::nil());
    let error = build(&source("agent.run"), facts).err().unwrap();
    assert_eq!(error.code, "publication.ownership");
    assert_eq!(&*error.field_path, "/steps/start/with/agent");
    assert!(
        error
            .message
            .contains("assistant: belongs to another company")
    );
    let error = parent(&source("workflow.call"), vec![]).err().unwrap();
    assert_eq!(error.code, "publication.missing");
    assert_eq!(&*error.field_path, "/steps/start/child_version_id");
    assert!(error.message.contains(&Uuid::from_u128(3).to_string()));
    let pinned = child(&child_source());
    let error = parent(&source("workflow.call"), vec![pinned.clone(), pinned])
        .err()
        .unwrap();
    assert_eq!(error.code, "publication.duplicate");
    assert!(error.message.contains("more than once"));
    let mut facts = DependencySnapshots {
        tools: vec![tool_snapshot("mcp.call")],
        ..Default::default()
    };
    facts.tools[0].policy.policy_revision = 0;
    let error = build(&source("mcp.call"), facts).err().unwrap();
    assert_eq!(error.code, "publication.policy");
    assert_eq!(&*error.field_path, "/steps/start/with/tool");
    assert!(error.message.contains("lookup"));
}

#[test]
fn autonomous_agent_workflow_reference_does_not_resolve_agent_tools_from_step_slots() {
    let mut facts = snapshots();
    facts.tools = vec![tool_snapshot("tool.call"), tool_snapshot("mcp.call")];
    let mut source = source("agent.run");
    source["resources"] = json!([{"slot":"service","kind":"mcp"}]);
    assert!(build(&source, facts).is_ok());
}

#[test]
fn workflow_publication_requires_and_hashes_trusted_agent_identity() {
    let source = source("agent.run");
    let original = build(&source, snapshots()).unwrap();
    let mut changed = snapshots();
    changed.agents[0].agent_id =
        crate::entities::agent_capability::AgentId::new(Uuid::from_u128(2));
    let replaced = build(&source, changed).unwrap();
    assert_ne!(
        original.content_hash().as_str(),
        replaced.content_hash().as_str()
    );
    let mut invalid = snapshots();
    invalid.agents[0].agent_id = crate::entities::agent_capability::AgentId::new(Uuid::nil());
    assert_eq!(
        build(&source, invalid).err().unwrap().code,
        "publication.agent_identity"
    );
}

/// 07-D2 §D2.2: a granted workflow tool pins its child like a child step. The bundle carries the
/// child; the frozen contract must be the child's own, its parameters must satisfy the child, the
/// child's resource slots must be the parent's, and a tool cannot reach the root workflow.
#[test]
fn workflow_publication_freezes_workflow_tool_pins_like_children() {
    let version = VersionId::new(Uuid::from_u128(3));
    let tool = |child: &PublishedBundle| {
        let definition = child.compiled().graph().definition();
        ToolSnapshot {
            company_id: company(),
            contract: registry::ToolContract {
                name: name("refund.review"),
                connection: None,
                input_schema: definition.input_schema.clone().unwrap(),
                output_schema: definition.output_schema.clone().unwrap(),
            },
            policy: ApprovedActionPolicy {
                capability: name("workflow.tool"),
                policy_revision: 1,
                effect: ActionEffect::Write,
                recovery: ActionRecovery::SafeRepeat,
            },
            workflow: Some(WorkflowToolPin {
                workflow_id: definition.workflow_id,
                version_id: definition.version_id,
                params: json!({}),
            }),
        }
    };
    let publish = |parent: &Value, tool: Option<ToolSnapshot>, children| {
        let agent = agent();
        freeze(
            decode(&parent.to_string()).unwrap(),
            company(),
            VersionId::new(Uuid::from_u128(10)),
            DependencySnapshots {
                agents: vec![agent],
                tools: tool.into_iter().collect(),
            },
            children,
        )
    };
    let refused = |result: Result<PublishedBundle, Diagnostic>, code: &str| {
        assert_eq!(result.err().map(|diagnostic| diagnostic.code), Some(code));
    };
    let parent = source("agent.run");
    let leaf = child(&child_source());
    let bundle = publish(&parent, Some(tool(&leaf)), vec![leaf.clone()]).unwrap();
    assert!(Arc::ptr_eq(&bundle.children()[&version], &leaf));
    assert_eq!(bundle.snapshots().tools[0].workflow, tool(&leaf).workflow);
    refused(
        publish(&parent, Some(tool(&leaf)), vec![]),
        "publication.missing",
    );
    refused(
        publish(&parent, None, vec![leaf.clone()]),
        "publication.unused",
    );
    // A contract that is not the child's, or a pin naming another workflow.
    let mut changed = tool(&leaf);
    changed.contract.output_schema = json!({"type":"string"});
    refused(
        publish(&parent, Some(changed), vec![leaf.clone()]),
        "publication.workflow_tool",
    );
    let mut changed = tool(&leaf);
    changed.workflow.as_mut().unwrap().workflow_id = WorkflowId::new(Uuid::from_u128(99));
    refused(
        publish(&parent, Some(changed), vec![leaf.clone()]),
        "publication.workflow_tool",
    );
    // Parameters the child refuses.
    let mut strict = child_source();
    strict["parameter_schema"] = json!({"type":"object","additionalProperties":false});
    let strict = child(&strict);
    let mut changed = tool(&strict);
    changed.workflow.as_mut().unwrap().params = json!({"reviewer": "someone"});
    refused(
        publish(&parent, Some(changed), vec![strict.clone()]),
        "publication.workflow_tool",
    );
    assert!(publish(&parent, Some(tool(&strict)), vec![strict]).is_ok());
    // The child's slots must be the parent's, by name, kind and contract.
    let mut slotted = child_source();
    slotted["resources"] = json!([{"slot":"service","kind":"mcp"}]);
    let slotted = child(&slotted);
    refused(
        publish(&parent, Some(tool(&slotted)), vec![slotted.clone()]),
        "publication.workflow_tool",
    );
    let mut declared = parent.clone();
    declared["resources"] = json!([{"slot":"service","kind":"mcp"}]);
    assert!(publish(&declared, Some(tool(&slotted)), vec![slotted]).is_ok());
    // A tool pinned to a version of the root workflow itself.
    let mut root = child_source();
    root["workflow_id"] = parent["workflow_id"].clone();
    let root = child(&root);
    refused(
        publish(&parent, Some(tool(&root)), vec![root]),
        "publication.recursion",
    );
}
