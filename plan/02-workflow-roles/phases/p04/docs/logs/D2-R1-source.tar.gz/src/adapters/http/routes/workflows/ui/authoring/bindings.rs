//! The bindings tab (p09 B1b): the tab body, its form (rendered again when the chosen version
//! changes, since params and slots are the version's), create or configure through the JSON
//! route's own command (`bindings::configure_binding`), activate and deactivate at the state
//! revision seen, and the channel pane's card of the bindings on one channel.
use super::super::super::bindings::{
    BindingRequest, Visibility, configure_binding, set_binding_activity,
};
use super::*;
use crate::application::workflow::authoring::{
    field_value, fields_for, parameter_fields, parameters_from_fields, parameters_from_json,
};
use crate::application::workflow::reads::{BindingOptions, BindingUse, WorkflowUsage};
use crate::application::workflow::{RelatedAssociation, RelatedChannelId};
use crate::domain::workflow::WorkflowDefinition;

/// What the tab's last write did.
pub(super) enum BindingsBanner {
    Done(String),
    RowRefused { binding: Uuid, message: String },
}

/// The params the form shows: a stored binding's, or what the author typed.
pub(super) enum ParamsInput {
    Stored(serde_json::Value),
    Typed {
        values: BTreeMap<String, String>,
        json: String,
        /// The form showed the whole object as JSON (`params_mode=json`).
        json_mode: bool,
    },
}

/// The form as opened or as submitted.
pub(super) struct BindingForm {
    /// The binding being configured; `None` creates one under `form_key`.
    binding: Option<Uuid>,
    form_key: String,
    version: Option<Uuid>,
    association: String,
    params: ParamsInput,
    resources: BTreeMap<String, Uuid>,
    message_trigger: String,
    escalation: Result<Option<crate::application::workflow::binding::EscalationPolicy>, String>,
    run_as: Option<Uuid>,
    error: Option<String>,
}

impl BindingForm {
    fn new_binding(newest: Option<Uuid>) -> Self {
        Self {
            binding: None,
            form_key: Uuid::new_v4().to_string(),
            version: newest,
            association: "company".into(),
            params: ParamsInput::Stored(serde_json::json!({})),
            resources: BTreeMap::new(),
            message_trigger: String::new(),
            escalation: Ok(None),
            run_as: None,
            error: None,
        }
    }

    fn stored(binding: &BindingUse) -> Self {
        let summary = &binding.binding;
        Self {
            binding: Some(summary.binding.as_uuid()),
            form_key: String::new(),
            version: Some(summary.version.as_uuid()),
            association: association_value(summary.association),
            params: ParamsInput::Stored(summary.params.clone()),
            resources: binding.resources.clone(),
            escalation: Ok(summary.escalation),
            message_trigger: summary
                .message_trigger
                .map(|trigger| trigger.as_str().to_owned())
                .unwrap_or_default(),
            run_as: Some(summary.run_as),
            error: None,
        }
    }

    fn typed(form: &FormFields) -> Self {
        let mut values = BTreeMap::new();
        let mut resources = BTreeMap::new();
        for (name, value) in form.pairs() {
            if let Some(parameter) = name.strip_prefix("param:") {
                values.insert(parameter.to_owned(), value.to_owned());
            } else if let Some(slot) = name.strip_prefix("resource:")
                && let Ok(resource) = value.parse()
            {
                resources.insert(slot.to_owned(), resource);
            }
        }
        Self {
            binding: form.get("binding_id").and_then(|id| id.parse().ok()),
            form_key: form.text("form_key"),
            version: form.get("version_id").and_then(|id| id.parse().ok()),
            association: form.get("association").unwrap_or("company").to_owned(),
            params: ParamsInput::Typed {
                values,
                json: form.text("params_json"),
                json_mode: form.get("params_mode") == Some("json"),
            },
            resources,
            message_trigger: form.text("message_trigger"),
            escalation: escalation_of(form.get("escalation").unwrap_or("")),
            run_as: form.get("run_as").and_then(|id| id.parse().ok()),
            error: None,
        }
    }
}

fn escalation_of(
    value: &str,
) -> Result<Option<crate::application::workflow::binding::EscalationPolicy>, String> {
    use crate::application::workflow::binding::{EscalationHops, EscalationPolicy};
    use crate::entities::department::DepartmentRole;
    let (notify, hops) = match value {
        "" => return Ok(None),
        "lead:1" => (DepartmentRole::Lead, 1),
        "lead:2" => (DepartmentRole::Lead, 2),
        "reviewer:1" => (DepartmentRole::Reviewer, 1),
        "reviewer:2" => (DepartmentRole::Reviewer, 2),
        _ => return Err("Choose a role and one or two escalation hops.".into()),
    };
    Ok(Some(EscalationPolicy {
        notify,
        hops: EscalationHops::try_from(hops).map_err(str::to_owned)?,
    }))
}

fn association_value(association: RelatedAssociation) -> String {
    match association {
        RelatedAssociation::Company => "company".into(),
        RelatedAssociation::Channel(channel) => format!("channel:{}", channel.as_uuid()),
        RelatedAssociation::Thread { channel_id, .. } => {
            format!("channel:{}", channel_id.as_uuid())
        }
    }
}

fn parse_association(value: &str) -> AppResult<RelatedAssociation> {
    match value.strip_prefix("channel:") {
        None if value == "company" => Ok(RelatedAssociation::Company),
        Some(channel) => channel
            .parse()
            .map(|channel| RelatedAssociation::Channel(RelatedChannelId::new(channel)))
            .map_err(|_| AppError::BadRequest("The association names no channel".into())),
        None => Err(AppError::BadRequest(
            "The association is the company or a channel".into(),
        )),
    }
}

/// The params object the form builds: from the fields it showed, or from the whole object as
/// JSON when it showed that (the schema has no fields, or the stored params were not exactly
/// what the fields can carry).
fn params_of(
    definition: &WorkflowDefinition,
    form: &FormFields,
) -> Result<serde_json::Value, String> {
    let fields = (form.get("params_mode") != Some("json"))
        .then(|| parameter_fields(definition.parameter_schema.as_ref()))
        .flatten();
    match fields {
        Some(fields) => parameters_from_fields(&fields, |name| {
            form.get(&format!("param:{name}")).map(str::to_owned)
        }),
        None => parameters_from_json(&form.text("params_json")),
    }
}

/// The message a refused configure or activation shows; `None` is not the author's to fix.
fn binding_refusal(error: &WorkflowError) -> Option<String> {
    match error {
        WorkflowError::Diagnostic(diagnostic) => Some(match &diagnostic.instance_path {
            Some(path) if !path.is_empty() => format!("{} (at {path})", diagnostic.message),
            _ => diagnostic.message.to_string(),
        }),
        WorkflowError::App(AppError::BadRequest(message)) => Some(message.clone()),
        WorkflowError::App(AppError::WorkflowRole(refusal)) => Some(refusal.to_string()),
        WorkflowError::App(AppError::NotFound(_)) => Some(
            "A chosen desk, version, run-as or resource is not available: it may be hidden from \
             you, disabled, revoked or not ready, or a tool the version froze is no longer \
             registered or approved."
                .into(),
        ),
        _ => None,
    }
}

impl Ui {
    /// The bindings of a workflow listing the viewer may see, and how many were left out.
    pub(super) async fn visible_usage(
        &self,
        company: Uuid,
        usage: WorkflowUsage,
        listing: &'static str,
    ) -> AppResult<(Vec<BindingUse>, usize)> {
        let mut visibility = Visibility::new(&self.engine, super::company(company), self.actor()?);
        let mut visible = Vec::new();
        let mut hidden = 0;
        for binding in usage.bindings {
            if visibility.allows(binding.binding.association).await? {
                visible.push(binding);
            } else {
                hidden += 1;
            }
        }
        visibility.report(listing);
        Ok((visible, hidden))
    }

    /// The choices a binding form offers, with the channels the viewer cannot see left out.
    pub(super) async fn binding_options(&self, company: Uuid) -> AppResult<BindingOptions> {
        let company_id = super::company(company);
        let mut options = self
            .engine
            .authoring_reads()
            .binding_options(company_id)
            .await?;
        let mut visibility = Visibility::new(&self.engine, company_id, self.actor()?);
        let mut channels = Vec::new();
        for channel in std::mem::take(&mut options.channels) {
            let association = RelatedAssociation::Channel(RelatedChannelId::new(channel.id));
            if visibility.allows(association).await? {
                channels.push(channel);
            }
        }
        visibility.report("workflow-binding-channels");
        options.channels = channels;
        Ok(options)
    }

    async fn typesafe_options(
        &self,
        company: Uuid,
        definition: Option<&WorkflowDefinition>,
    ) -> AppResult<Vec<crate::application::workflow::reads::ChoiceOption>> {
        let typesafe = if definition.is_some_and(|definition| {
            definition
                .resources
                .iter()
                .any(|resource| resource.kind.as_str() == "typesafe")
        }) {
            self.engine
                .jev_connections()
                .list_jev(super::company(company), self.actor()?)
                .await?
                .into_iter()
                .map(|connection| {
                    let models = connection
                        .models
                        .iter()
                        .map(|model| model.as_str())
                        .collect::<Vec<_>>()
                        .join(", ");
                    crate::application::workflow::reads::ChoiceOption {
                        id: connection.id,
                        label: format!(
                            "{} · {} · {models}",
                            connection.id,
                            if connection.ready {
                                "ready"
                            } else {
                                "not ready"
                            }
                        ),
                        enabled: connection.enabled,
                        detail: String::new(),
                    }
                })
                .collect::<Vec<_>>()
        } else {
            Vec::new()
        };
        Ok(typesafe)
    }

    /// The chosen version's definition, when it is a selectable version of this workflow.
    async fn binding_definition(
        &self,
        company: Uuid,
        workflow: Uuid,
        version: Option<Uuid>,
    ) -> AppResult<Option<WorkflowDefinition>> {
        let Some(version) = version else {
            return Ok(None);
        };
        let bundle = self
            .engine
            .selectable_bundle(super::company(company), VersionId::new(version))
            .await?;
        Ok(bundle
            .map(|bundle| bundle.compiled().graph().definition().clone())
            .filter(|definition| definition.workflow_id.as_uuid() == workflow))
    }

    async fn binding_form_html(
        &self,
        company: &crate::entities::company::Company,
        detail: &DefinitionDetail,
        form: &BindingForm,
        options: &BindingOptions,
        editing: Option<&BindingUse>,
    ) -> AppResult<String> {
        let workflow = detail.summary.workflow.as_uuid();
        let definition = self
            .binding_definition(company.id, workflow, form.version)
            .await?;
        let schema = definition
            .as_ref()
            .and_then(|definition| definition.parameter_schema.as_ref());
        // Fields only when they carry the stored params exactly (F021), or when the author was
        // already typing into fields.
        let fields = match &form.params {
            ParamsInput::Stored(params) => fields_for(schema, params),
            ParamsInput::Typed {
                json_mode: true, ..
            } => None,
            ParamsInput::Typed { .. } => parameter_fields(schema),
        };
        let (values, json) = match (&form.params, &fields) {
            (ParamsInput::Stored(params), Some(fields)) => (
                fields
                    .iter()
                    .map(|field| (field.name.clone(), field_value(field, params)))
                    .collect(),
                String::new(),
            ),
            (ParamsInput::Stored(params), None) => (
                BTreeMap::new(),
                serde_json::to_string_pretty(params).unwrap_or_default(),
            ),
            (ParamsInput::Typed { values, json, .. }, _) => (values.clone(), json.clone()),
        };
        let params = match &fields {
            Some(fields) => pages::BindingParams::Fields {
                fields,
                values: &values,
            },
            None => pages::BindingParams::Json(&json),
        };
        let typesafe = self
            .typesafe_options(company.id, definition.as_ref())
            .await?;
        Ok(pages::workflow_binding_form(&pages::BindingFormView {
            company_id: company.id,
            workflow,
            editing,
            form_key: &form.form_key,
            versions: &detail.versions,
            version: form.version,
            definition: definition.as_ref(),
            association: &form.association,
            channels: &options.channels,
            params,
            resources: &form.resources,
            http: &options.http,
            mcp: &options.mcp,
            typesafe: &typesafe,
            message_trigger: &form.message_trigger,
            escalation: form.escalation.as_ref().ok().copied().flatten(),
            run_as: form.run_as,
            owner: company.user_id == self.user,
            viewer: self.user,
            people: &options.people,
            options_truncated: options.truncated,
            error: form.error.as_deref(),
        }))
    }

    /// The whole pane on the bindings tab, with `form` open (a fresh create form when `None`).
    pub(super) async fn bindings_pane(
        &self,
        company: Uuid,
        workflow: Uuid,
        banner: Option<BindingsBanner>,
        form: Option<BindingForm>,
    ) -> AppResult<String> {
        let detail = self.detail(company, workflow).await?;
        let body = self.bindings_body(company, &detail, banner, form).await?;
        Ok(self
            .render_pane(company, &detail, pages::WorkflowTab::Bindings, body)
            .await)
    }

    pub(super) async fn bindings_body(
        &self,
        company: Uuid,
        detail: &DefinitionDetail,
        banner: Option<BindingsBanner>,
        form: Option<BindingForm>,
    ) -> AppResult<String> {
        let managed = self.company(company).await?;
        let usage = self
            .engine
            .authoring_reads()
            .workflow_usage(super::company(company), detail.summary.workflow)
            .await?;
        let truncated = usage.truncated;
        let (bindings, hidden) = self
            .visible_usage(company, usage, "workflow-bindings-tab")
            .await?;
        let options = self.binding_options(company).await?;
        let form = form.unwrap_or_else(|| {
            BindingForm::new_binding(detail.versions.first().map(|v| v.version.as_uuid()))
        });
        let editing = match form.binding {
            Some(binding) => Some(
                self.visible_binding(company, detail.summary.workflow.as_uuid(), binding)
                    .await?,
            ),
            None => None,
        };
        let form_html = self
            .binding_form_html(&managed, detail, &form, &options, editing.as_ref())
            .await?;
        let banner = match &banner {
            Some(BindingsBanner::Done(message)) => Some(pages::BindingBanner::Done(message)),
            Some(BindingsBanner::RowRefused { binding, message }) => {
                Some(pages::BindingBanner::RowRefused {
                    binding: *binding,
                    message,
                })
            }
            None => None,
        };
        Ok(pages::workflow_bindings_body(&pages::BindingsView {
            company_id: company,
            workflow: detail.summary.workflow.as_uuid(),
            archived: detail.summary.archived,
            versions: &detail.versions,
            bindings: &bindings,
            truncated,
            hidden,
            people: &options.people,
            banner,
            form_html: &form_html,
        }))
    }

    /// Whether a `Conflict` from the binding command means the binding itself moved: a create
    /// whose keyed binding now exists, or an edit whose state revision is no longer the one the
    /// form or row was shown at. Any other `Conflict` is one of the command's own refusals.
    async fn binding_moved(
        &self,
        company: Uuid,
        binding: Uuid,
        expected: Option<u64>,
    ) -> AppResult<bool> {
        let current = self
            .engine
            .authoring_reads()
            .binding_use(super::company(company), binding)
            .await?;
        Ok(match (current, expected) {
            (Some(_), None) | (None, Some(_)) => true,
            (Some(current), Some(expected)) => current.binding.state_revision != expected,
            (None, None) => false,
        })
    }

    /// A binding of this workflow the viewer may see.
    async fn visible_binding(
        &self,
        company: Uuid,
        workflow: Uuid,
        binding: Uuid,
    ) -> AppResult<BindingUse> {
        let not_found = || AppError::NotFound("Workflow binding not found".into());
        let found = self
            .engine
            .authoring_reads()
            .binding_use(super::company(company), binding)
            .await?
            .filter(|found| found.binding.workflow.as_uuid() == workflow)
            .ok_or_else(not_found)?;
        let mut visibility = Visibility::new(&self.engine, super::company(company), self.actor()?);
        if !visibility.allows(found.binding.association).await? {
            return Err(not_found());
        }
        Ok(found)
    }
}

#[derive(Deserialize)]
pub(super) struct BindingFormQuery {
    pub(super) company_id: Uuid,
    pub(super) binding_id: Option<Uuid>,
}

/// GET /ui/workflows/{workflow}/bindings/form — the form for `binding_id` as stored, or the
/// fields it carries (a version change), rendered for the chosen version.
pub(super) async fn binding_form(
    ui: Ui,
    Path(workflow): Path<Uuid>,
    Query(query): Query<BindingFormQuery>,
    uri: axum::http::Uri,
) -> AppResult<Html<String>> {
    let company = ui.company(query.company_id).await?;
    let detail = ui.detail(company.id, workflow).await?;
    let fields = FormFields::parse(uri.query().unwrap_or_default().as_bytes());
    let typed = fields.get("version_id").is_some();
    let editing = match query.binding_id {
        Some(binding) => Some(ui.visible_binding(company.id, workflow, binding).await?),
        None => None,
    };
    let form = match (&editing, typed) {
        (_, true) => BindingForm::typed(&fields),
        (Some(binding), false) => BindingForm::stored(binding),
        (None, false) => {
            BindingForm::new_binding(detail.versions.first().map(|v| v.version.as_uuid()))
        }
    };
    let options = ui.binding_options(company.id).await?;
    Ok(Html(
        ui.binding_form_html(&company, &detail, &form, &options, editing.as_ref())
            .await?,
    ))
}

/// POST /ui/workflows/{workflow}/bindings — create (keyed by the form) or configure a binding
/// through the binding command. A refusal keeps every choice in the form.
pub(super) async fn save_binding(
    ui: Ui,
    Path(workflow): Path<Uuid>,
    Query(query): Query<CompanyQuery>,
    body: Bytes,
) -> WorkflowResult<Html<String>> {
    let company = ui.company(query.company_id).await?.id;
    let fields = FormFields::parse(&body);
    let mut form = BindingForm::typed(&fields);
    let refused = |mut form: BindingForm, message: String| {
        form.error = Some(message);
        form
    };
    let editing = match form.binding {
        Some(binding) => Some(ui.visible_binding(company, workflow, binding).await?),
        None => None,
    };
    let Some(definition) = ui
        .binding_definition(company, workflow, form.version)
        .await?
    else {
        let form = refused(
            form,
            "Choose a published version of this workflow; its workflow may have been archived."
                .into(),
        );
        return Ok(Html(
            ui.bindings_pane(company, workflow, None, Some(form))
                .await?,
        ));
    };
    let (params, escalation) = match params_of(&definition, &fields).and_then(|params| {
        form.escalation
            .clone()
            .map(|escalation| (params, escalation))
    }) {
        Ok(configuration) => configuration,
        Err(message) => {
            let form = refused(form, message);
            return Ok(Html(
                ui.bindings_pane(company, workflow, None, Some(form))
                    .await?,
            ));
        }
    };
    let association = match &editing {
        Some(binding) => binding.binding.association,
        None => parse_association(&form.association)?,
    };
    let binding = match form.binding {
        Some(binding) => binding,
        None => {
            let key = crate::application::workflow::IdempotencyKey::parse(form.form_key.clone())?;
            keyed_id("workflow.ui_binding", super::company(company), key.as_str())
        }
    };
    // The revision the author saw; a binding changed since then is the command's conflict.
    let expected_state_revision = match &editing {
        Some(_) => Some(fields.number("expected_state_revision")?),
        None => None,
    };
    let request = BindingRequest {
        expected_state_revision,
        association,
        version: definition.version_id.as_uuid(),
        params,
        resources: form.resources.clone(),
        run_as: form.run_as,
        message_trigger: Some(form.message_trigger.clone()).filter(|trigger| !trigger.is_empty()),
        escalation,
    };
    match configure_binding(&ui.engine, company, ui.actor()?, binding, request).await {
        Ok(state) => {
            let message = format!(
                "Saved binding {} at state revision {}; it is {}.",
                pages::short_id(binding),
                state.revision.get(),
                if state.active {
                    "active"
                } else {
                    "paused until you activate it"
                },
            );
            Ok(Html(
                ui.bindings_pane(company, workflow, Some(BindingsBanner::Done(message)), None)
                    .await?,
            ))
        }
        Err(WorkflowError::App(AppError::Conflict(message)))
            if !ui
                .binding_moved(company, binding, expected_state_revision)
                .await? =>
        {
            // One of the command's own refusals that answer `Conflict` too (a resource slot
            // that is not ready, a version changed under the binding): nothing moved (F019).
            let form = refused(form, format!("Not saved: {message}"));
            Ok(Html(
                ui.bindings_pane(company, workflow, None, Some(form))
                    .await?,
            ))
        }
        Err(WorkflowError::App(AppError::Conflict(_))) if editing.is_none() => {
            // A double submit of the create (the key names the binding) or a reused key.
            Ok(Html(
                ui.bindings_pane(
                    company,
                    workflow,
                    Some(BindingsBanner::Done(format!(
                        "Binding {} was already created; it is listed above.",
                        pages::short_id(binding)
                    ))),
                    None,
                )
                .await?,
            ))
        }
        Err(WorkflowError::App(AppError::Conflict(_))) => {
            form.error = Some(
                "Someone changed this binding while you saved it. Your choices are kept below; \
                 saving again replaces its configuration."
                    .into(),
            );
            Ok(Html(
                ui.bindings_pane(company, workflow, None, Some(form))
                    .await?,
            ))
        }
        Err(error) => match binding_refusal(&error) {
            Some(message) => {
                let form = refused(form, format!("Not saved: {message}"));
                Ok(Html(
                    ui.bindings_pane(company, workflow, None, Some(form))
                        .await?,
                ))
            }
            None => Err(error),
        },
    }
}

#[derive(Deserialize)]
pub(super) struct ActivityForm {
    pub(super) expected_state_revision: u64,
}

async fn set_activity(
    ui: Ui,
    company_id: Uuid,
    workflow: Uuid,
    binding: Uuid,
    expected: u64,
    active: bool,
) -> WorkflowResult<Html<String>> {
    let company = ui.company(company_id).await?.id;
    ui.visible_binding(company, workflow, binding).await?;
    let banner =
        match set_binding_activity(&ui.engine, company, ui.actor()?, binding, expected, active)
            .await
        {
            Ok(state) => BindingsBanner::Done(format!(
                "{} binding {} (state revision {}).",
                if state.active {
                    "Activated"
                } else {
                    "Deactivated"
                },
                pages::short_id(binding),
                state.revision.get(),
            )),
            Err(WorkflowError::App(AppError::Conflict(_)))
                if ui.binding_moved(company, binding, Some(expected)).await? =>
            {
                BindingsBanner::RowRefused {
                    binding,
                    message: "This binding changed since the page was shown; here it is as it is \
                              now. Nothing was changed."
                        .into(),
                }
            }
            Err(WorkflowError::App(AppError::Conflict(message))) => BindingsBanner::RowRefused {
                binding,
                message: format!(
                    "Not {}: {message}",
                    if active { "activated" } else { "deactivated" }
                ),
            },
            Err(error) => match binding_refusal(&error) {
                Some(message) => BindingsBanner::RowRefused {
                    binding,
                    message: format!(
                        "Not {}: {message}",
                        if active { "activated" } else { "deactivated" }
                    ),
                },
                None => return Err(error),
            },
        };
    Ok(Html(
        ui.bindings_pane(company, workflow, Some(banner), None)
            .await?,
    ))
}

/// POST /ui/workflows/{workflow}/bindings/{binding}/activate — readiness is checked again.
pub(super) async fn activate_binding(
    ui: Ui,
    Path((workflow, binding)): Path<(Uuid, Uuid)>,
    Query(query): Query<CompanyQuery>,
    axum::Form(form): axum::Form<ActivityForm>,
) -> WorkflowResult<Html<String>> {
    set_activity(
        ui,
        query.company_id,
        workflow,
        binding,
        form.expected_state_revision,
        true,
    )
    .await
}

/// POST /ui/workflows/{workflow}/bindings/{binding}/deactivate.
pub(super) async fn deactivate_binding(
    ui: Ui,
    Path((workflow, binding)): Path<(Uuid, Uuid)>,
    Query(query): Query<CompanyQuery>,
    axum::Form(form): axum::Form<ActivityForm>,
) -> WorkflowResult<Html<String>> {
    set_activity(
        ui,
        query.company_id,
        workflow,
        binding,
        form.expected_state_revision,
        false,
    )
    .await
}

/// GET /ui/workflows/channels/{channel}/bindings — the channel pane's "Workflows on this
/// channel" card, for a channel the viewer can see.
pub(super) async fn channel_bindings(
    ui: Ui,
    Path(channel): Path<Uuid>,
    Query(query): Query<CompanyQuery>,
) -> AppResult<Html<String>> {
    let company = ui.company(query.company_id).await?.id;
    let company_id = super::company(company);
    let mut visibility = Visibility::new(&ui.engine, company_id, ui.actor()?);
    if !visibility
        .allows(RelatedAssociation::Channel(RelatedChannelId::new(channel)))
        .await?
    {
        return Err(AppError::NotFound("Desk not found".into()));
    }
    Ok(Html(
        super::channel_response::card(&ui, company, channel, None, None).await?,
    ))
}

/// Resolve an attention item to the binding's workflow without trusting an incoming workflow id.
pub(super) async fn binding_destination(
    ui: Ui,
    Path(binding): Path<Uuid>,
    Query(query): Query<CompanyQuery>,
) -> AppResult<axum::response::Redirect> {
    ui.company(query.company_id).await?;
    let summary = ui
        .engine
        .authoring_reads()
        .binding_use(company(query.company_id), binding)
        .await?
        .ok_or_else(|| AppError::NotFound("Workflow binding not found".into()))?;
    let workflow = summary.binding.workflow.as_uuid();
    ui.visible_binding(query.company_id, workflow, binding)
        .await?;
    Ok(axum::response::Redirect::to(&format!(
        "/ui/workflows?company_id={}&workflow_id={workflow}&tab=bindings",
        query.company_id
    )))
}
