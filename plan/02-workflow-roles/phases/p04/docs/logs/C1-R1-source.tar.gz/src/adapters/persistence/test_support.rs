//! One way for the DB-backed tests in this directory to reach a database.
//!
//! # Why these tests do not use the development database
//!
//! The queue operations under test are deliberately unscoped: `claim_pending_tasks` and
//! `claim_deliveries` sweep every row in the database, because that is what a real worker does.
//! Pointed at the development database, a test run therefore competes with — and claims rows out
//! from under — a `cargo run` server polling the same queues twice a second, and can charge real
//! deliveries an attempt through `reap_expired_deliveries`.
//!
//! So the tests get their own database, derived from `DATABASE_URL` by suffixing the database name.
//! The command `src/adapters/persistence/AGENTS.md` tells you to run is unchanged; it just lands
//! somewhere it cannot do damage.
//!
//! # Missing configuration shouts too, unless silence is asked for
//!
//! These tests used to skip when `DATABASE_URL` was unset, so the suite could run without a
//! database. The cost is recorded in `src/adapters/persistence/AGENTS.md`: three tests in
//! `thread.rs` named columns no migration creates and went unnoticed, because nothing ever set the
//! variable. Two more slipped through the same gap later — a content-hash mismatch that broke every
//! internal delegation hop, and a `WHERE id = $9` placeholder collision — each hidden behind a
//! green run of a suite that had silently skipped every Postgres test.
//!
//! The failure mode is what makes it dangerous: a skipped test is *counted as passing*, the suite
//! reports the same total either way, and whole-suite wall time is too noisy to notice. So the
//! default is now loud. Unset is a panic naming the fix, exactly like a database that cannot be
//! reached.
//!
//! Silence is still available, but it has to be asked for: set `ALLOW_MISSING_DATABASE_URL=1` and
//! the tests skip as before. That is the switch for a CI job that deliberately runs without
//! Postgres — this repository has no CI at all today, which is why the old default was protecting
//! nothing.
//!
//! # A test that cannot share at all gets a database of its own
//!
//! The queue claims sweep every row of the database they run against, so a test asserting *which*
//! rows a claim took cannot tolerate a neighbour's rows, and a test that leaves a claimable row
//! behind breaks whichever test claims it next. [`own_database`] hands one test a database of its
//! own, migrated, and drops it when the handle goes out of scope — on a panic too.

use sqlx::postgres::PgPoolOptions;
use sqlx::{Connection, PgConnection, PgPool};
use tokio::sync::{Mutex, OnceCell};
use uuid::Uuid;

use crate::adapters::persistence::PostgresPersistence;
use crate::application::ports::integration::ChannelBindingPersistence;
use crate::application::ports::thread::MessageAuthorWrite;
use crate::application::ports::thread::MessageWrite;
use crate::application::ports::thread::ThreadPersistence;
use crate::entities::correlation::CorrelationId;
use crate::entities::message::CanonicalMessageId;
use crate::entities::message::MessageDirection;
use crate::entities::message::MessageRole;
use crate::entities::transport::ChannelBindingId;
use crate::entities::transport::DeliveryId;
use crate::entities::transport::DeliveryPurpose;
use crate::entities::transport::ExternalDestination;
use crate::entities::transport::TransportKind;
use crate::entities::value_objects::EmailAddress;
use crate::transport::ContentDigest;
use crate::transport::DeliveryKey;
use crate::transport::MAX_DELIVERY_ATTEMPTS;
use crate::transport::NewDelivery;
use crate::transport::PartIndex;
use crate::transport::PartKey;
use crate::transport::RenderedPart;
use crate::transport::TransportPayload;

/// The suffix that separates the tests' database from the one you develop against.
const TEST_DB_SUFFIX: &str = "_test";

/// Migrations run once per test binary, not once per test.
static MIGRATED: OnceCell<()> = OnceCell::const_new();

// PostgreSQL shares its lock table across databases. Concurrent init schemas can exhaust the
// default max_locks_per_transaction budget even though every fixture has a database of its own.
// Serialize schema creation, then let the migrated fixtures run their tests concurrently.
static MIGRATION_LOCK: Mutex<()> = Mutex::const_new(());

/// The environment variable that buys back the old skip-when-unset behaviour.
const ALLOW_MISSING_URL_VAR: &str = "ALLOW_MISSING_DATABASE_URL";

/// Whether the caller has explicitly asked for DB-backed tests to be skipped.
///
/// Any non-empty value counts. The point is that skipping is a deliberate act with a name on it,
/// not the accident of an unexported variable.
fn skipping_is_permitted() -> bool {
    permits_skipping(std::env::var(ALLOW_MISSING_URL_VAR).ok().as_deref())
}

/// The decision itself, separated from the environment so it can be tested without `set_var` —
/// which is `unsafe` in edition 2024 and process-global besides, so a test using it would race
/// every other test in the binary.
fn permits_skipping(value: Option<&str>) -> bool {
    value.is_some_and(|value| !value.trim().is_empty())
}

/// Where the tests should connect, or `None` when skipping has been explicitly permitted.
///
/// `TEST_DATABASE_URL` wins outright, for a database that is not named after the development one.
/// Otherwise `DATABASE_URL` is redirected onto its `_test` sibling.
///
/// Panics when neither is set and [`ALLOW_MISSING_URL_VAR`] is absent — see the module docs for
/// why an unset variable is a failure rather than a skip.
fn test_database_url() -> Option<String> {
    let explicit = std::env::var("TEST_DATABASE_URL")
        .ok()
        .filter(|url| !url.trim().is_empty());
    if let Some(explicit) = explicit {
        return Some(explicit);
    }

    let configured = std::env::var("DATABASE_URL")
        .ok()
        .filter(|url| !url.trim().is_empty());
    match configured {
        Some(configured) => Some(with_test_database_name(&configured)),
        None if skipping_is_permitted() => None,
        None => panic!(
            "DATABASE_URL is not set, so this test would silently skip and be counted as passing.\n\n\
             Run the suite with a database:\n\n    \
             DATABASE_URL=\"postgres://$(whoami)@localhost:5432/open_bots\" cargo test\n\n\
             (Tests never use that database directly — they are redirected onto its `_test` \
             sibling. Create it once with `createdb open_bots_test`.)\n\n\
             To skip them on purpose, set {ALLOW_MISSING_URL_VAR}=1."
        ),
    }
}

/// Redirect a connection URL onto its `_test` sibling, leaving everything else about it alone.
///
/// Split before the query string first: `?sslmode=require` contains no `/`, but a naive
/// `rsplit_once('/')` over the whole URL would still find the last path separator and rebuild the
/// parameters into the database name.
fn with_test_database_name(url: &str) -> String {
    let base = url.split_once('?').map_or(url, |(base, _)| base);
    let name = base.rsplit_once('/').map_or("", |(_, name)| name);

    // Nothing to rename: no database name at all, or already a test database — a
    // `TEST_DATABASE_URL` that went through `DATABASE_URL`, or a second call. Suffixing again
    // would invent `open_bots_test_test`. Hand the URL back and let the connection report why.
    if name.is_empty() || name.ends_with(TEST_DB_SUFFIX) {
        return url.to_string();
    }
    with_database_name(url, &format!("{name}{TEST_DB_SUFFIX}"))
}

/// Point `url` at database `name`, leaving everything else about it alone.
fn with_database_name(url: &str, name: &str) -> String {
    let (base, query) = match url.split_once('?') {
        Some((base, query)) => (base, Some(query)),
        None => (url, None),
    };

    let renamed = match base.rsplit_once('/') {
        Some((prefix, _)) => format!("{prefix}/{name}"),
        None => base.to_string(),
    };

    match query {
        Some(query) => format!("{renamed}?{query}"),
        None => renamed,
    }
}

/// Clear what earlier runs left behind, once per test binary.
///
/// Tests build their fixtures — a user, a company, a channel, some queue rows — and delete them on
/// the way out, but a test that panics never reaches its cleanup. Companies at least cascade when
/// a later run deletes them; `users` never does, because *nothing in this codebase deletes a user
/// row at all*. So every panicking run leaked a handful of users permanently, and the table had
/// grown to some 4,600 rows across roughly 200 runs before this existed.
///
/// That debris is not inert. These queue claims are unscoped, so leftover rows are exactly the
/// neighbours that make a claim-and-assert test flaky — the failure this was written alongside.
///
/// `TRUNCATE ... CASCADE` over every table but the migration ledger, rather than a curated list of
/// `DELETE`s in dependency order: it cannot go stale as tables are added, and it cannot silently
/// half-clean because someone forgot that `companies.user_id` is `ON DELETE RESTRICT`.
///
/// It runs *before* the suite rather than after it, which is deliberate: the wreckage of a failed
/// run stays on the database for you to inspect until the next run starts.
async fn purge_fixtures(pool: &PgPool) {
    sqlx::query(
        r#"DO $$
           DECLARE tables text;
           BEGIN
               SELECT string_agg(format('%I', tablename), ', ')
                 INTO tables
                 FROM pg_tables
                WHERE schemaname = 'public' AND tablename <> '_sqlx_migrations';
               IF tables IS NOT NULL THEN
                   EXECUTE 'TRUNCATE TABLE ' || tables || ' CASCADE';
               END IF;
           END $$"#,
    )
    .execute(pool)
    .await
    .expect("the test database can be cleared between runs");
}

/// Options for every test pool: the production pool's guard, so tests run on the connection
/// hygiene production has (WF-C004).
pub fn pool_options() -> PgPoolOptions {
    crate::infra::db::discard_leaked_transactions(PgPoolOptions::new())
}

/// A pool against the test database, with migrations applied, or `None` when unconfigured.
///
/// Panics if a database was configured but cannot be reached — see the module docs.
pub async fn test_pool() -> Option<PgPool> {
    let url = test_database_url()?;

    let pool = match pool_options().connect(&url).await {
        Ok(pool) => pool,
        Err(error) => panic!(
            "DATABASE_URL is set, so these tests are meant to run, but the test database could not \
             be reached: {error}\n\nCreate it once with:\n\n    createdb open_bots_test\n\n\
             (Tests never use the development database: they claim from the same queues a running \
             server polls. Set TEST_DATABASE_URL to override the derived name.)"
        ),
    };

    MIGRATED
        .get_or_init(|| async {
            Box::pin(migrate_test_database(&pool))
                .await
                .expect("the test database accepts this checkout's migrations");
            purge_fixtures(&pool).await;
        })
        .await;

    Some(pool)
}

/// A database created for one test, dropped when this handle goes out of scope.
///
/// Hold it for the length of the test and take `database.pool.clone()` for a persistence handle:
///
/// ```ignore
/// let Some(database) = own_database().await else { return };
/// let pool = database.pool.clone();
/// ```
pub struct OwnDatabase {
    /// A pool against this test's own database.
    pub pool: PgPool,
    name: String,
    admin_url: String,
}

impl Drop for OwnDatabase {
    fn drop(&mut self) {
        // There is no async `Drop` to hang this on, and the test's runtime may be mid-unwind and
        // about to shut down, so the statement runs on a thread and a runtime of its own.
        let name = std::mem::take(&mut self.name);
        let admin_url = std::mem::take(&mut self.admin_url);
        let dropped = std::thread::spawn(move || {
            tokio::runtime::Builder::new_current_thread()
                .enable_all()
                .build()
                .expect("a runtime for one statement")
                .block_on(admin_statement(
                    &admin_url,
                    // `FORCE`: this test's pool still holds connections, and a panicking test may
                    // have left others open.
                    &format!(r#"DROP DATABASE "{name}" WITH (FORCE)"#),
                ));
        })
        .join();
        if dropped.is_err() {
            // Reported, not raised: a test that is already failing keeps its own panic, and a
            // `open_bots_own_%` database left behind shows up in `psql -l`.
            eprintln!("could not drop this test's database; it is left behind");
        }
    }
}

/// A database of this test's own: created, migrated, and dropped when the handle drops.
///
/// `None` when no database is configured and skipping has been permitted, exactly as [`test_pool`]
/// skips. Migrations run once per database rather than once per binary, which is what the isolation
/// costs: the database starts empty, so the test states every row that exists in it.
pub async fn own_database() -> Option<OwnDatabase> {
    // Keep the migrator and pool setup off stock test stacks.
    Box::pin(migrated_own_database()).await
}

/// A task-owned database migrated with the checkout's single init schema.
async fn migrated_own_database() -> Option<OwnDatabase> {
    let url = test_database_url()?;
    // Generated, so it needs no quoting beyond the identifier quotes: `CREATE DATABASE` takes no
    // parameters.
    let name = format!("open_bots_own_{}", Uuid::new_v4().simple());
    let admin_url = with_database_name(&url, "postgres");
    admin_statement(&admin_url, &format!(r#"CREATE DATABASE "{name}""#)).await;

    // Every isolated test holds a pool of its own and `cargo test` runs them in parallel, so these
    // are kept small: the default of ten would put a busy machine's worth of tests within reach of
    // the server's `max_connections`. A test that needs more fan-out than this opens its own pool.
    let pool = pool_options()
        .max_connections(5)
        .connect(&with_database_name(&url, &name))
        .await
        .expect("a database this test just created accepts connections");
    let database = OwnDatabase {
        pool,
        name,
        admin_url,
    };
    Box::pin(migrate_test_database(&database.pool))
        .await
        .expect("a fresh database accepts the init schema");
    prewarm(&database.pool).await;
    Some(database)
}

async fn migrate_test_database(pool: &PgPool) -> Result<(), sqlx::migrate::MigrateError> {
    let _migration = MIGRATION_LOCK.lock().await;
    sqlx::migrate!("./migrations").run(pool).await
}

/// Opens every connection of a test's pool up front, concurrently, and returns them idle.
///
/// This models a warm steady-state production pool: bounded workflow persistence operations
/// then measure lock waits and statements, not backend startup on a loaded host (which a cold
/// pool would charge to the first acquires of each test). It hides nothing the tests check:
/// a test that exhausts the pool still holds every connection, and the persistence recorder
/// still reports each acquire. Production still opens connections cold after `max_lifetime`
/// recycling; the post-effect receipt commit waits for a connection for its whole attempt
/// for that reason.
async fn prewarm(pool: &PgPool) {
    let size = pool.options().get_max_connections();
    let connections = futures::future::try_join_all((0..size).map(|_| pool.acquire()))
        .await
        .expect("a database this test just created accepts its pool's connections");
    drop(connections);
}

/// Run one statement against the maintenance database. `CREATE`/`DROP DATABASE` cannot run inside
/// a transaction or through a pool holding other connections to the target.
async fn admin_statement(admin_url: &str, statement: &str) {
    let mut connection = PgConnection::connect(admin_url)
        .await
        .expect("the maintenance database is reachable");
    sqlx::query(statement)
        .execute(&mut connection)
        .await
        .unwrap_or_else(|error| panic!("{statement} failed: {error}"));
    let _ = connection.close().await;
}

/// One canonical message and one delivery carrying it, on the channel's own email interface.
///
/// Shared because three test modules need the same four rows -- a message, its thread association,
/// the interface, and the queue row -- and because a delivery's foreign keys make "just insert a
/// row" impossible: every one of them has to be a real, same-company row.
pub struct DeliveryFixture {
    pub delivery: NewDelivery,
    pub message_id: CanonicalMessageId,
    pub binding_id: ChannelBindingId,
}

/// What a fixture delivery should look like. Defaults to a plain email reply to one recipient.
pub struct DeliveryFixtureRequest<'a> {
    pub company_id: Uuid,
    pub channel_id: Uuid,
    pub thread_id: Uuid,
    /// Distinguishes one fixture delivery from another within the same interface, which is what
    /// the unique index is over.
    pub source_key: &'a str,
    pub recipient: &'a str,
    pub subject: &'a str,
    pub body: &'a str,
    pub purpose: DeliveryPurpose,
    /// How many parts to freeze. Email renders one; more than one exercises the aggregation rule
    /// that a parent is delivered only when every part is.
    pub parts: u16,
    pub depends_on: Option<DeliveryId>,
}

impl<'a> DeliveryFixtureRequest<'a> {
    pub fn new(company_id: Uuid, channel_id: Uuid, thread_id: Uuid, source_key: &'a str) -> Self {
        Self {
            company_id,
            channel_id,
            thread_id,
            source_key,
            recipient: "customer@example.com",
            subject: "Re: order",
            body: "On its way.",
            purpose: DeliveryPurpose::WorkflowReply,
            parts: 1,
            depends_on: None,
        }
    }
}

/// Write the message and return the delivery that carries it, ready to insert.
///
/// The delivery is *not* written: callers insert it through the path they are testing -- the
/// dispatch commit, the outreach transaction, or `enqueue_delivery` -- which is the whole point of
/// the exercise.
pub async fn delivery_fixture(
    persistence: &PostgresPersistence,
    request: DeliveryFixtureRequest<'_>,
) -> DeliveryFixture {
    let binding = ChannelBindingPersistence::active_bindings_for_channel(
        persistence,
        request.company_id,
        request.channel_id,
    )
    .await
    .expect("the channel's interfaces are readable")
    .into_iter()
    .find(|binding| binding.transport == TransportKind::Email)
    .expect("a channel is created with its canonical email interface");

    let write = MessageWrite::internal(
        request.thread_id,
        MessageAuthorWrite::Platform,
        request.subject.to_string(),
        request.body.to_string(),
        MessageDirection::Outbound,
        MessageRole::Agent,
        CorrelationId::new(),
    )
    .external_conversation();
    let message_id = write.id;
    ThreadPersistence::create_message(persistence, &write)
        .await
        .expect("the fixture message is stored");

    let destination = ExternalDestination::Email(EmailAddress::from(request.recipient));
    let key = crate::transport::delivery_key(
        request.purpose,
        request.source_key,
        &crate::transport::DeliveryDestination::External(destination.clone()),
    );

    DeliveryFixture {
        message_id,
        binding_id: binding.id,
        delivery: NewDelivery {
            id: DeliveryId::random(),
            company_id: request.company_id,
            channel_id: request.channel_id,
            message_id,
            message_audience: crate::entities::message::MessageAudience::ExternalConversation,
            source_binding_id: binding.id,
            destination_binding_id: binding.id,
            external_destination: Some(destination),
            depends_on_delivery_id: request.depends_on,
            correlation_id: CorrelationId::new(),
            transport: TransportKind::Email,
            purpose: request.purpose,
            idempotency_key: key.clone(),
            max_attempts: MAX_DELIVERY_ATTEMPTS,
            parts: NewDelivery::frozen_parts(
                (0..request.parts)
                    .map(|index| fixture_part(&key, index, request.body))
                    .collect(),
            )
            .expect("a fixture freezes at least one part and fewer than the bound"),
        },
    }
}

/// One frozen part, keyed the way the email renderer keys its own: from the delivery's stable
/// idempotency key, so a re-render addresses the part that already exists.
fn fixture_part(key: &DeliveryKey, index: u16, body: &str) -> RenderedPart {
    RenderedPart {
        index: PartIndex::new(index),
        key: PartKey::parse(format!("email:{}:{index}", key.as_str()))
            .expect("a fixture part key is within its bound"),
        payload: TransportPayload::encode(
            TransportKind::Email,
            crate::adapters::protocols::email::OUTBOUND_EMAIL_VERSION,
            &serde_json::json!({ "fixture": index }),
        )
        .expect("a small object encodes"),
        digest: ContentDigest::sha256_of(body.as_bytes()),
    }
}

/// Write a bare company row and its owner's member row in one transaction, for fixtures that need
/// a company without what `CompanyPersistence::create` also sets up (principals, identities).
/// The two rows are one fact checked at commit, so neither can be written alone.
pub async fn insert_company_with_owner(
    pool: &PgPool,
    company_id: Uuid,
    name: &str,
    slug: &str,
    owner: Uuid,
) {
    let mut transaction = pool.begin().await.expect("a transaction");
    sqlx::query("INSERT INTO companies (id, name, slug, user_id) VALUES ($1, $2, $3, $4)")
        .bind(company_id)
        .bind(name)
        .bind(slug)
        .bind(owner)
        .execute(&mut *transaction)
        .await
        .expect("the company row");
    sqlx::query(
        "INSERT INTO company_members (id, company_id, user_id, role, access_level) VALUES ($1, $2, $3, 'owner', 9)",
    )
    .bind(Uuid::new_v4())
    .bind(company_id)
    .bind(owner)
    .execute(&mut *transaction)
    .await
    .expect("the owner's member row");
    transaction
        .commit()
        .await
        .expect("a company with its owner row commits");
}

/// Hand a company to `new_owner` the one way the schema allows: in one transaction, the previous
/// owner's member row becomes `previous_owner_role`, the new owner gets the owner row (created if
/// they were not a member yet), and `companies.user_id` follows.
///
/// `companies.user_id` and the owner member row are one fact, checked at commit
/// (`companies_owner_member_fk`, `companies_owner_member_agreement`), so a fixture that changes
/// either alone -- or in separate autocommit statements -- describes a state the database refuses.
pub async fn transfer_company_ownership(
    pool: &PgPool,
    company_id: Uuid,
    new_owner: Uuid,
    previous_owner_role: crate::entities::company_member::CompanyAccessRole,
) {
    let mut transaction = pool.begin().await.expect("a transaction");
    let previous_owner: Uuid =
        sqlx::query_scalar("SELECT user_id FROM companies WHERE id = $1 FOR UPDATE")
            .bind(company_id)
            .fetch_one(&mut *transaction)
            .await
            .expect("the company exists");
    sqlx::query("UPDATE company_members SET role = $3 WHERE company_id = $1 AND user_id = $2")
        .bind(company_id)
        .bind(previous_owner)
        .bind(previous_owner_role.as_str())
        .execute(&mut *transaction)
        .await
        .expect("the previous owner is demoted");
    sqlx::query(
        r#"INSERT INTO company_members (id, company_id, user_id, role, access_level)
           VALUES ($1, $2, $3, 'owner', 9)
           ON CONFLICT (company_id, user_id) DO UPDATE SET role = 'owner', access_level = 9"#,
    )
    .bind(Uuid::new_v4())
    .bind(company_id)
    .bind(new_owner)
    .execute(&mut *transaction)
    .await
    .expect("the new owner holds the owner row");
    sqlx::query("UPDATE companies SET user_id = $2 WHERE id = $1")
        .bind(company_id)
        .bind(new_owner)
        .execute(&mut *transaction)
        .await
        .expect("the company names its new owner");
    transaction
        .commit()
        .await
        .expect("a complete ownership transfer commits");
}

/// Take `user_id` off the company inside the caller's transaction, as fixtures modelling "the actor
/// lost every authority" need.
///
/// The member row goes first, so a competitor holding a lock on it still makes this wait exactly
/// where a bare `DELETE` would. When the user is the owner, a fresh replacement account then takes
/// the company in the same transaction: the owner row cannot simply disappear, because
/// `companies.user_id` and the owner member row are one fact checked at commit.
pub async fn revoke_membership(connection: &mut PgConnection, company_id: Uuid, user_id: Uuid) {
    let owner: Uuid = sqlx::query_scalar("SELECT user_id FROM companies WHERE id = $1")
        .bind(company_id)
        .fetch_one(&mut *connection)
        .await
        .expect("the company exists");
    sqlx::query("DELETE FROM company_members WHERE company_id = $1 AND user_id = $2")
        .bind(company_id)
        .bind(user_id)
        .execute(&mut *connection)
        .await
        .expect("the member row is deleted");
    if owner != user_id {
        return;
    }
    let replacement = Uuid::new_v4();
    let name = format!("replacement_{}", replacement.simple());
    sqlx::query(
        "INSERT INTO users (id, username, email, password_hash) VALUES ($1, $2, $3, 'hash')",
    )
    .bind(replacement)
    .bind(&name)
    .bind(format!("{name}@example.test"))
    .execute(&mut *connection)
    .await
    .expect("a replacement owner account");
    sqlx::query(
        "INSERT INTO company_members (id, company_id, user_id, role, access_level) VALUES ($1, $2, $3, 'owner', 9)",
    )
    .bind(Uuid::new_v4())
    .bind(company_id)
    .bind(replacement)
    .execute(&mut *connection)
    .await
    .expect("the replacement holds the owner row");
    sqlx::query("UPDATE companies SET user_id = $2 WHERE id = $1")
        .bind(company_id)
        .bind(replacement)
        .execute(&mut *connection)
        .await
        .expect("the company names its replacement owner");
}

/// [`revoke_membership`] committed on its own.
pub async fn revoke_membership_now(pool: &PgPool, company_id: Uuid, user_id: Uuid) {
    let mut transaction = pool.begin().await.expect("a transaction");
    revoke_membership(&mut transaction, company_id, user_id).await;
    transaction.commit().await.expect("the revocation commits");
}

/// Wait until some backend of this test's database is blocked on a lock.
///
/// The barrier for a concurrency test: hold a lock in one transaction, start the competing
/// operation, and only then release it -- which proves the competitor actually waited on that lock
/// rather than happening to run afterwards. Use it with `own_database`, where every waiting backend
/// is one the test started.
pub async fn wait_until_a_backend_is_blocked(pool: &PgPool) {
    wait_until_backends_are_blocked(pool, 1).await;
}

/// [`wait_until_a_backend_is_blocked`] for a queue: at least `count` backends are waiting at once,
/// so a test can line up two competitors behind one held lock before releasing it.
pub async fn wait_until_backends_are_blocked(pool: &PgPool, count: i64) {
    for _ in 0..500 {
        let waiting: i64 = sqlx::query_scalar(
            "SELECT count(*) FROM pg_stat_activity
              WHERE datname = current_database() AND wait_event_type = 'Lock'",
        )
        .fetch_one(pool)
        .await
        .expect("pg_stat_activity is readable");
        if waiting >= count {
            return;
        }
        tokio::time::sleep(std::time::Duration::from_millis(10)).await;
    }
    panic!("fewer than {count} backends ever blocked on the locks this test holds");
}

/// Native fixture commands carry the actual owner, rather than bypassing writer authority.
pub async fn invite_command(
    persistence: &super::PostgresPersistence,
    company_id: Uuid,
    email: &str,
    role: crate::entities::company_member::CompanyAccessRole,
) -> crate::use_cases::company_invite::CreateCompanyInvite {
    let actor_id = sqlx::query_scalar("SELECT user_id FROM companies WHERE id=$1")
        .bind(company_id)
        .fetch_one(&persistence.pool)
        .await
        .unwrap();
    crate::use_cases::company_invite::CreateCompanyInvite {
        actor_id,
        company_id,
        email: email.into(),
        role,
        access_level: crate::entities::access_level::AccessLevel::PUBLIC,
    }
}
pub async fn invite_update_command(
    persistence: &super::PostgresPersistence,
    company_id: Uuid,
    invite_id: Uuid,
    email: &str,
    role: crate::entities::company_member::CompanyAccessRole,
) -> crate::use_cases::company_invite::UpdateCompanyInvite {
    let actor_id = sqlx::query_scalar("SELECT user_id FROM companies WHERE id=$1")
        .bind(company_id)
        .fetch_one(&persistence.pool)
        .await
        .unwrap();
    crate::use_cases::company_invite::UpdateCompanyInvite {
        actor_id,
        company_id,
        invite_id,
        email: email.into(),
        role: Some(role),
        access_level: None,
    }
}

/// The shipped provisioning templates on the test domain, as production builds them.
/// Department use cases over `persistence`, with the test provisioning templates.
pub fn department_use_cases(
    persistence: &super::PostgresPersistence,
) -> std::sync::Arc<crate::use_cases::department::DepartmentUseCases> {
    std::sync::Arc::new(crate::use_cases::department::DepartmentUseCases::new(
        std::sync::Arc::new(persistence.clone()),
        std::sync::Arc::new(super::department::PostgresDepartments::new(
            persistence.clone(),
            provisioning_templates(),
        )),
    ))
}

pub fn provisioning_templates() -> super::workflow::provisioning::ProvisioningDeployment {
    super::workflow::provisioning::ProvisioningDeployment::new(
        std::sync::Arc::new(
            crate::application::workflow::templates::TemplateCatalogue::shipped(
                &crate::adapters::workflow_source::WorkflowSourceDecoder,
            )
            .unwrap(),
        ),
        &[],
        "agents.test",
    )
}

/// Company-agent creation over `persistence` with [`provisioning_templates`] (01DEP-P03-D2).
pub fn company_agents(
    persistence: &super::PostgresPersistence,
) -> std::sync::Arc<dyn crate::use_cases::agent::CompanyAgents> {
    std::sync::Arc::new(super::company_agent::CompanyAgentService::new(
        persistence.clone(),
        provisioning_templates(),
    ))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[tokio::test]
    async fn competing_fixtures_migrate_independent_databases() {
        if test_database_url().is_none() {
            return;
        }
        let names = futures::future::join_all((0..16).map(|_| async {
            let database = own_database().await.unwrap();
            let applied: i64 =
                sqlx::query_scalar("SELECT count(*) FROM _sqlx_migrations WHERE success")
                    .fetch_one(&database.pool)
                    .await
                    .unwrap();
            assert_eq!(applied, 1, "each contender receives a migrated database");
            database.name.clone()
        }))
        .await;
        let distinct: std::collections::HashSet<_> = names.iter().collect();
        assert_eq!(
            distinct.len(),
            names.len(),
            "fixtures never share a database"
        );
    }

    /// The checkout has one migration, the squashed init schema. A fresh database records exactly
    /// it, a rerun changes nothing, and it seeds no rows: there is no upgrade path to exercise.
    #[tokio::test]
    async fn a_fresh_database_applies_only_the_init_schema() {
        let migrator = sqlx::migrate!("./migrations");
        let expected: Vec<_> = migrator
            .iter()
            .map(|migration| {
                (
                    migration.version,
                    migration.description.to_string(),
                    migration.checksum.to_vec(),
                )
            })
            .collect();
        assert_eq!(
            expected
                .iter()
                .map(|(version, description, _)| (*version, description.as_str()))
                .collect::<Vec<_>>(),
            vec![(20260817000000, "init schema")]
        );
        let Some(database) = own_database().await else {
            return;
        };
        let ledger = || async {
            sqlx::query_as::<_, (i64, String, Vec<u8>, bool)>(
                "SELECT version, description, checksum, success FROM _sqlx_migrations ORDER BY version",
            )
            .fetch_all(&database.pool)
            .await
            .unwrap()
        };
        let recorded = ledger().await;
        assert_eq!(
            recorded
                .iter()
                .map(|(version, description, checksum, success)| {
                    assert!(*success);
                    (*version, description.clone(), checksum.clone())
                })
                .collect::<Vec<_>>(),
            expected
        );
        migrator.run(&database.pool).await.unwrap();
        assert_eq!(ledger().await, recorded, "a rerun applies nothing");
        let populated: Vec<String> = sqlx::query_scalar(
            "SELECT relname::text FROM pg_class WHERE relnamespace='public'::regnamespace AND relkind IN ('r','p') \
               AND relname<>'_sqlx_migrations' AND (xpath('/row/n/text()', query_to_xml(format('SELECT count(*) AS n FROM public.%I', relname), false, true, '')))[1]::text<>'0'",
        )
        .fetch_all(&database.pool)
        .await
        .unwrap();
        assert!(
            populated.is_empty(),
            "the init schema seeds no rows: {populated:?}"
        );
    }

    #[test]
    fn skipping_needs_a_real_value_not_just_a_present_variable() {
        assert!(permits_skipping(Some("1")));
        assert!(permits_skipping(Some("true")));
        // An exported-but-empty variable is the classic `export FOO=` accident. It must not buy
        // silence, or the failure this whole mechanism exists to prevent comes back.
        assert!(!permits_skipping(Some("")));
        assert!(!permits_skipping(Some("   ")));
        assert!(!permits_skipping(None));
    }

    #[test]
    fn a_development_url_is_redirected_to_its_test_sibling() {
        assert_eq!(
            with_test_database_name("postgres://mac03@localhost:5432/open_bots"),
            "postgres://mac03@localhost:5432/open_bots_test"
        );
    }

    #[test]
    fn query_parameters_survive_the_rename() {
        // The rename must land on the database name, not on the last path-looking thing in the URL.
        assert_eq!(
            with_test_database_name("postgres://user:pw@host:5432/open_bots?sslmode=require"),
            "postgres://user:pw@host:5432/open_bots_test?sslmode=require"
        );
    }

    #[test]
    fn a_test_database_is_not_suffixed_twice() {
        assert_eq!(
            with_test_database_name("postgres://localhost/open_bots_test"),
            "postgres://localhost/open_bots_test"
        );
    }

    #[test]
    fn a_url_with_no_database_name_is_left_for_the_connection_to_reject() {
        assert_eq!(
            with_test_database_name("postgres://localhost:5432/"),
            "postgres://localhost:5432/"
        );
    }
}

pub(crate) fn notification_worker(
    persistence: &super::PostgresPersistence,
    escalation_ack_hours: crate::application::workflow::binding::EscalationAckHours,
) -> crate::application::services::notification_worker::NotificationWorker {
    use crate::application::transport::{DeliveryComposer, TransportRenderers};
    use std::sync::Arc;
    let store = Arc::new(persistence.clone());
    let renderers = TransportRenderers::new()
        .register(Arc::new(
            crate::adapters::protocols::email::EmailRenderer::new("example.test"),
        ))
        .unwrap();
    crate::application::services::notification_worker::NotificationWorker::new(
        store.clone(),
        DeliveryComposer::new(Arc::new(renderers), store),
        crate::application::settings::NotificationMailSettings {
            escalation_ack_hours,
            mail_domain: "example.test".into(),
            public_base_url: "https://example.test".into(),
        },
        Arc::new(crate::adapters::monitoring::InMemoryMonitor::new()),
    )
}
