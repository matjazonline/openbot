use super::*;
use crate::adapters::persistence::workflow::tests::approval_test_support::notices;
use crate::application::workflow::activation::{ActivationRequest, WorkflowJobId};
use crate::application::workflow::decisions::{
    DecisionCommandKey, DecisionId, SubmitDecision, WorkflowDecisions,
};

#[derive(sqlx::FromRow)]
struct ScopeIds {
    execution: Uuid,
    job: Uuid,
}

struct PeopleFixture {
    role: RoleFixture,
    users: Vec<Uuid>,
    principals: Vec<PrincipalId>,
}
impl PeopleFixture {
    async fn new(count: usize) -> Self {
        let fixture = Fixture::new().await;
        let mut users = Vec::new();
        let mut principals = Vec::new();
        for _ in 0..count {
            let user =
                crate::adapters::persistence::workflow::tests::message_tests::support::member(
                    &fixture, "admin",
                )
                .await;
            users.push(user);
            principals.push(PrincipalId::new(fixture.principal(user).await));
        }
        let mut source: Value =
            serde_json::from_str(&registry::example("decision.human").unwrap().source).unwrap();
        source["input_schema"] = json!({"type":"object","properties":{"value":{"type":"integer"}},"required":["value"],"additionalProperties":false});
        source["steps"]["start"]["with"]["data_schema"] = json!({"literal":true});
        source["steps"]["start"]["with"]["feedback_required"] = json!({"literal":[]});
        source["steps"]["start"]["with"]["reviewers"] = json!({"literal":["reviewer"]});
        source["steps"]["start"]["with"]["deadline"] =
            json!({"literal":(chrono::Utc::now()+chrono::Duration::minutes(20)).to_rfc3339()});
        let binding = BindingFixture::from_fixture(fixture, source).await;
        let role = RoleFixture::from_binding(binding).await;
        let departments =
            crate::adapters::persistence::test_support::department_use_cases(role.p());
        for principal in &principals {
            departments
                .assign_role(
                    role.admission.binding.target.actor.user_id(),
                    role.company().as_uuid(),
                    role.department,
                    DepartmentRole::Reviewer,
                    *principal,
                )
                .await
                .unwrap();
        }
        Self {
            role,
            users,
            principals,
        }
    }
    async fn scope(&self, run: RunId) -> ActivationRequest {
        let row: ScopeIds = sqlx::query_as("SELECT execution.id AS execution,job.id AS job FROM workflow_executions AS execution JOIN background_tasks AS job ON job.company_id=execution.company_id AND job.workflow_execution_id=execution.id WHERE execution.company_id=$1 AND execution.run_id=$2")
            .bind(self.role.company().as_uuid()).bind(run.as_uuid()).fetch_one(self.role.p().pool()).await.unwrap();
        ActivationRequest {
            company: self.role.company(),
            run,
            execution: ExecutionId::new(row.execution),
            job: WorkflowJobId(row.job),
        }
    }
}

#[tokio::test]
async fn workflow_role_reviewer_captures_all_people_parks_notices_labels_and_submits() {
    let f = Box::pin(PeopleFixture::new(2)).await;
    let run = f.role.admitted("people").await;
    let manifest = f.role.manifest(run).await;
    assert_eq!(manifest.roles.len(), 1);
    assert_eq!(manifest.roles[0].principals.len(), 2);
    assert!(
        manifest.roles[0]
            .principals
            .iter()
            .all(|holder| holder.agent_id.is_none() && holder.revision_id.is_none())
    );
    let scope = f.scope(run).await;
    f.role
        .p()
        .park_decision(scope, &notices(f.role.p()))
        .await
        .unwrap()
        .unwrap();
    let decision: Uuid =
        sqlx::query_scalar("SELECT id FROM workflow_decisions WHERE company_id=$1 AND run_id=$2")
            .bind(scope.company.as_uuid())
            .bind(run.as_uuid())
            .fetch_one(f.role.p().pool())
            .await
            .unwrap();
    let actor = WorkflowActor::authenticated(f.users[0]).unwrap();
    let view = f
        .role
        .p()
        .read_decision(scope.company, actor, DecisionId(decision))
        .await
        .unwrap();
    assert_eq!(view.reviewers.len(), 2);
    assert_eq!(view.reviewer_labels.len(), 2);
    assert!(view.can_submit);
    assert!(
        view.reviewers
            .iter()
            .all(|id| f.principals.contains(&PrincipalId::new(*id)))
    );
    let deliveries: i64 = sqlx::query_scalar("SELECT count(*) FROM workflow_decision_reviewers WHERE company_id=$1 AND decision_id=$2 AND notice_delivery_id IS NOT NULL")
        .bind(scope.company.as_uuid()).bind(decision).fetch_one(f.role.p().pool()).await.unwrap();
    assert_eq!(deliveries, 2);
    f.role
        .p()
        .submit_decision(SubmitDecision {
            company: scope.company,
            actor,
            decision: DecisionId(decision),
            command_key: DecisionCommandKey::parse("role-vote").unwrap(),
            expected_revision: view.revision,
            expected_artifact: view.artifact_digest,
            choice: view.choices[0].clone(),
            data: json!(null),
            feedback: String::new(),
        })
        .await
        .unwrap();
}

#[tokio::test]
async fn workflow_role_reviewer_missing_holder_refuses_before_run() {
    let f = Box::pin(PeopleFixture::new(0)).await;
    let command = f.role.prepared("missing-people").await;
    assert!(
        matches!(f.role.p().admit(&command).await,Err(AppError::WorkflowRole(refusal)) if refusal.kind==RoleRefusalKind::NoHolder && refusal.role==DepartmentRole::Reviewer)
    );
    let exists: bool = sqlx::query_scalar(
        "SELECT EXISTS(SELECT 1 FROM workflow_runs WHERE company_id=$1 AND id=$2)",
    )
    .bind(f.role.company().as_uuid())
    .bind(command.proposed_run_id().as_uuid())
    .fetch_one(f.role.p().pool())
    .await
    .unwrap();
    assert!(!exists);
}
