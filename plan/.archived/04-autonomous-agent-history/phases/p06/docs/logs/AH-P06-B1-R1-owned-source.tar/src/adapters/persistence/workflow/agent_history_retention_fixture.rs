//! Clock setup only, in the caller's OwnDatabase. All expiry/retirement uses native guards.
use super::*;
use crate::application::workflow::activation::ActivationRequest;
use crate::application::workflow::{agent_history::AgentExchangeId, storage::*};

pub(super) async fn age(p: &PostgresPersistence, scope: ActivationRequest) {
    let mut tx = p.pool().begin().await.unwrap();
    sqlx::raw_sql(
        "ALTER TABLE workflow_runs DISABLE TRIGGER workflow_run_snapshot_immutable;
        ALTER TABLE agent_history_exchanges DISABLE TRIGGER agent_history_exchange_change",
    )
    .execute(&mut *tx)
    .await
    .unwrap();
    sqlx::query(
        "UPDATE workflow_runs SET created_at=created_at-interval '100 days',
        deadline=deadline-interval '100 days',finished_at=finished_at-interval '100 days'
        WHERE company_id=$1 AND id=$2",
    )
    .bind(scope.company.as_uuid())
    .bind(scope.run.as_uuid())
    .execute(&mut *tx)
    .await
    .unwrap();
    sqlx::query(
        "UPDATE agent_history_exchanges SET created_at=created_at-interval '100 days',
        activated_at=activated_at-interval '100 days',finished_at=finished_at-interval '100 days'
        WHERE company_id=$1 AND id=$2 AND state IN ('completed','failed','cancelled')",
    )
    .bind(scope.company.as_uuid())
    .bind(scope.execution.as_uuid())
    .execute(&mut *tx)
    .await
    .unwrap();
    sqlx::raw_sql(
        "SET CONSTRAINTS ALL IMMEDIATE;
        ALTER TABLE workflow_runs ENABLE TRIGGER workflow_run_snapshot_immutable;
        ALTER TABLE agent_history_exchanges ENABLE TRIGGER agent_history_exchange_change",
    )
    .execute(&mut *tx)
    .await
    .unwrap();
    tx.commit().await.unwrap();
}

pub(super) async fn candidate(
    p: &PostgresPersistence,
    scope: ActivationRequest,
) -> HistoryCandidate {
    let finished_at = sqlx::query_scalar(
        "SELECT finished_at FROM agent_history_exchanges WHERE company_id=$1 AND id=$2",
    )
    .bind(scope.company.as_uuid())
    .bind(scope.execution.as_uuid())
    .fetch_one(p.pool())
    .await
    .unwrap();
    HistoryCandidate {
        company: scope.company,
        finished_at,
        exchange: AgentExchangeId::for_execution(scope.execution),
    }
}

pub(super) async fn expire(p: &PostgresPersistence, scope: ActivationRequest) {
    age(p, scope).await;
    assert!(p.expire_history(candidate(p, scope).await).await.unwrap());
}

pub(super) async fn retire(p: &PostgresPersistence, scope: ActivationRequest) {
    expire(p, scope).await;
    retire_source(p, scope).await;
}

pub(super) async fn retire_source(p: &PostgresPersistence, scope: ActivationRequest) {
    let finished_at =
        sqlx::query_scalar("SELECT finished_at FROM workflow_runs WHERE company_id=$1 AND id=$2")
            .bind(scope.company.as_uuid())
            .bind(scope.run.as_uuid())
            .fetch_one(p.pool())
            .await
            .unwrap();
    let result = p
        .retire_tree(RetentionRoot {
            company: scope.company,
            run: scope.run,
            finished_at,
        })
        .await
        .unwrap();
    assert!(
        result.is_some(),
        "eligible aged source tree must retire after payload expiry"
    );
    let count: i64 = sqlx::query_scalar(
        "SELECT count(*) FROM agent_history_exchanges WHERE company_id=$1 AND id=$2",
    )
    .bind(scope.company.as_uuid())
    .bind(scope.execution.as_uuid())
    .fetch_one(p.pool())
    .await
    .unwrap();
    assert_eq!(count, 0, "source cascade removes only expired metadata");
}
