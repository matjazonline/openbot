use super::*;
use crate::domain::entities::{correlation::CorrelationId, message::CanonicalMessageId};
use serde_json::Value;

#[derive(sqlx::FromRow)]
pub(super) struct HeadRow {
    pub knowledge_ceiling: i16,
    pub content_level: i16,
    pub company_id: Uuid,
    pub id: Uuid,
    pub workflow_id: Uuid,
    pub version_id: Uuid,
    pub channel_id: Option<Uuid>,
    pub thread_id: Option<Uuid>,
    pub trigger_id: Uuid,
    pub correlation_id: Uuid,
    pub state: String,
    pub waiting_reason: Option<String>,
    pub revision: i64,
    pub source_key: String,
    pub rerun_of_run_id: Option<Uuid>,
}

pub(super) const HEAD: &str = "SELECT run.company_id,run.id,run.workflow_id,run.version_id,run.channel_id,run.thread_id,run.trigger_id,run.correlation_id,run.state,run.waiting_reason,run.revision,admission.source_key,run.rerun_of_run_id,run.knowledge_ceiling::smallint AS knowledge_ceiling,run.content_level::smallint AS content_level FROM workflow_runs AS run JOIN workflow_admissions AS admission ON admission.company_id=run.company_id AND admission.run_id=run.id WHERE run.company_id=$1 AND run.id=$2";

#[async_trait]
impl WorkflowInspection for PostgresPersistence {
    async fn head(&self, company_id: CompanyId, run_id: RunId) -> AppResult<Option<RunHead>> {
        sqlx::query_as::<_, HeadRow>(HEAD)
            .bind(company_id.as_uuid())
            .bind(run_id.as_uuid())
            .fetch_optional(&self.pool)
            .await?
            .map(HeadRow::restore)
            .transpose()
    }
}

impl HeadRow {
    pub(super) fn restore(self) -> AppResult<RunHead> {
        let company = CompanyId::new(self.company_id);
        let trigger = TriggerRef::new(
            company,
            TriggerId::new(self.trigger_id),
            source(company, self.trigger_id, &self.source_key)?,
        )
        .map_err(|_| invalid())?;
        let state = run_state(&self.state, self.waiting_reason.as_deref())?;
        let association = binding_rows::association_from_columns(self.channel_id, self.thread_id)?;
        Ok(RunHead {
            knowledge: super::knowledge::stored_levels(self.knowledge_ceiling, self.content_level)?,
            causality: RunCausality::new(
                RunId::new(self.id),
                trigger,
                CorrelationId::from(self.correlation_id),
            )
            .map_err(|_| invalid())?,
            workflow_id: WorkflowId::new(self.workflow_id),
            version_id: VersionId::new(self.version_id),
            association,
            state,
            revision: RunRevision(u64::try_from(self.revision).map_err(|_| invalid())?),
            rerun_of: self.rerun_of_run_id.map(RunId::new),
        })
    }
}

/// A run's stored `state` and `waiting_reason` columns as the engine's state.
pub(super) fn run_state(state: &str, waiting_reason: Option<&str>) -> AppResult<RunState> {
    Ok(match state {
        "queued" => RunState::Queued,
        "running" => RunState::Running,
        "succeeded" => RunState::Succeeded,
        "failed" => RunState::Failed,
        "cancelled" => RunState::Cancelled,
        "waiting" => RunState::Waiting(match waiting_reason {
            Some("decision") => WaitingReason::Decision,
            Some("event") => WaitingReason::Event,
            Some("timer") => WaitingReason::Timer,
            Some("child_run") => WaitingReason::ChildRun,
            Some("effect") => WaitingReason::Effect,
            Some("reconciliation") => WaitingReason::Reconciliation,
            Some("agent_turn") => WaitingReason::AgentTurn,
            _ => return Err(invalid()),
        }),
        _ => return Err(invalid()),
    })
}

fn source(company: CompanyId, trigger: Uuid, source: &str) -> AppResult<TriggerSource> {
    let value: Value = serde_json::from_str(source.strip_prefix("v1:").ok_or_else(invalid)?)
        .map_err(|_| invalid())?;
    let fields = value.as_array().ok_or_else(invalid)?;
    let uuid = |index: usize| -> AppResult<Uuid> {
        Uuid::parse_str(
            fields
                .get(index)
                .and_then(Value::as_str)
                .ok_or_else(invalid)?,
        )
        .map_err(|_| invalid())
    };
    Ok(match fields.first().and_then(Value::as_str) {
        Some("manual") if fields.len() == 2 && uuid(1)? == trigger => TriggerSource::Manual,
        Some("message") if fields.len() == 2 => TriggerSource::Message {
            message_id: CanonicalMessageId::new(uuid(1)?),
        },
        Some("schedule") if fields.len() == 3 => TriggerSource::Schedule {
            schedule_id: ScheduleId::new(uuid(1)?),
            occurrence_id: ScheduleOccurrenceId::new(uuid(2)?),
        },
        Some("child") if fields.len() == 6 => {
            let execution = ExecutionRef::new(
                company,
                RunId::new(uuid(1)?),
                ExecutionId::new(uuid(2)?),
                StepId::parse(fields[3].as_str().ok_or_else(invalid)?).map_err(|_| invalid())?,
            );
            let parent = match (fields[4].is_null(), fields[5].as_u64()) {
                (true, Some(ordinal)) => ChildCause::Step(ChildStepRef::new(
                    execution,
                    u32::try_from(ordinal)
                        .ok()
                        .and_then(ChildOrdinal::new)
                        .ok_or_else(invalid)?,
                )),
                (false, None) if fields[5].is_null() => ChildCause::ToolCall(
                    ChildToolCallRef::new(execution, ToolCallId::new(uuid(4)?)),
                ),
                _ => return Err(invalid()),
            };
            TriggerSource::Child { parent }
        }
        _ => return Err(invalid()),
    })
}
