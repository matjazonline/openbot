use super::*;
use crate::application::workflow::{activation::*, polling::*};
use std::time::Duration;

#[derive(sqlx::FromRow)]
pub(super) struct CandidateRow {
    company_id: Uuid,
    run_id: Uuid,
    execution_id: Uuid,
    pub(super) job_id: Uuid,
    work: String,
}
#[async_trait]
impl WorkflowPolling for PostgresPersistence {
    async fn poll_work(&self, after: Option<PollCursor>, limit: u16) -> AppResult<PollPage> {
        if !(1..=128).contains(&limit) {
            return Err(invalid());
        }
        tokio::time::timeout(Duration::from_secs(2), async {
            let mut tx = self.pool.begin().await?;
            sqlx::query("SELECT set_config('lock_timeout','1000ms',true),set_config('statement_timeout','1000ms',true)")
                .execute(&mut *tx).await?;
            let rows = sqlx::query_as::<_, CandidateRow>(&format!("{CANDIDATES_SQL} AND ($1::uuid IS NULL OR job.id > $1) ORDER BY job.id LIMIT $2")).bind(after.map(|cursor| cursor.0)).bind(i64::from(limit))
                .fetch_all(&mut *tx).await?;
            tx.commit().await?;
            let next = rows.last().map(|row| PollCursor(row.job_id));
            let candidates = rows.into_iter().map(candidate).collect::<AppResult<Vec<_>>>()?;
            Ok(PollPage { candidates, next })
        }).await.map_err(|_| lease::timed_out())?
    }
    async fn expire_run(&self, scope: ActivationRequest) -> AppResult<bool> {
        tokio::time::timeout(Duration::from_secs(2), async {
            let mut tx = self.pool.begin().await?;
            let changed = maintenance::expire_on(&mut tx, scope).await?;
            tx.commit().await?;
            Ok(changed)
        })
        .await
        .map_err(|_| lease::timed_out())?
    }
    async fn step_kind(&self, scope: ActivationRequest) -> AppResult<WorkflowStepKind> {
        tokio::time::timeout(Duration::from_secs(2), async {
            let mut tx = self.pool.begin().await?;
            sqlx::query("SELECT set_config('lock_timeout','1000ms',true),set_config('statement_timeout','1000ms',true)")
                .execute(&mut *tx).await?;
            let row: Option<(Uuid, String)> = sqlx::query_as(
                "SELECT run.binding_id, execution.step_id FROM workflow_runs AS run \
                 JOIN workflow_executions AS execution ON execution.company_id=run.company_id AND execution.run_id=run.id \
                 JOIN background_tasks AS job ON job.company_id=run.company_id AND job.workflow_execution_id=execution.id \
                 WHERE run.company_id=$1 AND run.id=$2 AND execution.id=$3 AND job.id=$4 ")
                .bind(scope.company.as_uuid()).bind(scope.run.as_uuid()).bind(scope.execution.as_uuid()).bind(scope.job.0)
                .fetch_optional(&mut *tx).await?;
            let (binding, step) = row.ok_or_else(missing)?;
            let binding = admission_binding::read_saved_binding(&mut tx, scope.company, WorkflowBindingId::new(binding), scope.run.as_uuid()).await?;
            let step = StepId::parse(step).map_err(|_| invalid())?;
            let kind = binding.bundle().compiled().graph().definition().steps.get(&step).ok_or_else(invalid)?.step_type.as_str().to_owned();
            tx.commit().await?;
            Ok(WorkflowStepKind(kind))
        }).await.map_err(|_| lease::timed_out())?
    }
}
pub(super) fn candidate(row: CandidateRow) -> AppResult<PollCandidate> {
    Ok(PollCandidate {
        scope: ActivationRequest {
            company: CompanyId::new(row.company_id),
            run: RunId::new(row.run_id),
            execution: ExecutionId::new(row.execution_id),
            job: WorkflowJobId(row.job_id),
        },
        work: match row.work.as_str() {
            "job" => PollWork::Job,
            "expired" => PollWork::ExpiredLease,
            "deadline" => PollWork::ExpiredRun,
            "exhausted" => PollWork::ExhaustedPending,
            "wait" => PollWork::Wait,
            "message_receipt" => PollWork::MessageReceipt,
            _ => return Err(invalid()),
        },
    })
}

/// An action of this execution with delivery events beyond its cursor and no backoff pending.
macro_rules! message_receipt_candidates {
    () => {
        r#"EXISTS (SELECT 1 FROM workflow_message_actions AS action
                WHERE action.company_id = execution.company_id AND action.execution_id = execution.id
                  AND action.state IN ('pending','uncertain') AND action.consume_after <= clock_timestamp()
                  AND EXISTS (SELECT 1 FROM workflow_message_delivery_events AS event
                      WHERE event.company_id = action.company_id AND event.invocation_id = action.invocation_id
                        AND event.seq > action.consumed_through))"#
    };
}

/// Shared eligibility for diagnostics and fair discovery. Neither grants ownership.
///
/// Message receipt work (04.11-D3 §E) is discovered on live, terminal and cancelled runs and
/// whether or not the execution completed: an action with unconsumed delivery events.
pub(super) const CANDIDATES_SQL: &str = concat!(
    r#"
                SELECT job.company_id, execution.run_id, execution.id AS execution_id,
                       job.id AS job_id,
                       CASE WHEN execution.completed_at IS NULL AND run.state IN ('queued','running','waiting') AND run.deadline <= clock_timestamp() THEN 'deadline'
                            WHEN "#,
    message_receipt_candidates!(),
    r#" THEN 'message_receipt'
                            WHEN wait.id IS NOT NULL THEN 'wait'
                            WHEN job.status = 'processing' THEN 'expired'
                            WHEN job.retry_count >= job.max_retries THEN 'exhausted' ELSE 'job' END AS work
                FROM background_tasks AS job
                JOIN workflow_executions AS execution
                  ON execution.company_id = job.company_id AND execution.id = job.workflow_execution_id
                JOIN workflow_runs AS run
                  ON run.company_id = execution.company_id AND run.id = execution.run_id
                LEFT JOIN workflow_waits AS wait
                  ON wait.company_id = execution.company_id AND wait.execution_id = execution.id
                 AND wait.run_id = run.id AND wait.state = 'waiting'
                WHERE ((execution.completed_at IS NULL
                  AND (
                    (run.state IN ('queued','running','waiting') AND run.deadline <= clock_timestamp())
                    OR (wait.id IS NULL AND run.state IN ('queued','running')
                     AND run.deadline > clock_timestamp()
                     AND ((job.status = 'pending' AND job.run_at <= clock_timestamp()
                           )
                          OR (job.status = 'processing' AND job.lock_expires_at <= clock_timestamp())))
                    OR (wait.id IS NOT NULL AND (
                        wait.deadline <= clock_timestamp() OR run.deadline <= clock_timestamp()
                        OR run.state IN ('cancelled','failed','succeeded')
                        -- Run-scoped events wake only event waits (05-D2 §11): a persisted,
                        -- unconsumed match, however early it arrived.
                        OR (wait.reason = 'event' AND EXISTS (SELECT 1 FROM workflow_wait_events AS event
                            WHERE event.company_id = wait.company_id AND event.run_id = wait.run_id
                              AND event.consumed_execution_id IS NULL
                              AND event.event_name = wait.event_name AND event.correlation = wait.correlation))
                        OR (wait.reason='agent_turn' AND agent_history_turn_ready(wait.company_id,wait.agent_exchange_id))
                        -- A child_run wait wakes on its child's terminal fact (07-D1 §D1.4).
                        OR (wait.reason = 'child_run' AND EXISTS (SELECT 1 FROM workflow_runs AS child
                            WHERE child.company_id = wait.company_id AND child.id = wait.child_run_id
                              AND child.terminal_wakeup_sequence IS NOT NULL))
                        -- An effect wait wakes on its action's receipt or on a finality breach
                        -- (04.11-D2 §4.4, D4 §M); otherwise only at the run deadline.
                        OR (wait.reason = 'effect' AND (
                            EXISTS (SELECT 1 FROM workflow_message_actions AS action
                                JOIN workflow_action_receipts AS receipt
                                  ON receipt.company_id = action.company_id AND receipt.invocation_id = action.invocation_id
                                WHERE action.company_id = wait.company_id AND action.execution_id = wait.execution_id
                                  AND action.wait_id = wait.id)
                            OR workflow_action_has_evidence_conflict(wait.company_id, wait.execution_id)))))
                  )) OR "#,
    message_receipt_candidates!(),
    r#")
"#
);
