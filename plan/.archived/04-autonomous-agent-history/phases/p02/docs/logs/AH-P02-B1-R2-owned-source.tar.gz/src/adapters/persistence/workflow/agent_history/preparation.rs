//! One bounded native owner captures original input before checkpoint/provider entry.
use super::*;
use crate::application::workflow::{
    agent::{PreparedAgent, PreparedStep},
    lease::{ClaimedWorkflow, LeasePolicy},
    publication::ResolvedAgent,
};

pub(super) struct LockedAgent {
    pub actor: WorkflowActor,
    pub facts: scope::Facts,
    pub selection: ResolvedAgent,
}
struct Candidate {
    prepared: PreparedAgent,
    context: Option<Context>,
}

pub(in crate::adapters::persistence::workflow) async fn prepare(
    persistence: &PostgresPersistence,
    claim: &ClaimedWorkflow,
    policy: LeasePolicy,
) -> AppResult<PreparedAgent> {
    let bound = WriteBound::start("agent_history.prepare", policy);
    let attempt = bound
        .attempt(Box::pin(async {
            let mut connection = bound.acquire(persistence.pool()).await?;
            let mut tx = bound.begin(&mut connection).await?;
            let body = async {
                let candidate = Box::pin(candidate_on(&mut tx, claim, &bound)).await?;
                let prepared = match candidate.context {
                    None => candidate.prepared,
                    Some(context) => {
                        let conversation = conversation_on(&mut tx, &context).await?;
                        let exchange = storage::enqueue_on(
                            &mut tx,
                            claim.fence,
                            conversation,
                            &candidate.prepared,
                        )
                        .await?;
                        candidate.prepared.with_history(exchange)?
                    }
                };
                if lease::live_window(&mut tx, claim.fence, bound.started())
                    .await?
                    .is_none()
                {
                    return Err(ownership_lost());
                }
                Ok(prepared)
            }
            .await;
            bound.end(tx, body.map(End::Commit)).await
        }))
        .await;
    match attempt {
        Attempt::Done(prepared) => Ok(prepared),
        Attempt::Failed(error) => Err(error),
        Attempt::Ambiguous => {
            bound
                .resolve(Box::pin(async {
                    let mut connection = bound.acquire(persistence.pool()).await?;
                    let mut tx = bound.begin(&mut connection).await?;
                    let body = async {
                        let candidate = Box::pin(candidate_on(&mut tx, claim, &bound)).await?;
                        let Some(context) = candidate.context else {
                            return Ok(Evidence::Applied(candidate.prepared));
                        };
                        let Some(conversation) = find_on(&mut tx, &context).await? else {
                            return Ok(Evidence::NotApplied);
                        };
                        Ok(
                            match storage::matching_on(
                                &mut tx,
                                claim.fence,
                                conversation,
                                &candidate.prepared,
                            )
                            .await?
                            {
                                Some(exchange) => {
                                    Evidence::Applied(candidate.prepared.with_history(exchange)?)
                                }
                                None => Evidence::NotApplied,
                            },
                        )
                    }
                    .await;
                    bound.roll_back(tx, body).await
                }))
                .await
        }
    }
}

pub(super) async fn locked_on(
    tx: &mut Transaction<'_, Postgres>,
    fence: WorkflowFence,
    bound: &WriteBound,
) -> AppResult<LockedAgent> {
    let action = ActionScope {
        company: fence.scope.company,
        run: fence.scope.run,
        execution: fence.scope.execution,
    };
    let actor = action_authority::prelock_on(tx, action)
        .await?
        .ok_or_else(missing)?;
    let facts = scope::facts_on(tx, action, actor).await?;
    let association = binding_rows::association_from_columns(facts.channel_id, facts.thread_id)?;
    association::authorize_association(tx, action.company, actor, association).await?;
    let selection =
        agent_manifest::execution_selection_on(tx, action, actor, &facts.bundle).await?;
    agent_authority::check_execution_on(tx, action, selection.agent(), selection.mode()).await?;
    // Global account/company/association/agent authority precedes the native local fence.
    if !checkpoints::lock_owner(tx, fence, bound).await? {
        return Err(ownership_lost());
    }
    Ok(LockedAgent {
        actor,
        facts,
        selection,
    })
}

async fn candidate_on(
    tx: &mut Transaction<'_, Postgres>,
    claim: &ClaimedWorkflow,
    bound: &WriteBound,
) -> AppResult<Candidate> {
    let LockedAgent {
        actor,
        facts,
        selection,
    } = locked_on(tx, claim.fence, bound).await?;
    if facts.step != claim.activation.step || facts.inputs != claim.activation.inputs {
        return Err(missing());
    }
    let prepared = build(selection, &facts)?;
    let context = if agent_history_eligible(facts.kind) {
        let action = ActionScope {
            company: claim.fence.scope.company,
            run: claim.fence.scope.run,
            execution: claim.fence.scope.execution,
        };
        Some(Context {
            company: action.company,
            actor,
            agent: prepared.selection().agent().agent_id,
            boundary: scope::boundary_on(tx, action, actor, &facts).await?,
        })
    } else {
        None
    };
    Ok(Candidate { prepared, context })
}

fn build(selection: ResolvedAgent, facts: &scope::Facts) -> AppResult<PreparedAgent> {
    let step = match facts.kind {
        ModelStep::AgentRun => PreparedStep::AgentRun {
            targets: agent_preparation::targets(selection.agent().company_id, selection.tools())?,
        },
        ModelStep::Classify => PreparedStep::Classify,
        ModelStep::Decide => PreparedStep::Decide {
            contract: facts
                .bundle
                .compiled()
                .step_output_schema(&facts.step)
                .cloned()
                .ok_or_else(invalid)?,
        },
    };
    PreparedAgent::new(selection, &facts.inputs, step)
}
