use super::*;
use crate::adapters::persistence::workflow::tests::admission_tests::lease_tests::resolution_gate::{Gate,Stall,connect};

async fn delete(f: &ModelFixture) -> Result<sqlx::postgres::PgQueryResult, sqlx::Error> {
    sqlx::query("DELETE FROM agent_history_exchanges WHERE company_id=$1 AND execution_id=$2")
        .bind(f.write.fence.scope.company.as_uuid())
        .bind(f.write.fence.scope.execution.as_uuid())
        .execute(f.native.fixture.persistence().pool())
        .await
}

#[tokio::test]
async fn agent_history_storage_failed_exchange_delete_and_actual_control_retry_do_not_deadlock() {
    let f = Box::pin(settled_history()).await;
    fail(&f).await;
    let original = exchange(&f).await;
    let scope = f.write.fence.scope;
    let fixture = &f.native.fixture;
    let condition = format!(
        "NEW.id='{}'::uuid AND OLD.status='failed' AND NEW.status='pending'",
        scope.job.0
    );
    let mut gate = Gate::arm(
        fixture,
        "background_tasks",
        "UPDATE",
        &condition,
        Stall::Statement {
            table: "background_tasks",
            events: "UPDATE",
            when: &condition,
        },
    )
    .await;
    let command = control(&f, "delete-versus-retry").await;
    let retry = RetryCommand {
        company_id: command.company_id,
        run_id: command.run_id,
        actor: command.actor,
        command_key: command.command_key,
        expected_revision: command.expected_revision,
    };
    let p = fixture.persistence().clone();
    let pending = tokio::spawn(async move { p.retry(retry).await });
    let (mut observer, _) = connect(fixture).await;
    gate.stalled(&mut observer, &[&|| !pending.is_finished()])
        .await;
    let error = tokio::time::timeout(Duration::from_secs(2), delete(&f))
        .await
        .unwrap()
        .unwrap_err();
    assert_eq!(
        error.as_database_error().unwrap().code().as_deref(),
        Some("55P03")
    );
    gate.drain().await;
    assert!(matches!(
        pending.await.unwrap().unwrap(),
        RetryResult::Applied { .. }
    ));
    let queued = exchange(&f).await;
    assert_eq!(queued["state"], "queued");
    for field in [
        "id",
        "position",
        "checkpoint_id",
        "input_digest",
        "provenance",
    ] {
        assert_eq!(queued[field], original[field], "{field}");
    }
}

#[tokio::test]
async fn agent_history_storage_expired_failed_exchange_can_release_its_source_pin() {
    let f = Box::pin(settled_history()).await;
    fail(&f).await;
    let p = f.native.fixture.persistence();
    // Isolated fixture time travel; restore the native snapshot guard before DELETE/retry.
    sqlx::raw_sql("ALTER TABLE workflow_runs DISABLE TRIGGER workflow_run_snapshot_immutable; UPDATE workflow_runs SET created_at=clock_timestamp()-interval '2 minutes',deadline=clock_timestamp()-interval '1 minute'; SET CONSTRAINTS ALL IMMEDIATE; ALTER TABLE workflow_runs ENABLE TRIGGER workflow_run_snapshot_immutable")
        .execute(p.pool()).await.unwrap();
    assert_eq!(delete(&f).await.unwrap().rows_affected(), 1);
    let command = control(&f, "expired-retry").await;
    let result = p
        .retry(RetryCommand {
            company_id: command.company_id,
            run_id: command.run_id,
            actor: command.actor,
            command_key: command.command_key,
            expected_revision: command.expected_revision,
        })
        .await
        .unwrap();
    assert!(!matches!(result, RetryResult::Applied { .. }));
    let count: i64 =
        sqlx::query_scalar("SELECT count(*) FROM agent_history_exchanges WHERE company_id=$1")
            .bind(f.write.fence.scope.company.as_uuid())
            .fetch_one(p.pool())
            .await
            .unwrap();
    assert_eq!(count, 0);
}

#[tokio::test]
async fn agent_history_storage_nonresumable_failed_exchange_can_be_deleted_before_deadline() {
    use crate::domain::workflow::{FailureClass, FailureCode, RetrySafety, StepFailure};
    let f = Box::pin(settled_history()).await;
    let p = f.native.fixture.persistence();
    let failure = WorkflowFailure {
        failure: StepFailure::new(
            FailureClass::Terminal,
            FailureCode::parse("agent.budget").unwrap(),
            None,
        )
        .unwrap(),
        safety: RetrySafety::SafeToRetry,
    };
    p.settled()
        .release_io(
            f.write.fence,
            f.write.lease_policy,
            LeaseReleaseCause::Classified(failure),
        )
        .await
        .unwrap();
    assert_eq!(exchange(&f).await["state"], "failed");
    assert_eq!(delete(&f).await.unwrap().rows_affected(), 1);
}

#[tokio::test]
async fn agent_history_storage_company_teardown_removes_even_retryable_failed_exchange() {
    let f = Box::pin(settled_history()).await;
    fail(&f).await;
    let p = f.native.fixture.persistence();
    let company = f.write.fence.scope.company.as_uuid();
    sqlx::query("DELETE FROM companies WHERE id=$1")
        .bind(company)
        .execute(p.pool())
        .await
        .unwrap();
    let count: i64 =
        sqlx::query_scalar("SELECT count(*) FROM agent_history_exchanges WHERE company_id=$1")
            .bind(company)
            .fetch_one(p.pool())
            .await
            .unwrap();
    assert_eq!(count, 0);
}
