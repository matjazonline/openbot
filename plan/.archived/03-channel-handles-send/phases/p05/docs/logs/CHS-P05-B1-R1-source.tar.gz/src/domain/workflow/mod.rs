//! Pure workflow definitions and decisions. Validation here covers structural graph
//! integrity and bounded context construction; schema, resource authorization,
//! expression compilation, and publication checks belong to later layers.

mod budget;
mod causality;
mod context;
mod definition;
mod evidence;
mod expression;
mod graph;
mod ids;
mod outcome;
mod recovery;
mod reply_integrity;
mod response;
mod rule;
mod state;
mod transition;
mod trigger;

pub use budget::{
    BudgetCharge, BudgetLimitError, BudgetResource, MAX_ROOT_REPETITIONS, RootBudgetLimits,
    TokenAllowance, TokenRefusal,
};
pub use causality::{
    ActionRef, CausalError, ChildCause, ChildOrdinal, ChildStepRef, ChildToolCallRef, ExecutionRef,
    MessageEffectLink, RunCausality, StepCausality, TriggerRef, TriggerSource,
};
pub use context::{
    Binding, Comparison, Context, ContextError, ContextLimits, ContextReference, RunMetadata,
    canonical_array_index, preflight_binding, render_deadline, resolve, resolve_inputs,
    validate_context_value,
};
pub use definition::{
    ExecutionLimits, ResourceRequirement, Routes, StepDefinition, WorkflowDefinition,
};
pub use evidence::*;
pub use graph::{GraphError, ValidatedWorkflow, validate};
pub use ids::{
    ActionEvidenceId, ActionInvocationId, ActionReconciliationCommandId, ActionRemoteAttemptId,
    ActionRemoteEntryId, ActionRemoteMarkerId, BindingRevision, BindingStateRevision, ChoiceName,
    CompanyId, DraftRevision, ExecutionId, FailureCode, NameError, ResourceName, RunId,
    RuntimeResourceId, ScheduleId, ScheduleOccurrenceId, StepId, TemplateId, TemplateRevision,
    ToolCallId, TriggerId, TypeName, VersionId, WaitId, WorkflowBindingId, WorkflowId,
};
pub use ids::{ChannelReplyId, ReplyProposalId};
pub use outcome::{
    CompletedStep, CompletionRoute, DurableWaitRequest, EngineDisposition, FailureClass,
    KNOWLEDGE_AUDIENCE_BELOW_CONTENT, KnowledgeRefusal, OutcomeError, RetryEligibility,
    StepFailure, StepOutcome, resolve_outcome,
};
pub use recovery::{
    AttemptBudget, RecoveryDecision, RecoveryLimit, RecoveryPolicy, RecoveryPolicyError,
    RecoverySnapshot, RetrySafety,
};
pub use reply_integrity::ReplyIntegrity;
pub use response::{InvalidResponseDisposition, ResponseDisposition};
pub use rule::{OrderedRule, RuleCase, RuleError};
pub use state::{RunState, RunStateError, WaitingReason};
pub use transition::{RouteError, RouteSelection, TransitionTarget, select_route};
pub use trigger::{MAX_MESSAGE_BINDINGS_PER_CHANNEL, MessageFacts, MessageTrigger};
