use std::fmt;
use thiserror::Error;
use uuid::Uuid;

pub const MAX_NAME_BYTES: usize = 128;

#[derive(Debug, Clone, PartialEq, Eq, Error)]
pub enum NameError {
    #[error("name must be 1..={MAX_NAME_BYTES} ASCII bytes and start with a letter or underscore")]
    Invalid,
    #[error("$end is reserved as a transition target")]
    Reserved,
}

fn valid_part(value: &str) -> bool {
    value.len() <= MAX_NAME_BYTES
        && value
            .as_bytes()
            .first()
            .is_some_and(|c| c.is_ascii_alphabetic() || *c == b'_')
        && value.as_bytes()[1..]
            .iter()
            .all(|c| c.is_ascii_alphanumeric() || *c == b'_' || *c == b'-')
}

macro_rules! name_type {
    ($name:ident, $dotted:expr) => {
        #[derive(Debug, Clone, PartialEq, Eq, PartialOrd, Ord, Hash, serde::Serialize)]
        #[serde(transparent)]
        pub struct $name(String);

        impl<'de> serde::Deserialize<'de> for $name {
            fn deserialize<D: serde::Deserializer<'de>>(decoder: D) -> Result<Self, D::Error> {
                let value = <String as serde::Deserialize>::deserialize(decoder)?;
                Self::parse(value).map_err(serde::de::Error::custom)
            }
        }

        impl $name {
            pub fn parse(value: impl AsRef<str>) -> Result<Self, NameError> {
                let value = value.as_ref();
                if value == "$end" {
                    return Err(NameError::Reserved);
                }
                let valid = if $dotted {
                    value.len() <= MAX_NAME_BYTES && value.split('.').all(valid_part)
                } else {
                    valid_part(value)
                };
                if !valid {
                    return Err(NameError::Invalid);
                }
                Ok(Self(value.to_owned()))
            }

            pub fn as_str(&self) -> &str {
                &self.0
            }
        }

        impl fmt::Display for $name {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                self.0.fmt(f)
            }
        }
    };
}

name_type!(StepId, false);
name_type!(ChoiceName, false);
name_type!(ResourceName, false);
name_type!(TypeName, true);
name_type!(FailureCode, true);
name_type!(TemplateId, false);

macro_rules! positive_revision {
    ($name:ident) => {
        #[derive(Debug, Clone, Copy, PartialEq, Eq)]
        pub struct $name(std::num::NonZeroU64);
        impl $name {
            pub fn new(value: u64) -> Option<Self> {
                std::num::NonZeroU64::new(value).map(Self)
            }
            pub fn get(self) -> u64 {
                self.0.get()
            }
        }
    };
}
positive_revision!(TemplateRevision);
positive_revision!(DraftRevision);
positive_revision!(BindingRevision);
positive_revision!(BindingStateRevision);

macro_rules! uuid_type {
    ($name:ident) => {
        #[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash, serde::Serialize)]
        #[serde(transparent)]
        pub struct $name(Uuid);
        impl<'de> serde::Deserialize<'de> for $name {
            fn deserialize<D: serde::Deserializer<'de>>(decoder: D) -> Result<Self, D::Error> {
                <Uuid as serde::Deserialize>::deserialize(decoder).map(Self)
            }
        }
        impl $name {
            pub fn new(value: Uuid) -> Self {
                Self(value)
            }
            pub fn as_uuid(self) -> Uuid {
                self.0
            }
        }
        impl fmt::Display for $name {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                self.0.fmt(f)
            }
        }
    };
}

uuid_type!(WorkflowId);
uuid_type!(VersionId);
uuid_type!(CompanyId);
uuid_type!(RunId);
uuid_type!(ExecutionId);
uuid_type!(TriggerId);
uuid_type!(ScheduleId);
uuid_type!(ScheduleOccurrenceId);
uuid_type!(ActionInvocationId);
uuid_type!(ActionEvidenceId);
uuid_type!(ActionReconciliationCommandId);
uuid_type!(ActionRemoteMarkerId);
uuid_type!(ActionRemoteEntryId);
uuid_type!(ActionRemoteAttemptId);
uuid_type!(WaitId);
uuid_type!(WorkflowBindingId);
uuid_type!(RuntimeResourceId);
// The saved model tool call of an agent execution (07-D2 §D2.3): the harness invocation
// identity, persisted before dispatch, which identifies the child a workflow tool call creates.
uuid_type!(ToolCallId);
uuid_type!(ReplyProposalId);
uuid_type!(ChannelReplyId);

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn checked_names() {
        for bad in ["", "0bad", "bad.dot", "$end", "é", "a".repeat(129).as_str()] {
            assert!(StepId::parse(bad).is_err(), "{bad}");
        }
        assert!(StepId::parse("valid_2-name").is_ok());
        assert!(TypeName::parse("agent.run").is_ok());
        assert!(TypeName::parse("agent..run").is_err());
    }
}
