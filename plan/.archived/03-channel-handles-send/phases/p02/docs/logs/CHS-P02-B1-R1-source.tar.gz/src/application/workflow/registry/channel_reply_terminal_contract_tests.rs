use super::tests::{changed, compile_example, step};
use super::*;
use uuid::Uuid;

#[test]
fn channel_reply_terminal_contract_roundtrip_and_identity() {
    let sample = example("channel.no_reply").unwrap();
    let compiled = compile_example(&sample).unwrap();
    let roundtrip = compile(
        crate::adapters::workflow_source::decode(compiled.source()).unwrap(),
        VersionId::new(Uuid::nil()),
        &sample.facts,
        &sample.dependencies,
    )
    .unwrap();
    assert_eq!(roundtrip.representation(), compiled.representation());
    assert_eq!(compiler::SEMANTIC_REVISION, 8);
    assert_eq!(
        compiled.representation()["descriptors"]["start"]["registration"]["revision"],
        CONTRACT_REVISION
    );
    assert_eq!(
        metadata::constraints("channel.no_reply").effect,
        EffectClass::Pure
    );
    let ordinary = compile_example(&example("data.map").unwrap()).unwrap();
    assert_ne!(compiled.representation(), ordinary.representation());
}

#[test]
fn channel_reply_terminal_contract_rejects_nonterminal_and_choice_routes() {
    for routes in [json!({"success":"next"}), json!({"choices":{"yes":"$end"}})] {
        let mut sample = example("channel.no_reply").unwrap();
        changed(&mut sample, |source| {
            source["steps"]["start"]["routes"] = routes;
            source["steps"]["next"] = json!({"type":"data.map","with":{
                "value":{"literal":"done"},"output_schema":{"literal":true}},"routes":{"success":"$end"}});
        });
        assert_eq!(
            compile_example(&sample).err().unwrap().code,
            "registry.terminal_route"
        );
    }
}

#[test]
fn channel_reply_terminal_contract_retains_error_routing_and_typed_value() {
    let mut sample = example("channel.no_reply").unwrap();
    changed(&mut sample, |source| {
        source["steps"]["start"]["routes"]["error"] = json!("recover");
        source["steps"]["recover"] = json!({"type":"data.map","with":{
            "value":{"literal":"recovered"},"output_schema":{"literal":true}},"routes":{"success":"$end"}});
    });
    let compiled = compile_example(&sample).unwrap();
    assert!(compiled.validate_step_output(&step(), &json!(7)).is_err());
    assert!(
        compiled
            .validate_step_output(&step(), &json!("done"))
            .is_ok()
    );
}

#[test]
fn channel_reply_terminal_contract_accepts_schema_valid_empty_business_values() {
    for value in [json!(null), json!(""), json!({}), json!([])] {
        let mut sample = example("channel.no_reply").unwrap();
        changed(&mut sample, |source| {
            source["steps"]["start"]["with"] = json!({
                "value":{"literal":value},"output_schema":{"literal":true}});
        });
        let compiled = compile_example(&sample).unwrap();
        compiled.validate_step_output(&step(), &value).unwrap();
        compiled.validate_output(&value).unwrap();
    }
}
