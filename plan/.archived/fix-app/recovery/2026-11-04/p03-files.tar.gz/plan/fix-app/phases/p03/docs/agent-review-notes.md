# FIXAPP-P03 agent review notes

## FIXAPP-P03-G1-R1 — architecture gate G1, decision revision r1

### Identity

- Date 2026-11-01. Workflow `implement-opus-reviewed-2_2`.
- Records:
  - task: `TASK.md` ("Architecture gate G1 — decision revision r1");
  - review record: `REVIEW.md`;
  - findings: `agent-review-findings.md`.
- Batch: phase p03 (plan 03, batches 1–4). Stage: architecture gate G1. Reviewer B: Opus 5.5 /
  xhigh (independent reviewer subagent).
- Phase p03, worktree `/Users/mac03/dev/openbot/.worktrees/fix-app-p03`, branch `fix-app/p03`.
- Phase start and review base: `48626a1`. HEAD: `48626a1240f032ca3b99372bd3f5a05eb08c0c66`.
- Artifact digest `c325eea2f3e71d55bbb4f3c5acdfb0df01515171e063db16d2366218d4aa3462`
  (exclusion `plan/fix-app/phases/p03/docs`). Confirmed with `snapshot.sh` at start and again
  before returning; the working tree holds only the phase records.
- Gated decisions: D1–D4, revision r1. TASK.md sha256
  `61469d8e708e39f1d467aac611f99570f3ce867f94ef56a2cdd8119ddfc6e0a7`, confirmed at start and
  end. D5–D7 were read for context but are not gated.
- Coordination: `/Users/mac03/dev/openbot/plan/fix-app/COORDINATION.md`, revision 4.
  - Byte-identical to the immutable copy `logs/coordination-r4.md` at start and at end (`diff -q`).
  - Applicable: fix-app-I001 r1, I002 r1, I003 r1, I004 r1, C001 r1, C002 r1, C005 r1.
  - Freshness: no revision change during the review, so no changed applicable requirement.
- Original requirements: `plan/fix-app/03-workflow-database-guards.md`, `plan/fix-app/README.md`.
  Instructions: `AGENTS.md`, `src/AGENTS.md`, `src/application/AGENTS.md`,
  `src/adapters/persistence/AGENTS.md`, `src/adapters/http/AGENTS.md`.

### Coverage and evidence

All evidence is code inspection at HEAD, plus one Postgres probe. No cargo command was run; none
is needed for a decision gate, and fix-app-I004 forbids the full suite.

**D1 — identification.** Re-counted the RAISEs in init-schema functions whose names contain
`workflow`:

- 130 in total: 115 × 23514, 11 × P0001, 1 × 54000, and 3 × 23503 in
  `validate_workflow_job_association`, which is excluded. That leaves 127, matching TASK.md's ~127.
- The four pre-existing constraint names match TASK.md.
- Probe (`logs/g1-r1-probe-raise-constraint.log`, throwaway database, created and dropped): a
  deferred trigger's `RAISE ... USING CONSTRAINT='workflow_guard:x'` reaches the client at COMMIT
  for both 23514 and default P0001.
- No production code string-matches error text.
- `decisions.rs::closed_at_commit` inspects the raw `sqlx::Error`, so the remapping does not
  affect it.

**D1 — mapping and consumers.**

- `From<sqlx::Error>` (`persistence/mod.rs:105-117`).
- Exhaustive `AppError` matches: `app_error_impl.rs`, `inbound_event_worker.rs:658`.
- Wildcard consumers: `actions/failure.rs:99-112`, `message_runtime.rs:540-580`,
  `harness/rig/workflow.rs:402-416`, `message_admission.rs:444-461`.
- `persistence_bound.rs` classifies a COMMIT refusal as `Failed`, not `Ambiguous`, so guard errors
  do propagate (`:217-226`).

**D1 — worker and failure transaction.**

- Read `worker.rs` in full, plus `CANDIDATES_SQL` and the scope for each `PollWork` kind
  (`polling.rs:62-160`).
- Lock order and effects: `maintenance.rs`, `controls.rs:173-230`, `recovery.rs:60-270`,
  `lease.rs:66-420`, `completion.rs:23-130`.
- `check_workflow_fenced_retirement`, `check_workflow_fenced_completion`,
  `check_workflow_control_retry`, `workflow_control_retry_safe`, `..._reopen_safe`.
- Message receipt consumption swallows per-action errors with backoff
  (`message_receipts.rs:27-62`), so receipts never reach the wrapper. That part is fine.

**D1 — challenged assumptions.**

- Deferral rules. They miss the retirement race and do not check that the scope execution is still
  current (F1). Wait deadlines are not deferred (F5).
- Coverage of handler-internal guards and the C001 claim (F2).
- Children (F3).
- The "never retry-safe" claim (F4).
- The metric owner: `metrics.rs` gauges versus counters. In-process counters have precedent in
  `schedule_admission.rs` and `message_admission.rs`, so no finding.

**D2 — transition table.**

- Checked every real writer of `workflow_runs.state`:
  - 26 Rust UPDATEs in 17 files;
  - SQL `workflow_action_conflict_park_pending` (`init_schema.sql:2206`);
  - the test fixture SQL.
- Every non-test writer fits the r1 table, including queued→waiting, queued→succeeded/failed,
  waiting→waiting re-park, reconciliation reopen from waiting only (`settlement.rs:181-221`), and
  cancel from live states only.
- `waiting → succeeded` never happens directly: every resume path sets `running` before
  `batch_commit`.

**D2 — trigger order and retry edge.**

- Listed every trigger on `workflow_runs`, including multi-line ones. All BEFORE triggers start
  with `workflow_`, so `guard_…` fires first.
- `workflow_control_retry_safe` does not test the job's status, so evaluating it in a BEFORE
  trigger after `retry_on` has reopened the job is consistent with the deferred
  `check_workflow_control_retry`.

**D2 — `terminal_execution_id`.**

- Inventory checked against the code: every writer of `failed` or `succeeded` is listed. The
  `wait_commit` `expire`/`fail` gap and the `child_waits.rs:264` follow-up are correctly
  identified.
- The follow-up must go: with an immediate CHECK, the `fail` UPDATE would otherwise violate it.
- The retry-eligibility claim holds for the `wait_commit` paths (their job is not `failed`;
  TASK.md says "completed", but for timer/event steps it is `pending`, with the same conclusion).
- `workflow_run_terminal_execution_fk` is already composite, scoped by run.

**D3 — root budgets.**

- FK and trigger order verified:
  - root budget → run FK is deferrable;
  - run_budgets.root → root_budgets FK is immediate;
  - usage → root_budgets FK is immediate;
  - `preserve_workflow_budget_usage`'s INSERT branch has no dependence on trigger depth.
- Compiled `root_budget` equals `definition.limits.root_budget` with `limit()` and token policy
  (`compile.rs:709-725`). The SQL reads the root version's compiled `root_budget`, which
  `PublishedBundle::compiled()` also returns.
- Every provenance reference is covered by D3: `init_schema.sql:477`, `:2584`, `:5514-5521`,
  `token_budget.rs:94`, the validate SQL and the schema tests.
- `admission_write::insert_run` is the only non-test insert site for runs. Reruns and schedules go
  through `create`.
- No defect found.

**D4 — lease renewal.** Renewal statement at `lease.rs:85` checked. The decision is sound;
verification is vacuous (F6.5); optional completeness item in F8.

**Instructions checked.** Persistence `AGENTS.md`:

- "Encode queue state machines as constraints" plus the equivalence matrix: D2 complies.
- "Fence leases": D4.
- "Audited transitions carry typed reason": the guard name comes from a structured field.

Root `AGENTS.md` competing-claimant rule: F1. Application `AGENTS.md` poison-batch rule: F6.6.

**Reviewed lightly.**

- D5–D7: not gated, read only.
- The ~44 test fixtures that update run state: sampled, not individually checked (F6.3 asks for an
  inventory).
- Guard functions outside the `workflow` naming rule: listed, not analysed one by one (F7).

### Outcome

**Changes required** for decision revision r1. No PASS.

- Actionable:
  - FIXAPP-P03-G1-F1 (High): the failure transaction misclassifies a lost-lease race that a
    competing retirement settles first, and does not check the scope execution is current.
  - FIXAPP-P03-G1-F2 (High): guard errors inside handler-owned transactions never reach the
    wrapper; the C001 response is incorrect; the handler-contract decision is missing.
  - FIXAPP-P03-G1-F3 (Medium): live children are not cascaded; the deadline-equivalence rationale
    is false.
  - FIXAPP-P03-G1-F4 (Low): "a guard failure is never retry-safe" is false for pending-job guard
    failures.
  - FIXAPP-P03-G1-F5 (Low): wait-deadline time races are not deferred.
  - FIXAPP-P03-G1-F6 (Low): verification plan gaps.
- Optional: FIXAPP-P03-G1-F7, FIXAPP-P03-G1-F8.
- D2, D3 and D4 have no acceptance-blocking defect of their own. F4 touches D2's retry edge only
  through D1's claim, and F6 items 2–5 are verification-plan corrections. The recheck must cover
  D1 in full. For D2–D4 it can be limited to the F4 and F6 deltas, unless the corrections change
  them.
- Unresolved questions:
  - F2's choice between options (a) and (b) is the author's to make and record.
  - F3: cascade or justify.

### Process and instruction feedback

- Batch and gate size were appropriate. One gate for D1–D4 was reviewable in one pass. D1 alone
  carries the concurrency and contract risk, and gating it was justified: F1 and F2 would be
  costly to unwind after the port, wrapper and handler mappings exist.
- TASK.md was demonstrably useful:
  - accurate writer inventories (D2), RAISE counts (D1) and provenance references (D3);
  - a clear statement of invariants, which made F1, F3 and F4 checkable against code.
- What TASK.md was missing:
  - the actors competing for the run lock after a failed commit (F1);
  - the error's consumers after `From<sqlx::Error>` (F2).
- Candidate instructions are recorded in F1, F2 and F6 under "Instruction lesson":
  - competing owners for compensating transactions;
  - trace consumers of a reclassified error;
  - grep tests for assertions on the changed error fields.
  Each is supported by one case in this phase only, so treat them as candidates, not established
  patterns.
- All findings are defects in gated decisions. There is no implementation yet.

---

## Working notes saved mid-review (2026-11-01, kept for continuity; superseded by the entry above)

Candidate findings identified by inspection before final write-up:

1. Lease-retirement race in D1's deferral (became F1).
2. Wrong C001 response for handler-internal guards (became F2).
3. Children not cascaded (became F3).
4. "Never retry-safe" claim (became F4).
5. Wait-deadline races (became F5).
6. Verification gaps (became F6).

## Follow-up to FIXAPP-P03-G1-R1 (2026-11-01, during recheck R2)

R1 missed one gap in r1 step 2. A guard trip at the `RunExpiry` site was deferred whenever the scope
job was `processing` with an expired lease. After the deadline nothing else settles such a job, so
the deferral is unbounded. The gap persists in r2's rule 5 and is now logged as FIXAPP-P03-G1-F9
(together with a related rule-4 issue r2 introduced). R1's outcome (changes required) is unchanged;
the miss is recorded for later evaluation. Cause: R1 checked the deferral rules against the
competing owners of the `Step` and `LeaseExpiry` sites, but not against the `RunExpiry` site's own
job states.

---

## FIXAPP-P03-G1-R2 — correction recheck, decision revision r2

### Identity

- Date 2026-11-01. Workflow `implement-opus-reviewed-2_2`.
- Records: `TASK.md` (section "G1 decision revision r2 — responses to FIXAPP-P03-G1-R1"; the r1
  text above it is preserved and was spot-checked unchanged), `REVIEW.md`,
  `agent-review-findings.md`.
- Batch: phase p03. Stage: architecture gate G1 correction recheck. Reviewer B: Opus 5.5 / xhigh,
  the same reviewer instance as R1, resumed.
- Phase p03, worktree `/Users/mac03/dev/openbot/.worktrees/fix-app-p03`, branch `fix-app/p03`.
  Review base `48626a1`, HEAD `48626a1240f032ca3b99372bd3f5a05eb08c0c66`.
- Decision under review: revision r2, TASK.md sha256
  `bb318b3df60479a1d38f44abd9dd05d69a49918c2f585c1859c790ada448f9a7`. Confirmed at start and end.
- Working-tree digest at recheck: `4c4d8ed41059c06725a679f1c02cdff8d971865c3b251b23494e801c93adc5ac`
  (exclusion `plan/fix-app/phases/p03/docs`).
  - It differs from R1's `c325eea2…` only by A's announced, ungated batch-4 edit to
    `src/domain/entities/transport/delivery.rs` (D5).
  - The gate reviews decision text, so that file is outside this recheck. A will freeze a new
    digest for batch review B1.
  - At the end of the recheck the digest was `a99f7816d3b9dd12ad26fbd68113258ce5b59ea9aaf0a09304ad8166b8778afd`.
    A's further ungated D6 edits produced it; `git diff --stat` shows:
    - `init_schema.sql`: `token_refusal` CHECK and `refuse_expired_workflow_tokens` only;
    - `harness_token_refusal_tests.rs`;
    - `domain/workflow/budget.rs`;
    - `delivery.rs`.
    None touches a D1–D4 statement. Incidentally, D6 no longer refuses the root on a cancelled
    token wait, which removes the D6 interaction noted under F3's cascade. Batch review B1 will
    verify it.
- Gated decisions: D1–D4. Coordination is revision 4, byte-identical to `logs/coordination-r4.md`
  at start and end, with the same applicable notices as R1 and no changed requirement.

### Coverage and evidence

Recheck by finding ID against r2's text and the code it relies on. Inspection only; no checks run.

- **F1, retirement race.** Verified that r2's confirmation re-run handles the retirement-first
  interleaving:
  - `complete_on` locks the run, then `lock_job` refuses a settled fence (`completion.rs:78-95`).
  - Rule 5's exact-fence deferral, the rule-2 currency check and the READ COMMITTED reasoning are
    correct.
- **F2, handler-internal guards.** Verified the handler mappings r2 changes and the guard lists.
  - `StepFailure::new` accepts a bounded diagnostic (`outcome.rs:99-117`).
  - Failure codes are length-checked only (`init_schema.sql:4196`).
  - Receipt consumption absorbs per-action errors (`message_receipts.rs:27-62`, `:213-233`), so
    one entry in the guard list is inaccurate (F11).
- **F3, cascade.** The cascade's lock order matches `cancel_tree_on` (`controls.rs:173-197`).
- **F4, retry safety.** The exclusion is inherited by `check_workflow_control_retry` and by D2's
  trigger.
- **F5, wait deadlines.** Confirmation covers the race; the residual is acceptable.
- **F6–F8.** Adopted as recorded.
- **New checks against the r2 deferral rules:**
  - Claim and renewal leases are capped at the run deadline (`lease_claim.rs:168`, `lease.rs:85`).
  - The `CANDIDATES_SQL` CASE order puts `deadline` before `expired`.
  - `finish_job` requires a live lease unless the cause is expiry (`recovery.rs:213`).
  - The resume and timeout paths are in `wait_commit.rs:5-191`.
  These lead to F9.
- **New check on the confirmation wording:** read `worker.rs:177-202` against r2's confirmation
  rule. This leads to F10.
- Not rechecked: D2, D3 and D4 beyond the r2 deltas, which are unchanged and so reuse R1's
  evidence.

### Outcome

**Changes required** for revision r2. No PASS yet.

- Resolved at decision level, with implementation and tests to be verified in B1:
  - F1 fixed;
  - F2 fixed, option (b);
  - F3 fixed;
  - F4 fixed;
  - F5 fixed, with one documented residual;
  - F6 fixed (plan);
  - F7 declined with reason, closed;
  - F8 fixed, closed.
- New actionable findings:
  - FIXAPP-P03-G1-F9 (Medium): rules 4 and 5 defer to the owner that just failed. At `RunExpiry`
    the deferral is unbounded past the deadline (also present in r1; missed in R1). At a `Wait`
    site's timeout path it spins until the deadline.
  - FIXAPP-P03-G1-F10 (Low): the confirmation contract at the `complete_io` site needs stating,
    plus a site test.
- Optional: FIXAPP-P03-G1-F11, an accuracy fix for the receipt-consumption guard list.
- The next recheck can be limited to the F9 and F10 deltas, plus the F11 wording if adopted.

### Process and instruction feedback

- The correction round was efficient. Each response is traceable to its finding ID. Confirmation
  by re-execution is a clean, uniform answer to time races.
- The new defect (F9) came from deferral rules that name an owner without checking that the owner
  differs from the failing operation. The candidate instruction is recorded in F9.
- This reviewer missed the rule-5 instance in R1 (follow-up above). That is evidence that
  per-site enumeration of job states should be part of reviewing a compensating transaction, not
  only competing actors.

---

## FIXAPP-P03-G1-R3 — correction recheck, decision revision r3: **PASS**

### Identity

- Date 2026-11-01. Workflow `implement-opus-reviewed-2_2`.
- Records: `TASK.md` (section "G1 decision revision r3 — responses to FIXAPP-P03-G1-R2"; r1 and
  r2 text preserved, spot-checked), `REVIEW.md`, `agent-review-findings.md`.
- Stage: architecture gate G1 correction recheck. Reviewer B: Opus 5.5 / xhigh, the same instance
  as R1 and R2, resumed.
- Phase p03, worktree `/Users/mac03/dev/openbot/.worktrees/fix-app-p03`, branch `fix-app/p03`.
  Review base `48626a1`, HEAD `48626a1240f032ca3b99372bd3f5a05eb08c0c66`.
- Decision under review: revision r3, TASK.md sha256
  `bb5e48e479581a889125faac1b3ae2677a07874db4affe31b669b412f4cfd864`. Confirmed at start and end.
- Working-tree digest `a99f7816d3b9dd12ad26fbd68113258ce5b59ea9aaf0a09304ad8166b8778afd`
  (exclusion `plan/fix-app/phases/p03/docs`), confirmed at start and end. It is the same as at the
  end of R2: only A's ungated D5/D6 edits, none touching D1–D4.
- Coordination: revision 4, byte-identical to `logs/coordination-r4.md` at start and end. The
  applicable notices are I001–I004 r1, C001 r1, C002 r1 and C005 r1; there is no changed
  requirement.

### Coverage and evidence

The recheck is limited to the F9, F10 and F11 deltas, as agreed. All other evidence is reused from
R1 (D2–D4 full review, D1 r1) and R2 (D1 r2, D2/D4 r2 deltas); the decision text it rests on is
unchanged. Inspection only; no checks run.

- **F9.**
  - Rule 4 is gone.
  - Rule 5 at `RunExpiry` admits any job state. This matches `retire_jobs`, which handles
    `processing` (live or expired) and `pending` jobs (`maintenance.rs:58-79`), and `expire_on`'s
    own currency check (`:22-27`).
  - Rule 3 is not circular. `resume_on` runs `expire_on` itself (`wait_commit.rs:8`, `:48`), but
    the next poll classifies the work as `deadline` (`polling.rs` `CANDIDATES_SQL`) and reaches
    `expire_run` at site `RunExpiry`.
  - Every remaining deferral in the r3 final list has a distinct settling owner, or leaves no
    candidate to loop on. Details are in F9's resolution entry.
- **F10.**
  - `execute_io` (`worker.rs:177-202`) now confirms and acts internally, with the claim fence, and
    never re-raises. So the wrapper's candidate re-run applies only to errors raised before any
    handler ran (`claim_io` or earlier).
  - Test specified: one claim, one handler execution, retirement `guard`, two empty polls.
- **F11.** The list correction was adopted. In the F11 resolution I noted that
  `workflow_message_reopen_guard` also fires at worker level through `continue_delivery`; r2's
  "site decides" already covers it.

### Outcome

**PASS for architecture gate G1, decision revision r3 (decisions D1–D4).**

- Every G1 finding has a disposition: F1–F6, F9 and F10 fixed at decision level; F7 declined with
  reason (closed); F8 fixed (closed); F11 adopted (closed). No acceptance-blocking defect remains
  in the decision text.
- Coverage relied on:
  - R1's full read of D1–D4 against the code: writers of run state, trigger order,
    `terminal_execution_id` writers, budget FK and trigger ordering, the error-consumer trace, the
    worker and polling paths, the retirement and expiry lock order;
  - the Postgres probe in `logs/g1-r1-probe-raise-constraint.log`;
  - R2's and R3's delta checks.
- This is a decision pass, not an implementation pass. Batch review B1 must verify the following
  (D1 r2's "F6 verification additions", D1 r2 confirmation and deferral, and r3):
  - **Tests:**
    - competing-claimant tests (i) retirement-first, (ii) guard failure vs cancel, and (iii)
      pending-job guard failure not retry-safe;
    - forced-guard tests at the expiry, decision-timeout and IO-completion sites, plus the pure
      step, each with two empty polls;
    - the D2 matrix asserting the guard constraint name and including an accepted
      `failed → running`;
    - D4's predicate tested on the UPDATE itself;
    - the F6 test and fixture updates (empty-constraint pins, the state-witness attack disposition,
      the raw fixture inventory);
    - the handler mapping units.
  - **Behaviour:**
    - the cascade cancels only the children's subtrees;
    - the counter and log on the `execute_io` path;
    - the `workflow_control_retry_safe` exclusion;
    - p02's C001 filters still pass.

### Process and instruction feedback

- Three rounds were needed. R1 found the main issues (F1–F6). R2 found one issue the r2 correction
  introduced (rule 4) and one I had missed in R1 (the `RunExpiry` instance), plus a contract
  precision gap (F10). R3 closed them. The rounds converged with new evidence each time, so they
  were not a stalled loop.
- Candidate instructions, already recorded in F1, F2, F6 and F9:
  - for compensating transactions, enumerate competing actors per site, and for every deferral
    name a distinct settling owner and the candidate that reaches it;
  - trace the consumers of a reclassified error;
  - grep tests for assertions on changed error fields.
  Supported by this phase only.


## FIXAPP-P03-G1-R4 — fresh architecture review of consolidated r4: PASS

### Identity

- Date: 2026-11-04. Workflow: `implement-astra-reviewed-2-2`; phase p03, whole B1 architecture gate G1, D1–D4.
- Reviewer: `/root/p03_reviewer`, requested `gpt-6-astra` / `high`, independent context. Actual runtime model/effort metadata is not exposed; no substitution inferred. New reviewer, not the historical Opus reviewer.
- Records: [TASK](TASK.md), [REVIEW](REVIEW.md), [findings](agent-review-findings.md).
- Worktree `/Users/mac03/dev/openbot/.worktrees/fix-app-p03`, branch `fix-app/p03`.
  Phase start/review base/HEAD: `48626a1240f032ca3b99372bd3f5a05eb08c0c66`.
- Decision: [G1 r4](logs/G1-r4-decision.md), SHA256
  `5753375da4d526406487a78080c9deecdbd090b8dc16afa947ab7e398bbf2e25`.
- Preserved implementation snapshot: `7b5299ca08b6dec63a7c84ef37d266e2a1c98103a838681ee0a1e6c721c9c979`, sole exclusion `plan/fix-app/phases/p03/docs`. Confirmed before inspection and after inspection using the installed snapshot script via the retained macOS realpath adapter. [Final identity evidence](logs/G1-r4-review-verification.log).
- Coordination authority `/Users/mac03/dev/openbot/plan/fix-app/COORDINATION.md`, revision 6; pinned [copy](logs/coordination-r6.md), SHA256 `d3c5b83ecf08b42314e1194bb371ebee030216d8c875cc7f76cf5b0f20322371`. Authority and pinned copy byte-identical at entry and exit. Applicable I001–I004/r1 and C001/C002/C005/C007/r1; C006/r1 is a proposed output, not an accepted producer contract. r4 acknowledges those requirements. C007 remains an integration obligation.

### Coverage and evidence

Original phase 03 plan and README supplied requirements; root/src/application/persistence/http/infra guides supplied constraints. Historical r1/r2/r3 decision text in [paused TASK](logs/TASK-paused-20261101.md), prior REVIEW entries, review notes, and F1–F11 dispositions were inspected independently. r4 preserves their effective decisions and the explicitly bounded handler/receipt exceptions; historical passes were not treated as fresh acceptance.

Graft orientation, ranked discovery, skeletons and caller traces preceded source reasoning. The worktree has no local map; graft reported fallback to the primary checkout graph. Therefore graph spans/edges were discovery hints, not proof of the preserved source: the pertinent local definitions were read directly. New `guard_failure.rs` is unindexed and was inspected directly. Ambiguous `renew_io` call edges were not assumed exhaustive.

- **D1:** Inspected SQL error conversion (`persistence/mod.rs:105`), action mappings (`actions/failure.rs:95`), worker candidate confirmation and IO completion (`worker.rs:114–315`), polling candidate priority (`polling.rs:98`), wait timeout/resumption (`wait_commit.rs:5`), deadline maintenance (`maintenance.rs:5`), compensation (`guard_failure.rs`), and cancellation traversal (`controls.rs:163`). Traced action failure consumers, completion, retry, and cancellation callers. The decision distinguishes guard identification from policy at each consumer. Its repeated-error confirmation, exact live-fence check, execution currency, deadline owner, and RunExpiry exception address historical F1/F5/F9/F10. Child subtree cancellation and durable guard-event exclusion address F3/F4. No new acceptance-blocking decision defect found. Compensation-transaction errors, including guard errors, must retain r4's no-handler-reexecution and observability requirements in B1; the preserved partial code is not accepted by this gate.
- **D2:** Inspected `control_retry.rs:3–43`, deferred SQL `check_workflow_control_retry` (schema:121), `workflow_control_retry_safe` (schema:2833), run BEFORE-trigger declarations, and relevant wait/maintenance writers. Reopening the job before the run is consistent with the immediate eligibility guard plus deferred receipt check. The new `guard_` trigger sorts before existing `workflow_` triggers. The explicit eligible-retry exception is necessary in the domain/SQL matrix; table CHECKs are deliberately outside typed guard mapping. Every row fixture and every rewritten terminal-state writer still requires final batch review, rather than inference from this gate.
- **D3:** Inspected `admission_write::insert_run` (`:94–125`) and its callers, existing SQL budget-link trigger (`schema:675`), budget usage INSERT guard (`schema:1186`), root-budget deferred owner FK (`schema:10827`) and immediate link FK (`schema:10843`). The proposed budget/zero-usage insertion before the root run is consistent with those constraints; child linking continues to use its parent's root. Removing compiler-revision/provenance branching and sharing token encoding meet the original no-compatibility requirement. Raw fixtures, rollback behavior and compiled-limit equality remain B1 obligations.
- **D4:** Inspected `lease.rs:68–118` and lease API surface. Complete identity predicates on the renewal UPDATE preserve existing ownership and deadline semantics. The proposed direct UPDATE test avoids a vacuous test that only exercises preceding `lock_fence`.
- **Coordination/verification:** C001 continuation limit and handler backstop policy are carried forward with its required focused filters. C002 fixture ownership atomicity and C005 FK preservation are explicit. C007 needs combined integration review. C006 must await accepted/integrated p03. D5/D6 are ungated and not freshly accepted here. Competing-claimant, forced-site, two-empty-poll, transition-matrix, root-budget, and direct renewal tests are specified; none was executed by this decision review.

Checks actually run: branch/HEAD checks; read-only graph/source/SQL inspection; installed snapshot and SHA256 checks before/after. No cargo, database migration, DB fixture, or full-suite command was run. No test pass is claimed. Historical test evidence is contextual only. I004 constrains later checks to affected scope; the source remains incomplete and frozen only for this gate.

### Outcome

**PASS for G1 decision revision r4, SHA256 `5753375da4d526406487a78080c9deecdbd090b8dc16afa947ab7e398bbf2e25`, D1–D4.** No new concrete decision findings. F1–F11 keep their historical dispositions; their implementation obligations remain open until B1 evidence is reviewed. This is neither implementation acceptance nor integration acceptance.

### Process and instruction feedback

The consolidated decision and immutable historical records made one cohesive fresh gate practical. Its scope is appropriate because D1 ownership/compensation and D2/D3 schema contracts are expensive to unwind. The fallback graph is stale relative to preserved work, so local source verification was necessary and is explicitly recorded. No additional instruction change is supported beyond the historical candidates. Keep the existing B1 checklist; do not convert this decision pass into acceptance of the partially implemented tree.
