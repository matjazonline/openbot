//! All connected-account and credential SQL belongs to this adapter.
mod accounts;
#[cfg_attr(
    not(test),
    expect(dead_code, reason = "Final business dispatch is wired in phase06")
)]
pub(crate) mod grants;
pub(crate) mod inventory;
pub(crate) mod lifecycle;
mod rows;
#[cfg(test)]
mod tests;
use super::PostgresPersistence;
use crate::{
    application::integrations::{
        registry::{CodeOwnedRegistry, static_registry},
        *,
    },
    domain::integrations::*,
};
use std::sync::Arc;

#[derive(Clone)]
pub(crate) struct PostgresVault {
    pub(super) persistence: PostgresPersistence,
    pub(super) registry: Arc<CodeOwnedRegistry>,
}
impl PostgresVault {
    pub fn new(persistence: PostgresPersistence) -> Self {
        Self {
            persistence,
            registry: Arc::new(static_registry()),
        }
    }
    pub fn gateway(
        &self,
        authority: Arc<dyn crate::application::integrations::grants::BindingAuthority>,
    ) -> Arc<dyn IntegrationGateway> {
        let management = Arc::new(management::VaultManagement::new(
            Arc::new(self.clone()),
            self.registry.clone(),
        ));
        let unavailable = Arc::new(unavailable::UnavailableIntegrations);
        Arc::new(LocalIntegrationGateway::new(
            management,
            unavailable.clone(),
            Arc::new(crate::application::integrations::grants::GrantService {
                writer: Arc::new(self.clone()),
                authority,
            }),
            unavailable,
        ))
    }
    fn registration(
        &self,
        provider: &ProviderId,
        config: &AuthConfigId,
        method: AuthMethod,
        schema: &CredentialSchema,
    ) -> IntegrationResult<&crate::application::integrations::registry::Registration> {
        self.registry.for_account(provider, config, method, schema)
    }
}
fn storage_error(error: sqlx::Error) -> IntegrationError {
    if let Some(db) = error.as_database_error() {
        return match db.constraint() {
            Some("integration_account_owner_cap" | "integration_grant_cap") => {
                IntegrationError::Limit
            }
            Some("integration_owner_retired") => IntegrationError::Denied,
            _ => match db.code().as_deref() {
                Some("23505") => IntegrationError::Conflict,
                Some("23514" | "22P02") => IntegrationError::Invalid,
                _ => IntegrationError::Storage,
            },
        };
    }
    IntegrationError::Storage
}
