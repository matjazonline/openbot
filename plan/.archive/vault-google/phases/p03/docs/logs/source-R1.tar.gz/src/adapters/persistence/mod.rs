use sqlx::PgPool;
use std::sync::Arc;

use crate::app_error::AppError;

pub(crate) mod account_identity;
pub mod agent;
mod agent_authoring;
mod agent_binding_selection;
pub(crate) mod agent_capability;
pub(in crate::adapters::persistence) mod agent_publication;
pub mod attention;
mod auth_attempts;
pub mod channel;
pub(crate) mod channel_edit;
pub(crate) mod channel_gate;
pub mod company;
pub mod company_invite;
pub mod company_resend_api;
pub mod credential_rotation;
pub mod credentials;
pub mod dashboard;
pub mod database_query_health;
pub mod delivery;
pub mod inbound_event;
pub mod integration;
pub(crate) mod integrations;
pub mod knowledge;
pub(crate) mod model_usage;
pub mod notification;
pub mod onboarding;
pub mod participant;
pub mod run_counts;
pub mod runtime_metrics;
mod session;
pub mod skill;
#[cfg(test)]
pub mod test_support;
pub mod thread;
pub mod thread_activity;
pub mod user;
mod view_visibility;
pub mod workflow;

#[derive(Clone)]
pub struct PostgresPersistence {
    pool: PgPool,
    credential_cipher: Option<Arc<credentials::CredentialCipher>>,
    channel_reply_notices: Option<Arc<crate::application::workflow::decisions::DecisionNotices>>,
}

impl PostgresPersistence {
    pub fn new(pool: PgPool) -> Self {
        PostgresPersistence {
            pool,
            credential_cipher: None,
            channel_reply_notices: None,
        }
    }

    pub fn with_credential_cipher(
        pool: PgPool,
        credential_cipher: credentials::CredentialCipher,
    ) -> Self {
        Self {
            pool,
            credential_cipher: Some(Arc::new(credential_cipher)),
            channel_reply_notices: None,
        }
    }

    pub fn pool(&self) -> &PgPool {
        &self.pool
    }

    /// Configure the completion owner before cloning it into runtime services.
    /// The composer is built from the original persistence, so it cannot retain this value.
    pub fn with_channel_reply_notices(
        mut self,
        notices: crate::application::workflow::decisions::DecisionNotices,
    ) -> Self {
        self.channel_reply_notices = Some(Arc::new(notices));
        self
    }

    pub(crate) fn channel_reply_notices(
        &self,
    ) -> Option<&crate::application::workflow::decisions::DecisionNotices> {
        self.channel_reply_notices.as_deref()
    }

    /// The configured cipher, or an error naming the missing configuration.
    ///
    /// Credential storage has no plaintext fallback: a deployment without a key ring must fail the
    /// read or write rather than quietly persist a token in the clear.
    pub(crate) fn credential_cipher(&self) -> Result<&credentials::CredentialCipher, AppError> {
        self.credential_cipher
            .as_deref()
            .ok_or_else(|| AppError::Internal("Credential encryption is not configured".into()))
    }

    pub(crate) fn encrypt_credential(
        &self,
        value: Option<&str>,
    ) -> Result<Option<String>, AppError> {
        value
            .map(|value| match &self.credential_cipher {
                Some(cipher) => cipher.encrypt(value),
                None => Ok(value.to_string()),
            })
            .transpose()
    }

    pub(crate) fn decrypt_credential(
        &self,
        value: Option<String>,
    ) -> Result<Option<String>, AppError> {
        value
            .map(|value| match &self.credential_cipher {
                Some(cipher) => cipher.decrypt(&value),
                None => Ok(value),
            })
            .transpose()
    }
}

/// `lock_not_available`: a lock wait reached `lock_timeout`.
const LOCK_NOT_AVAILABLE: &str = "55P03";
/// `query_canceled`: a statement reached `statement_timeout`, or was cancelled from outside.
const QUERY_CANCELED: &str = "57014";

impl From<sqlx::Error> for AppError {
    fn from(value: sqlx::Error) -> Self {
        let gave_up_waiting = value
            .as_database_error()
            .and_then(|error| error.code())
            .is_some_and(|code| matches!(code.as_ref(), LOCK_NOT_AVAILABLE | QUERY_CANCELED));
        if gave_up_waiting {
            return AppError::DatabaseTimeout(value.to_string());
        }
        let guard = value
            .as_database_error()
            .and_then(|error| error.constraint())
            .and_then(|constraint| {
                crate::app_error::WorkflowGuardViolation::from_constraint(
                    constraint,
                    value.to_string(),
                )
            });
        match guard {
            Some(violation) => AppError::WorkflowGuard(violation),
            None => AppError::Database(value.to_string()),
        }
    }
}

#[cfg(test)]
mod tests {
    //! Guards the schema-wide invariant that every temporal column carries its timezone.
    //!
    //! A `timestamp without time zone` column is written by two clocks that need not agree:
    //! `CURRENT_TIMESTAMP` resolves in the *session's* timezone, while the app binds `Utc::now()`.
    //! sqlx pins its own sessions to UTC, so the app stays self-consistent and the divergence only
    //! shows up through another client — which is exactly what makes it easy to reintroduce.
    //!
    //! Every test here needs a live database and no-ops without one, so the rest of the suite still
    //! runs with no `DATABASE_URL` set.

    use chrono::{DateTime, Utc};
    use uuid::Uuid;

    /// Stands in for a client that picks up the server's `timezone` setting instead of pinning UTC,
    /// the way `psql` and `fly postgres connect` do.
    const NON_UTC_SESSION_TIMEZONE: &str = "Europe/Ljubljana";

    use crate::adapters::persistence::test_support::test_pool;

    #[tokio::test]
    async fn every_timestamp_column_carries_a_timezone() {
        let Some(pool) = test_pool().await else {
            return;
        };

        let naive: Vec<String> = sqlx::query_scalar(
            r#"SELECT table_name || '.' || column_name
                 FROM information_schema.columns
                WHERE table_schema = 'public'
                  AND data_type = 'timestamp without time zone'
                ORDER BY table_name, ordinal_position"#,
        )
        .fetch_all(&pool)
        .await
        .expect("information_schema is readable");

        assert!(
            naive.is_empty(),
            "these columns are `timestamp without time zone`, so CURRENT_TIMESTAMP writes the \
             session's local wall clock into them and any non-UTC client silently disagrees with \
             the app's own clock: {naive:?}"
        );
    }

    /// Two indexes with the same definition are both maintained on every insert and every update
    /// that touches their columns, and the planner will only ever choose one of them. Grouping on
    /// the definition with the index name stripped catches the *next* duplicate, not only the pair
    /// this was written for.
    #[tokio::test]
    async fn no_two_indexes_share_a_definition() {
        let Some(pool) = test_pool().await else {
            return;
        };

        let duplicates: Vec<(String, String)> = sqlx::query_as(
            r#"SELECT definition.tablename, string_agg(definition.indexname, ', ')
                 FROM (SELECT tablename, indexname,
                              regexp_replace(indexdef, '^CREATE (UNIQUE )?INDEX \S+ ON',
                                             'CREATE \1INDEX ON') AS body
                         FROM pg_indexes
                        WHERE schemaname = 'public') AS definition
                GROUP BY definition.tablename, definition.body
               HAVING COUNT(*) > 1
                ORDER BY definition.tablename"#,
        )
        .fetch_all(&pool)
        .await
        .expect("pg_indexes is readable");

        assert!(
            duplicates.is_empty(),
            "these indexes are identical apart from their names, so every write maintains all of \
             them and the planner can only use one: {duplicates:?}"
        );
    }

    /// p08 P08-Q1: long-term memory providers are gone, schema and all. The workflow memory steps
    /// are a separate, still-unhandled language feature and own no storage.
    #[tokio::test]
    async fn the_memory_provider_schema_is_gone() {
        let Some(pool) = test_pool().await else {
            return;
        };

        let tables: Vec<String> = sqlx::query_scalar(
            r#"SELECT table_name::text
                 FROM information_schema.tables
                WHERE table_schema = 'public' AND table_name LIKE 'memory%'
                ORDER BY table_name"#,
        )
        .fetch_all(&pool)
        .await
        .expect("the table catalog is readable");
        assert!(tables.is_empty(), "memory tables remain: {tables:?}");

        let columns: Vec<String> = sqlx::query_scalar(
            r#"SELECT table_name || '.' || column_name
                 FROM information_schema.columns
                WHERE table_schema = 'public'
                  AND (column_name LIKE '%memory%' OR column_name LIKE 'hydradb%')
                  AND (table_name, column_name) <> ('runtime_metric_samples', 'memory_limit_bytes')
                ORDER BY table_name, column_name"#,
        )
        .fetch_all(&pool)
        .await
        .expect("the column catalog is readable");
        assert!(columns.is_empty(), "memory columns remain: {columns:?}");

        let functions: Vec<String> = sqlx::query_scalar(
            r#"SELECT proname::text
                 FROM pg_proc
                WHERE pronamespace = 'public'::regnamespace AND proname LIKE '%memory%'
                ORDER BY proname"#,
        )
        .fetch_all(&pool)
        .await
        .expect("the function catalog is readable");
        assert!(
            functions.is_empty(),
            "memory functions remain: {functions:?}"
        );
    }

    #[tokio::test]
    async fn clean_schema_contains_only_the_canonical_message_spine() {
        let Some(pool) = test_pool().await else {
            return;
        };

        let retired_tables: Vec<String> = sqlx::query_scalar(
            r#"SELECT table_name
                 FROM information_schema.tables
                WHERE table_schema = 'public'
                  AND table_name = ANY($1)
                ORDER BY table_name"#,
        )
        .bind(["email_messages", "email_outbox"])
        .fetch_all(&pool)
        .await
        .expect("the table catalog is readable");
        assert!(
            retired_tables.is_empty(),
            "retired tables remain: {retired_tables:?}"
        );

        let retired_columns: Vec<String> = sqlx::query_scalar(
            r#"SELECT table_name || '.' || column_name
                 FROM information_schema.columns
                WHERE table_schema = 'public'
                  AND (table_name, column_name) IN (
                      ('thread_messages', 'email_message_id'),
                      ('threads', 'external_thread_key'),
                      ('background_tasks', 'source_email_message_id'),
                      ('background_tasks', 'source_message_id'),
                      ('background_tasks', 'source_message_uuid')
                  )
                ORDER BY table_name, column_name"#,
        )
        .fetch_all(&pool)
        .await
        .expect("the column catalog is readable");
        assert!(
            retired_columns.is_empty(),
            "retired columns remain: {retired_columns:?}"
        );

        let canonical_columns: Vec<(String, String, String, String)> = sqlx::query_as(
            r#"SELECT table_name, column_name, is_nullable, udt_name
                 FROM information_schema.columns
                WHERE table_schema = 'public'
                  AND table_name = 'thread_messages' AND column_name = 'message_id'
                ORDER BY table_name, column_name"#,
        )
        .fetch_all(&pool)
        .await
        .expect("the canonical columns are inspectable");
        assert_eq!(
            canonical_columns,
            vec![(
                "thread_messages".into(),
                "message_id".into(),
                "NO".into(),
                "uuid".into(),
            ),],
            "the canonical message UUID column must have its final nullability",
        );

        let required_constraints: Vec<String> = sqlx::query_scalar(
            r#"SELECT conname
                 FROM pg_constraint
                WHERE conname = ANY($1)
                ORDER BY conname"#,
        )
        .bind(["thread_messages_message_fk"])
        .fetch_all(&pool)
        .await
        .expect("the canonical constraints are inspectable");
        assert_eq!(
            required_constraints,
            vec!["thread_messages_message_fk".to_owned()],
            "the canonical message constraint must be installed",
        );
    }

    #[tokio::test]
    async fn a_row_defaulted_from_a_non_utc_session_reads_back_as_the_same_instant() {
        let Some(pool) = test_pool().await else {
            return;
        };

        let mut tx = pool
            .begin()
            .await
            .expect("a transaction to roll the probe row back with");
        sqlx::query(&format!("SET LOCAL TIME ZONE '{NON_UTC_SESSION_TIMEZONE}'"))
            .execute(&mut *tx)
            .await
            .expect("the session timezone is settable");

        let probe = Uuid::new_v4();
        let before = Utc::now();
        let created_at: DateTime<Utc> = sqlx::query_scalar(
            r#"INSERT INTO users (id, username, email, password_hash)
               VALUES ($1, $2, $3, 'probe')
               RETURNING created_at"#,
        )
        .bind(probe)
        .bind(format!("tz-probe-{probe}"))
        .bind(format!("tz-probe-{probe}@example.test"))
        .fetch_one(&mut *tx)
        .await
        .expect("the probe row inserts and its created_at decodes as an absolute instant");

        let skew = (created_at - before).num_seconds().abs();
        assert!(
            skew < 60,
            "a DEFAULT written from a {NON_UTC_SESSION_TIMEZONE} session landed {skew}s from the \
             app's clock; a row inserted by hand would stay invisible to the workers that long"
        );

        tx.rollback()
            .await
            .expect("the probe row leaves nothing behind");
    }

    /// A statement the server cancels at its bound is a transient timeout; any other failure stays
    /// a database error. Lock waits reaching `lock_timeout` are covered by the channel edit.
    #[tokio::test]
    async fn a_statement_cancelled_at_its_timeout_is_a_database_timeout() {
        use crate::app_error::AppError;

        let Some(pool) = test_pool().await else {
            return;
        };

        let mut tx = pool.begin().await.expect("a transaction to bound");
        sqlx::query("SELECT set_config('statement_timeout', '20ms', true)")
            .execute(&mut *tx)
            .await
            .expect("the bound is settable");
        let cancelled = sqlx::query("SELECT pg_sleep(1)")
            .execute(&mut *tx)
            .await
            .expect_err("the sleep outlives its bound");
        assert!(
            matches!(AppError::from(cancelled), AppError::DatabaseTimeout(_)),
            "a cancelled statement is a timeout"
        );

        let broken = sqlx::query("SELECT no_such_column FROM users")
            .execute(&pool)
            .await
            .expect_err("the column does not exist");
        assert!(matches!(AppError::from(broken), AppError::Database(_)));
    }

    /// A refusal carrying a `workflow_guard:` constraint name is a typed guard violation with that
    /// name, whatever its SQLSTATE; a table constraint name or a malformed guard name is not.
    #[tokio::test]
    async fn workflow_guard_error_is_typed_by_its_constraint_name() {
        use crate::app_error::AppError;

        let Some(pool) = test_pool().await else {
            return;
        };
        let raise = |code: &str, constraint: &str| {
            format!(
                "DO $$ BEGIN RAISE EXCEPTION 'refused' USING ERRCODE='{code}', CONSTRAINT='{constraint}'; END $$"
            )
        };
        for code in ["23514", "P0001", "54000"] {
            let refused = sqlx::query(&raise(code, "workflow_guard:check_workflow_test_guard"))
                .execute(&pool)
                .await
                .expect_err("the block raises");
            let AppError::WorkflowGuard(violation) = AppError::from(refused) else {
                panic!("{code} with a guard name is a workflow guard violation");
            };
            assert_eq!(violation.guard(), "check_workflow_test_guard");
            assert!(violation.message().contains("refused"));
        }
        for constraint in [
            "workflow_run_state",
            "workflow_guard:",
            "workflow_guard:Bad-Name",
        ] {
            let refused = sqlx::query(&raise("23514", constraint))
                .execute(&pool)
                .await
                .expect_err("the block raises");
            assert!(
                matches!(AppError::from(refused), AppError::Database(_)),
                "{constraint} is not a workflow guard name"
            );
        }
    }
}

#[cfg(test)]
mod agent_config_tests;
#[cfg(test)]
mod legacy_runtime_schema_tests;

pub mod mcp;
#[cfg(test)]
mod mcp_tests;

mod harness_checkpoint;

#[cfg(test)]
mod auth_key_rotation_tests;

#[cfg(test)]
mod jsonb_test_support;
mod user_lifecycle;

pub(crate) mod integration_bindings;
