use super::*;
use crate::{
    adapters::persistence::{
        PostgresPersistence,
        credentials::{CredentialCipher, envelope::CredentialContext},
        test_support::{OwnDatabase, own_database, test_pool},
    },
    application::integrations::{
        lifecycle::TeardownDrain,
        management::{AccountRepository, AccountWrite},
        private::*,
        registry::*,
    },
    domain::integrations::*,
};
use secrecy::{ExposeSecret, SecretString};
use serde::Deserialize;
use serde_json::json;
use sha2::{Digest, Sha256};
use std::sync::Arc;
use tokio_util::sync::CancellationToken;
use uuid::Uuid;
struct Fixture {
    vault: PostgresVault,
    owner: AccountOwner,
    _database: Option<OwnDatabase>,
}
impl Fixture {
    fn on(pool: sqlx::PgPool) -> Self {
        let persistence = PostgresPersistence::with_credential_cipher(
            pool,
            CredentialCipher::for_test_with_keys(&[(1, [7; 32])], 1),
        );
        let owner = AccountOwner {
            namespace: OwnerNamespace::parse("vault-test").unwrap(),
            subject: OwnerSubject::parse(Uuid::new_v4().to_string()).unwrap(),
        };
        Self {
            vault: PostgresVault::new(persistence),
            owner,
            _database: None,
        }
    }
    async fn shared() -> Self {
        Self::on(test_pool().await.expect("disposable database required"))
    }
    async fn isolated() -> Self {
        let database = own_database().await.expect("disposable database required");
        let mut f = Self::on(database.pool.clone());
        f._database = Some(database);
        f
    }
    fn pool(&self) -> &sqlx::PgPool {
        self.vault.persistence.pool()
    }
    async fn create(&self, key: &str) -> ConnectedAccount {
        self.vault
            .create(&self.owner, static_write(key, "fixture-secret"))
            .await
            .unwrap()
    }
    fn rotating(&self) -> PostgresPersistence {
        PostgresPersistence::with_credential_cipher(
            self.pool().clone(),
            CredentialCipher::for_test_with_keys(&[(1, [7; 32]), (2, [8; 32])], 2),
        )
    }
}
fn static_write(key: &str, value: &str) -> AccountWrite {
    AccountWrite {
        key: AccountKey::parse(key).unwrap(),
        provider: ProviderId::parse("static-bearer").unwrap(),
        config: AuthConfigId::parse("static-bearer").unwrap(),
        method: AuthMethod::StaticSecret,
        schema: CredentialSchema::parse("static-v1").unwrap(),
        identity: None,
        metadata: AccountMetadata::new(key.into(), None).unwrap(),
        payload: SecretString::from(value.to_owned()),
    }
}
struct WorkspaceAdapter {
    client: String,
}
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct WorkspacePayload {
    workspace: ExternalSubject,
    client: ExternalSubject,
    token: SecretString,
    generation: CredentialGeneration,
}
impl CredentialAdapter for WorkspaceAdapter {
    fn validate(&self, raw: &SecretString) -> IntegrationResult<Option<ExternalIdentity>> {
        if raw.expose_secret().len() > MAX_CREDENTIAL_BYTES {
            return Err(IntegrationError::Invalid);
        }
        let payload: WorkspacePayload =
            serde_json::from_str(raw.expose_secret()).map_err(|_| IntegrationError::Credential)?;
        if payload.client.as_str() != self.client || payload.token.expose_secret().is_empty() {
            return Err(IntegrationError::Credential);
        }
        let _ = payload.generation;
        let key = format!(
            "{:x}",
            Sha256::digest(
                serde_json::to_vec(&(payload.workspace.as_str(), payload.client.as_str())).unwrap()
            )
        );
        Ok(Some(ExternalIdentity {
            kind: ExternalIdentityKind::parse("workspace")?,
            subject: payload.workspace,
            authorization_key: AuthorizationKey::parse(key)?,
        }))
    }
    fn injection(&self, raw: &SecretString) -> IntegrationResult<TypedInjection> {
        self.validate(raw)?;
        let p: WorkspacePayload =
            serde_json::from_str(raw.expose_secret()).map_err(|_| IntegrationError::Credential)?;
        Ok(TypedInjection {
            method: InjectionMethod::Bearer,
            value: p.token,
        })
    }
}
fn managed_registry() -> Arc<CodeOwnedRegistry> {
    let mut registry = static_registry();
    for (name, client) in [
        ("workspace-a", "same-client"),
        ("workspace-b", "same-client"),
        ("workspace-other", "other-client"),
    ] {
        let provider = ProviderId::parse("workspace-fixture").unwrap();
        let config = AuthConfigId::parse(name).unwrap();
        registry
            .register(Registration {
                provider: AuthProvider {
                    id: provider.clone(),
                    method: AuthMethod::OAuthAuthorizationCode,
                    schema: CredentialSchema::parse("workspace-fixture-v1").unwrap(),
                },
                config: AuthConfig {
                    id: config.clone(),
                    provider: provider.clone(),
                    client_identity: ExternalSubject::parse(client).unwrap(),
                    client_secret_reference: None,
                },
                app: AppDefinition {
                    id: AppId::parse(name).unwrap(),
                    provider,
                    config,
                    destinations: vec![],
                    capabilities: vec![],
                },
                adapter: Arc::new(WorkspaceAdapter {
                    client: client.into(),
                }),
            })
            .unwrap();
    }
    Arc::new(registry)
}
fn managed_payload(client: &str, generation: i64) -> SecretString {
    SecretString::from(json!({"workspace":"workspace-without-email","client":client,"token":"fixture-managed-secret","generation":generation}).to_string())
}
fn managed_write(registry: &CodeOwnedRegistry, key: &str, app: &str) -> AccountWrite {
    let registration = registry.get(&AppId::parse(app).unwrap()).unwrap();
    let payload = managed_payload(registration.config.client_identity.as_str(), 1);
    AccountWrite {
        key: AccountKey::parse(key).unwrap(),
        provider: registration.provider.id.clone(),
        config: registration.config.id.clone(),
        method: registration.provider.method,
        schema: registration.provider.schema.clone(),
        identity: registration.adapter.validate(&payload).unwrap(),
        metadata: AccountMetadata::new(key.into(), None).unwrap(),
        payload,
    }
}
#[path = "lifecycle_tests.rs"]
mod lifecycle_tests;
#[path = "rotation_tests.rs"]
mod rotation_tests;
#[path = "storage_tests.rs"]
mod storage_tests;
