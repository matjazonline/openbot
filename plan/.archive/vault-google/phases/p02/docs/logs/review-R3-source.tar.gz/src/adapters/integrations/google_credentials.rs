//! Current Google credential schema. No login, consent, or network behavior.
use crate::{
    application::integrations::private::{CredentialAdapter, InjectionMethod, TypedInjection},
    domain::integrations::*,
};
use chrono::{DateTime, Utc};
use secrecy::{ExposeSecret, SecretString};
use serde::Deserialize;
use sha2::{Digest, Sha256};

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct GooglePayload {
    subject: ExternalSubject,
    client: ExternalSubject,
    scopes: Vec<Scope>,
    refresh_token: SecretString,
    access_token: Option<SecretString>,
    expires_at: Option<DateTime<Utc>>,
    generation: CredentialGeneration,
    refresh_retry_at: Option<DateTime<Utc>>,
}

pub(crate) struct GoogleCredentialAdapter {
    pub client: ExternalSubject,
}
impl GoogleCredentialAdapter {
    fn decode(&self, raw: &SecretString) -> IntegrationResult<GooglePayload> {
        if raw.expose_secret().len() > MAX_CREDENTIAL_BYTES {
            return Err(IntegrationError::Invalid);
        }
        let payload: GooglePayload =
            serde_json::from_str(raw.expose_secret()).map_err(|_| IntegrationError::Credential)?;
        if payload.client != self.client
            || payload.scopes.len() > MAX_SCOPES
            || payload.refresh_token.expose_secret().is_empty()
            || payload.access_token.is_some() != payload.expires_at.is_some()
            || payload
                .access_token
                .as_ref()
                .is_some_and(|token| token.expose_secret().is_empty())
        {
            return Err(IntegrationError::Credential);
        }
        // Both fields are part of the current schema even when a cache/retry is absent.
        let _ = (payload.generation, payload.refresh_retry_at);
        Ok(payload)
    }
}
impl CredentialAdapter for GoogleCredentialAdapter {
    fn validate(&self, raw: &SecretString) -> IntegrationResult<Option<ExternalIdentity>> {
        let payload = self.decode(raw)?;
        let mut digest = Sha256::new();
        for field in [payload.subject.as_str(), payload.client.as_str()] {
            digest.update((field.len() as u32).to_be_bytes());
            digest.update(field.as_bytes());
        }
        Ok(Some(ExternalIdentity {
            kind: ExternalIdentityKind::parse("google-subject-client")?,
            subject: payload.subject,
            authorization_key: AuthorizationKey::parse(format!("{:x}", digest.finalize()))?,
        }))
    }
    fn injection(&self, raw: &SecretString) -> IntegrationResult<TypedInjection> {
        let payload = self.decode(raw)?;
        Ok(TypedInjection {
            method: InjectionMethod::Bearer,
            value: payload.access_token.ok_or(IntegrationError::Credential)?,
        })
    }
}
