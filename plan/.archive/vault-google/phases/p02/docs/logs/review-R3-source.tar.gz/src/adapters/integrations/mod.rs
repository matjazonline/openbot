//! Provider-specific integration adapters, distinct from login OAuth.
#[cfg_attr(
    not(test),
    allow(dead_code, reason = "External-app OAuth registration ships in phase04")
)]
pub(crate) mod google_credentials;
pub(crate) mod owner;
