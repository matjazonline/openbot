use super::{PostgresVault, storage_error};
use crate::{application::integrations::lifecycle::TeardownDrain, domain::integrations::*};
use async_trait::async_trait;
use sqlx::{Acquire, Postgres, Transaction};
use tokio_util::sync::CancellationToken;
use uuid::Uuid;

/// Local implementation hooks: the host owns the surrounding deletion transaction.
/// No host-table query or host foreign key exists inside the integrations module.
pub(crate) async fn retire_owner_on(
    tx: &mut Transaction<'_, Postgres>,
    owner: &AccountOwner,
) -> IntegrationResult<()> {
    sqlx::query("INSERT INTO integration_owner_states(owner_namespace,owner_subject,retired) VALUES($1,$2,true) ON CONFLICT(owner_namespace,owner_subject) DO UPDATE SET retired=true")
        .bind(owner.namespace.as_str()).bind(owner.subject.as_str()).execute(&mut **tx).await.map_err(storage_error)?;
    sqlx::query("UPDATE integration_accounts SET status='disconnected',envelope=NULL,revision=revision+1,authorization_revision=authorization_revision+1,credential_generation=credential_generation+1,updated_at=clock_timestamp() WHERE owner_namespace=$1 AND owner_subject=$2 AND status<>'disconnected'")
        .bind(owner.namespace.as_str()).bind(owner.subject.as_str()).execute(&mut **tx).await.map_err(storage_error)?;
    enqueue(tx, "owner", &owner.namespace, owner.subject.as_str(), "").await
}
pub(crate) async fn revoke_company_on(
    tx: &mut Transaction<'_, Postgres>,
    client: &OwnerNamespace,
    binding: &HostBinding,
) -> IntegrationResult<()> {
    enqueue(tx, "company", client, "", binding.as_str()).await
}
pub(crate) async fn revoke_membership_on(
    tx: &mut Transaction<'_, Postgres>,
    owner: &AccountOwner,
    binding: &HostBinding,
) -> IntegrationResult<()> {
    enqueue(
        tx,
        "membership",
        &owner.namespace,
        owner.subject.as_str(),
        binding.as_str(),
    )
    .await
}
async fn enqueue(
    tx: &mut Transaction<'_, Postgres>,
    kind: &str,
    client: &OwnerNamespace,
    subject: &str,
    binding: &str,
) -> IntegrationResult<()> {
    sqlx::query("INSERT INTO integration_teardown_intents(id,kind,owner_namespace,owner_subject,host_binding) VALUES($1,$2,$3,$4,$5) ON CONFLICT(kind,owner_namespace,owner_subject,host_binding) DO NOTHING")
        .bind(Uuid::new_v4()).bind(kind).bind(client.as_str()).bind(subject).bind(binding).execute(&mut **tx).await.map_err(storage_error)?;
    Ok(())
}
#[derive(sqlx::FromRow)]
struct Intent {
    id: Uuid,
    kind: String,
    owner_namespace: String,
    owner_subject: String,
    attempts: i32,
}
async fn cleanup(tx: &mut Transaction<'_, Postgres>, intent: &Intent) -> IntegrationResult<()> {
    match intent.kind.as_str() {
        "owner" => {
            sqlx::query(
                "DELETE FROM integration_accounts WHERE owner_namespace=$1 AND owner_subject=$2",
            )
            .bind(&intent.owner_namespace)
            .bind(&intent.owner_subject)
            .execute(&mut **tx)
            .await
            .map_err(storage_error)?;
        }
        // There are no grants/bindings in02 and GrantGateway explicitly denies creation.
        //03 must invalidate its grants here and in the corresponding deletion hooks.
        // A host binding never owns private accounts, so neither case deletes accounts.
        "company" | "membership" => {}
        _ => return Err(IntegrationError::Invalid),
    }
    Ok(())
}
impl PostgresVault {
    async fn drain_one(&self, stop: &CancellationToken) -> IntegrationResult<bool> {
        let mut tx = tokio::select! {
            biased;
            _=stop.cancelled()=>return Ok(false),
            transaction=self.persistence.pool().begin()=>transaction.map_err(storage_error)?,
        };
        sqlx::query("SET LOCAL lock_timeout='100ms'")
            .execute(&mut *tx)
            .await
            .map_err(storage_error)?;
        sqlx::query("SET LOCAL statement_timeout='2s'")
            .execute(&mut *tx)
            .await
            .map_err(storage_error)?;
        let claimed = tokio::select! {
            biased;
            _=stop.cancelled()=>None,
            intent=sqlx::query_as::<_,Intent>("SELECT id,kind,owner_namespace,owner_subject,attempts FROM integration_teardown_intents WHERE state='pending' AND available_at<=clock_timestamp() ORDER BY available_at,id LIMIT 1 FOR UPDATE SKIP LOCKED").fetch_optional(&mut *tx)=>Some(intent.map_err(storage_error)?),
        };
        let Some(intent) = claimed else {
            tx.rollback().await.map_err(storage_error)?;
            return Ok(false);
        };
        let Some(intent) = intent else {
            tx.rollback().await.map_err(storage_error)?;
            return Ok(false);
        };
        let mut work = tx.begin().await.map_err(storage_error)?;
        let result = tokio::select! {biased; _=stop.cancelled()=>None,result=cleanup(&mut work,&intent)=>Some(result)};
        let success = matches!(result, Some(Ok(())));
        if success {
            work.commit().await.map_err(storage_error)?;
        } else {
            work.rollback().await.map_err(storage_error)?;
        }
        if result.is_none() || stop.is_cancelled() {
            tx.rollback().await.map_err(storage_error)?;
            return Ok(false);
        }
        let outcome = if success {
            CleanupOutcome::Completed
        } else {
            CleanupOutcome::Deferred
        };
        settle(&mut tx, &intent, outcome).await?;
        tx.commit().await.map_err(storage_error)?;
        Ok(true)
    }
}
enum CleanupOutcome {
    Completed,
    Deferred,
}
async fn settle(
    tx: &mut Transaction<'_, Postgres>,
    intent: &Intent,
    outcome: CleanupOutcome,
) -> IntegrationResult<()> {
    if matches!(outcome, CleanupOutcome::Completed) {
        sqlx::query("UPDATE integration_teardown_intents SET state='completed',completed_at=clock_timestamp() WHERE id=$1")
            .bind(intent.id).execute(&mut **tx).await.map_err(storage_error)?;
    } else {
        let attempts = intent.attempts + 1;
        let seconds = 2i32.pow((attempts + 5).min(8) as u32);
        sqlx::query("UPDATE integration_teardown_intents SET attempts=$2,state=CASE WHEN $2>=8 THEN 'failed' ELSE 'pending' END,available_at=clock_timestamp()+$3*interval '1 second' WHERE id=$1")
            .bind(intent.id).bind(attempts).bind(f64::from(seconds)).execute(&mut **tx).await.map_err(storage_error)?;
        tracing::warn!(intent_id=%intent.id,attempt=attempts,terminal=attempts>=8,"Integration teardown deferred");
    }
    Ok(())
}
#[async_trait]
impl TeardownDrain for PostgresVault {
    async fn drain(&self, limit: u16, stop: &CancellationToken) -> IntegrationResult<usize> {
        if limit == 0 || limit > 16 {
            return Err(IntegrationError::Limit);
        }
        let mut count = 0;
        for _ in 0..limit {
            if stop.is_cancelled() || !self.drain_one(stop).await? {
                break;
            }
            count += 1;
        }
        Ok(count)
    }
}
