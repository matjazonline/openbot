//! Persistence contract for company MCP catalog operations. HTTP transport/discovery is separate.
use crate::{
    app_error::{AppError, AppResult},
    entities::mcp::*,
};
use async_trait::async_trait;
use secrecy::SecretString;
use serde::Deserialize;
use uuid::Uuid;

#[derive(Debug, Clone, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct McpConnectionWrite {
    pub slug: crate::entities::value_objects::McpConnectionSlug,
    pub endpoint: McpEndpoint,
    pub enabled: bool,
    pub auth: McpAuth,
    pub discovered_tools: Vec<McpDiscoveredTool>,
    pub tool_grants: Vec<McpToolName>,
}
impl McpConnectionWrite {
    pub fn validate(&self) -> AppResult<()> {
        super::channel::validate_slug(&self.slug, super::channel::SlugKind::AgentSlug)?;
        validate_catalog(&self.discovered_tools, &self.tool_grants)
    }
}
/// Validate the reviewed discovery and grants together; callers cannot widen a bad catalog.
pub(crate) fn validate_catalog(
    discovered_tools: &[McpDiscoveredTool],
    tool_grants: &[McpToolName],
) -> AppResult<()> {
    if discovered_tools.len() > MAX_MCP_DISCOVERED_TOOLS
        || tool_grants.len() > MAX_EFFECTIVE_MCP_TOOLS
    {
        return Err(invalid("MCP tool count exceeds the server limit"));
    }
    let encoded =
        serde_json::to_vec(discovered_tools).map_err(|_| invalid("Invalid MCP discovery"))?;
    if encoded.len() > MAX_MCP_DISCOVERY_BYTES {
        return Err(invalid("MCP discovery exceeds 1 MiB"));
    }
    let mut names = std::collections::HashSet::new();
    for tool in discovered_tools {
        if !names.insert(&tool.name) {
            return Err(invalid("Duplicate discovered MCP tool name"));
        }
        for schema in std::iter::once(&tool.input_schema).chain(&tool.output_schema) {
            crate::services::tool_schema::compile(schema)?;
            if !schema.is_object()
                || serde_json::to_vec(schema)
                    .map_err(|_| invalid("Invalid MCP schema"))?
                    .len()
                    > MAX_MCP_SCHEMA_BYTES
            {
                return Err(invalid(
                    "MCP tool schema must be an object of at most 64 KiB",
                ));
            }
        }
    }
    let mut grants = std::collections::HashSet::new();
    for grant in tool_grants {
        if !names.contains(grant) || !grants.insert(grant) {
            return Err(invalid(
                "MCP grants must uniquely name reviewed discovered tools",
            ));
        }
    }
    Ok(())
}

fn invalid(message: &str) -> AppError {
    AppError::BadRequest(message.into())
}
/// A connection id names one endpoint for its lifetime; frozen workflow actions rely on it.
pub fn endpoint_fixed() -> AppError {
    invalid("An MCP connection's endpoint cannot change; create a new connection instead")
}

/// Tokens are write-only and use a distinct port from catalog projections.
#[async_trait]
pub trait McpCredentialPersistence: Send + Sync {
    async fn replace_mcp_token(
        &self,
        company_id: Uuid,
        connection_id: Uuid,
        expected_revision: i64,
        token: Option<SecretString>,
    ) -> AppResult<i64>;
    async fn mcp_token(
        &self,
        company_id: Uuid,
        connection_id: Uuid,
        expected_revision: i64,
    ) -> AppResult<Option<SecretString>>;
}

#[async_trait]
pub trait McpPersistence: Send + Sync {
    async fn set_mcp_level(
        &self,
        command: crate::application::workflow::connection_level::ConnectionLevelCommand,
    ) -> AppResult<CompanyMcpConnection>;
    async fn list_mcp_connections(&self, company_id: Uuid) -> AppResult<Vec<CompanyMcpConnection>>;
    async fn create_mcp_connection(
        &self,
        company_id: Uuid,
        write: McpConnectionWrite,
    ) -> AppResult<CompanyMcpConnection>;
    async fn update_mcp_connection(
        &self,
        company_id: Uuid,
        connection_id: Uuid,
        expected_revision: i64,
        write: McpConnectionWrite,
    ) -> AppResult<CompanyMcpConnection>;
    async fn delete_mcp_connection(
        &self,
        company_id: Uuid,
        connection_id: Uuid,
        expected_revision: i64,
    ) -> AppResult<()>;
}

/// Authorization belongs to the application boundary; storage adapters never infer an actor.
#[derive(Clone)]
pub struct McpUseCases {
    discovery: std::sync::Arc<dyn McpIntegrationDiscovery>,
    companies: std::sync::Arc<dyn super::company::CompanyPersistence>,
    catalog: std::sync::Arc<dyn McpPersistence>,
    credentials: std::sync::Arc<dyn McpCredentialPersistence>,
    client: std::sync::Arc<dyn crate::services::mcp_client::McpClient>,
}

/// Host-owned configuration discovery and catalog commit, separate from business actions.
#[async_trait]
pub trait McpIntegrationDiscovery: Send + Sync {
    async fn refresh(
        &self,
        user: Uuid,
        owner: crate::application::integrations::VerifiedOwner,
        current: &CompanyMcpConnection,
    ) -> AppResult<CompanyMcpConnection>;
}
#[cfg(test)]
pub(crate) struct UnavailableMcpDiscovery;
#[cfg(test)]
#[async_trait]
impl McpIntegrationDiscovery for UnavailableMcpDiscovery {
    async fn refresh(
        &self,
        _: Uuid,
        _: crate::application::integrations::VerifiedOwner,
        _: &CompanyMcpConnection,
    ) -> AppResult<CompanyMcpConnection> {
        Err(AppError::ServiceUnavailable(
            "Integration discovery is unavailable".into(),
        ))
    }
}
impl McpUseCases {
    pub fn new(
        companies: std::sync::Arc<dyn super::company::CompanyPersistence>,
        catalog: std::sync::Arc<dyn McpPersistence>,
        credentials: std::sync::Arc<dyn McpCredentialPersistence>,
        client: std::sync::Arc<dyn crate::services::mcp_client::McpClient>,
        discovery: std::sync::Arc<dyn McpIntegrationDiscovery>,
    ) -> Self {
        Self {
            discovery,
            companies,
            catalog,
            credentials,
            client,
        }
    }
    pub async fn level_actor(
        &self,
        user: Uuid,
        company: Uuid,
    ) -> AppResult<crate::entities::access_level::LevelActor> {
        let access =
            super::company::readable_company(self.companies.as_ref(), user, company).await?;
        if !access.membership.manages_company_operations() {
            return Err(AppError::NotFound("Company connection".into()));
        }
        Ok(crate::entities::access_level::LevelActor {
            membership: access.membership,
            access_level: access.access_level,
        })
    }
    pub async fn list(&self, user: Uuid, company: Uuid) -> AppResult<Vec<CompanyMcpConnection>> {
        super::company::managed_company(self.companies.as_ref(), user, company).await?;
        self.catalog.list_mcp_connections(company).await
    }
    pub async fn create(
        &self,
        user: Uuid,
        company: Uuid,
        write: McpConnectionWrite,
    ) -> AppResult<CompanyMcpConnection> {
        super::company::managed_company(self.companies.as_ref(), user, company).await?;
        write.validate()?;
        self.client.validate_endpoint(&write.endpoint)?;
        self.catalog.create_mcp_connection(company, write).await
    }
    pub async fn update(
        &self,
        user: Uuid,
        current: &CompanyMcpConnection,
        write: McpConnectionWrite,
    ) -> AppResult<CompanyMcpConnection> {
        super::company::managed_company(self.companies.as_ref(), user, current.company_id).await?;
        write.validate()?;
        if write.endpoint != current.endpoint {
            return Err(endpoint_fixed());
        }
        self.client.validate_endpoint(&write.endpoint)?;
        self.catalog
            .update_mcp_connection(current.company_id, current.id, current.revision, write)
            .await
    }
    pub async fn set_level(
        &self,
        command: crate::application::workflow::connection_level::ConnectionLevelCommand,
    ) -> AppResult<CompanyMcpConnection> {
        super::company::managed_company(
            self.companies.as_ref(),
            command.actor.user_id(),
            command.company.as_uuid(),
        )
        .await?;
        self.catalog.set_mcp_level(command).await
    }
    pub async fn delete(&self, user: Uuid, current: &CompanyMcpConnection) -> AppResult<()> {
        super::company::managed_company(self.companies.as_ref(), user, current.company_id).await?;
        self.catalog
            .delete_mcp_connection(current.company_id, current.id, current.revision)
            .await
    }
    pub async fn replace_token(
        &self,
        user: Uuid,
        current: &CompanyMcpConnection,
        token: Option<SecretString>,
    ) -> AppResult<i64> {
        super::company::managed_company(self.companies.as_ref(), user, current.company_id).await?;
        self.credentials
            .replace_mcp_token(current.company_id, current.id, current.revision, token)
            .await
    }
}

impl McpUseCases {
    pub async fn shutdown(&self) -> AppResult<()> {
        self.client.shutdown().await
    }
    pub async fn get(
        &self,
        user: Uuid,
        company: Uuid,
        id: Uuid,
    ) -> AppResult<CompanyMcpConnection> {
        self.list(user, company)
            .await?
            .into_iter()
            .find(|c| c.id == id)
            .ok_or_else(|| AppError::NotFound("MCP connection not found".into()))
    }
    pub async fn refresh(
        &self,
        user: Uuid,
        current: &CompanyMcpConnection,
        owner: crate::application::integrations::VerifiedOwner,
    ) -> AppResult<CompanyMcpConnection> {
        super::company::managed_company(self.companies.as_ref(), user, current.company_id).await?;
        if matches!(current.auth, McpAuth::Integration(_)) {
            return self.discovery.refresh(user, owner, current).await;
        }
        let token = self
            .credentials
            .mcp_token(current.company_id, current.id, current.revision)
            .await?;
        if current.auth == McpAuth::Bearer && token.is_none() {
            return Err(invalid("Set a bearer token before testing this connection"));
        }
        let session = self.client.connect(&current.endpoint, token).await?;
        let discovery = session.discover().await;
        let closed = session.close().await;
        let tools = discovery?;
        closed?;
        // Retain only grants whose reviewed schema is unchanged. Refresh never expands authority.
        let grants = current
            .tool_grants
            .iter()
            .filter(|name| {
                let old = current.discovered_tools.iter().find(|t| &t.name == *name);
                let new = tools.iter().find(|t| &t.name == *name);
                matches!((old, new), (Some(a), Some(b)) if a.input_schema == b.input_schema
                    && a.output_schema == b.output_schema)
            })
            .cloned()
            .collect();
        self.update(
            user,
            current,
            McpConnectionWrite {
                slug: current.slug.clone(),
                endpoint: current.endpoint.clone(),
                enabled: current.enabled,
                auth: current.auth.clone(),
                discovered_tools: tools,
                tool_grants: grants,
            },
        )
        .await
    }
}
