use super::*;
use crate::application::integrations::wire::{self, Command, Reply};

#[tokio::test]
async fn integration_service_contract_control_cannot_decode_owner_deadline_or_cancellation_into_authority()
 {
    let f = Box::pin(Fixture::new()).await;
    for fault in ["owner", "deadline", "expired", "cancelled", "version"] {
        let deadline =
            Utc::now() + chrono::Duration::seconds(if fault == "expired" { -1 } else { 20 });
        let request = wire::Request {
            version: wire::PROTOCOL_VERSION,
            identity: DispatchId::new(Uuid::new_v4()),
            owner: f.owner.owner().clone(),
            deadline,
            cancellation: CancellationId::parse(Uuid::new_v4().to_string()).unwrap(),
            command: Command::ListAccounts {
                page: wire::Page {
                    after: None,
                    size: 10,
                },
            },
        };
        let mut value = serde_json::to_value(&request).unwrap();
        match fault {
            "owner" => value["owner"]["subject"] = json!(Uuid::new_v4().to_string()),
            "deadline" => value["deadline"] = json!(deadline + chrono::Duration::seconds(1)),
            "version" => value["version"] = json!(wire::PROTOCOL_VERSION + 1),
            _ => {}
        }
        let cancel = CancellationToken::new();
        if fault == "cancelled" {
            cancel.cancel();
        }
        assert!(
            wire::control_transport::exchange(
                f.gateway().as_ref(),
                &f.owner,
                &serde_json::to_vec(&value).unwrap(),
                ConnectWork {
                    deadline,
                    cancellation: cancel
                },
                None
            )
            .await
            .is_err(),
            "{fault}"
        );
    }
    assert_eq!(f.script.calls.load(Ordering::SeqCst), 0);
}

async fn command(f: &Fixture, owner: &VerifiedOwner, command: Command) -> Reply {
    let deadline = Utc::now() + chrono::Duration::seconds(20);
    let request = wire::Request {
        version: wire::PROTOCOL_VERSION,
        identity: DispatchId::new(Uuid::new_v4()),
        owner: owner.owner().clone(),
        deadline,
        cancellation: CancellationId::parse(Uuid::new_v4().to_string()).unwrap(),
        command,
    };
    let bytes = wire::control_transport::exchange(
        f.gateway().as_ref(),
        owner,
        &request.encode().unwrap(),
        ConnectWork {
            deadline,
            cancellation: CancellationToken::new(),
        },
        None,
    )
    .await
    .unwrap();
    for secret in [
        "wire-static-secret",
        "wire-static-replacement",
        "refresh-sentinel",
        "access-sentinel",
        "client-secret-sentinel",
        "enc:v2",
    ] {
        assert!(!String::from_utf8_lossy(&bytes).contains(secret));
    }
    wire::Response::decode(&bytes, request.identity)
        .unwrap()
        .reply
}
fn static_input(secret: &str) -> wire::StaticInput {
    wire::StaticInput {
        key: AccountKey::parse("wire-static").unwrap(),
        app: AppId::parse("static-bearer").unwrap(),
        metadata: AccountMetadata::new("Private wire account".into(), None).unwrap(),
        value: wire::SecretSubmission::new(SecretString::from(secret.to_owned())).unwrap(),
    }
}
fn account(reply: Reply) -> ConnectedAccount {
    let Reply::Account { account } = reply else {
        panic!("account reply");
    };
    *account
}

#[tokio::test]
async fn integration_service_contract_control_crud_preserves_owner_stale_versions_and_redaction() {
    let f = Box::pin(Fixture::new()).await;
    assert!(
        matches!(command(&f,&f.owner,Command::BindingApps {}).await,Reply::BindingApps {apps} if !apps.is_empty())
    );
    let a = account(
        command(
            &f,
            &f.owner,
            Command::CreateStatic {
                input: static_input("wire-static-secret"),
            },
        )
        .await,
    );
    for cmd in [
        Command::GetAccount { account: a.id },
        Command::ListAccounts {
            page: wire::Page {
                after: None,
                size: 10,
            },
        },
        Command::AccountChoices {
            app: AppId::parse("static-bearer").unwrap(),
            page: wire::Page {
                after: None,
                size: 10,
            },
        },
        Command::InspectGrants {
            account: a.id,
            after: None,
        },
    ] {
        assert!(!matches!(
            command(&f, &f.owner, cmd).await,
            Reply::Failure { .. }
        ));
    }
    let mut foreign = f.owner.owner().clone();
    foreign.subject = OwnerSubject::parse(Uuid::new_v4().to_string()).unwrap();
    let foreign = VerifiedOwner::from_verified_client(foreign);
    assert!(matches!(
        command(&f, &foreign, Command::GetAccount { account: a.id }).await,
        Reply::Failure {
            failure: wire::Failure::NotFound
        }
    ));
    let b = account(
        command(
            &f,
            &f.owner,
            Command::ReplaceStatic {
                account: a.id,
                expected: a.revision,
                input: static_input("wire-static-replacement"),
            },
        )
        .await,
    );
    assert!(matches!(
        command(
            &f,
            &f.owner,
            Command::ReplaceStatic {
                account: a.id,
                expected: a.revision,
                input: static_input("wire-static-secret")
            }
        )
        .await,
        Reply::Failure {
            failure: wire::Failure::Conflict
        }
    ));
    let c = account(
        command(
            &f,
            &f.owner,
            Command::Disconnect {
                account: b.id,
                expected: b.authorization_revision,
            },
        )
        .await,
    );
    assert!(matches!(
        command(
            &f,
            &f.owner,
            Command::DeleteAccount {
                account: c.id,
                expected: c.authorization_revision
            }
        )
        .await,
        Reply::Done {}
    ));
    assert!(matches!(
        command(&f, &f.owner, Command::GetAccount { account: c.id }).await,
        Reply::Failure {
            failure: wire::Failure::NotFound
        }
    ));
}
async fn begin(f: &Fixture) -> (ConnectAttempt, String) {
    let cmd = super::command(None);
    let reply = command(
        f,
        &f.owner,
        Command::BeginConnect {
            app: cmd.app,
            config: cmd.config,
            capabilities: cmd.requested_capabilities,
            return_target: cmd.return_target,
            reconnect: None,
        },
    )
    .await;
    let Reply::ConnectStarted {
        attempt,
        authorization_url,
    } = reply
    else {
        panic!("connect start");
    };
    let url = url::Url::parse(authorization_url.as_str()).unwrap();
    let state = url
        .query_pairs()
        .find(|(k, _)| k == "state")
        .unwrap()
        .1
        .into_owned();
    (attempt, state)
}
#[tokio::test]
async fn integration_service_contract_control_connect_uses_original_browser_and_private_code_exchange()
 {
    let f = Box::pin(Fixture::new()).await;
    assert!(
        matches!(command(&f,&f.owner,Command::ConnectableApps {}).await,Reply::ConnectableApps {apps} if !apps.is_empty())
    );
    let (a, state) = Box::pin(begin(&f)).await;
    assert!(
        matches!(command(&f,&f.owner,Command::GetConnectAttempt {attempt:a.id}).await,Reply::ConnectAttempt {attempt} if attempt.status==ConnectStatus::Pending)
    );
    let reply = command(
        &f,
        &f.owner,
        Command::FinishConnect {
            provider: ProviderId::parse("google").unwrap(),
            state: wire::SecretSubmission::new(state.into()).unwrap(),
            code: Some(wire::SecretSubmission::new("code-sentinel".into()).unwrap()),
            error: None,
        },
    )
    .await;
    assert!(
        matches!(reply,Reply::ConnectAttempt {attempt} if attempt.status==ConnectStatus::Connected)
    );
    assert_eq!(f.script.calls.load(Ordering::SeqCst), 1);
    let (cancelled, _) = Box::pin(begin(&f)).await;
    assert!(
        matches!(command(&f,&f.owner,Command::CancelConnect {attempt:cancelled.id}).await,Reply::ConnectAttempt {attempt} if attempt.status==ConnectStatus::Cancelled)
    );
}
