//! Provider-specific integration adapters, distinct from login OAuth.
pub(crate) mod google_credentials;
