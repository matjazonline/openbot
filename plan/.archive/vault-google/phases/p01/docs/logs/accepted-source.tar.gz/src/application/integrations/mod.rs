//! Application-owned gateway. Credential-bearing ports are crate-private.
pub mod execution;
pub mod gateway;
pub(crate) mod private;
pub(crate) mod registry;
pub use execution::*;
pub use gateway::*;

#[cfg(test)]
mod tests;
pub use registry::{AppDefinition, AuthConfig, AuthProvider};
