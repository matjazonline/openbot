//! Narrow nonserializable module ports. Never re-export from the public gateway.
use crate::domain::integrations::*;
use async_trait::async_trait;
use secrecy::SecretString;

#[derive(Debug)]
pub(crate) struct CredentialRecord {
    pub account: ConnectedAccount,
    pub versions: CredentialVersions,
    pub payload: SecretString,
}
#[async_trait]
pub(crate) trait CredentialStore: Send + Sync {
    async fn read_usable(
        &self,
        owner: &AccountOwner,
        id: AccountId,
    ) -> IntegrationResult<CredentialRecord>;
}
#[derive(Debug)]
pub(crate) struct ProviderAuthorization {
    pub identity: ExternalIdentity,
    pub payload: SecretString,
}
#[derive(Debug)]
pub(crate) struct ProviderConnectRequest {
    pub config: AuthConfigId,
    pub scopes: Vec<Scope>,
    pub verifier: SecretString,
}
#[async_trait]
pub(crate) trait ProviderLifecycle: Send + Sync {
    async fn complete(
        &self,
        request: ProviderConnectRequest,
        code: SecretString,
    ) -> IntegrationResult<ProviderAuthorization>;
    async fn renew(&self, current: &CredentialRecord) -> IntegrationResult<ProviderAuthorization>;
    async fn revoke(&self, current: &CredentialRecord) -> IntegrationResult<()>;
}
#[derive(Debug)]
pub(crate) enum InjectionMethod {
    Bearer,
    ApiKeyHeader(String),
}
#[derive(Debug)]
pub(crate) struct TypedInjection {
    pub method: InjectionMethod,
    pub value: SecretString,
}
pub(crate) struct CredentialCacheUpdate<'a> {
    pub previous: &'a SecretString,
    pub replacement: &'a SecretString,
}

pub(crate) trait CredentialAdapter: Send + Sync {
    fn validate(&self, payload: &SecretString) -> IntegrationResult<Option<ExternalIdentity>>;
    /// Routine renewal must preserve the provider's consent identity and permission facts.
    /// Token/cache changes are permitted; owner consent changes require reconnect.
    fn validate_cache_update(&self, update: CredentialCacheUpdate<'_>) -> IntegrationResult<()>;
    fn injection(&self, payload: &SecretString) -> IntegrationResult<TypedInjection>;
}
