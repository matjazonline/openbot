//! Reader of the run's frozen thread history for `context.history` (06-D6 A). One read in
//! the claim's transaction: the admission snapshot (`workflow_history_members`), with
//! internal notes excluded at capture; only the newest 256 members join their messages,
//! so a long thread never materializes bodies it cannot return.
use super::http::{begin_http, runtime};
use super::*;
use crate::application::workflow::{
    actions::ActionScope,
    history::{FrozenHistory, HistoryMessage, KIND, MAX_HISTORY_ITEMS, MAX_HISTORY_TEXT},
    lease::ClaimedWorkflow,
    polling::WorkflowStepKind,
};
use crate::entities::message::{MessageAudience, MessageRole, ThreadEntryKind};
use chrono::{DateTime, Utc};
use serde_json::Value;
use std::str::FromStr;

#[derive(sqlx::FromRow)]
struct HistoryRow {
    message_id: Uuid,
    access_level: i16,
    at: DateTime<Utc>,
    role: String,
    audience: String,
    entry_kind: String,
    author_label: String,
    author_subject: Option<String>,
    subject: String,
    body: String,
}

impl HistoryRow {
    fn message(self) -> AppResult<HistoryMessage> {
        let malformed = || AppError::BadRequest("Invalid stored workflow history".into());
        Ok(HistoryMessage {
            message_id: self.message_id,
            at: self.at,
            role: MessageRole::from_str(&self.role).map_err(|_| malformed())?,
            audience: MessageAudience::from_str(&self.audience).map_err(|_| malformed())?,
            entry_kind: ThreadEntryKind::from_str(&self.entry_kind).map_err(|_| malformed())?,
            // The legacy display rule: the label, else the identity handle.
            author: match self.author_label.trim() {
                "" => self.author_subject.unwrap_or_else(|| "Unknown".into()),
                _ => self.author_label,
            },
            subject: self.subject,
            body: self.body,
        })
    }
}

#[async_trait]
impl crate::application::workflow::history::WorkflowHistory for PostgresPersistence {
    async fn frozen_history(&self, claim: &ClaimedWorkflow) -> AppResult<FrozenHistory> {
        let scope = claim.fence.scope;
        let mut tx = begin_http(self).await?;
        let facts = runtime::facts(
            &mut tx,
            ActionScope {
                company: scope.company,
                run: scope.run,
                execution: scope.execution,
            },
        )
        .await?;
        let inputs =
            runtime::frozen_inputs(&mut tx, &facts, claim, &WorkflowStepKind(KIND.into())).await?;
        let max_tokens = inputs
            .get("max_tokens")
            .and_then(Value::as_u64)
            .ok_or_else(invalid)?;
        // Texts are cut one character past the bound so the handler can mark truncation
        // without reading an unbounded body.
        let eligible: i64 = sqlx::query_scalar(
            "SELECT eligible_count FROM workflow_history_snapshots WHERE company_id=$1 AND run_id=$2",
        ).bind(scope.company.as_uuid()).bind(scope.run.as_uuid())
            .fetch_optional(&mut *tx).await?.unwrap_or(0);
        let rows: Vec<HistoryRow> = sqlx::query_as(
            "SELECT newest.message_id, message.access_level::smallint AS access_level, association.created_at AS at, message.role, message.audience, \
                    association.entry_kind, author.display_label AS author_label, \
                    author_identity.subject AS author_subject, \
                    left(message.subject, $3) AS subject, left(message.clean_text_body, $3) AS body \
               FROM (SELECT * FROM workflow_history_members WHERE company_id=$1 AND run_id=$2 \
                     ORDER BY ordinal DESC LIMIT $4) AS newest \
               JOIN thread_messages AS association \
                 ON (association.company_id, association.channel_id, association.thread_id, association.message_id) = \
                    ($1, newest.channel_id, newest.thread_id, newest.message_id) \
               JOIN messages AS message \
                 ON (message.company_id, message.id) = ($1, newest.message_id) \
               JOIN principals AS author \
                 ON (author.company_id, author.id) = (message.company_id, message.author_principal_id) \
               LEFT JOIN participant_identities AS author_identity \
                 ON (author_identity.company_id, author_identity.id) = (message.company_id, message.authored_identity_id) \
              ORDER BY newest.ordinal DESC",
        )
        .bind(scope.company.as_uuid())
        .bind(scope.run.as_uuid())
        .bind(MAX_HISTORY_TEXT as i32 + 1)
        .bind(MAX_HISTORY_ITEMS as i64)
        .fetch_all(&mut *tx)
        .await?;
        let highest = rows
            .iter()
            .map(|row| {
                crate::entities::access_level::AccessLevel::try_from(row.access_level)
                    .map_err(|_| invalid())
            })
            .collect::<AppResult<Vec<_>>>()?
            .into_iter()
            .max()
            .unwrap_or(crate::entities::access_level::AccessLevel::PUBLIC);
        let newest = rows
            .into_iter()
            .map(HistoryRow::message)
            .collect::<AppResult<_>>()?;
        super::knowledge::raise_content_level_on(&mut tx, scope.company, scope.run, highest)
            .await?;
        tx.commit().await?;
        Ok(FrozenHistory {
            max_tokens,
            eligible: u64::try_from(eligible).map_err(|_| invalid())?,
            newest,
        })
    }
}
